import { pgTable, text, serial, integer, boolean, date, timestamp, doublePrecision, jsonb, varchar, index } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User model
export const users = pgTable("users", {
  id: varchar("id").primaryKey(), // Using varchar for compatibility with Replit Auth IDs
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  emailVerified: boolean("email_verified").default(false),
  phone: text("phone").notNull(),
  phoneVerified: boolean("phone_verified").default(false),
  fullName: text("full_name").notNull(),
  userType: text("user_type").notNull(), // "user" or "transporter"
  company: text("company"),
  verified: boolean("verified").default(false),
  role: text("role").default("user").notNull(), // "user", "admin", "moderator"
  createdAt: timestamp("created_at").defaultNow(),
});

// Transport providers (shipping companies, truck companies, etc.)
export const transporters = pgTable("transporters", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  transporterType: text("transporter_type").notNull(), // "ship", "truck", "train"
  companyName: text("company_name").notNull(),
  companyDescription: text("company_description"),
  contactEmail: text("contact_email").notNull(),
  contactPhone: text("contact_phone").notNull(),
  address: text("address"),
  verified: boolean("verified").default(false),
});

// Ports and locations
export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // "port", "inland", "rail_station"
  country: text("country").notNull(),
  city: text("city").notNull(),
  coordinates: text("coordinates"), // lat,lng format
});

// Available shipments that transporters offer
export const shipments = pgTable("shipments", {
  id: serial("id").primaryKey(),
  transporterId: integer("transporter_id").notNull().references(() => transporters.id),
  originId: integer("origin_id").notNull().references(() => locations.id),
  destinationId: integer("destination_id").notNull().references(() => locations.id),
  departureDate: date("departure_date").notNull(),
  arrivalDate: date("arrival_date").notNull(),
  transportType: text("transport_type").notNull(), // "sea", "land", "rail", "mixed"
  containerType: text("container_type"), // "20_standard", "40_standard", "20_refrigerated", "40_refrigerated", etc.
  capacity: integer("capacity").notNull(), // how many containers/units available
  price: doublePrecision("price").notNull(),
  insuranceAvailable: boolean("insurance_available").default(true),
  insurancePrice: doublePrecision("insurance_price"),
  active: boolean("active").default(true),
  specialNotes: text("special_notes"),
  isComposite: boolean("is_composite").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Shipment segments for composite/mixed shipments
export const shipmentSegments = pgTable("shipment_segments", {
  id: serial("id").primaryKey(),
  shipmentId: integer("shipment_id").notNull().references(() => shipments.id, { onDelete: "cascade" }),
  originId: integer("origin_id").notNull().references(() => locations.id),
  destinationId: integer("destination_id").notNull().references(() => locations.id),
  departureDate: date("departure_date").notNull(),
  arrivalDate: date("arrival_date").notNull(),
  transportType: text("transport_type").notNull(), // "sea", "land", "rail"
  containerType: text("container_type"), 
  capacity: integer("capacity").notNull(),
  price: doublePrecision("price").notNull(),
  description: text("description"),
  segmentOrder: integer("segment_order").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Bookings made by cargo owners
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  shipmentId: integer("shipment_id").notNull().references(() => shipments.id),
  quantity: integer("quantity").notNull(), // number of containers/units
  cargoType: text("cargo_type").notNull(),
  cargoWeight: doublePrecision("cargo_weight").notNull(),
  cargoDetails: text("cargo_details"),
  withInsurance: boolean("with_insurance").default(false),
  status: text("status").notNull(), // "pending", "confirmed", "in_transit", "delivered", "cancelled"
  totalPrice: doublePrecision("total_price").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Support tickets
export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull(), // "open", "in_progress", "resolved", "closed"
  createdAt: timestamp("created_at").defaultNow(),
});

// Ticket responses
export const ticketResponses = pgTable("ticket_responses", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull().references(() => tickets.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// User documents for verification
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  documentType: text("document_type").notNull(), // "id_card", "company_license", "passport", etc.
  documentPath: text("document_path").notNull(),
  verified: boolean("verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Blog posts
export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt"),
  authorId: varchar("author_id").notNull().references(() => users.id),
  featuredImage: text("featured_image"),
  published: boolean("published").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertTransporterSchema = createInsertSchema(transporters).omit({ id: true });
export const insertLocationSchema = createInsertSchema(locations).omit({ id: true });
export const insertShipmentSchema = createInsertSchema(shipments).omit({ id: true, createdAt: true });
export const insertShipmentSegmentSchema = createInsertSchema(shipmentSegments).omit({ id: true, createdAt: true });
export const insertBookingSchema = createInsertSchema(bookings).omit({ id: true, createdAt: true });
export const insertTicketSchema = createInsertSchema(tickets).omit({ id: true, createdAt: true });
export const insertTicketResponseSchema = createInsertSchema(ticketResponses).omit({ id: true, createdAt: true });
export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, createdAt: true });
export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({ id: true, createdAt: true, updatedAt: true });

// Create types for insertion
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertTransporter = z.infer<typeof insertTransporterSchema>;
export type InsertLocation = z.infer<typeof insertLocationSchema>;
export type InsertShipment = z.infer<typeof insertShipmentSchema>;
export type InsertShipmentSegment = z.infer<typeof insertShipmentSegmentSchema>;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type InsertTicketResponse = z.infer<typeof insertTicketResponseSchema>;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;

// Define relations
export const usersRelations = relations(users, ({ many, one }) => ({
  transporter: one(transporters, {
    fields: [users.id],
    references: [transporters.userId],
  }),
  bookings: many(bookings),
  tickets: many(tickets),
  ticketResponses: many(ticketResponses),
  documents: many(documents),
  blogPosts: many(blogPosts),
}));

export const transportersRelations = relations(transporters, ({ one, many }) => ({
  user: one(users, {
    fields: [transporters.userId],
    references: [users.id],
  }),
  shipments: many(shipments),
}));

export const locationsRelations = relations(locations, ({ many }) => ({
  shipmentsAsOrigin: many(shipments),
  shipmentsAsDestination: many(shipments),
}));

export const shipmentsRelations = relations(shipments, ({ one, many }) => ({
  transporter: one(transporters, {
    fields: [shipments.transporterId],
    references: [transporters.id],
  }),
  origin: one(locations, {
    fields: [shipments.originId],
    references: [locations.id],
  }),
  destination: one(locations, {
    fields: [shipments.destinationId],
    references: [locations.id],
  }),
  bookings: many(bookings),
  segments: many(shipmentSegments),
}));

export const shipmentSegmentsRelations = relations(shipmentSegments, ({ one }) => ({
  shipment: one(shipments, {
    fields: [shipmentSegments.shipmentId],
    references: [shipments.id],
  }),
  origin: one(locations, {
    fields: [shipmentSegments.originId],
    references: [locations.id],
  }),
  destination: one(locations, {
    fields: [shipmentSegments.destinationId],
    references: [locations.id],
  }),
}));

export const bookingsRelations = relations(bookings, ({ one }) => ({
  user: one(users, {
    fields: [bookings.userId],
    references: [users.id],
  }),
  shipment: one(shipments, {
    fields: [bookings.shipmentId],
    references: [shipments.id],
  }),
}));

export const ticketsRelations = relations(tickets, ({ one, many }) => ({
  user: one(users, {
    fields: [tickets.userId],
    references: [users.id],
  }),
  responses: many(ticketResponses),
}));

export const ticketResponsesRelations = relations(ticketResponses, ({ one }) => ({
  ticket: one(tickets, {
    fields: [ticketResponses.ticketId],
    references: [tickets.id],
  }),
  user: one(users, {
    fields: [ticketResponses.userId],
    references: [users.id],
  }),
}));

export const documentsRelations = relations(documents, ({ one }) => ({
  user: one(users, {
    fields: [documents.userId],
    references: [users.id],
  }),
}));

export const blogPostsRelations = relations(blogPosts, ({ one }) => ({
  author: one(users, {
    fields: [blogPosts.authorId],
    references: [users.id],
  }),
}));

// Create types for selection
export type User = typeof users.$inferSelect;
export type Transporter = typeof transporters.$inferSelect;
export type Location = typeof locations.$inferSelect;
export type Shipment = typeof shipments.$inferSelect;
export type ShipmentSegment = typeof shipmentSegments.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type TicketResponse = typeof ticketResponses.$inferSelect;
export type Document = typeof documents.$inferSelect;
export type BlogPost = typeof blogPosts.$inferSelect;

// Define shipping rates table
export const shippingRates = pgTable("shipping_rates", {
  id: serial("id").primaryKey(),
  originId: integer("origin_id").notNull().references(() => locations.id),
  destinationId: integer("destination_id").notNull().references(() => locations.id),
  transportType: text("transport_type").notNull(), // "rail", "sea", "air", "land"
  pricePerKg: doublePrecision("price_per_kg").notNull(),
  distance: integer("distance"),
  transitTime: integer("transit_time"), // in days
  containerType: text("container_type"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Define shipping rates relations
export const shippingRatesRelations = relations(shippingRates, ({ one }) => ({
  origin: one(locations, {
    fields: [shippingRates.originId],
    references: [locations.id],
  }),
  destination: one(locations, {
    fields: [shippingRates.destinationId],
    references: [locations.id],
  }),
}));

// کدهای تایید هویت کاربران
export const verificationCodes = pgTable("verification_codes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  verificationType: text("verification_type").notNull(), // "email", "phone"
  code: text("code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const verificationCodesRelations = relations(verificationCodes, ({ one }) => ({
  user: one(users, {
    fields: [verificationCodes.userId],
    references: [users.id],
  }),
}));

// Define shipping rate schemas
export const insertShippingRateSchema = createInsertSchema(shippingRates).omit({ id: true, createdAt: true, updatedAt: true });
export const insertVerificationCodeSchema = createInsertSchema(verificationCodes).omit({ id: true, createdAt: true });

export type InsertShippingRate = z.infer<typeof insertShippingRateSchema>;
export type InsertVerificationCode = z.infer<typeof insertVerificationCodeSchema>;
export type ShippingRate = typeof shippingRates.$inferSelect;
export type VerificationCode = typeof verificationCodes.$inferSelect;
