import Layout from "@/components/layout/Layout";
import UserRegisterForm from "@/components/auth/UserRegisterForm";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Search, Ship, Package, CreditCard } from "lucide-react";

const UserRegisterPage = () => {
  const { user, isLoading } = useAuth();
  
  // Redirect to dashboard if already logged in
  if (!isLoading && user) {
    return <Redirect to="/dashboard" />;
  }

  return (
    <Layout>
      <div className="py-12 md:py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Left Column: Register Form */}
            <div>
              <h1 className="text-2xl font-bold mb-6 text-primary">ثبت‌نام کاربر (صاحب کالا)</h1>
              <UserRegisterForm />
            </div>
            
            {/* Right Column: Benefits */}
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <h2 className="text-xl font-bold text-primary mb-6">مزایای ثبت‌نام در لاجیستینو</h2>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                    <Search size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">جستجوی آسان حمل و نقل</h3>
                    <p className="text-gray-600 text-sm">
                      به راحتی گزینه‌های حمل و نقل برای محموله خود را جستجو و مقایسه کنید و بهترین قیمت را پیدا کنید.
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                    <Ship size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">دسترسی به شبکه گسترده</h3>
                    <p className="text-gray-600 text-sm">
                      به شبکه‌ای از شرکت‌های معتبر حمل و نقل دریایی، زمینی، ریلی و هوایی دسترسی داشته باشید.
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                    <Package size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">ردیابی محموله‌ها</h3>
                    <p className="text-gray-600 text-sm">
                      وضعیت محموله‌های خود را در هر مرحله از سفر به صورت زنده پیگیری کنید.
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                    <CreditCard size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">پرداخت امن</h3>
                    <p className="text-gray-600 text-sm">
                      با استفاده از سیستم پرداخت امن ما، با خیال راحت هزینه حمل و نقل را پرداخت کنید.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-10 pt-6 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  قبلاً ثبت‌نام کرده‌اید؟{" "}
                  <a href="/auth" className="text-primary hover:text-primary-dark font-semibold">
                    وارد شوید
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default UserRegisterPage;