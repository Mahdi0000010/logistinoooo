import { useState, useEffect, useMemo } from 'react';
import { useLocation } from 'wouter';
import Layout from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ShipmentResults from '@/components/search/ShipmentResults';
import { useQuery } from '@tanstack/react-query';
import { Calendar, Ship, TruckIcon, ArrowLeft, Filter, Sliders, Train, Clock, PackageOpen } from "lucide-react";
import { storageManager, SearchValues } from '@/lib/storage-manager';
import { formatPrice, formatDuration, formatCurrency } from '@/lib/utils';

const SearchResultsPage = () => {
  const [, navigate] = useLocation();
  const [resultView, setResultView] = useState('list');
  const [withInsurance, setWithInsurance] = useState<boolean>(false);
  const [containerCount, setContainerCount] = useState<number>(1);
  
  // Parse query parameters
  const searchParams = new URLSearchParams(window.location.search);
  
  // برای موارد جدید از storage manager استفاده می‌کنیم
  const savedValues = storageManager.getSearchValues();

  // برای هر پارامتر، ابتدا از URL بخوانید و اگر نبود از storageManager استفاده کنید
  const getParamWithFallback = (paramName: string, storedValue: string): string | null => {
    if (searchParams.has(paramName)) {
      return searchParams.get(paramName);
    } else {
      return storedValue || null;
    }
  };
  
  const originId = getParamWithFallback('originId', savedValues.originId);
  const destinationId = getParamWithFallback('destinationId', savedValues.destinationId);
  const departureDate = getParamWithFallback('departureDate', savedValues.departureDate);
  const cargoType = getParamWithFallback('cargoType', savedValues.cargoType);
  
  // برای موارد دیگر نیز از ترکیب URL و storage manager استفاده می‌کنیم
  const transportType = searchParams.get('transportType');
  const containerType = searchParams.get('containerType') || savedValues.containerType;
  const cargoWeight = searchParams.get('cargoWeight') || savedValues.cargoWeight || undefined;
  const preferredTransport = searchParams.get('preferredTransport') || savedValues.preferredTransportType || 'all';
  
  // Fetch locations for origin/destination names
  const { data: locations } = useQuery({
    queryKey: ['/api/locations'],
    queryFn: async () => {
      const res = await fetch('/api/locations');
      return await res.json();
    },
  });
  
  // ذخیره مقادیر استفاده شده با storage manager
  useEffect(() => {
    if (!locations) return; // ابتدا صبر کنیم تا مکان‌ها بارگذاری شوند
    
    const searchValues: Partial<SearchValues> = {};
    
    if (originId) {
      searchValues.originId = originId;
      
      // ذخیره اطلاعات مکان در صورت موجود بودن
      const selectedLocation = locations.find(
        (loc: any) => loc.id.toString() === originId
      );
      
      if (selectedLocation) {
        searchValues.originCountry = selectedLocation.country;
        searchValues.originType = selectedLocation.type;
      }
    }
    
    if (destinationId) {
      searchValues.destinationId = destinationId;
      
      // ذخیره اطلاعات مکان در صورت موجود بودن
      const selectedLocation = locations.find(
        (loc: any) => loc.id.toString() === destinationId
      );
      
      if (selectedLocation) {
        searchValues.destinationCountry = selectedLocation.country;
        searchValues.destinationType = selectedLocation.type;
      }
    }
    
    if (departureDate) searchValues.departureDate = departureDate;
    if (cargoType) searchValues.cargoType = cargoType;
    if (containerType) searchValues.containerType = containerType;
    if (cargoWeight) searchValues.cargoWeight = cargoWeight;
    if (preferredTransport) searchValues.preferredTransportType = preferredTransport;
    
    // تنظیم بیمه و تعداد کانتینر
    if (searchParams.has('withInsurance') && searchParams.get('withInsurance') === 'true') {
      searchValues.withInsurance = true;
      setWithInsurance(true);
    }
    
    if (searchParams.has('containerCount')) {
      const count = parseInt(searchParams.get('containerCount') || '1');
      if (!isNaN(count) && count > 0) {
        searchValues.cargoQuantity = count.toString();
        setContainerCount(count);
      }
    }
    
    // ذخیره همه مقادیر در یک مرحله
    storageManager.updateSearchValues(searchValues);
    
  }, [searchParams, originId, destinationId, departureDate, cargoType, cargoWeight, containerType, preferredTransport, locations]);

  // Get origin and destination names
  const originLocation = locations?.find((loc: any) => loc.id.toString() === originId);
  const destinationLocation = locations?.find((loc: any) => loc.id.toString() === destinationId);
  
  // تابع تبدیل نوع حمل و نقل انگلیسی به فارسی
  const getTransportTypeText = (type: string) => {
    switch (type) {
      case "land": return "حمل و نقل جاده‌ای";
      case "rail": return "حمل و نقل ریلی";
      case "sea": return "حمل و نقل دریایی";
      case "air": return "حمل و نقل هوایی";
      case "mixed": return "حمل و نقل ترکیبی";
      default: return type;
    }
  };
  
  // Fetch regular search results
  const { data: regularSearchResults, isLoading: isLoadingRegular } = useQuery({
    queryKey: [`/api/shipments/search`, originId, destinationId, cargoWeight, containerType],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (originId) params.append('originId', originId);
      if (destinationId) params.append('destinationId', destinationId);
      if (cargoWeight) params.append('cargoWeight', cargoWeight); // وزن محموله را به پارامترهای جستجو اضافه می‌کنیم
      
      // اضافه کردن اطلاعات کانتینر به API
      if (containerType) {
        params.append('containerType', containerType);
      }
      
      if (searchParams.has('containerCount')) {
        params.append('containerCount', searchParams.get('containerCount') || '1');
      }
      
      const requestUrl = `/api/shipments/search?${params.toString()}`;
      console.log('Search Request URL:', requestUrl);
      
      const response = await fetch(requestUrl);
      const data = await response.json();
      console.log('Regular Search Results:', data);
      
      // اگر پاسخ خطا داشت، یک آرایه خالی برگردان
      if (data && data.message && data.message.includes('Failed')) {
        console.warn('Error in search results:', data.message);
        return [];
      }
      
      return data;
    },
    enabled: !!(originId && destinationId),
  });
  
  // تعریف نوع داده برای بنادر
  interface Port {
    name: string;
    country: string;
    distanceFromLocation: number;
    travelTime: number;
  }

  // تعریف مدل برای اطلاعات مسیر زمینی/ریلی/دریایی
  interface RouteSegment {
    distance: number;
    duration: number;
    price?: number;
    priceToman?: number;
    vehicleType?: string;
    vehicleDisplayName?: string;
  }

  // تعریف نوع داده برای گزینه‌های مسیریابی بندری
  interface PortRouteOption {
    port: Port;
    landRoute: RouteSegment;
    railRoute?: RouteSegment & { available: boolean };
    seaRoute?: RouteSegment;
  }

  // تعریف نوع داده برای اطلاعات مسیریابی بنادر
  interface PortRouteInfo {
    originPorts: Port[];
    destinationPorts: Port[];
    directRouteAvailable: boolean;
    // اضافه کردن گزینه‌های مسیریابی از طریق بنادر مختلف
    portRoutes?: PortRouteOption[];
    bestAlternativeRoute?: {
      originPort: Port;
      destinationPort: Port;
      totalDistance: number;
      landDistance1: number;
      seaDistance: number;
      landDistance2: number;
      totalDuration: number;
    };
  }

  // تعریف نوع داده‌های مسیریابی هوشمند برای TypeScript
  interface SmartRoutingResults {
    route: {
      segments: Array<{
        from: string;
        to: string;
        distance: number;
        duration: number;
        transportType: string;
      }>;
      totalDistance: number;
      totalDuration: number;
      transportTypes: string[];
    };
    routeWithShipments: Array<{
      from: string;
      to: string;
      distance: number;
      duration: number;
      transportType: string;
      shipments: Array<{
        id: string;
        price: number | null;
        transportType: string;
        [key: string]: any;
      }> | null;
    }>;
    smartRoutingSummary: {
      totalPrice: number;
      totalDistance: number;
      totalDuration: number;
      estimatedDays: number;
      segments: number;
      transportModes: string[];
    };
    // اطلاعات مربوط به بنادر نزدیک
    portInfo?: PortRouteInfo;
    // المان‌های اضافی موجود در API که نیاز است پشتیبانی شوند
    totalPrice?: number;
    totalDistance?: number;
    totalDuration?: number;
    estimatedDays?: number;
    segments?: number;
    transportModes?: string[];
    shipments?: any[];
  }
  
  // Fetch smart routing results
  const { data: smartRoutingResults, isLoading: isLoadingSmartRouting } = useQuery<SmartRoutingResults, Error, SmartRoutingResults>({
    queryKey: [`/api/smart-routing`, originId, destinationId, preferredTransport, containerType, cargoWeight],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (originId) params.append('fromLocationId', originId);
      if (destinationId) params.append('toLocationId', destinationId);
      
      // اضافه کردن نوع حمل و نقل ترجیحی به درخواست
      if (preferredTransport && preferredTransport !== 'all') {
        params.append('preferredTransport', preferredTransport);
      }
      
      // اضافه کردن تاریخ در صورت موجود بودن
      if (departureDate) {
        params.append('date', departureDate);
      }
      
      // اضافه کردن اطلاعات کانتینر و وزن
      if (containerType) {
        params.append('containerType', containerType);
      }
      
      if (searchParams.has('containerCount')) {
        params.append('containerCount', searchParams.get('containerCount') || '1');
      }
      
      if (cargoWeight) {
        params.append('cargoWeight', cargoWeight);
      }
      
      // اضافه کردن پارامتر نمایش اطلاعات بنادر
      params.append('showPortOptions', 'true');
      
      const requestUrl = `/api/smart-routing?${params.toString()}`;
      console.log('Smart Routing Request URL:', requestUrl);
      
      const response = await fetch(requestUrl);
      if (!response.ok) {
        throw new Error('Failed to fetch smart routing results');
      }
      
      // دریافت داده‌های جستجو
      const data = await response.json();
      console.log('Smart Routing Results:', data);
      
      // بازگرداندن داده‌ها با ساختار SmartRoutingResults مطابق با آنچه در API دریافت می‌کنیم
      return {
        route: data.route || {
          segments: [],
          totalDistance: 0,
          totalDuration: 0,
          transportTypes: []
        },
        routeWithShipments: data.routeWithShipments || [],
        smartRoutingSummary: {
          totalPrice: data.totalPrice || 0,
          totalDistance: data.totalDistance || 0,
          totalDuration: data.totalDuration || 0,
          estimatedDays: data.estimatedDays || 0,
          segments: data.segments || 0,
          transportModes: data.transportModes || []
        },
        // اضافه کردن اطلاعات بنادر نزدیک به خروجی
        portInfo: data.portInfo
      };
    },
    enabled: !!(originId && destinationId),
  });
  
  // استخراج محموله‌ها از نتایج مسیریابی هوشمند
  const smartShipments = useMemo(() => {
    if (!smartRoutingResults || !smartRoutingResults.routeWithShipments) return [];
    
    // استخراج همه سرویس‌های موجود از همه سگمنت‌ها و فیلتر کردن موارد با قیمت null
    return smartRoutingResults.routeWithShipments.flatMap((segment: any) => {
      if (!segment.shipments || segment.shipments.length === 0) return [];
      
      // فیلتر کردن محموله‌های بدون قیمت
      const validShipments = segment.shipments.filter((shipment: any) => shipment.price !== null);
      if (validShipments.length === 0) return [];
      
      // افزودن اطلاعات سگمنت به هر سرویس
      return validShipments.map((shipment: any) => ({
        ...shipment,
        smartRouting: true,
        segmentInfo: {
          from: segment.from,
          to: segment.to,
          distance: segment.distance,
          duration: segment.duration,
          transportType: segment.transportType
        }
      }));
    });
  }, [smartRoutingResults]);
  
  // Combine regular and smart routing results
  const searchResults = useMemo(() => {
    const regular = regularSearchResults || [];
    const smart = smartShipments || [];
    
    // ترکیب نتایج و حذف موارد تکراری با اولویت به نتایج مسیریابی هوشمند
    const allResults = [...smart];
    
    // اضافه کردن نتایج معمولی که در نتایج هوشمند نیستند
    regular.forEach((reg: any) => {
      // بررسی تکراری نبودن با استفاده از شناسه
      if (!allResults.some((sr: any) => sr.id === reg.id)) {
        allResults.push(reg);
      }
    });
    
    return allResults;
  }, [regularSearchResults, smartShipments]);
  
  // Status for combined loading state
  const isLoading = isLoadingRegular || isLoadingSmartRouting;

  const handleBackToSearch = () => {
    navigate('/search');
  };
  
  return (
    <Layout>
      <section className="bg-primary py-6">
        <div className="container mx-auto px-4">
          <div className="text-white mb-4">
            <Button 
              variant="outline" 
              className="bg-white hover:bg-gray-100 text-primary border-none"
              onClick={handleBackToSearch}
            >
              <ArrowLeft className="ml-2" size={16} />
              بازگشت به جستجو
            </Button>
          </div>
          
          <Card className="bg-white shadow-lg">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="col-span-2">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                    <div>
                      <h2 className="text-xl font-bold mb-1">نتایج جستجو</h2>
                      <div className="text-sm text-gray-600">
                        {originLocation?.name && destinationLocation?.name ? (
                          <span>
                            {originLocation.name}، {originLocation.country} به {destinationLocation.name}، {destinationLocation.country}
                          </span>
                        ) : (
                          <span>مورد جستجو</span>
                        )}
                        
                        {departureDate && (
                          <span className="inline-flex items-center mr-4">
                            <Calendar size={14} className="ml-1" />
                            {departureDate}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="mt-3 md:mt-0 flex space-x-2 space-x-reverse">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={resultView === 'list' ? 'bg-gray-100' : ''}
                        onClick={() => setResultView('list')}
                      >
                        <Filter size={16} className="ml-1" />
                        نمایش لیستی
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={resultView === 'compare' ? 'bg-gray-100' : ''}
                        onClick={() => setResultView('compare')}
                      >
                        <Sliders size={16} className="ml-1" />
                        مقایسه
                      </Button>
                    </div>
                  </div>
                  
                  <Separator className="mb-6" />
                  
                  {/* Smart Routing Summary - نمایش خلاصه مسیریابی هوشمند */}
                  {smartRoutingResults?.smartRoutingSummary && (
                    <div className="mb-6 bg-blue-50 border border-blue-100 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <div className="bg-blue-100 rounded-full p-2 ml-3">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                          </svg>
                        </div>
                        <div>
                          <h3 className="font-semibold text-blue-700">مسیریابی هوشمند فعال است</h3>
                          <p className="text-sm text-blue-600">سیستم بهترین مسیر را برای شما پیدا کرده است</p>
                        </div>
                      </div>
                      
                      {/* نمایش هشدار برای مسیرهای ترکیبی دریایی که بخشی از آن بدون قیمت است */}
                      {/* بررسی می‌کنیم آیا داده‌های مسیریابی هوشمند شامل routeWithShipments هستند */}
                      {smartRoutingResults && 'route' in smartRoutingResults && 
                       'routeWithShipments' in smartRoutingResults &&
                       smartRoutingResults.routeWithShipments && 
                       smartRoutingResults.routeWithShipments.some((segment: any) => 
                         segment.transportType === 'sea' && (!segment.shipments || segment.shipments.every((s: any) => s.price === null))
                       ) && (
                        <div className="mt-3 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                          <div className="flex">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-600 mt-0.5 ml-2 flex-shrink-0">
                              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                              <line x1="12" y1="9" x2="12" y2="13"></line>
                              <line x1="12" y1="17" x2="12.01" y2="17"></line>
                            </svg>
                            <div>
                              <p className="text-sm text-yellow-800 font-medium">این مسیر شامل بخش دریایی است</p>
                              <p className="text-xs text-yellow-700 mt-1">برای بخش دریایی این مسیر، قیمت‌های معتبری از شرکت‌های حمل و نقل دریایی موجود نیست. جهت اطلاعات بیشتر به صفحه مسیریابی هوشمند مراجعه کنید.</p>
                              <Button variant="outline" size="sm" className="mt-2 text-xs" onClick={() => navigate(`/smart-routing?from=${originId}&to=${destinationId}`)}>
                                مشاهده جزئیات مسیر
                              </Button>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-3">
                        <div className="bg-white p-3 rounded-md text-center">
                          <div className="text-xs text-gray-500 mb-1">فاصله کل</div>
                          <div className="font-semibold">{smartRoutingResults.smartRoutingSummary.totalDistance.toLocaleString('fa-IR')} کیلومتر</div>
                        </div>
                        <div className="bg-white p-3 rounded-md text-center">
                          <div className="text-xs text-gray-500 mb-1">زمان تقریبی</div>
                          <div className="font-semibold">{formatDuration(smartRoutingResults.smartRoutingSummary.totalDuration)}</div>
                        </div>
                        <div className="bg-white p-3 rounded-md text-center">
                          <div className="text-xs text-gray-500 mb-1">تعداد مسیرها</div>
                          <div className="font-semibold">{smartRoutingResults.smartRoutingSummary.segments} قطعه</div>
                        </div>
                        <div className="bg-white p-3 rounded-md text-center">
                          <div className="text-xs text-gray-500 mb-1">روش حمل و نقل</div>
                          <div className="font-semibold">
                            {smartRoutingResults.smartRoutingSummary.transportModes.map((mode: string) => 
                              mode === 'sea' ? 'دریایی' : mode === 'land' ? 'زمینی' : mode === 'rail' ? 'ریلی' : mode
                            ).join(' + ')}
                          </div>
                        </div>
                        <div className="bg-white p-3 rounded-md text-center">
                          <div className="text-xs text-gray-500 mb-1">هزینه تقریبی</div>
                          <div className="font-semibold text-primary">{formatPrice(smartRoutingResults.smartRoutingSummary.totalPrice)}</div>
                        </div>
                      </div>
                      
                      <div className="text-sm text-blue-600">
                        <span className="font-medium">نکته: </span>
                        گزینه‌های نمایش داده شده شامل بهترین مسیرهای پیشنهادی سیستم هوشمند میباشد.
                      </div>
                    </div>
                  )}
                  
                  {/* نمایش اطلاعات بنادر */}
                  {smartRoutingResults?.portInfo && (
                    <div className="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <div className="bg-blue-100 rounded-full p-2 ml-3">
                          <Ship className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-blue-700">مسیرهای جایگزین از طریق بنادر</h3>
                          <p className="text-sm text-blue-600">برای مسیرهای طولانی یا بین‌المللی، استفاده از بنادر می‌تواند اقتصادی‌تر باشد</p>
                        </div>
                      </div>
                      
                      {/* نمایش مسیرهای متنوع از طریق بنادر مختلف */}
                      {smartRoutingResults.portInfo.portRoutes && smartRoutingResults.portInfo.portRoutes.length > 0 ? (
                        <div className="space-y-6">
                          <div className="border-b pb-4 mb-4">
                            <h4 className="text-sm font-bold text-gray-700 mb-3">گزینه‌های مسیریابی از طریق بنادر:</h4>
                            <div className="space-y-4">
                              {smartRoutingResults.portInfo.portRoutes.map((route, idx) => (
                                <div key={`port-route-${idx}`} className="bg-white p-4 rounded-lg shadow-sm">
                                  <div className="flex items-center mb-3">
                                    <Ship className="h-5 w-5 text-blue-500 ml-2" />
                                    <h5 className="font-bold text-gray-800">{route.port.name}</h5>
                                    <Badge className="mr-2" variant="outline">{route.port.country}</Badge>
                                  </div>
                                  
                                  {/* مسیر زمینی تا بندر */}
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                    <div className="border-r p-3">
                                      <h6 className="text-sm font-semibold mb-2 flex items-center">
                                        <TruckIcon className="h-4 w-4 ml-1 text-gray-600" />
                                        مسیر زمینی تا بندر
                                      </h6>
                                      <div className="text-xs text-gray-600 space-y-1">
                                        <div className="flex justify-between">
                                          <span>فاصله:</span>
                                          <span className="font-medium">{route.landRoute.distance} کیلومتر</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span>مدت زمان:</span>
                                          <span className="font-medium">~{Math.ceil(route.landRoute.duration / 60)} ساعت</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span>وسیله نقلیه:</span>
                                          <span className="font-medium">{route.landRoute.vehicleDisplayName || 'تریلی'}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span>هزینه:</span>
                                          <span className="font-medium text-primary">
                                            {route.landRoute.priceToman ? formatPrice(route.landRoute.priceToman) : 'قیمت موجود نیست'}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                    
                                    {/* مسیر ریلی در صورت وجود */}
                                    {route.railRoute ? (
                                      <div className="border-r p-3">
                                        <h6 className="text-sm font-semibold mb-2 flex items-center">
                                          <Train className="h-4 w-4 ml-1 text-gray-600" />
                                          مسیر ریلی تا بندر
                                        </h6>
                                        <div className="text-xs text-gray-600 space-y-1">
                                          <div className="flex justify-between">
                                            <span>فاصله:</span>
                                            <span className="font-medium">{route.railRoute.distance} کیلومتر</span>
                                          </div>
                                          <div className="flex justify-between">
                                            <span>مدت زمان:</span>
                                            <span className="font-medium">~{Math.ceil(route.railRoute.duration / 60)} ساعت</span>
                                          </div>
                                          <div className="flex justify-between">
                                            <span>هزینه:</span>
                                            <span className="font-medium text-primary">
                                              {route.railRoute.priceToman ? formatPrice(route.railRoute.priceToman) : 'قیمت موجود نیست'}
                                            </span>
                                          </div>
                                        </div>
                                      </div>
                                    ) : (
                                      <div className="p-3 flex items-center justify-center text-gray-500 text-xs">
                                        <div className="text-center">
                                          <Train className="h-5 w-5 mx-auto mb-1 opacity-40" />
                                          <p>مسیر ریلی برای این بندر در دسترس نیست</p>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                  
                                  {/* اطلاعات مسیر دریایی */}
                                  {route.seaRoute && (
                                    <div className="border-t pt-3">
                                      <h6 className="text-sm font-semibold mb-2 flex items-center">
                                        <Ship className="h-4 w-4 ml-1 text-gray-600" />
                                        مسیر دریایی
                                      </h6>
                                      <div className="text-xs text-gray-600 space-y-1">
                                        <div className="flex justify-between">
                                          <span>فاصله دریایی:</span>
                                          <span className="font-medium">{route.seaRoute.distance} کیلومتر</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span>مدت زمان تقریبی:</span>
                                          <span className="font-medium">~{Math.ceil(route.seaRoute.duration / (60 * 24))} روز</span>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                  
                                  {/* دکمه انتخاب این گزینه */}
                                  <div className="mt-3 flex justify-end">
                                    <Button 
                                      size="sm" 
                                      className="text-xs"
                                      variant="outline"
                                      onClick={() => {
                                        // منطق انتخاب مسیر خاص
                                        // می‌توان اطلاعات این مسیر را در state ذخیره کرد
                                        console.log('Selected port route:', route);
                                      }}
                                    >
                                      انتخاب این مسیر
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          {/* بنادر نزدیک به مبدا */}
                          {smartRoutingResults.portInfo.originPorts.length > 0 && (
                            <div>
                              <h4 className="text-sm font-bold text-gray-700 mb-2">نزدیکترین بنادر به مبدا:</h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {smartRoutingResults.portInfo.originPorts.map((port, idx) => (
                                  <div key={`origin-port-${idx}`} className="bg-white p-3 rounded-md shadow-sm">
                                    <div className="flex items-center">
                                      <Ship className="h-4 w-4 text-blue-500 ml-1" />
                                      <p className="font-bold text-sm">{port.name}</p>
                                    </div>
                                    <p className="text-xs text-gray-600 mt-1">{port.country}</p>
                                    <div className="flex justify-between text-xs mt-2">
                                      <span>فاصله: {port.distanceFromLocation} کیلومتر</span>
                                      <span>زمان: ~{Math.floor(port.travelTime / 60)} ساعت</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {/* نمایش مسیر جایگزین بهینه از طریق بنادر */}
                          {smartRoutingResults.portInfo.bestAlternativeRoute && (
                            <div>
                              <h4 className="text-sm font-bold text-gray-700 mb-2">مسیر جایگزین پیشنهادی از طریق بنادر:</h4>
                              <div className="bg-white p-3 rounded-md shadow-sm">
                                <div className="space-y-2">
                                  <div className="flex justify-between">
                                    <div className="flex items-center">
                                      <TruckIcon className="h-4 w-4 text-primary ml-1" />
                                      <span className="text-sm">
                                        {originLocation?.name} به {smartRoutingResults.portInfo.bestAlternativeRoute.originPort.name}
                                      </span>
                                    </div>
                                    <span className="text-xs">{smartRoutingResults.portInfo.bestAlternativeRoute.landDistance1} کیلومتر</span>
                                  </div>
                                  
                                  <div className="flex justify-between">
                                    <div className="flex items-center">
                                      <Ship className="h-4 w-4 text-blue-500 ml-1" />
                                      <span className="text-sm">
                                        {smartRoutingResults.portInfo.bestAlternativeRoute.originPort.name} به {smartRoutingResults.portInfo.bestAlternativeRoute.destinationPort.name}
                                      </span>
                                    </div>
                                    <span className="text-xs">{smartRoutingResults.portInfo.bestAlternativeRoute.seaDistance} کیلومتر</span>
                                  </div>
                                  
                                  <div className="flex justify-between">
                                    <div className="flex items-center">
                                      <TruckIcon className="h-4 w-4 text-primary ml-1" />
                                      <span className="text-sm">
                                        {smartRoutingResults.portInfo.bestAlternativeRoute.destinationPort.name} به {destinationLocation?.name}
                                      </span>
                                    </div>
                                    <span className="text-xs">{smartRoutingResults.portInfo.bestAlternativeRoute.landDistance2} کیلومتر</span>
                                  </div>
                                  
                                  <Separator />
                                  
                                  <div className="flex justify-between font-bold">
                                    <span>مجموع</span>
                                    <div>
                                      <span>{smartRoutingResults.portInfo.bestAlternativeRoute.totalDistance} کیلومتر</span>
                                      <span className="mx-2">•</span>
                                      <span>~{Math.floor(smartRoutingResults.portInfo.bestAlternativeRoute.totalDuration / 60)} ساعت</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              
                              <div className="mt-3">
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="w-full"
                                  onClick={() => navigate(`/smart-routing?from=${originId}&to=${destinationId}`)}
                                >
                                  مشاهده جزئیات بیشتر و قیمت‌ها
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="text-sm text-gray-600">
                          برای این مسیر، اطلاعات بنادر در دسترس نیست.
                        </p>
                      )}
                    </div>
                  )}
                  
                  {/* نمایش جزئیات مسیر */}
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h3 className="text-xl font-bold">جزئیات مسیر</h3>
                      {smartRoutingResults?.smartRoutingSummary && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => navigate(`/smart-routing?from=${originId}&to=${destinationId}`)}
                        >
                          مشاهده همه گزینه‌های مسیر
                        </Button>
                      )}
                    </div>
                    
                    {isLoading ? (
                      <div className="space-y-4">
                        {[1, 2, 3].map((i) => (
                          <Card key={`skeleton-${i}`} className="bg-gray-50 animate-pulse">
                            <CardContent className="p-6">
                              <div className="h-20"></div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : !smartRoutingResults || !smartRoutingResults.routeWithShipments || smartRoutingResults.routeWithShipments.length === 0 ? (
                      <Card className="bg-yellow-50">
                        <CardContent className="p-6">
                          <div className="text-center py-8">
                            <p className="text-yellow-700 font-medium mb-2">برای این مسیر هیچ حمل و نقلی پیدا نشد</p>
                            <p className="text-sm text-yellow-600">لطفاً مبدا یا مقصد دیگری را انتخاب کنید یا با پشتیبانی تماس بگیرید.</p>
                          </div>
                        </CardContent>
                      </Card>
                    ) : (
                      <div className="space-y-4">
                        {/* فیلتر کردن سگمنت‌های با قیمت معتبر */}
                        {smartRoutingResults.routeWithShipments.filter(segment => 
                          segment.shipments && segment.shipments.some(shipment => 
                            (shipment.transportPrice && shipment.transportPrice.priceToman !== null) ||
                            shipment.calculatedPrice || 
                            shipment.price !== null
                          )
                        ).map((segment, index) => {
                          // یافتن محموله‌های معتبر برای هر سگمنت
                          const validShipments = segment.shipments ? 
                            segment.shipments.filter(shipment => 
                              (shipment.transportPrice && shipment.transportPrice.priceToman !== null) ||
                              shipment.calculatedPrice || 
                              shipment.price !== null
                            ) : [];
                            
                          // تعیین آیکون مناسب برای هر نوع حمل و نقل
                          const getTransportIcon = (type: string) => {
                            switch (type) {
                              case "land":
                                return <TruckIcon className="h-5 w-5 text-primary" />;
                              case "rail":
                                return <Train className="h-5 w-5 text-primary" />;
                              case "sea":
                                return <Ship className="h-5 w-5 text-primary" />;
                              default:
                                return <TruckIcon className="h-5 w-5 text-primary" />;
                            }
                          };

                          // تعیین متن فارسی برای هر نوع حمل و نقل
                          const getTransportTypeText = (type: string) => {
                            switch (type) {
                              case "land": return "حمل و نقل جاده‌ای";
                              case "rail": return "حمل و نقل ریلی";
                              case "sea": return "حمل و نقل دریایی";
                              case "air": return "حمل و نقل هوایی";
                              case "mixed": return "حمل و نقل ترکیبی";
                              default: return type;
                            }
                          };
                          
                          return (
                            <Card key={`segment-${index}`} className="overflow-hidden">
                              <div className="flex items-center p-4 border-b bg-gray-50">
                                <div className="bg-primary/10 p-2 rounded-full mr-4">
                                  {getTransportIcon(segment.transportType)}
                                </div>
                                <div>
                                  <h3 className="font-bold text-lg">{segment.from} به {segment.to}</h3>
                                  <div className="flex items-center text-sm text-gray-600 mt-1">
                                    <Badge variant="outline" className="mr-2">
                                      {getTransportTypeText(segment.transportType)}
                                    </Badge>
                                    <span className="mx-2">•</span>
                                    <span>{segment.distance} کیلومتر</span>
                                    <span className="mx-2">•</span>
                                    <span>
                                      {Math.floor(segment.duration / 60)} ساعت و {segment.duration % 60} دقیقه
                                    </span>
                                  </div>
                                </div>
                              </div>
                              
                              <div className="p-4">
                                {validShipments.length > 0 ? (
                                  <div className="space-y-4">
                                    {validShipments.map((shipment, shipmentIndex) => {
                                      // تعیین قیمت نمایشی با اولویت و محاسبه مجدد برای قیمت‌های نادرست
                                      let displayPrice;
                                      if (shipment.transportPrice?.priceToman) {
                                        // قیمت از سرویس دهنده حمل و نقل (قابل اعتماد)
                                        displayPrice = shipment.transportPrice.priceToman;
                                      } else {
                                        // محاسبه مجدد قیمت بر اساس نرخ‌های استاندارد و فاصله
                                        const distance = segment.distance; // فاصله به کیلومتر
                                        let weight = cargoWeight ? parseInt(cargoWeight) : 8000; // وزن به کیلوگرم
                                        weight = Math.max(weight, 8000); // حداقل 8 تن
                                        
                                        // تبدیل به تن
                                        const weightInTons = weight / 1000;
                                        
                                        // تعیین نرخ بر اساس نوع وسیله
                                        let ratePerTonKm = 10000; // پیش‌فرض کامیون: 10000 ریال/تن-کیلومتر
                                        let vehicleCapacity = 18000; // ظرفیت پیش‌فرض (کامیون جفت): 18 تن
                                        
                                        if (shipment.vehicleType) {
                                          if (shipment.vehicleType === 'land_trailer' || shipment.vehicleType.includes('trailer')) {
                                            ratePerTonKm = 9500; // تریلی: 9500 ریال/تن-کیلومتر
                                            vehicleCapacity = 24000; // ظرفیت تریلی: 24 تن
                                          } else if (shipment.vehicleType === 'land_truck' || shipment.vehicleType.includes('truck')) {
                                            ratePerTonKm = 10000; // کامیون: 10000 ریال/تن-کیلومتر
                                            vehicleCapacity = 18000; // ظرفیت کامیون جفت: 18 تن
                                          } else if (shipment.vehicleType === 'land_small_truck' || shipment.vehicleType.includes('small')) {
                                            ratePerTonKm = 13500; // خاور: 13500 ریال/تن-کیلومتر
                                            vehicleCapacity = 9000; // ظرفیت خاور: 9 تن
                                          } else if (shipment.vehicleType === 'land_pickup' || shipment.vehicleType.includes('pickup')) {
                                            ratePerTonKm = 17500; // نیسان: 17500 ریال/تن-کیلومتر
                                            vehicleCapacity = 5000; // ظرفیت نیسان: 5 تن
                                          } else if (shipment.vehicleType === 'land_van' || shipment.vehicleType.includes('van')) {
                                            ratePerTonKm = 20000; // وانت: 20000 ریال/تن-کیلومتر
                                            vehicleCapacity = 2000; // ظرفیت وانت: 2 تن
                                          }
                                        }
                                        
                                        // برای کانتینر، از ظرفیت کانتینر استفاده می‌شود
                                        const effectiveWeight = shipment.containerType && shipment.containerType.includes('container') ? 
                                          30000 / 1000 : // برای کانتینر 30 تن استفاده می‌شود
                                          vehicleCapacity / 1000; // برای سایر موارد، از ظرفیت ماکزیمم وسیله نقلیه استفاده می‌شود
                                        
                                        // محاسبه قیمت به ریال
                                        const priceRial = distance * effectiveWeight * ratePerTonKm;
                                        
                                        // تبدیل به تومان و گرد کردن به نزدیکترین مضرب 10,000 تومان (مطابق با سرور)
                                        displayPrice = Math.round(priceRial / 10 / 10000) * 10000;
                                        
                                        // برای حمل و نقل ریلی، محاسبه بر اساس فرمول مخصوص
                                        if (segment.transportType === 'rail') {
                                          const railRatePerKgKm = 34; // نرخ ریلی: 34 ریال/کیلوگرم-کیلومتر
                                        
                                          // برای محاسبه قیمت ریلی، حداقل 100 کیلوگرم استفاده می‌شود
                                          let effectiveRailWeight = 100; // حداقل 100 کیلوگرم
                                          
                                          // برای کانتینر، از ظرفیت کانتینر استفاده می‌شود
                                          if (shipment.containerType && shipment.containerType.includes('container')) {
                                            effectiveRailWeight = 30000; // برای کانتینر 30 تن استفاده می‌شود
                                          } else if (weight > 20000) {
                                            effectiveRailWeight = weight; // اگر وزن واقعی بیشتر از 20 تن است، از آن استفاده می‌شود
                                          }
                                          
                                          const railPriceRial = distance * effectiveRailWeight * railRatePerKgKm;
                                          // تبدیل به تومان و گرد کردن به نزدیکترین مضرب 10,000 تومان (مطابق با سرور)
                                          displayPrice = Math.round(railPriceRial / 10 / 10000) * 10000;
                                        }
                                        
                                        // برای حمل و نقل دریایی، قیمت از شرکت‌های حمل و نقل
                                        if (segment.transportType === 'sea') {
                                          displayPrice = null;
                                        }
                                      }
                                        
                                      return (
                                        <div key={`shipment-${shipmentIndex}`} className="bg-gray-50 p-4 rounded-lg">
                                          <div className="flex justify-between items-start">
                                            <div>
                                              <div className="font-medium mb-2">
                                                {shipment.transporterName || "گزینه حمل و نقل"} 
                                                {shipment.containerType && (
                                                  <span className="text-gray-600 text-sm mr-2">
                                                    ({shipment.containerType})
                                                  </span>
                                                )}
                                              </div>
                                              
                                              <div className="grid grid-cols-2 gap-3 text-sm">
                                                <div className="flex items-center">
                                                  <Clock className="h-4 w-4 ml-1 text-gray-500" />
                                                  <span>
                                                    {Math.floor(segment.duration / 60)} ساعت و {segment.duration % 60} دقیقه
                                                  </span>
                                                </div>
                                                
                                                <div className="flex items-center">
                                                  <Calendar className="h-4 w-4 ml-1 text-gray-500" />
                                                  <span>
                                                    {shipment.departureDate ? (
                                                      typeof shipment.departureDate === 'string' ? 
                                                        shipment.departureDate.substring(0, 10) : 
                                                        'تاریخ نامشخص'
                                                    ) : 'تاریخ نامشخص'}
                                                  </span>
                                                </div>
                                                
                                                <div className="flex items-center">
                                                  <PackageOpen className="h-4 w-4 ml-1 text-gray-500" />
                                                  <span>ظرفیت: {shipment.capacity || "نامشخص"}</span>
                                                </div>
                                                
                                                {shipment.vehicleType && (
                                                  <div className="flex items-center">
                                                    <TruckIcon className="h-4 w-4 ml-1 text-gray-500" />
                                                    <span>نوع وسیله: {shipment.vehicleType}</span>
                                                  </div>
                                                )}
                                              </div>
                                            </div>
                                            
                                            <div className="text-left">
                                              <div className="font-bold text-xl text-primary">
                                                {displayPrice !== null ? 
                                                  formatPrice(displayPrice) : 
                                                  "قیمت موجود نیست"}
                                              </div>
                                              {shipment.vehicleType && (
                                                <div className="text-xs text-gray-600 mt-1">
                                                  {shipment.vehicleType.includes('truck') || shipment.vehicleType === 'van' ? 
                                                    `انتخاب ${
                                                      shipment.vehicleType === 'land_trailer' ? 'تریلی' : 
                                                      shipment.vehicleType === 'land_truck' ? 'کامیون' : 
                                                      shipment.vehicleType === 'land_small_truck' ? 'خاور' : 
                                                      shipment.vehicleType === 'van' ? 'وانت' : 
                                                      shipment.containerType || 'کامیون'
                                                    } مناسب برای وزن ${cargoWeight || '۷۰۰۰'} کیلوگرم` : ''
                                                  }
                                                </div>
                                              )}
                                              
                                              <Button 
                                                size="sm" 
                                                className="mt-2"
                                                onClick={() => navigate(`/shipment/${shipment.id}`)}
                                              >
                                                انتخاب و ادامه
                                              </Button>
                                            </div>
                                          </div>
                                          
                                          {shipment.transportPrice?.formulaDescription && (
                                            <div className="mt-3 text-xs text-gray-500 bg-gray-100 p-2 rounded">
                                              <span className="font-medium">شیوه محاسبه قیمت: </span>
                                              {shipment.transportPrice.formulaDescription}
                                            </div>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                ) : (
                                  <div className="text-center py-4 text-gray-500">
                                    <p>برای این بخش از مسیر، هیچ گزینه حمل و نقلی با قیمت معتبر یافت نشد.</p>
                                  </div>
                                )}
                              </div>
                            </Card>
                          );
                        })}
                        
                        {/* نمایش اطلاعات سگمنت‌های بدون قیمت معتبر */}
                        {smartRoutingResults.routeWithShipments.filter(segment => 
                          !segment.shipments || segment.shipments.every(shipment => 
                            (!shipment.transportPrice || shipment.transportPrice.priceToman === null) &&
                            !shipment.calculatedPrice && 
                            shipment.price === null
                          )
                        ).length > 0 && (
                          <Card className="bg-yellow-50 border border-yellow-200">
                            <CardContent className="p-4">
                              <h4 className="font-bold text-yellow-800 mb-2">بخش‌های مسیر بدون قیمت</h4>
                              <div className="space-y-3">
                                {smartRoutingResults.routeWithShipments.filter(segment => 
                                  !segment.shipments || segment.shipments.every(shipment => 
                                    (!shipment.transportPrice || shipment.transportPrice.priceToman === null) &&
                                    !shipment.calculatedPrice && 
                                    shipment.price === null
                                  )
                                ).map((segment, idx) => (
                                  <div key={`missing-${idx}`} className="flex items-center p-3 bg-white rounded-md">
                                    {segment.transportType === 'sea' ? (
                                      <Ship className="h-5 w-5 text-blue-500 ml-2" />
                                    ) : segment.transportType === 'rail' ? (
                                      <Train className="h-5 w-5 text-indigo-500 ml-2" />
                                    ) : (
                                      <TruckIcon className="h-5 w-5 text-gray-500 ml-2" />
                                    )}
                                    <div>
                                      <p className="font-medium">{segment.from} به {segment.to}</p>
                                      <p className="text-xs text-gray-600">
                                        {segment.distance} کیلومتر • {
                                          segment.transportType === "land" ? "حمل و نقل جاده‌ای" :
                                          segment.transportType === "rail" ? "حمل و نقل ریلی" :
                                          segment.transportType === "sea" ? "حمل و نقل دریایی" :
                                          segment.transportType === "air" ? "حمل و نقل هوایی" :
                                          segment.transportType === "mixed" ? "حمل و نقل ترکیبی" :
                                          segment.transportType
                                        }
                                      </p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                              <p className="text-sm text-yellow-700 mt-3">
                                برای بخش‌های فوق، هیچ حمل و نقلی با قیمت مشخص در سیستم ثبت نشده است.
                              </p>
                              <Button 
                                variant="outline" 
                                className="mt-3 w-full"
                                onClick={() => {
                                  // ارسال به فرم استعلام قیمت برای مسیرهای دریایی
                                  const hasMissingSeaPrices = smartRoutingResults.routeWithShipments.some(segment => 
                                    segment.transportType === 'sea' && 
                                    (!segment.shipments || segment.shipments.every(s => 
                                      (!s.transportPrice || s.transportPrice.priceToman === null) &&
                                      !s.calculatedPrice && 
                                      s.price === null
                                    ))
                                  );
                                  
                                  if (hasMissingSeaPrices) {
                                    navigate(`/support?subject=استعلام قیمت حمل دریایی&message=درخواست استعلام قیمت برای مسیر ${originLocation?.name} به ${destinationLocation?.name}`);
                                  } else {
                                    navigate('/support');
                                  }
                                }}
                              >
                                استعلام قیمت
                              </Button>
                            </CardContent>
                          </Card>
                        )}
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Sidebar Filters */}
                <div className="lg:border-r lg:pr-6">
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <h3 className="font-semibold mb-3">فیلترهای پیشرفته</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      از فیلترهای زیر برای محدود کردن نتایج استفاده کنید
                    </p>
                    
                    {/* Price Range Filter will be implemented here */}
                    
                    {/* Departure Date Filter will be implemented here */}
                    
                    {/* Container Type Filter will be implemented here */}
                    
                    {/* Transporter Rating Filter will be implemented here */}
                  </div>
                  
                  <div className="bg-primary/5 rounded-lg p-4">
                    <h3 className="font-semibold mb-3">نیاز به مشاوره دارید؟</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      کارشناسان ما آماده پاسخگویی به سوالات شما هستند
                    </p>
                    <Button className="w-full">
                      تماس با پشتیبانی
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </Layout>
  );
};

export default SearchResultsPage;