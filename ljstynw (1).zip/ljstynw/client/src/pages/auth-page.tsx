import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import Layout from "@/components/layout/Layout";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { LogIn, Monitor, Loader2, User, Mail, Phone, Lock, Briefcase, Package } from "lucide-react";
import { SiGoogle, SiApple, SiGithub } from "react-icons/si";

// اسکیما برای ورود
const loginSchema = z.object({
  identifier: z.string().min(1, "وارد کردن نام کاربری، ایمیل یا شماره تلفن الزامی است"),
  password: z.string().min(6, "رمز عبور باید حداقل ۶ کاراکتر باشد"),
});

// اسکیما برای ثبت نام
const registerSchema = z.object({
  username: z.string().min(3, "نام کاربری باید حداقل ۳ کاراکتر باشد"),
  email: z.string().email("ایمیل نامعتبر است"),
  phone: z.string().min(10, "شماره تلفن باید حداقل ۱۰ رقم باشد"),
  password: z.string().min(6, "رمز عبور باید حداقل ۶ کاراکتر باشد"),
  fullName: z.string().min(3, "نام و نام خانوادگی باید حداقل ۳ کاراکتر باشد"),
  userType: z.enum(["user", "transporter"], {
    required_error: "لطفا نوع کاربری خود را انتخاب کنید",
  }),
});

type LoginForm = z.infer<typeof loginSchema>;
type RegisterForm = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, isLoading, login, loginWithCredentials, registerWithCredentials } = useAuth();
  const [authTab, setAuthTab] = useState<string>("login");

  // فرم ورود
  const loginForm = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      identifier: "",
      password: "",
    },
  });

  // فرم ثبت نام
  const registerForm = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      phone: "",
      password: "",
      fullName: "",
      userType: "user", // پیش‌فرض برای صاحب کالا
    },
  });

  // اگر در حال بارگذاری هستیم، چیزی نشان می‌دهیم
  if (isLoading) {
    return (
      <Layout>
        <div className="container py-12">
          <div className="flex justify-center items-center min-h-[50vh]">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        </div>
      </Layout>
    );
  }

  // اگر کاربر وارد شده است، به صفحه اصلی هدایت می‌کنیم
  if (user) {
    return <Redirect to="/" />;
  }

  // تابع ورود با Replit
  const handleLogin = () => {
    login();
  };

  // تابع ورود با استفاده از فرم دستی
  const onLoginSubmit = (data: LoginForm) => {
    // تشخیص نوع شناسه ورود (ایمیل، شماره تلفن یا نام کاربری)
    const identifier = data.identifier;
    
    const loginData = {
      password: data.password
    };

    if (identifier.includes('@')) {
      // ورود با ایمیل
      loginWithCredentials.mutate({ 
        loginType: 'email',
        email: identifier, 
        password: data.password 
      });
    } else if (/^\d+$/.test(identifier)) {
      // ورود با شماره تلفن
      loginWithCredentials.mutate({ 
        loginType: 'phone',
        phone: identifier, 
        password: data.password 
      });
    } else {
      // ورود با نام کاربری
      loginWithCredentials.mutate({ 
        loginType: 'username',
        username: identifier, 
        password: data.password 
      });
    }
  };

  // تابع ثبت نام
  const onRegisterSubmit = (data: RegisterForm) => {
    registerWithCredentials.mutate({
      ...data,
      // استفاده از نوع کاربر انتخاب شده در فرم
    });
  };

  return (
    <Layout>
      <div className="container py-12">
        <div className="grid md:grid-cols-2 gap-8 w-full max-w-6xl mx-auto">
          {/* بخش فرم ورود/ثبت نام */}
          <div>
            <h1 className="text-3xl font-bold mb-6">ورود به سیستم</h1>
            <Tabs defaultValue="login" value={authTab} onValueChange={setAuthTab}>
              <TabsList className="grid grid-cols-2 w-full mb-6">
                <TabsTrigger value="login">ورود</TabsTrigger>
                <TabsTrigger value="register">ثبت نام</TabsTrigger>
              </TabsList>
              <TabsContent value="login">
                <Card>
                  <CardHeader>
                    <CardTitle>ورود به حساب کاربری</CardTitle>
                    <CardDescription>
                      با استفاده از حساب کاربری خود، به سیستم وارد شوید.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* فرم ورود */}
                    <Form {...loginForm}>
                      <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                        <FormField
                          control={loginForm.control}
                          name="identifier"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>نام کاربری، ایمیل یا شماره تلفن</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input placeholder="نام کاربری، ایمیل یا شماره تلفن" {...field} />
                                  <User className="absolute top-2.5 left-3 h-5 w-5 text-muted-foreground" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={loginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>رمز عبور</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input type="password" placeholder="رمز عبور" {...field} />
                                  <Lock className="absolute top-2.5 left-3 h-5 w-5 text-muted-foreground" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={loginWithCredentials.isPending}
                        >
                          {loginWithCredentials.isPending ? (
                            <>
                              <Loader2 className="ml-2 h-5 w-5 animate-spin" />
                              در حال ورود...
                            </>
                          ) : (
                            "ورود به سیستم"
                          )}
                        </Button>
                      </form>
                    </Form>
                    
                    <div className="relative my-4">
                      <div className="absolute inset-0 flex items-center">
                        <Separator className="w-full" />
                      </div>
                      <div className="relative flex justify-center">
                        <span className="bg-background px-2 text-muted-foreground text-sm">
                          یا ورود با
                        </span>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-3">
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={handleLogin}
                      >
                        <SiGoogle className="h-5 w-5 text-[#DB4437]" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={handleLogin}
                      >
                        <SiApple className="h-5 w-5 text-[#000000]" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={handleLogin}
                      >
                        <SiGithub className="h-5 w-5 text-[#333333]" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={handleLogin}
                      >
                        <Monitor className="h-5 w-5 text-[#00A4EF]" />
                      </Button>
                    </div>
                    
                    <p className="text-center text-muted-foreground text-sm mt-3">
                      هنوز حساب کاربری ندارید؟{" "}
                      <Button 
                        variant="link" 
                        className="p-0 h-auto text-primary" 
                        onClick={() => setAuthTab("register")}
                      >
                        ثبت نام کنید
                      </Button>
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="register">
                <Card>
                  <CardHeader>
                    <CardTitle>ایجاد حساب کاربری</CardTitle>
                    <CardDescription>
                      با ایجاد حساب کاربری، از امکانات سامانه لجیستینو بهره‌مند شوید.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* فرم ثبت نام */}
                    <Form {...registerForm}>
                      <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                        <FormField
                          control={registerForm.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>نام و نام خانوادگی</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input placeholder="نام و نام خانوادگی" {...field} />
                                  <User className="absolute top-2.5 left-3 h-5 w-5 text-muted-foreground" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>نام کاربری</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input placeholder="نام کاربری" {...field} />
                                  <User className="absolute top-2.5 left-3 h-5 w-5 text-muted-foreground" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                نام کاربری شما برای ورود به سیستم استفاده می‌شود
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={registerForm.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>ایمیل</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input type="email" placeholder="ایمیل" {...field} />
                                    <Mail className="absolute top-2.5 left-3 h-5 w-5 text-muted-foreground" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={registerForm.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>شماره تلفن</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <Input type="tel" placeholder="09..." {...field} />
                                    <Phone className="absolute top-2.5 left-3 h-5 w-5 text-muted-foreground" />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={registerForm.control}
                          name="userType"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormLabel>نوع کاربری</FormLabel>
                              <FormControl>
                                <RadioGroup
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                  className="flex flex-col space-y-1"
                                >
                                  <FormItem className="flex items-center space-x-3 space-x-reverse">
                                    <FormControl>
                                      <RadioGroupItem value="user" />
                                    </FormControl>
                                    <FormLabel className="flex items-center cursor-pointer">
                                      <Package className="ml-2 h-5 w-5 text-muted-foreground" />
                                      صاحب کالا
                                      <span className="text-xs text-muted-foreground mr-2">(شخصی که قصد حمل بار دارد)</span>
                                    </FormLabel>
                                  </FormItem>
                                  <FormItem className="flex items-center space-x-3 space-x-reverse">
                                    <FormControl>
                                      <RadioGroupItem value="transporter" />
                                    </FormControl>
                                    <FormLabel className="flex items-center cursor-pointer">
                                      <Briefcase className="ml-2 h-5 w-5 text-muted-foreground" />
                                      شرکت حمل و نقل
                                      <span className="text-xs text-muted-foreground mr-2">(ارائه دهنده خدمات حمل و نقل)</span>
                                    </FormLabel>
                                  </FormItem>
                                </RadioGroup>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>رمز عبور</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input type="password" placeholder="رمز عبور" {...field} />
                                  <Lock className="absolute top-2.5 left-3 h-5 w-5 text-muted-foreground" />
                                </div>
                              </FormControl>
                              <FormDescription>
                                رمز عبور باید حداقل ۶ کاراکتر باشد
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={registerWithCredentials.isPending}
                        >
                          {registerWithCredentials.isPending ? (
                            <>
                              <Loader2 className="ml-2 h-5 w-5 animate-spin" />
                              در حال ثبت نام...
                            </>
                          ) : (
                            "ثبت نام"
                          )}
                        </Button>
                      </form>
                    </Form>
                    
                    <div className="relative my-4">
                      <div className="absolute inset-0 flex items-center">
                        <Separator className="w-full" />
                      </div>
                      <div className="relative flex justify-center">
                        <span className="bg-background px-2 text-muted-foreground text-sm">
                          یا ثبت نام با
                        </span>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-3">
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={handleLogin}
                      >
                        <SiGoogle className="h-5 w-5 text-[#DB4437]" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={handleLogin}
                      >
                        <SiApple className="h-5 w-5 text-[#000000]" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={handleLogin}
                      >
                        <SiGithub className="h-5 w-5 text-[#333333]" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={handleLogin}
                      >
                        <Monitor className="h-5 w-5 text-[#00A4EF]" />
                      </Button>
                    </div>
                    
                    <p className="text-center text-muted-foreground text-sm mt-3">
                      قبلاً حساب کاربری ایجاد کرده‌اید؟{" "}
                      <Button 
                        variant="link" 
                        className="p-0 h-auto text-primary" 
                        onClick={() => setAuthTab("login")}
                      >
                        وارد شوید
                      </Button>
                    </p>

                    <p className="text-center text-muted-foreground text-sm mt-3">
                      با ثبت نام، <a href="/terms" className="text-primary hover:underline">شرایط استفاده</a> را می‌پذیرید.
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* بخش تبلیغات و معرفی سایت */}
          <div className="bg-primary text-white rounded-lg p-8 flex flex-col justify-center">
            <h2 className="text-3xl font-bold mb-4">به لجیستینو خوش آمدید</h2>
            <p className="text-lg mb-6">
              سامانه هوشمند حمل و نقل بار در سطح بین‌المللی با پشتیبانی از روش‌های متنوع حمل و نقل
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="bg-primary-700 rounded-lg p-4">
                <h3 className="font-bold mb-2">حمل و نقل چندوجهی</h3>
                <p>بهترین ترکیب زمینی، ریلی و دریایی برای حمل بار شما</p>
              </div>
              <div className="bg-primary-700 rounded-lg p-4">
                <h3 className="font-bold mb-2">قیمت‌گذاری شفاف</h3>
                <p>محاسبه دقیق هزینه حمل بار بر اساس وزن، مسافت و نوع حمل</p>
              </div>
              <div className="bg-primary-700 rounded-lg p-4">
                <h3 className="font-bold mb-2">پیگیری آنلاین</h3>
                <p>مشاهده لحظه‌ای وضعیت حمل بار شما در مسیر</p>
              </div>
              <div className="bg-primary-700 rounded-lg p-4">
                <h3 className="font-bold mb-2">پشتیبانی ۲۴ ساعته</h3>
                <p>پاسخگویی به سوالات و مشکلات در هر زمان</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}