import React, { useEffect, useState } from "react";
import { Redirect, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import BlogPostForm from "@/components/admin/BlogPostForm";
import TicketManagement from "@/components/admin/TicketManagement";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

// UI Components
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

// Icons
import {
  LayoutDashboard,
  Users,
  Truck,
  Package,
  CalendarCheck,
  FileText,
  LifeBuoy,
  FileStack,
  Map,
  LogOut,
  Settings,
  Bell,
  Search,
  Plus,
  MoreHorizontal,
  Check,
  X,
  Edit,
  Trash,
  Eye,
  FileEdit,
  ShieldCheck,
  PanelLeft,
  Loader2
} from "lucide-react";

// Types
import { 
  User as UserType, 
  Transporter, 
  Shipment, 
  Booking, 
  BlogPost, 
  Location, 
  Document, 
  Ticket 
} from "@shared/schema";

// Dashboard stats interface
interface DashboardStats {
  totalUsers: number;
  verifiedUsers: number;
  totalTransporters: number;
  verifiedTransporters: number;
  totalShipments: number;
  activeShipments: number;
  totalBookings: number;
  pendingBookings: number;
  openTickets: number;
}

const AdminDashboardPage: React.FC = () => {
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  // Extract tab from URL if present
  const getTabFromUrl = () => {
    const params = new URLSearchParams(window.location.search);
    return params.get("tab") || "overview";
  };

  // Set default tab
  const [activeTab, setActiveTab] = useState(getTabFromUrl());

  // Update URL when tab changes
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    searchParams.set("tab", activeTab);
    setLocation(`/admin?${searchParams.toString()}`, { replace: true });
  }, [activeTab, setLocation]);

  // Check if user is admin
  if (!user || user.role !== "admin") {
    return <Redirect to="/admin-login" />;
  }

  // Define menu items
  const menuItems = [
    { id: "overview", label: "داشبورد", icon: <LayoutDashboard size={18} /> },
    { id: "users", label: "کاربران", icon: <Users size={18} /> },
    { id: "transporters", label: "شرکت‌های حمل و نقل", icon: <Truck size={18} /> },
    { id: "shipments", label: "محموله‌ها", icon: <Package size={18} /> },
    { id: "bookings", label: "رزروها", icon: <CalendarCheck size={18} /> },
    { id: "blog", label: "وبلاگ", icon: <FileText size={18} /> },
    { id: "tickets", label: "تیکت‌های پشتیبانی", icon: <LifeBuoy size={18} /> },
    { id: "documents", label: "مدیریت اسناد", icon: <FileStack size={18} /> },
    { id: "locations", label: "مدیریت مکان‌ها", icon: <Map size={18} /> },
    { id: "settings", label: "تنظیمات", icon: <Settings size={18} /> },
  ];

  // Fetch overview dashboard stats
  const { 
    data: stats, 
    isLoading: isLoadingStats 
  } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/stats"],
    enabled: activeTab === "overview",
  });

  // Fetch users data
  const { 
    data: users, 
    isLoading: isLoadingUsers 
  } = useQuery<UserType[]>({
    queryKey: ["/api/admin/users"],
    enabled: activeTab === "users",
  });

  // Fetch transporters data
  const { 
    data: transporters, 
    isLoading: isLoadingTransporters,
    refetch: refetchTransporters
  } = useQuery<Transporter[]>({
    queryKey: ["/api/admin/transporters"],
    enabled: activeTab === "transporters",
  });

  // Fetch blog posts
  const {
    data: blogPosts,
    isLoading: isLoadingBlogPosts,
    refetch: refetchBlogPosts
  } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog"],
    enabled: activeTab === "blog",
  });

  // Handle verification of transporters
  const verifyTransporter = async (transporterId: number, verified: boolean) => {
    try {
      await apiRequest("PATCH", `/api/admin/transporters/${transporterId}/verify`, { verified });
      toast({
        title: "عملیات موفق",
        description: `شرکت حمل و نقل با موفقیت ${verified ? 'تایید' : 'رد'} شد.`,
      });
      refetchTransporters();
    } catch (error) {
      toast({
        title: "خطا",
        description: "عملیات با خطا مواجه شد. لطفا دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  };

  // Handle blog post deletion
  const deleteBlogPost = async (postId: number) => {
    try {
      await apiRequest("DELETE", `/api/blog/${postId}`);
      toast({
        title: "عملیات موفق",
        description: "مطلب با موفقیت حذف شد.",
      });
      refetchBlogPosts();
    } catch (error) {
      toast({
        title: "خطا",
        description: "حذف مطلب با خطا مواجه شد. لطفا دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  };

  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden">
      {/* Admin Sidebar */}
      <div 
        className={`bg-primary text-white transition-all duration-300 ${
          sidebarOpen ? "w-64" : "w-20"
        } flex flex-col h-full shadow-lg`}
      >
        {/* Sidebar Header */}
        <div className="p-4 flex items-center justify-between border-b border-primary-dark">
          <div className="flex items-center">
            <ShieldCheck className="h-8 w-8 text-white" />
            {sidebarOpen && (
              <span className="text-xl font-bold mr-2">پنل مدیریت</span>
            )}
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-white hover:bg-primary-dark rounded-full"
          >
            <PanelLeft className="h-5 w-5" />
          </Button>
        </div>

        {/* Admin Info */}
        <div className="p-4 border-b border-primary-dark">
          {sidebarOpen ? (
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-primary-dark flex items-center justify-center">
                <span className="text-white font-bold">{user.username.substring(0, 1)}</span>
              </div>
              <div className="mr-3">
                <div className="text-sm font-medium">{user.fullName || user.username}</div>
                <div className="text-xs text-gray-200">{user.email}</div>
              </div>
            </div>
          ) : (
            <div className="flex justify-center">
              <div className="w-10 h-10 rounded-full bg-primary-dark flex items-center justify-center">
                <span className="text-white font-bold">{user.username.substring(0, 1)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-2">
          <ul className="space-y-1">
            {menuItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center px-3 py-2 rounded-md transition-colors ${
                    activeTab === item.id 
                      ? "bg-white/20 text-white" 
                      : "text-gray-200 hover:bg-white/10"
                  }`}
                >
                  <span className="flex-shrink-0">{item.icon}</span>
                  {sidebarOpen && <span className="mr-3 text-sm">{item.label}</span>}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-primary-dark">
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center px-3 py-2 rounded-md text-white bg-primary-dark hover:bg-white hover:text-primary transition-colors"
          >
            <LogOut size={18} />
            {sidebarOpen && <span className="mr-2 text-sm">خروج از سیستم</span>}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm px-6 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-4 space-x-reverse">
            <h1 className="text-xl font-bold text-gray-800">
              {menuItems.find(item => item.id === activeTab)?.label || "داشبورد مدیریت"}
            </h1>
          </div>
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="relative">
              <button className="p-2 text-gray-500 rounded-full hover:bg-gray-100">
                <Bell size={20} />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
            </div>
            <div>
              <button className="p-2 text-gray-500 rounded-full hover:bg-gray-100">
                <Search size={20} />
              </button>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-6 bg-gray-50">
          {/* Overview Dashboard */}
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">کل کاربران</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {isLoadingStats ? <Loader2 className="h-6 w-6 animate-spin" /> : stats?.totalUsers || 0}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {isLoadingStats ? "" : `${stats?.verifiedUsers || 0} کاربر تایید شده`}
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">شرکت‌های حمل و نقل</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {isLoadingStats ? <Loader2 className="h-6 w-6 animate-spin" /> : stats?.totalTransporters || 0}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {isLoadingStats ? "" : `${stats?.verifiedTransporters || 0} شرکت تایید شده`}
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">محموله‌ها</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {isLoadingStats ? <Loader2 className="h-6 w-6 animate-spin" /> : stats?.totalShipments || 0}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {isLoadingStats ? "" : `${stats?.activeShipments || 0} محموله فعال`}
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-gray-500">رزروها</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {isLoadingStats ? <Loader2 className="h-6 w-6 animate-spin" /> : stats?.totalBookings || 0}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {isLoadingStats ? "" : `${stats?.pendingBookings || 0} رزرو در انتظار تایید`}
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activities */}
              <Card>
                <CardHeader>
                  <CardTitle>فعالیت‌های اخیر</CardTitle>
                  <CardDescription>آخرین فعالیت‌های سیستم</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center border-b pb-2">
                      <div className="bg-blue-100 p-2 rounded-full">
                        <Users size={16} className="text-blue-600" />
                      </div>
                      <div className="mr-3">
                        <p className="text-sm">یک کاربر جدید ثبت نام کرد</p>
                        <p className="text-xs text-gray-500">10 دقیقه پیش</p>
                      </div>
                    </div>
                    <div className="flex items-center border-b pb-2">
                      <div className="bg-green-100 p-2 rounded-full">
                        <Truck size={16} className="text-green-600" />
                      </div>
                      <div className="mr-3">
                        <p className="text-sm">یک شرکت حمل و نقل تایید شد</p>
                        <p className="text-xs text-gray-500">30 دقیقه پیش</p>
                      </div>
                    </div>
                    <div className="flex items-center border-b pb-2">
                      <div className="bg-yellow-100 p-2 rounded-full">
                        <Package size={16} className="text-yellow-600" />
                      </div>
                      <div className="mr-3">
                        <p className="text-sm">یک محموله جدید ثبت شد</p>
                        <p className="text-xs text-gray-500">1 ساعت پیش</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="bg-red-100 p-2 rounded-full">
                        <LifeBuoy size={16} className="text-red-600" />
                      </div>
                      <div className="mr-3">
                        <p className="text-sm">یک تیکت جدید ثبت شد</p>
                        <p className="text-xs text-gray-500">2 ساعت پیش</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Users Tab */}
          {activeTab === "users" && (
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>مدیریت کاربران</CardTitle>
                    <CardDescription>لیست تمام کاربران سیستم</CardDescription>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 ml-1" />
                    افزودن کاربر
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingUsers ? (
                  <div className="flex justify-center p-4">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <Table>
                    <TableCaption>لیست کاربران ثبت‌نام شده در سیستم</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>شناسه</TableHead>
                        <TableHead>نام کاربری</TableHead>
                        <TableHead>نام کامل</TableHead>
                        <TableHead>ایمیل</TableHead>
                        <TableHead>نوع کاربر</TableHead>
                        <TableHead>وضعیت</TableHead>
                        <TableHead>عملیات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users && users.length > 0 ? (
                        users.map(user => (
                          <TableRow key={user.id}>
                            <TableCell>{user.id}</TableCell>
                            <TableCell>{user.username}</TableCell>
                            <TableCell>{user.fullName}</TableCell>
                            <TableCell dir="ltr">{user.email}</TableCell>
                            <TableCell>
                              {user.userType === "cargo_owner" ? "صاحب کالا" : "شرکت حمل و نقل"}
                            </TableCell>
                            <TableCell>
                              <Badge variant={user.verified ? "success" : "secondary"}>
                                {user.verified ? "تایید شده" : "در انتظار تایید"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-1 space-x-reverse">
                                <Button variant="ghost" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center">هیچ کاربری یافت نشد.</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          )}

          {/* Transporters Tab */}
          {activeTab === "transporters" && (
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>مدیریت شرکت‌های حمل و نقل</CardTitle>
                    <CardDescription>تایید و مدیریت شرکت‌های حمل و نقل</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingTransporters ? (
                  <div className="flex justify-center p-4">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <Table>
                    <TableCaption>لیست شرکت‌های حمل و نقل</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>شناسه</TableHead>
                        <TableHead>نام شرکت</TableHead>
                        <TableHead>نوع حمل و نقل</TableHead>
                        <TableHead>ایمیل</TableHead>
                        <TableHead>تلفن</TableHead>
                        <TableHead>وضعیت</TableHead>
                        <TableHead>عملیات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transporters && transporters.length > 0 ? (
                        transporters.map(transporter => (
                          <TableRow key={transporter.id}>
                            <TableCell>{transporter.id}</TableCell>
                            <TableCell>{transporter.companyName}</TableCell>
                            <TableCell>
                              {transporter.transporterType === "sea" && "دریایی"}
                              {transporter.transporterType === "road" && "جاده‌ای"}
                              {transporter.transporterType === "rail" && "ریلی"}
                              {transporter.transporterType === "air" && "هوایی"}
                            </TableCell>
                            <TableCell dir="ltr">{transporter.contactEmail}</TableCell>
                            <TableCell dir="ltr">{transporter.contactPhone}</TableCell>
                            <TableCell>
                              <Badge variant={transporter.verified ? "success" : "secondary"}>
                                {transporter.verified ? "تایید شده" : "در انتظار تایید"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-1 space-x-reverse">
                                {!transporter.verified ? (
                                  <Button 
                                    variant="success" 
                                    size="sm"
                                    onClick={() => verifyTransporter(transporter.id, true)}
                                    className="bg-green-500 hover:bg-green-600 text-white"
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                ) : (
                                  <Button 
                                    variant="destructive" 
                                    size="sm"
                                    onClick={() => verifyTransporter(transporter.id, false)}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                )}
                                <Button variant="ghost" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center">هیچ شرکت حمل و نقلی یافت نشد.</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          )}

          {/* Blog Posts Tab */}
          {activeTab === "blog" && (
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>مدیریت وبلاگ</CardTitle>
                    <CardDescription>نوشته‌های وبلاگی را مدیریت کنید</CardDescription>
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="flex items-center gap-1">
                        <Plus className="h-4 w-4" />
                        <span>نوشته جدید</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>افزودن نوشته جدید</DialogTitle>
                        <DialogDescription>
                          مشخصات نوشته وبلاگی جدید را وارد کنید.
                        </DialogDescription>
                      </DialogHeader>
                      {/* Blog Post Form */}
                      <BlogPostForm onSuccess={() => {
                        refetchBlogPosts();
                        // Close dialog after successful submission
                        document.querySelector('[role="dialog"]')?.parentElement?.querySelector('button')?.click();
                      }} />
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingBlogPosts ? (
                  <div className="flex justify-center p-4">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <Table>
                    <TableCaption>لیست نوشته‌های وبلاگ</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>شناسه</TableHead>
                        <TableHead>عنوان</TableHead>
                        <TableHead>نامک</TableHead>
                        <TableHead>نویسنده</TableHead>
                        <TableHead>تاریخ</TableHead>
                        <TableHead>وضعیت</TableHead>
                        <TableHead>عملیات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {blogPosts && blogPosts.length > 0 ? (
                        blogPosts.map(post => (
                          <TableRow key={post.id}>
                            <TableCell>{post.id}</TableCell>
                            <TableCell className="font-medium">{post.title}</TableCell>
                            <TableCell dir="ltr">{post.slug}</TableCell>
                            <TableCell>{post.authorId}</TableCell>
                            <TableCell dir="ltr">
                              {post.createdAt && new Date(post.createdAt).toLocaleDateString('fa-IR')}
                            </TableCell>
                            <TableCell>
                              <Badge variant={post.published ? "success" : "secondary"}>
                                {post.published ? "منتشر شده" : "پیش‌نویس"}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-1 space-x-reverse">
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      <Eye className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[700px]">
                                    <DialogHeader>
                                      <DialogTitle>نمایش مطلب</DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-4 mt-4">
                                      <h2 className="text-2xl font-bold">{post.title}</h2>
                                      <div className="flex items-center text-sm text-gray-500">
                                        <span>{post.createdAt && new Date(post.createdAt).toLocaleDateString('fa-IR')}</span>
                                        <span className="mx-2">|</span>
                                        <Badge variant={post.published ? "success" : "secondary"}>
                                          {post.published ? "منتشر شده" : "پیش‌نویس"}
                                        </Badge>
                                      </div>
                                      <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: post.content }} />
                                    </div>
                                  </DialogContent>
                                </Dialog>
                                
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      <FileEdit className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                                    <DialogHeader>
                                      <DialogTitle>ویرایش مطلب</DialogTitle>
                                    </DialogHeader>
                                    <BlogPostForm
                                      initialData={post}
                                      onSuccess={() => {
                                        refetchBlogPosts();
                                        // Close dialog after successful submission
                                        document.querySelector('[role="dialog"]')?.parentElement?.querySelector('button')?.click();
                                      }}
                                    />
                                  </DialogContent>
                                </Dialog>
                                
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      <Trash className="h-4 w-4 text-red-500" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>حذف مطلب</DialogTitle>
                                      <DialogDescription>
                                        آیا از حذف این مطلب اطمینان دارید؟ این عمل غیرقابل بازگشت است.
                                      </DialogDescription>
                                    </DialogHeader>
                                    <DialogFooter className="mt-4">
                                      <Button
                                        variant="destructive"
                                        onClick={() => {
                                          deleteBlogPost(post.id);
                                          document.querySelector('[role="dialog"]')?.parentElement?.querySelector('button')?.click();
                                        }}
                                      >
                                        بله، حذف شود
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center">هیچ نوشته‌ای یافت نشد.</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          )}

          {/* Ticket Management Tab */}
          {activeTab === "tickets" && (
            <TicketManagement />
          )}
          
          {/* Placeholder for other tabs */}
          {(activeTab === "shipments" || 
            activeTab === "bookings" || 
            activeTab === "documents" || 
            activeTab === "locations" || 
            activeTab === "settings") && (
            <Card className="shadow-sm h-full">
              <CardHeader>
                <CardTitle>
                  {menuItems.find(item => item.id === activeTab)?.label || ""}
                </CardTitle>
                <CardDescription>
                  این بخش در حال توسعه است...
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="text-center">
                  <div className="mb-4 text-primary">
                    {menuItems.find(item => item.id === activeTab)?.icon && React.cloneElement(
                      menuItems.find(item => item.id === activeTab)?.icon as React.ReactElement, 
                      { size: 48 }
                    )}
                  </div>
                  <h3 className="text-lg font-medium mb-2">این بخش در حال تکمیل است</h3>
                  <p className="text-gray-500 max-w-md">
                    در حال حاضر این قسمت از پنل مدیریت در حال توسعه است و به زودی تکمیل خواهد شد.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminDashboardPage;