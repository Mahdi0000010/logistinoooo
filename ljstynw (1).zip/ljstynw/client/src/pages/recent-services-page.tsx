import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useLocation } from "wouter";
import { Ship, Truck, Train, Package, Filter, ArrowUpDown, CalendarRange, MapPin, Search, Loader2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Layout from "@/components/layout/Layout";

type ShipmentService = {
  id: number;
  transporterId: number;
  transporterName: string;
  transporterCompanyName: string;
  transporterDescription: string;
  originId: number;
  originName: string;
  originCountry: string;
  destinationId: number;
  destinationName: string;
  destinationCountry: string;
  departureDate: string;
  arrivalDate: string;
  transportType: "sea" | "land" | "rail" | "mixed";
  containerType: string;
  capacity: number;
  price: number;
  insuranceAvailable: boolean;
  insurancePrice: number;
  specialNotes?: string;

};

// تابع برای تبدیل تاریخ به فرمت فارسی
const formatPersianDate = (dateString: string): string => {
  try {
    return new Date(dateString).toLocaleDateString('fa-IR');
  } catch (e) {
    return 'تاریخ نامشخص';
  }
};

// تابع برای دریافت متن نوع حمل و نقل
const getTransportTypeText = (type: string): string => {
  switch (type) {
    case 'sea':
      return 'حمل و نقل دریایی';
    case 'land':
      return 'حمل و نقل زمینی';
    case 'rail':
      return 'حمل و نقل ریلی';
    case 'mixed':
      return 'حمل و نقل ترکیبی';
    default:
      return 'نامشخص';
  }
};

// تابع برای دریافت متن نوع کانتینر
const getContainerTypeText = (containerType: string): string => {
  if (!containerType) return 'نامشخص';
  
  if (containerType.includes('20_standard') || containerType.includes('کانتینر 20 فوت')) {
    return 'کانتینر 20 فوت استاندارد';
  } else if (containerType.includes('40_standard') || containerType.includes('کانتینر 40 فوت')) {
    return 'کانتینر 40 فوت استاندارد';
  } else if (containerType.includes('40_high_cube') || containerType.includes('کانتینر 40 فوت های کیوب')) {
    return 'کانتینر 40 فوت های کیوب';
  } else if (containerType.includes('20_refrigerated') || containerType.includes('کانتینر یخچالی 20 فوت')) {
    return 'کانتینر یخچالی 20 فوت';
  } else if (containerType.includes('40_refrigerated') || containerType.includes('کانتینر یخچالی 40 فوت')) {
    return 'کانتینر یخچالی 40 فوت';
  }
  
  return containerType;
};

// کامپوننت نمایش آیکون نوع حمل و نقل
const TransportIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'sea':
      return <Ship className="ml-1" size={16} />;
    case 'land':
      return <Truck className="ml-1" size={16} />;
    case 'rail':
      return <Train className="ml-1" size={16} />;
    default:
      return <Package className="ml-1" size={16} />;
  }
};

export default function RecentServicesPage() {
  const [location, setLocation] = useLocation();
  const [filterType, setFilterType] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<string>("date");

  // دریافت سرویس‌های یک ماه اخیر
  const { data, isLoading, error } = useQuery<ShipmentService[]>({
    queryKey: ['/api/recent-shipments'],
    queryFn: async () => {
      const res = await fetch('/api/recent-shipments');
      if (!res.ok) {
        throw new Error('خطا در دریافت سرویس‌های حمل و نقل');
      }
      return res.json();
    },
  });

  // فیلتر کردن داده‌ها بر اساس نوع حمل و نقل
  const filteredData = data ? data.filter(service => {
    if (!filterType) return true;
    return service.transportType === filterType;
  }) : [];

  // مرتب‌سازی داده‌ها
  const sortedData = [...filteredData].sort((a, b) => {
    if (sortBy === "date") {
      return new Date(b.departureDate).getTime() - new Date(a.departureDate).getTime();
    } else if (sortBy === "price") {
      return a.price - b.price;
    } else if (sortBy === "capacity") {
      return b.capacity - a.capacity;
    }
    return 0;
  });

  // ریدایرکت به صفحه جزئیات سرویس
  const handleViewDetails = (id: number) => {
    setLocation(`/shipment/${id}`);
  };

  return (
    <Layout>
      <div className="py-8 px-4 md:px-8">
        <div className="container mx-auto max-w-7xl">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">سرویس‌های حمل و نقل یک ماه اخیر</h1>
            <p className="text-gray-600 mt-2">
              این صفحه سرویس‌های حمل و نقلی که در یک ماه گذشته توسط شرکت‌های حمل و نقل در سیستم ثبت شده‌اند را نمایش می‌دهد
            </p>
          </div>

          {/* بخش فیلترها و مرتب‌سازی */}
          <div className="mb-6 flex flex-wrap gap-3 items-center justify-between bg-gray-50 p-4 rounded-lg">
            <div className="flex flex-wrap gap-3">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Filter size={16} />
                    {filterType ? `فیلتر: ${getTransportTypeText(filterType)}` : 'فیلتر نوع حمل و نقل'}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setFilterType(null)}>
                    <Package className="ml-2" size={16} />
                    <span>همه سرویس‌ها</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilterType('land')}>
                    <Truck className="ml-2" size={16} />
                    <span>حمل و نقل زمینی</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilterType('rail')}>
                    <Train className="ml-2" size={16} />
                    <span>حمل و نقل ریلی</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilterType('sea')}>
                    <Ship className="ml-2" size={16} />
                    <span>حمل و نقل دریایی</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <ArrowUpDown size={16} />
                    {sortBy === 'date' ? 'مرتب‌سازی: جدیدترین' : 
                     sortBy === 'price' ? 'مرتب‌سازی: ارزان‌ترین' : 
                     'مرتب‌سازی: بیشترین ظرفیت'}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setSortBy('date')}>
                    <CalendarRange className="ml-2" size={16} />
                    <span>جدیدترین سرویس‌ها</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortBy('price')}>
                    <span className="ml-2">₹</span>
                    <span>ارزان‌ترین سرویس‌ها</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortBy('capacity')}>
                    <Package className="ml-2" size={16} />
                    <span>بیشترین ظرفیت</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="flex items-center">
              <Button 
                variant="ghost"
                className="text-primary"
                onClick={() => setLocation('/search')}
              >
                <Search size={18} className="ml-2" />
                جستجوی پیشرفته
              </Button>
            </div>
          </div>

          {/* نمایش نتایج */}
          {isLoading ? (
            <div className="w-full py-12 flex justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <div className="w-full py-12 text-center text-red-500">
              خطا در بارگذاری سرویس‌ها. لطفاً مجدداً تلاش کنید.
            </div>
          ) : sortedData.length === 0 ? (
            <div className="w-full py-12 text-center text-muted-foreground bg-gray-50 rounded-lg">
              <Package className="mx-auto h-12 w-12 text-gray-300 mb-4" />
              <h2 className="text-xl font-bold text-gray-700 mb-2">هیچ سرویسی یافت نشد</h2>
              <p className="text-gray-500">
                {filterType 
                  ? `هیچ سرویس ${getTransportTypeText(filterType)} در یک ماه اخیر یافت نشد.` 
                  : 'هیچ سرویس حمل و نقلی در یک ماه اخیر یافت نشد.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedData.map((service) => (
                <Card key={service.id} className="overflow-hidden hover:shadow-xl transition-all duration-300 border-slate-200 group">
                  <CardHeader className="bg-gradient-to-r from-primary/90 to-primary-dark/90 text-white p-6 pb-16 relative overflow-hidden">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.1),transparent)] z-0"></div>
                    <div className="absolute inset-0 bg-black/25 z-5"></div>
                    <div className="relative z-10">
                      <div className="flex justify-between items-center mb-4">
                        <Badge variant="secondary" className="bg-white/20 text-white hover:bg-white/30 flex items-center gap-1 text-sm font-semibold">
                          <TransportIcon type={service.transportType} />
                          {getTransportTypeText(service.transportType)}
                        </Badge>
                        <Badge variant="secondary" className="bg-white/20 text-white hover:bg-white/30 text-sm font-semibold">
                          {formatPersianDate(service.departureDate)}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl font-extrabold text-yellow-300 drop-shadow-sm">
                        {service.originName} به {service.destinationName}
                      </CardTitle>
                      <CardDescription className="text-white text-md font-semibold mt-1">
                        {service.transporterCompanyName || service.transporterName}
                      </CardDescription>
                    </div>
                  </CardHeader>

                  <div className="relative -mt-10 mx-5 bg-white rounded-lg shadow-lg p-5 z-10 border border-slate-100">
                    <div className="flex items-center justify-between mb-5">
                      <div className="flex items-center bg-slate-50 px-3 py-2 rounded-md">
                        <Package className="h-5 w-5 text-primary ml-2" />
                        <span className="text-md font-semibold text-slate-800">
                          {getContainerTypeText(service.containerType)}
                        </span>
                      </div>
                      <Badge variant="outline" className="rounded-md text-md font-semibold py-2 px-3 bg-slate-50 border-slate-200">
                        ظرفیت: {service.capacity / 1000} تن
                      </Badge>
                    </div>

                    {service.specialNotes && (
                      <div className="text-md text-slate-700 mb-5 p-3 bg-yellow-50 border-r-4 border-yellow-400 rounded">
                        <span className="ml-2 font-bold">توضیحات:</span>
                        {service.specialNotes}
                      </div>
                    )}

                    <div className="flex flex-col items-center bg-primary/5 rounded-lg p-4 mb-4 mt-4 border border-primary/10">
                      <span className="text-md font-bold text-slate-700 mb-2">قیمت حمل و نقل</span>
                      <span className="text-3xl font-extrabold text-primary">
                        {service.price.toLocaleString('fa-IR')}
                        <span className="text-sm font-medium mr-2">تومان</span>
                      </span>
                      {service.insuranceAvailable && (
                        <div className="flex items-center gap-2 text-sm text-green-600 mt-3 bg-green-50 px-3 py-1 rounded-full">
                          <span className="font-semibold">امکان بیمه محموله</span>
                          <span className="font-bold">{service.insurancePrice.toLocaleString('fa-IR')} تومان</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <CardFooter className="flex justify-between pt-2 px-6 pb-6">
                    <Button 
                      variant="outline" 
                      onClick={() => handleViewDetails(service.id)}
                      className="transition-all hover:bg-slate-50 text-md font-semibold px-4 py-2"
                    >
                      مشاهده جزئیات
                    </Button>

                    <Button 
                      variant="default"
                      className="bg-primary hover:bg-primary-dark transition-all hover:scale-105 text-md font-semibold px-4 py-2"
                    >
                      ثبت سفارش
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}

          {/* نمایش تعداد نتایج */}
          {sortedData.length > 0 && (
            <div className="mt-8 text-center text-gray-600">
              {sortedData.length} سرویس حمل و نقل یافت شد
            </div>
          )}

          {/* دکمه بازگشت به صفحه اصلی */}
          <div className="mt-12 text-center">
            <Button
              variant="outline"
              className="px-6 py-2 text-md border border-gray-300"
              onClick={() => setLocation('/')}
            >
              بازگشت به صفحه اصلی
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}