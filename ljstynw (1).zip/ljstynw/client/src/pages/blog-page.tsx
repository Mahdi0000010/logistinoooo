import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout/Layout";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { CalendarDays, User, ChevronLeft, Search } from "lucide-react";
import { BlogPost } from "@shared/schema";

// Mock blog posts for development
const mockBlogPosts: Partial<BlogPost>[] = [
  {
    id: 1,
    title: "راهنمای جامع حمل و نقل بین‌المللی کالا",
    slug: "international-shipping-guide",
    excerpt: "در این مقاله با انواع روش‌های حمل و نقل بین‌المللی کالا و مزایا و معایب هر کدام آشنا می‌شوید...",
    content: "محتوای کامل مقاله...",
    featuredImage: "https://images.unsplash.com/photo-1578575437130-527eed3abbec?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    published: true,
    createdAt: new Date("2023-10-02"),
    authorId: 1
  },
  {
    id: 2,
    title: "چگونه هزینه‌های حمل و نقل خود را کاهش دهیم؟",
    slug: "reduce-shipping-costs",
    excerpt: "در این مقاله با راهکارهای عملی برای کاهش هزینه‌های حمل و نقل محموله‌های صادراتی آشنا می‌شوید...",
    content: "محتوای کامل مقاله...",
    featuredImage: "https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    published: true,
    createdAt: new Date("2023-09-27"),
    authorId: 1
  },
  {
    id: 3,
    title: "مقررات جدید گمرکی برای صادرات و واردات",
    slug: "new-customs-regulations",
    excerpt: "در این مقاله با آخرین تغییرات قوانین گمرکی کشور در زمینه صادرات و واردات کالا آشنا می‌شوید...",
    content: "محتوای کامل مقاله...",
    featuredImage: "https://images.unsplash.com/photo-1593672715438-d88a1cf7a48f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    published: true,
    createdAt: new Date("2023-09-19"),
    authorId: 1
  },
  {
    id: 4,
    title: "بهترین روش‌های بسته‌بندی کالا برای حمل و نقل دریایی",
    slug: "sea-shipping-packaging",
    excerpt: "در این مقاله با اصول و روش‌های بسته‌بندی محموله‌ها برای حمل و نقل دریایی آشنا می‌شوید...",
    content: "محتوای کامل مقاله...",
    featuredImage: "https://images.unsplash.com/photo-1584735010373-33e128075ba2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    published: true,
    createdAt: new Date("2023-09-10"),
    authorId: 1
  },
  {
    id: 5,
    title: "آشنایی با انکوترمز (Incoterms) و کاربرد آن در تجارت بین‌المللی",
    slug: "incoterms-guide",
    excerpt: "در این مقاله با قوانین انکوترمز و نحوه استفاده از آن‌ها در قراردادهای تجاری بین‌المللی آشنا می‌شوید...",
    content: "محتوای کامل مقاله...",
    featuredImage: "https://images.unsplash.com/photo-1625225233840-695456021cde?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    published: true,
    createdAt: new Date("2023-08-25"),
    authorId: 1
  },
  {
    id: 6,
    title: "مقایسه حمل و نقل دریایی، زمینی و هوایی: کدام برای شما مناسب است؟",
    slug: "transport-comparison",
    excerpt: "در این مقاله مزایا و معایب روش‌های مختلف حمل و نقل را بررسی می‌کنیم تا بهترین گزینه را انتخاب کنید...",
    content: "محتوای کامل مقاله...",
    featuredImage: "https://images.unsplash.com/photo-1471194402529-8e0f5a675de6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    published: true,
    createdAt: new Date("2023-08-15"),
    authorId: 1
  }
];

// Function to format date in Persian
const formatDate = (date: Date) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
  return date.toLocaleDateString('fa-IR', options);
};

const BlogPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredPosts, setFilteredPosts] = useState<Partial<BlogPost>[]>([]);
  
  // In a real app, this would fetch from API
  const { data: posts, isLoading } = useQuery({
    queryKey: ['/api/blog'],
    queryFn: async () => {
      // Simulating API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      return mockBlogPosts;
    }
  });
  
  useEffect(() => {
    if (posts) {
      if (searchQuery.trim() === "") {
        setFilteredPosts(posts);
      } else {
        const filtered = posts.filter(post => 
          post.title?.toLowerCase().includes(searchQuery.toLowerCase()) || 
          post.excerpt?.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredPosts(filtered);
      }
    }
  }, [posts, searchQuery]);

  return (
    <Layout>
      <div className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          {/* Blog Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-6">وبلاگ لجستینو</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              آخرین اخبار و مقالات تخصصی در حوزه حمل و نقل و لجستیک
            </p>
            {/* Search Bar */}
            <div className="max-w-md mx-auto mt-8 relative">
              <Search className="absolute top-3 right-3 text-gray-400" size={20} />
              <Input
                type="text"
                placeholder="جستجو در مقالات..."
                className="pr-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Blog Posts */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {isLoading ? (
              // Loading skeleton
              Array(6).fill(0).map((_, index) => (
                <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                  <Skeleton className="h-48 w-full" />
                  <div className="p-5">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <div className="flex items-center text-gray-500 text-sm mb-2">
                      <Skeleton className="h-4 w-24 mr-2" />
                      <Skeleton className="h-4 w-24 ml-2" />
                    </div>
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-3/4 mb-4" />
                    <Skeleton className="h-6 w-28" />
                  </div>
                </div>
              ))
            ) : filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <div key={post.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition">
                  <div className="h-48 overflow-hidden">
                    <div className="w-full h-full bg-gray-300 flex items-center justify-center">
                      <svg className="w-12 h-12 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                      </svg>
                    </div>
                  </div>
                  <div className="p-5">
                    <div className="flex items-center text-gray-500 text-sm mb-2">
                      <div className="flex items-center ml-3">
                        <CalendarDays className="ml-1" size={14} />
                        <span>{formatDate(new Date(post.createdAt!))}</span>
                      </div>
                      <div className="flex items-center">
                        <User className="ml-1" size={14} />
                        <span>ادمین</span>
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold mb-2 line-clamp-2 hover:text-primary transition">
                      <a href={`/blog/${post.slug}`}>{post.title}</a>
                    </h3>
                    <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt}</p>
                    <a href={`/blog/${post.slug}`} className="text-primary font-medium hover:text-primary-dark flex items-center w-fit">
                      ادامه مطلب 
                      <ChevronLeft className="mr-1" size={16} />
                    </a>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-1 md:col-span-2 lg:col-span-3 text-center py-10">
                <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="text-xl font-medium text-gray-700 mb-2">هیچ مقاله‌ای یافت نشد</h3>
                <p className="text-gray-500">
                  مقاله‌ای با عبارت جستجو شده پیدا نشد. لطفاً با کلمات کلیدی دیگری جستجو کنید.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default BlogPage;
