import React, { useEffect, useState } from "react";
import Layout from "@/components/layout/Layout";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/dashboard/Sidebar";
import CargoOwnerDashboard from "@/components/dashboard/CargoOwnerDashboard";
import TransporterDashboard from "@/components/dashboard/TransporterDashboard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation, Route, Switch } from "wouter";

const DashboardPage = () => {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [location] = useLocation();
  
  // Extract tab from URL if present
  const getTabFromUrl = () => {
    const params = new URLSearchParams(window.location.search);
    return params.get("tab") || "overview";
  };

  // Set default tab
  const [activeTab, setActiveTab] = useState(getTabFromUrl());

  // Update URL when tab changes
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    searchParams.set("tab", activeTab);
    setLocation(`/dashboard?${searchParams.toString()}`, { replace: true });
  }, [activeTab, setLocation]);

  // Update active tab when URL changes
  useEffect(() => {
    setActiveTab(getTabFromUrl());
  }, [location]);

  if (!user) {
    return null; // Should be handled by ProtectedRoute
  }

  return (
    <Layout hideFooter>
      <div className="flex h-screen bg-gray-100 overflow-hidden">
        {/* Sidebar */}
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        
        {/* Main Content */}
        <div className="flex-1 overflow-y-auto">
          <main className="p-6">
            <div className="mb-6">
              <h1 className="text-2xl font-bold">پنل کاربری</h1>
              <p className="text-gray-600">
                {user.userType === "cargo_owner" 
                  ? "مدیریت محموله‌ها و سفارش‌های شما"
                  : "مدیریت خدمات حمل و نقل شما"
                }
              </p>
            </div>
            
            <div className="mb-6">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-3 md:grid-cols-6 h-auto">
                  <TabsTrigger value="overview" className="py-2">داشبورد</TabsTrigger>
                  <TabsTrigger value="shipments" className="py-2">محموله‌ها</TabsTrigger>
                  {user.userType === "transporter" && (
                    <>
                      <TabsTrigger value="create" className="py-2">ثبت سرویس جدید</TabsTrigger>
                      <TabsTrigger value="edit" className="py-2">ویرایش سرویس</TabsTrigger>
                    </>
                  )}
                  <TabsTrigger value="profile" className="py-2">پروفایل</TabsTrigger>
                  <TabsTrigger value="documents" className="py-2">مدارک</TabsTrigger>
                  <TabsTrigger value="settings" className="py-2">تنظیمات</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {user.userType === "cargo_owner" ? (
              <CargoOwnerDashboard activeTab={activeTab} />
            ) : (
              <TransporterDashboard activeTab={activeTab} />
            )}
          </main>
        </div>
      </div>
    </Layout>
  );
};

export default DashboardPage;
