import React, { useState } from "react";
import { useLocation, Redirect } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import Layout from "@/components/layout/Layout";
import { Loader2, Lock, User as UserIcon } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(3, "نام کاربری باید حداقل ۳ کاراکتر باشد"),
  password: z.string().min(6, "رمز عبور باید حداقل ۶ کاراکتر باشد"),
});

type LoginFormData = z.infer<typeof loginSchema>;

const AdminLoginPage: React.FC = () => {
  const { toast } = useToast();
  const [location, navigate] = useLocation();
  const { loginMutation, user } = useAuth();

  // If already logged in and is admin, redirect to admin dashboard
  React.useEffect(() => {
    if (user && user.role === "admin") {
      navigate("/admin");
    }
  }, [user, navigate]);

  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    loginMutation.mutate(data, {
      onSuccess: (userData) => {
        // Check if user is admin
        if (userData.role !== "admin") {
          toast({
            title: "دسترسی محدود",
            description: "شما مجاز به ورود به پنل مدیریت نیستید.",
            variant: "destructive",
          });
          return;
        }
        
        toast({
          title: "ورود موفق",
          description: "به پنل مدیریت لاجیستینو خوش آمدید!",
        });
        
        navigate("/admin");
      },
      onError: (error) => {
        toast({
          title: "خطا در ورود",
          description: error.message || "نام کاربری یا رمز عبور اشتباه است",
          variant: "destructive",
        });
      }
    });
  };

  // If user is already logged in as admin, redirect to admin dashboard
  if (user && user.role === "admin") {
    return <Redirect to="/admin" />;
  }

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center">
            <div className="h-16 w-16 bg-primary text-white flex items-center justify-center rounded-full mb-4">
              <Lock className="h-8 w-8" />
            </div>
          </div>
          <h2 className="text-center text-3xl font-extrabold text-gray-900">
            پنل مدیریت لاجیستینو
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            لطفاً با حساب مدیریت وارد شوید
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white py-8 px-4 shadow-lg border border-gray-200 sm:rounded-lg sm:px-10">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-medium">
                        <UserIcon className="h-4 w-4 ml-1" />
                        نام کاربری مدیر
                      </FormLabel>
                      <FormControl>
                        <Input
                          autoComplete="username"
                          placeholder="نام کاربری مدیر"
                          {...field}
                          className="rounded-md"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-sm font-medium">
                        <Lock className="h-4 w-4 ml-1" />
                        رمز عبور
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          autoComplete="current-password"
                          placeholder="رمز عبور مدیر"
                          {...field}
                          className="rounded-md"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="pt-2">
                  <Button
                    type="submit"
                    className="w-full flex justify-center font-medium py-2"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin ml-2" />
                    ) : null}
                    ورود به پنل مدیریت
                  </Button>
                </div>
              </form>
            </Form>
            
            <div className="mt-8 pt-4 border-t border-gray-200">
              <div className="text-sm text-center">
                <p className="text-gray-600 mb-2">اطلاعات ورود مدیر:</p>
                <div className="bg-gray-50 p-3 rounded-md text-right space-y-1">
                  <p><span className="font-bold">نام کاربری:</span> admin</p>
                  <p><span className="font-bold">رمز عبور:</span> Admin@123</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AdminLoginPage;