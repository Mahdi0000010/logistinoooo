import Layout from "@/components/layout/Layout";
import TransporterRegisterForm from "@/components/auth/TransporterRegisterForm";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Truck, AnchorIcon, Train, Plane } from "lucide-react";

const TransporterRegisterPage = () => {
  const { user, isLoading } = useAuth();
  
  // Redirect to dashboard if already logged in
  if (!isLoading && user) {
    return <Redirect to="/dashboard" />;
  }

  return (
    <Layout>
      <div className="py-12 md:py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Left Column: Register Form */}
            <div>
              <h1 className="text-2xl font-bold mb-6 text-primary">ثبت‌نام شرکت حمل و نقل</h1>
              <TransporterRegisterForm />
            </div>
            
            {/* Right Column: Benefits */}
            <div className="bg-white rounded-lg p-8 shadow-lg">
              <h2 className="text-xl font-bold text-primary mb-6">مزایای ثبت‌نام شرکت حمل و نقل</h2>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                    <Truck size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">افزایش مشتریان</h3>
                    <p className="text-gray-600 text-sm">
                      با ثبت‌نام در پلتفرم لاجیستینو، به هزاران صاحب کالا دسترسی پیدا کنید و سفارشات جدید دریافت کنید.
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                    <AnchorIcon size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">مدیریت آسان ناوگان</h3>
                    <p className="text-gray-600 text-sm">
                      با داشبورد مدیریت اختصاصی، به راحتی ناوگان و محموله‌های خود را مدیریت کنید.
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                    <Train size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">پرداخت امن و به موقع</h3>
                    <p className="text-gray-600 text-sm">
                      سیستم پرداخت امن لاجیستینو، دریافت مطالبات شما را تضمین می‌کند.
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                    <Plane size={24} />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">افزایش اعتبار</h3>
                    <p className="text-gray-600 text-sm">
                      با نمایش رتبه و نظرات مشتریان، اعتبار شرکت خود را افزایش دهید.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-10 pt-6 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  قبلاً ثبت‌نام کرده‌اید؟{" "}
                  <a href="/auth" className="text-primary hover:text-primary-dark font-semibold">
                    وارد شوید
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default TransporterRegisterPage;