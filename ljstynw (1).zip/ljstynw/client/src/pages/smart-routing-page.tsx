import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronRight, TruckIcon, ShipIcon, TrainIcon, DollarSign, Clock, MapPin, Calendar, PackageIcon } from "lucide-react";
import LocationsDropdown from "@/components/home/LocationsDropdown";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import LoadingIndicator from "@/components/common/LoadingIndicator";
import { formatPrice, formatDuration } from "@/lib/utils";
import Layout from "@/components/layout/Layout";

interface Segment {
  from: string;
  to: string;
  distance: number;
  duration: number;
  transportType: string;
  shipments: any[] | null;
}

interface Route {
  segments: Segment[];
  totalDistance: number;
  totalDuration: number;
  transportTypes: string[];
}

interface Port {
  name: string;
  country: string;
  distanceFromLocation: number;
  travelTime: number;
}

interface PortRouteInfo {
  originPorts: Port[];
  destinationPorts: Port[];
  directRouteAvailable: boolean;
  bestAlternativeRoute?: {
    originPort: Port;
    destinationPort: Port;
    totalDistance: number;
    landDistance1: number;
    seaDistance: number;
    landDistance2: number;
    totalDuration: number;
  };
}

interface SmartRoutingResult {
  route: Route;
  routeWithShipments: Segment[];
  totalPrice: number;
  totalDistance: number;
  totalDuration: number;
  estimatedDays: number;
  segments: number;
  transportModes: string[];
  portInfo?: PortRouteInfo;
}

export default function SmartRoutingPage() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Parse search params manually
  const getParamValue = (paramName: string): string | null => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get(paramName);
    }
    return null;
  };
  
  // States for from and to locations
  const [fromLocationId, setFromLocationId] = useState<number | null>(
    getParamValue('from') ? parseInt(getParamValue('from')!) : null
  );
  const [toLocationId, setToLocationId] = useState<number | null>(
    getParamValue('to') ? parseInt(getParamValue('to')!) : null
  );
  const [fromLocationName, setFromLocationName] = useState<string>("");
  const [toLocationName, setToLocationName] = useState<string>("");
  
  // Update URL when origin or destination changes
  useEffect(() => {
    if (fromLocationId && toLocationId) {
      const newUrl = `/smart-routing?from=${fromLocationId}&to=${toLocationId}`;
      window.history.replaceState({}, '', newUrl);
    }
  }, [fromLocationId, toLocationId]);
  
  // Fetch routing data
  const { data: routingResults, isLoading, error, refetch } = useQuery<SmartRoutingResult>({
    queryKey: ["/api/smart-routing", fromLocationId, toLocationId],
    queryFn: async () => {
      if (!fromLocationId || !toLocationId) return null;
      // اضافه کردن پارامتر showPortOptions برای دریافت اطلاعات نزدیکترین بنادر
      const res = await fetch(
        `/api/smart-routing?fromLocationId=${fromLocationId}&toLocationId=${toLocationId}&showPortOptions=true`
      );
      if (!res.ok) throw new Error("Failed to fetch routing data");
      return res.json();
    },
    enabled: !!(fromLocationId && toLocationId),
  });
  
  // Function to map transport type to a descriptive text in Persian
  const getTransportTypeText = (type: string) => {
    switch (type) {
      case "land": return "حمل و نقل جاده‌ای";
      case "rail": return "حمل و نقل ریلی";
      case "sea": return "حمل و نقل دریایی";
      case "air": return "حمل و نقل هوایی";
      case "mixed": return "حمل و نقل ترکیبی";
      default: return type;
    }
  };
  
  // Function to get an appropriate icon for each transport type
  const getTransportIcon = (type: string) => {
    switch (type) {
      case "land":
        return <TruckIcon className="h-5 w-5 text-primary" />;
      case "rail":
        return <TrainIcon className="h-5 w-5 text-primary" />;
      case "sea":
        return <ShipIcon className="h-5 w-5 text-primary" />;
      case "air":
        return <PackageIcon className="h-5 w-5 text-primary" />;
      default:
        return <TruckIcon className="h-5 w-5 text-primary" />;
    }
  };
  
  // Handle location selection
  const handleFromLocationSelect = (locationId: number | undefined) => {
    if (locationId) {
      setFromLocationId(locationId);
      // Fetch location name if needed
      fetch(`/api/locations/${locationId}`)
        .then(res => res.json())
        .then(location => setFromLocationName(location.name))
        .catch(() => {});
    } else {
      setFromLocationId(null);
      setFromLocationName("");
    }
  };
  
  const handleToLocationSelect = (locationId: number | undefined) => {
    if (locationId) {
      setToLocationId(locationId);
      // Fetch location name if needed
      fetch(`/api/locations/${locationId}`)
        .then(res => res.json())
        .then(location => setToLocationName(location.name))
        .catch(() => {});
    } else {
      setToLocationId(null);
      setToLocationName("");
    }
  };
  
  // Handle search button click
  const handleSearch = () => {
    if (!fromLocationId || !toLocationId) {
      toast({
        title: "انتخاب مبدأ و مقصد الزامی است",
        description: "لطفاً مبدأ و مقصد را انتخاب کنید.",
        variant: "destructive",
      });
      return;
    }
    refetch();
  };
  
  // Function to get container type name or vehicle type name
  const getContainerTypeName = (type: string) => {
    switch (type) {
      // کانتینرها
      case "20_standard":
        return "کانتینر ۲۰ فوت استاندارد";
      case "40_standard":
        return "کانتینر ۴۰ فوت استاندارد";
      case "20_refrigerated":
        return "کانتینر ۲۰ فوت یخچالی";
      case "40_refrigerated":
        return "کانتینر ۴۰ فوت یخچالی";
      
      // وسایل نقلیه زمینی
      case "وانت":
        return "وانت‌بار (مناسب برای بارهای تا ۲ تن)";
      case "نیسان":
        return "نیسان (مناسب برای بارهای تا ۵ تن)";
      case "خاور":
        return "خاور (مناسب برای بارهای تا ۱۰ تن)";
      case "کامیون":
        return "کامیون (مناسب برای بارهای تا ۲۰ تن)";
      case "تریلی":
        return "تریلی (مناسب برای بارهای بیش از ۲۰ تن)";
      case "تریلی کشنده":
        return "تریلی کشنده (مناسب برای کانتینرها)";
        
      // وسایل نقلیه ریلی
      case "واگن باری":
        return "واگن باری قطار";
        
      // وسایل نقلیه دریایی
      case "کشتی حمل بار":
        return "کشتی باری";
        
      default:
        return type;
    }
  };
  
  return (
    <Layout>
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-6">مسیریابی هوشمند</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Search Panel */}
          <div className="md:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">جستجوی مسیر</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>مبدأ</Label>
                  <LocationsDropdown onLocationSelect={handleFromLocationSelect} />
                </div>
                
                <div className="space-y-2">
                  <Label>مقصد</Label>
                  <LocationsDropdown onLocationSelect={handleToLocationSelect} />
                </div>
                
                <Button 
                  onClick={handleSearch} 
                  className="w-full mt-4"
                  disabled={isLoading}
                >
                  {isLoading ? "در حال جستجو..." : "جستجوی مسیر"}
                </Button>
              </CardContent>
            </Card>
          </div>
          
          {/* Results Panel */}
          <div className="md:col-span-3">
            {isLoading ? (
              <LoadingIndicator text="در حال محاسبه بهترین مسیر..." />
            ) : error ? (
              <Card className="bg-red-50">
                <CardHeader>
                  <CardTitle className="text-red-600">خطا در دریافت اطلاعات</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>متأسفانه خطایی رخ داده است. لطفاً مجدداً تلاش کنید.</p>
                </CardContent>
              </Card>
            ) : routingResults ? (
              // Check if there are valid segments with shipments after filtering null prices
              routingResults.routeWithShipments
                .filter(segment => segment.shipments && segment.shipments.some(shipment => 
                  // استفاده از قیمت محاسبه شده در transportPrice در صورت وجود
                  (shipment.transportPrice && shipment.transportPrice.priceToman !== null) ||
                  // در صورت وجود calculatedPrice از API
                  shipment.calculatedPrice || 
                  // بررسی قیمت پایه
                  shipment.price !== null
                ))
                .length === 0 ? (
                  // If no valid segments with prices, show message
                  <Card className="bg-yellow-50">
                    <CardHeader>
                      <CardTitle className="text-yellow-700">برای این مسیر هیچ حمل و نقلی با قیمت مشخص پیدا نشد</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>در حال حاضر برای مسیر انتخاب شده، هیچ سرویس حمل و نقلی با قیمت مشخص وجود ندارد. لطفاً مسیر دیگری را انتخاب کنید.</p>
                    </CardContent>
                  </Card>
                ) : (
                  // If there are valid segments with prices, show the route details
                  <div className="space-y-6">
                    {/* اطلاعات بنادر نزدیک */}
                    {routingResults.portInfo && (
                      <Card className="bg-blue-50 border border-blue-200">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-blue-700 text-base">گزینه‌های مسیریابی از طریق بنادر</CardTitle>
                          <CardDescription className="text-blue-600">
                            در صورتی که مسیر مستقیم مناسب نیست، گزینه‌های زیر را بررسی کنید
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {/* اطلاعات بنادر نزدیک به مبدا */}
                          {routingResults.portInfo.originPorts.length > 0 && (
                            <div>
                              <h4 className="font-bold mb-2 text-sm">نزدیکترین بنادر به مبدا ({fromLocationName}):</h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {routingResults.portInfo.originPorts.map((port, idx) => (
                                  <div key={`origin-port-${idx}`} className="bg-white p-3 rounded-md shadow-sm">
                                    <p className="font-bold text-sm">{port.name}</p>
                                    <p className="text-xs text-gray-600">{port.country}</p>
                                    <div className="flex justify-between text-xs mt-1">
                                      <span>فاصله: {port.distanceFromLocation} کیلومتر</span>
                                      <span>زمان: {formatDuration(port.travelTime)}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {/* اطلاعات بنادر نزدیک به مقصد */}
                          {routingResults.portInfo.destinationPorts.length > 0 && (
                            <div>
                              <h4 className="font-bold mb-2 text-sm">نزدیکترین بنادر به مقصد ({toLocationName}):</h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {routingResults.portInfo.destinationPorts.map((port, idx) => (
                                  <div key={`dest-port-${idx}`} className="bg-white p-3 rounded-md shadow-sm">
                                    <p className="font-bold text-sm">{port.name}</p>
                                    <p className="text-xs text-gray-600">{port.country}</p>
                                    <div className="flex justify-between text-xs mt-1">
                                      <span>فاصله: {port.distanceFromLocation} کیلومتر</span>
                                      <span>زمان: {formatDuration(port.travelTime)}</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {/* اطلاعات بهترین مسیر جایگزین از طریق بنادر */}
                          {routingResults.portInfo.bestAlternativeRoute && (
                            <div>
                              <h4 className="font-bold mb-2 text-sm">بهترین مسیر جایگزین از طریق بنادر:</h4>
                              <div className="bg-white p-3 rounded-md shadow-sm">
                                <div className="flex flex-col gap-2">
                                  <div className="flex justify-between">
                                    <div className="flex items-center">
                                      <TruckIcon className="h-4 w-4 ml-1 text-primary" />
                                      <span className="text-sm">
                                        {fromLocationName} به {routingResults.portInfo.bestAlternativeRoute.originPort.name}
                                      </span>
                                    </div>
                                    <span className="text-xs">{routingResults.portInfo.bestAlternativeRoute.landDistance1} کیلومتر</span>
                                  </div>
                                  
                                  <div className="flex justify-between">
                                    <div className="flex items-center">
                                      <ShipIcon className="h-4 w-4 ml-1 text-primary" />
                                      <span className="text-sm">
                                        {routingResults.portInfo.bestAlternativeRoute.originPort.name} به {routingResults.portInfo.bestAlternativeRoute.destinationPort.name}
                                      </span>
                                    </div>
                                    <span className="text-xs">{routingResults.portInfo.bestAlternativeRoute.seaDistance} کیلومتر</span>
                                  </div>
                                  
                                  <div className="flex justify-between">
                                    <div className="flex items-center">
                                      <TruckIcon className="h-4 w-4 ml-1 text-primary" />
                                      <span className="text-sm">
                                        {routingResults.portInfo.bestAlternativeRoute.destinationPort.name} به {toLocationName}
                                      </span>
                                    </div>
                                    <span className="text-xs">{routingResults.portInfo.bestAlternativeRoute.landDistance2} کیلومتر</span>
                                  </div>
                                  
                                  <Separator />
                                  
                                  <div className="flex justify-between font-bold">
                                    <span>مجموع</span>
                                    <div>
                                      <span>{routingResults.portInfo.bestAlternativeRoute.totalDistance} کیلومتر</span>
                                      <span className="mx-2">•</span>
                                      <span>{formatDuration(routingResults.portInfo.bestAlternativeRoute.totalDuration)}</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    )}
                    
                    {/* Summary Card */}
                    <Card className="bg-primary/5">
                      <CardHeader>
                        <CardTitle className="text-primary">خلاصه بهترین مسیر</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                          <div className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="flex items-center mb-2">
                              <MapPin className="h-5 w-5 mr-2 text-primary" />
                              <span className="text-sm font-medium">مسافت کل</span>
                            </div>
                            <p className="text-xl font-bold">{routingResults.totalDistance} کیلومتر</p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="flex items-center mb-2">
                              <Clock className="h-5 w-5 mr-2 text-primary" />
                              <span className="text-sm font-medium">زمان تقریبی</span>
                            </div>
                            <p className="text-xl font-bold">{routingResults.estimatedDays} روز</p>
                          </div>
                          

                          
                          <div className="bg-white p-4 rounded-lg shadow-sm">
                            <div className="flex items-center mb-2">
                              <TruckIcon className="h-5 w-5 mr-2 text-primary" />
                              <span className="text-sm font-medium">روش حمل و نقل</span>
                            </div>
                            <div className="flex flex-wrap gap-1">
                              {routingResults.transportModes.map((mode, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {getTransportTypeText(mode)}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    {/* Segments */}
                    <div className="space-y-4">
                      <h3 className="text-xl font-bold mb-4">جزئیات مسیر</h3>
                      
                      {/* نمایش اطلاعات هشدار برای مسیرهای ترکیبی با بخش‌های ناقص */}
                      {routingResults.routeWithShipments.some(segment => segment.transportType === 'sea' && 
                        (!segment.shipments || segment.shipments.every(s => s.price === null))) && (
                        <Card className="mb-4 bg-yellow-50 border border-yellow-200">
                          <CardHeader className="pb-2">
                            <CardTitle className="text-yellow-700 text-base">
                              بخشی از این مسیر اطلاعات کامل ندارد
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              برای بخش حمل و نقل دریایی این مسیر، قیمت‌های معتبری از شرکت‌های حمل و نقل دریایی موجود نیست. فقط بخش‌های دارای قیمت نمایش داده شده‌اند.
                            </p>
                            <p className="text-sm mt-2 font-medium">
                              شما می‌توانید با بخش‌های موجود (زمینی/ریلی) محموله خود را تا بندر برسانید و سپس با یک شرکت حمل و نقل دریایی هماهنگی کنید.
                            </p>
                          </CardContent>
                        </Card>
                      )}
                      
                      {/* نمایش بخش‌های بدون قیمت */}
                      {routingResults.routeWithShipments
                        .filter(segment => segment.transportType === 'sea' && (!segment.shipments || segment.shipments.every(s => s.price === null)))
                        .map((segment, index) => (
                          <Card key={`sea-${index}`} className="border-2 border-yellow-300 bg-yellow-50/50 mb-4">
                            <CardHeader className="pb-2">
                              <div className="flex justify-between items-center">
                                <div className="flex items-center">
                                  {getTransportIcon(segment.transportType)}
                                  <CardTitle className="text-lg mr-2">
                                    {getTransportTypeText(segment.transportType)}
                                  </CardTitle>
                                  <Badge variant="outline" className="mr-2 bg-yellow-100 text-yellow-800 border-yellow-300">
                                    قیمت موجود نیست
                                  </Badge>
                                </div>
                                <Badge variant="outline" className="font-normal">
                                  {segment.distance} کیلومتر
                                </Badge>
                              </div>
                              <CardDescription className="flex items-center mt-2 text-base font-medium">
                                <span>{segment.from}</span>
                                <ChevronRight className="mx-2 h-4 w-4" />
                                <span>{segment.to}</span>
                              </CardDescription>
                            </CardHeader>
                            
                            <CardContent>
                              <div className="space-y-2">
                                <div className="flex justify-between text-sm">
                                  <span>مدت زمان تقریبی:</span>
                                  <span className="font-medium">{formatDuration(segment.duration)}</span>
                                </div>
                                
                                <div className="bg-white p-3 rounded-lg border border-yellow-200 mt-3">
                                  <p className="text-sm text-gray-700">
                                    برای این بخش از مسیر، قیمت‌های معتبری از شرکت‌های حمل و نقل دریایی در سیستم موجود نیست. جهت دریافت قیمت لطفاً با پشتیبانی تماس بگیرید.
                                  </p>
                                  <Button variant="outline" size="sm" className="mt-2">
                                    درخواست استعلام قیمت
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                      ))}
                      
                      {/* Filter segments to only include those with at least one shipment that has a price */}
                      {routingResults.routeWithShipments
                        .map(segment => {
                          // Filter out shipments with null prices
                          if (segment.shipments) {
                            segment.shipments = segment.shipments.filter(shipment => 
                              // استفاده از قیمت محاسبه شده در transportPrice در صورت وجود
                              (shipment.transportPrice && shipment.transportPrice.priceToman !== null) ||
                              // در صورت وجود calculatedPrice از API
                              shipment.calculatedPrice || 
                              // بررسی قیمت پایه
                              shipment.price !== null
                            );
                          }
                          return segment;
                        })
                        // Only include segments that have at least one shipment left after filtering
                        .filter(segment => segment.shipments && segment.shipments.length > 0)
                        .map((segment, index) => (
                        <Card key={index} className="border-2 border-primary/10">
                          <CardHeader className="pb-2">
                            <div className="flex justify-between items-center">
                              <div className="flex items-center">
                                {getTransportIcon(segment.transportType)}
                                <CardTitle className="text-lg mr-2">
                                  {getTransportTypeText(segment.transportType)}
                                </CardTitle>
                              </div>
                              <Badge variant="outline" className="font-normal">
                                {segment.distance} کیلومتر
                              </Badge>
                            </div>
                            <CardDescription className="flex items-center mt-2 text-base font-medium">
                              <span>{segment.from}</span>
                              <ChevronRight className="mx-2 h-4 w-4" />
                              <span>{segment.to}</span>
                            </CardDescription>
                          </CardHeader>
                          
                          <CardContent>
                            <div className="space-y-4">
                              <div className="flex justify-between text-sm">
                                <span>مدت زمان تقریبی:</span>
                                <span className="font-medium">{formatDuration(segment.duration)}</span>
                              </div>
                              
                              {/* Shipment options */}
                              <div className="space-y-3">
                                <h4 className="font-medium text-sm">گزینه‌های موجود برای این مسیر:</h4>
                                
                                {segment.shipments?.map((shipment, shipIndex) => {
                                  // Get the price to display
                                  let displayPrice = 0;
                                  if (shipment.transportPrice && shipment.transportPrice.priceToman !== null) {
                                    // transportPrice.priceToman از سرور می‌آید
                                    displayPrice = shipment.transportPrice.priceToman;
                                  } else if (shipment.calculatedPrice) {
                                    displayPrice = shipment.calculatedPrice;
                                  } else if (shipment.price) {
                                    displayPrice = shipment.price;
                                  }
                                  
                                  return (
                                    <div 
                                      key={shipIndex}
                                      className="bg-white p-3 rounded-lg border border-gray-200 hover:border-primary/30 hover:bg-primary/5 transition-colors cursor-pointer"
                                    >
                                      <div className="flex justify-between items-start mb-2">
                                        <div>
                                          <div className="font-medium">
                                            {shipment.transporterName || 'سیستم مسیریابی هوشمند'}
                                          </div>
                                          <div className="text-sm text-gray-600">
                                            {shipment.containerType ? getContainerTypeName(shipment.containerType) : 'حمل و نقل استاندارد'}
                                          </div>
                                        </div>
                                        <div className="text-lg font-bold text-primary">
                                          {formatPrice(displayPrice)} <span className="text-sm font-normal">تومان</span>
                                        </div>
                                      </div>
                                      
                                      <div className="flex gap-2 mt-3">
                                        <Button 
                                          variant="outline" 
                                          size="sm" 
                                          className="text-xs flex-1"
                                          onClick={() => window.location.href = `/shipment/${shipment.id}`}
                                        >
                                          مشاهده جزئیات
                                        </Button>
                                        <Button 
                                          size="sm" 
                                          className="text-xs flex-1"
                                        >
                                          انتخاب این گزینه
                                        </Button>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )
            ) : (
              <Card className="p-6 text-center">
                <div className="flex flex-col items-center justify-center">
                  <div className="text-gray-400 mb-4">
                    <MapPin className="h-12 w-12" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">مبدا و مقصد را انتخاب کنید</h3>
                  <p className="text-gray-600 mb-2">
                    برای مشاهده بهترین مسیرهای ترکیبی با بهترین قیمت، مبدا و مقصد خود را انتخاب کنید.
                  </p>
                  <div className="bg-primary/5 p-4 rounded-lg text-sm text-gray-600 mt-4 text-right w-full">
                    <p className="font-medium mb-2">سیستم مسیریابی هوشمند Logistino:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>ترکیب خودکار روش‌های مختلف حمل و نقل</li>
                      <li>یافتن بهترین مسیر از نظر زمان و هزینه</li>
                      <li>مسیریابی هوشمند بین بنادر و شهرها</li>
                      <li>پیشنهاد سرویس‌های موجود برای هر بخش مسیر</li>
                    </ul>
                  </div>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}