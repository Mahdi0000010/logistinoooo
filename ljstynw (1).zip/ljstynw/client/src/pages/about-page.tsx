import Layout from "@/components/layout/Layout";
import { Ship, Truck, Train, Shield, Award, Users } from "lucide-react";

const AboutPage = () => {
  return (
    <Layout>
      <div className="py-12 bg-white">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold mb-6">درباره لجستینو</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              لجستینو، سامانه جامع حمل و نقل دریایی، زمینی و ریلی برای صادرات و واردات کالا در سراسر جهان
            </p>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-20">
            <div>
              <h2 className="text-2xl font-bold mb-4">ما کی هستیم؟</h2>
              <p className="text-gray-700 mb-4">
                لجستینو یک پلتفرم آنلاین برای ارتباط میان صاحبان کالا و شرکت‌های حمل و نقل است. ما با ایجاد یک بازار دیجیتال، 
                امکان مقایسه قیمت‌ها، رزرو آنلاین و پیگیری محموله‌ها را فراهم می‌کنیم.
              </p>
              <p className="text-gray-700 mb-4">
                تیم ما متشکل از متخصصان با تجربه در زمینه‌های لجستیک، فناوری اطلاعات و تجارت بین‌المللی است که
                با هدف تسهیل فرآیندهای پیچیده حمل و نقل بین‌المللی گرد هم آمده‌اند.
              </p>
              <p className="text-gray-700">
                ما به دنبال ایجاد تحول در صنعت حمل و نقل و لجستیک ایران هستیم و با ارائه راهکارهای نوآورانه،
                به صاحبان کالا و شرکت‌های حمل و نقل کمک می‌کنیم تا با کارایی بیشتر و هزینه کمتر فعالیت کنند.
              </p>
            </div>
            <div className="bg-gray-100 p-8 rounded-lg">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center p-4">
                  <Ship className="w-12 h-12 text-primary mx-auto mb-2" />
                  <h3 className="font-bold mb-1">حمل و نقل دریایی</h3>
                  <p className="text-sm text-gray-600">پوشش تمامی بنادر خلیج فارس</p>
                </div>
                <div className="text-center p-4">
                  <Truck className="w-12 h-12 text-secondary mx-auto mb-2" />
                  <h3 className="font-bold mb-1">حمل و نقل زمینی</h3>
                  <p className="text-sm text-gray-600">اتصال شهرهای داخلی به بنادر</p>
                </div>
                <div className="text-center p-4">
                  <Train className="w-12 h-12 text-accent mx-auto mb-2" />
                  <h3 className="font-bold mb-1">حمل و نقل ریلی</h3>
                  <p className="text-sm text-gray-600">مسیرهای اصلی به بنادر جنوبی</p>
                </div>
                <div className="text-center p-4">
                  <Shield className="w-12 h-12 text-green-600 mx-auto mb-2" />
                  <h3 className="font-bold mb-1">بیمه کالا</h3>
                  <p className="text-sm text-gray-600">حفاظت از محموله‌های شما</p>
                </div>
              </div>
            </div>
          </div>

          {/* Values & Mission */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">ارزش‌ها و مأموریت ما</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                ما با تکیه بر ارزش‌های زیر، به دنبال تحقق مأموریت خود در ارتقاء صنعت لجستیک ایران هستیم
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <div className="w-14 h-14 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4 mx-auto">
                  <Award className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold text-center mb-3">کیفیت</h3>
                <p className="text-gray-600 text-center">
                  ما به ارائه خدمات با کیفیت و استاندارد متعهد هستیم و همواره به دنبال بهبود فرآیندها و خدمات خود هستیم.
                </p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <div className="w-14 h-14 rounded-full bg-secondary/10 text-secondary flex items-center justify-center mb-4 mx-auto">
                  <Users className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold text-center mb-3">مشتری‌مداری</h3>
                <p className="text-gray-600 text-center">
                  رضایت مشتریان اولویت اصلی ماست و تمام تلاش خود را برای ارائه بهترین تجربه به آن‌ها به کار می‌گیریم.
                </p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <div className="w-14 h-14 rounded-full bg-accent/10 text-accent flex items-center justify-center mb-4 mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-center mb-3">نوآوری</h3>
                <p className="text-gray-600 text-center">
                  ما به دنبال ارائه راهکارهای نوآورانه هستیم و از فناوری‌های نوین برای حل چالش‌های صنعت لجستیک استفاده می‌کنیم.
                </p>
              </div>
            </div>
          </div>

          {/* Team Section */}
          <div>
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">تیم ما</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                تیم لجستینو متشکل از افرادی با تخصص‌های مختلف است که با هدف مشترک توسعه صنعت لجستیک ایران فعالیت می‌کنند
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[1, 2, 3].map((_, index) => (
                <div key={index} className="text-center">
                  <div className="w-32 h-32 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                    <svg className="w-full h-full text-gray-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold">نام و نام خانوادگی</h3>
                  <p className="text-gray-600 mb-2">سمت سازمانی</p>
                  <p className="text-sm text-gray-500">
                    توضیحات مختصر درباره تجربیات و تخصص‌های فرد
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AboutPage;
