import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";

export default function NotFound() {
  const [clickCount, setClickCount] = useState(0);
  const [_, navigate] = useLocation();
  
  // تایمر برای ریست کردن تعداد کلیک‌ها بعد از یک مدت زمان مشخص
  useEffect(() => {
    if (clickCount > 0) {
      const timer = setTimeout(() => {
        setClickCount(0);
      }, 2000); // ریست بعد از 2 ثانیه
      
      return () => clearTimeout(timer);
    }
  }, [clickCount]);
  
  // در صورتی که 3 بار متوالی روی عنوان کلیک شود، به صفحه ورود مدیریت منتقل می‌شود
  const handleTitleClick = () => {
    const newCount = clickCount + 1;
    setClickCount(newCount);
    
    if (newCount >= 3) {
      navigate("/admin-login");
    }
  };
  
  return (
    <Layout>
      <div className="min-h-[70vh] w-full flex items-center justify-center bg-gray-50 py-12">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="flex mb-4 gap-2">
              <AlertCircle className="h-8 w-8 text-red-500" />
              <h1 
                className="text-2xl font-bold text-gray-900 cursor-default" 
                onClick={handleTitleClick}
              >
                صفحه مورد نظر یافت نشد
              </h1>
            </div>

            <p className="mt-4 mb-6 text-gray-600">
              متأسفانه صفحه مورد نظر شما پیدا نشد. ممکن است آدرس را اشتباه وارد کرده باشید یا صفحه حذف شده باشد.
            </p>
            
            <Link href="/">
              <Button className="w-full">
                بازگشت به صفحه اصلی
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
