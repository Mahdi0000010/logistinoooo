import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/layout/Layout";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from "@/components/ui/popover";
import DatePicker from "@/components/shared/DatePicker";
import { Location } from "@shared/schema";
import { ArrowRight, Search, PackageCheck, Ship, Package, TruckIcon, Check, ChevronsUpDown, X } from "lucide-react";
import { storageManager, SearchValues } from "@/lib/storage-manager";
import { cn } from "@/lib/utils";

const SearchPage = () => {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("loose-cargo");
  const [originId, setOriginId] = useState<string>("");
  const [destinationId, setDestinationId] = useState<string>("");
  const [departureDate, setDepartureDate] = useState<string>("");
  const [cargoType, setCargoType] = useState<string>("");
  const [cargoWeight, setCargoWeight] = useState<string>("");
  const [cargoQuantity, setCargoQuantity] = useState<string>("1");
  
  // اضافه کردن نوع حمل و نقل ترجیحی
  const [preferredTransportType, setPreferredTransportType] = useState<string>("all");
  
  const [containerType, setContainerType] = useState<string>("20_standard");
  const [withInsurance, setWithInsurance] = useState<boolean>(false);
  const [cargoWidth, setCargoWidth] = useState<string>("");
  const [cargoHeight, setCargoHeight] = useState<string>("");
  const [cargoLength, setCargoLength] = useState<string>("");
  const [cargoUnit, setCargoUnit] = useState<string>("cm");
  const [weightUnit, setWeightUnit] = useState<string>("kg");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [originCountry, setOriginCountry] = useState<string>("ایران");
  const [destinationCountry, setDestinationCountry] = useState<string>("امارات متحده عربی");
  // تنظیم مقادیر پیش‌فرض برای همه انواع (بدون نیاز به نمایش در UI)
  const originType = "all";
  const destinationType = "all";
  
  // توابع مورد استفاده در کد قبلی که دیگر فعال نیستند اما باید وجود داشته باشند
  const setOriginType = (value: string) => {
    // این تابع دیگر عملکردی ندارد چون نوع مبدا/مقصد ثابت است
    console.log("setOriginType is disabled", value);
  };
  
  const setDestinationType = (value: string) => {
    // این تابع دیگر عملکردی ندارد چون نوع مبدا/مقصد ثابت است
    console.log("setDestinationType is disabled", value);
  };
  const [originAddress, setOriginAddress] = useState<string>("");
  const [destinationAddress, setDestinationAddress] = useState<string>("");
  const [currentStep, setCurrentStep] = useState(1);
  
  // برای امکان جستجو با تایپ کردن
  const [openOrigin, setOpenOrigin] = useState(false);
  const [openDestination, setOpenDestination] = useState(false);
  const [originSearch, setOriginSearch] = useState("");
  const [destinationSearch, setDestinationSearch] = useState("");
  
  // Fetch locations
  const { data: locations, isLoading: isLoadingLocations } = useQuery({
    queryKey: ['/api/locations'],
    queryFn: async () => {
      const res = await fetch('/api/locations');
      return await res.json();
    },
  });

  const ports = locations?.filter((loc: Location) => loc.type === "port") || [];
  const inlandLocations = locations?.filter((loc: Location) => loc.type === "inland") || [];
  const allLocations = locations || [];
  
  // Get unique countries with standard JS
  const countryMap: Record<string, boolean> = {};
  const countries = allLocations
    .map((loc: Location) => loc.country)
    .filter((country: string) => {
      if (!countryMap[country]) {
        countryMap[country] = true;
        return true;
      }
      return false;
    });
  
  // تغییر: فقط نمایش مکان‌ها براساس کشور انتخاب شده
  const filteredOriginLocations = allLocations.filter((loc: Location) => 
    (originCountry === "all" || loc.country === originCountry)
  );
  
  const filteredDestinationLocations = allLocations.filter((loc: Location) => 
    (destinationCountry === "all" || loc.country === destinationCountry)
  );
  
  // وقتی کشور انتخاب شده، فقط مکان‌های آن کشور را نمایش می‌دهیم
  const originLocations = filteredOriginLocations;
  const destinationLocations = filteredDestinationLocations;
  
  // تابع کمکی برای چک کردن تطابق کاراکتر به کاراکتر
  const perCharacterMatch = (locationText: string, searchText: string): boolean => {
    if (!searchText.trim()) return true;
    
    // هر کاراکتر در جستجو را بررسی کن
    for (const char of searchText) {
      if (!locationText.includes(char)) {
        return false;
      }
    }
    return true;
  };

  // فیلتر براساس جستجوی متنی - با روش جدید کاراکتر به کاراکتر
  const searchFilteredOriginLocations = originLocations.filter((location: Location) => {
    if (!originSearch.trim()) return true;
    
    // روش ساده - هر کاراکتر را جداگانه چک کن
    return (
      // بررسی بر اساس تطابق دقیق (شامل بودن رشته)
      location.name.includes(originSearch) || 
      location.country.includes(originSearch) ||
      
      // بررسی بر اساس تطابق کاراکتر به کاراکتر
      perCharacterMatch(location.name, originSearch) || 
      perCharacterMatch(location.country, originSearch)
    );
  });

  const searchFilteredDestinationLocations = destinationLocations.filter((location: Location) => {
    if (!destinationSearch.trim()) return true;
    
    // روش ساده - هر کاراکتر را جداگانه چک کن
    return (
      // بررسی بر اساس تطابق دقیق (شامل بودن رشته)
      location.name.includes(destinationSearch) || 
      location.country.includes(destinationSearch) ||
      
      // بررسی بر اساس تطابق کاراکتر به کاراکتر
      perCharacterMatch(location.name, destinationSearch) || 
      perCharacterMatch(location.country, destinationSearch)
    );
  });
  
  // جستجوی مکان با شناسه
  const getLocationNameById = (locationId: string) => {
    const location = allLocations.find((loc: Location) => loc.id.toString() === locationId);
    return location ? `${location.name}، ${location.country}` : "انتخاب مکان";
  };

  // Load search parameters from URL and storage manager
  useEffect(() => {
    // ابتدا مقادیر را از مدیریت کننده ذخیره‌سازی بخوانیم
    const savedValues = storageManager.getSearchValues();
    
    // پارامترهای URL را بخوانیم (اولویت بالاتر دارند)
    const params = new URLSearchParams(window.location.search);
    
    // ترکیب مقادیر ذخیره شده و پارامترهای URL
    const values = {
      ...savedValues,
      originId: params.get('originId') || savedValues.originId || "",
      destinationId: params.get('destinationId') || savedValues.destinationId || "",
      departureDate: params.get('departureDate') || savedValues.departureDate || "",
      cargoType: params.get('cargoType') || savedValues.cargoType || ""
    };
    
    // تنظیم فیلترها از بالا به پایین (اولویت‌بندی مهم است)
    // ابتدا فیلترهای کشور و نوع را تنظیم می‌کنیم
    if (values.originCountry) {
      setOriginCountry(values.originCountry);
    }
    
    // Type is now fixed to "all"
    
    if (values.destinationCountry) {
      setDestinationCountry(values.destinationCountry);
    }
    
    // Type is now fixed to "all"
    
    // سپس ID‌های مکان را تنظیم می‌کنیم
    if (values.originId) {
      setOriginId(values.originId);
      
      // اگر فیلترها تنظیم نشده‌اند، از اطلاعات مکان استفاده کنیم
      if ((!values.originCountry || !values.originType) && allLocations && allLocations.length > 0) {
        const selectedLocation = allLocations.find(
          (loc: Location) => loc.id.toString() === values.originId
        );
        
        if (selectedLocation) {
          if (!values.originCountry) setOriginCountry(selectedLocation.country);
          // Type is now fixed to "all"
        }
      }
    }
    
    if (values.destinationId) {
      setDestinationId(values.destinationId);
      
      // اگر فیلترها تنظیم نشده‌اند، از اطلاعات مکان استفاده کنیم
      if ((!values.destinationCountry || !values.destinationType) && allLocations && allLocations.length > 0) {
        const selectedLocation = allLocations.find(
          (loc: Location) => loc.id.toString() === values.destinationId
        );
        
        if (selectedLocation) {
          if (!values.destinationCountry) setDestinationCountry(selectedLocation.country);
          // Type is now fixed to "all"
        }
      }
    }
    
    // سایر فیلدها را تنظیم می‌کنیم
    if (values.departureDate) {
      setDepartureDate(values.departureDate);
    }
    
    if (values.cargoType) {
      setCargoType(values.cargoType);
    }
    
    if (values.cargoWeight) {
      setCargoWeight(values.cargoWeight);
    }
    
    if (values.containerType) {
      setContainerType(values.containerType);
    }
    
    if (values.cargoQuantity) {
      setCargoQuantity(values.cargoQuantity);
    }
    
    setWithInsurance(values.withInsurance || false);
    
  }, [allLocations]);
  
  // استفاده از مدیریت کننده ذخیره‌سازی برای ذخیره مقادیر
  // مدیریت تغییر مبدا با ذخیره در storage manager
  const updateOriginChange = (value: string) => {
    if (!value) return;
    
    const selectedLocation = allLocations.find(
      (loc: Location) => loc.id.toString() === value
    );
    
    if (selectedLocation) {
      // ذخیره همه مقادیر مرتبط
      storageManager.updateSearchValues({
        originId: value,
        originCountry: selectedLocation.country,
        originType: selectedLocation.type
      });
    } else {
      storageManager.updateSearchValues({ originId: value });
    }
  };
  
  // مدیریت تغییر مقصد با ذخیره در storage manager
  const updateDestinationChange = (value: string) => {
    if (!value) return;
    
    const selectedLocation = allLocations.find(
      (loc: Location) => loc.id.toString() === value
    );
    
    if (selectedLocation) {
      // ذخیره همه مقادیر مرتبط
      storageManager.updateSearchValues({
        destinationId: value,
        destinationCountry: selectedLocation.country,
        destinationType: selectedLocation.type
      });
    } else {
      storageManager.updateSearchValues({ destinationId: value });
    }
  };
  
  // ذخیره مقادیر در هر تغییر
  useEffect(() => {
    if (originId) updateOriginChange(originId);
  }, [originId, allLocations]);
  
  useEffect(() => {
    if (destinationId) updateDestinationChange(destinationId);
  }, [destinationId, allLocations]);
  
  // ذخیره فیلترها در localStorage از طریق مدیریت کننده
  useEffect(() => {
    if (originCountry) {
      storageManager.updateSearchValues({ originCountry });
    }
  }, [originCountry]);
  
  useEffect(() => {
    if (originType) {
      storageManager.updateSearchValues({ originType });
    }
  }, [originType]);
  
  useEffect(() => {
    if (destinationCountry) {
      storageManager.updateSearchValues({ destinationCountry });
    }
  }, [destinationCountry]);
  
  useEffect(() => {
    if (destinationType) {
      storageManager.updateSearchValues({ destinationType });
    }
  }, [destinationType]);
  
  useEffect(() => {
    if (departureDate) {
      storageManager.updateSearchValues({ departureDate });
    }
  }, [departureDate]);
  
  useEffect(() => {
    if (cargoType) {
      storageManager.updateSearchValues({ cargoType });
    }
  }, [cargoType]);

  const handleSearch = () => {
    const params = new URLSearchParams();
    
    // ذخیره تمام مقادیر در storage manager
    storageManager.updateSearchValues({
      originId,
      destinationId,
      departureDate,
      cargoType,
      originCountry,
      originType,
      destinationCountry,
      destinationType,
      cargoWeight,
      containerType,
      cargoQuantity,
      withInsurance,
      preferredTransportType // اضافه کردن نوع حمل و نقل ترجیحی
    });
    
    // افزودن پارامترها به URL
    if (originId) {
      params.append("originId", originId);
    }
    
    if (destinationId) {
      params.append("destinationId", destinationId);
    }
    
    if (departureDate) {
      params.append("departureDate", departureDate);
    }
    
    if (cargoType && cargoType !== "all") {
      params.append("cargoType", cargoType);
    }
    
    // اضافه کردن پارامترهای تکمیلی به URL
    if (cargoWeight) params.append("cargoWeight", cargoWeight);
    if (containerType) params.append("containerType", containerType);
    if (cargoQuantity) params.append("containerCount", cargoQuantity);
    if (withInsurance) params.append("withInsurance", "true");
    
    // اضافه کردن نوع حمل و نقل ترجیحی به URL
    if (preferredTransportType) {
      params.append("preferredTransport", preferredTransportType);
    }
    
    // افزودن پارامتر جدید برای فعال کردن سیستم مسیریابی هوشمند
    params.append("useSmartRouting", "true");
    
    navigate(`/search-results?${params.toString()}`);
  };

  const nextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      handleSearch();
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  // وقتی کشور مبدا تغییر می‌کند، مقدار مبدا را به اولین مکان آن کشور تغییر می‌دهیم
  useEffect(() => {
    // Only run when country changes
    if (originCountry && originCountry !== "all" && allLocations && allLocations.length > 0) {
      // فیلتر کردن مکان‌ها براساس کشور انتخاب شده
      const locationsOfCountry = allLocations.filter(
        (loc: Location) => loc.country === originCountry
      );
      
      // اگر مکانی در این کشور وجود داشت
      if (locationsOfCountry.length > 0) {
        // چک کنیم آیا مکان فعلی در کشور جدید است یا نه
        const currentLocationInNewCountry = locationsOfCountry.find(
          (loc: Location) => loc.id.toString() === originId
        );
        
        // اگر مکان فعلی در کشور جدید نیست، مقدار را به اولین مکان تغییر می‌دهیم
        if (!currentLocationInNewCountry) {
          setOriginId(locationsOfCountry[0].id.toString());
        }
      } else {
        // اگر هیچ مکانی در کشور جدید نیست، مقدار را خالی می‌کنیم
        setOriginId("");
      }
    }
  }, [originCountry, allLocations]);

  // وقتی کشور مقصد تغییر می‌کند، مقدار مقصد را به اولین مکان آن کشور تغییر می‌دهیم
  useEffect(() => {
    // Only run when country changes
    if (destinationCountry && destinationCountry !== "all" && allLocations && allLocations.length > 0) {
      // فیلتر کردن مکان‌ها براساس کشور انتخاب شده
      const locationsOfCountry = allLocations.filter(
        (loc: Location) => loc.country === destinationCountry
      );
      
      // اگر مکانی در این کشور وجود داشت
      if (locationsOfCountry.length > 0) {
        // چک کنیم آیا مکان فعلی در کشور جدید است یا نه
        const currentLocationInNewCountry = locationsOfCountry.find(
          (loc: Location) => loc.id.toString() === destinationId
        );
        
        // اگر مکان فعلی در کشور جدید نیست، مقدار را به اولین مکان تغییر می‌دهیم
        if (!currentLocationInNewCountry) {
          setDestinationId(locationsOfCountry[0].id.toString());
        }
      } else {
        // اگر هیچ مکانی در کشور جدید نیست، مقدار را خالی می‌کنیم
        setDestinationId("");
      }
    }
  }, [destinationCountry, allLocations]);

  return (
    <Layout>
      <section className="bg-primary py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="text-center text-white max-w-4xl mx-auto mb-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">
              کجا می‌خواهید محموله خود را ارسال کنید؟
            </h1>
            <p className="text-lg md:text-xl opacity-90">
              جستجو، مقایسه، رزرو و مدیریت حمل و نقل خود، همه در یک پلتفرم
            </p>
          </div>

          <Card className="bg-white shadow-xl rounded-xl">
            <CardContent className="p-0">
              <div className="flex items-center justify-center border-b py-3">
                <div className="flex items-center justify-center space-x-2 space-x-reverse">
                  <div className={`w-8 h-8 rounded-full ${currentStep >= 1 ? 'bg-primary' : 'bg-gray-200'} flex items-center justify-center text-white font-medium`}>
                    1
                  </div>
                  <div className={`w-16 h-1 ${currentStep >= 2 ? 'bg-primary' : 'bg-gray-200'}`}></div>
                  <div className={`w-8 h-8 rounded-full ${currentStep >= 2 ? 'bg-primary' : 'bg-gray-200'} flex items-center justify-center text-white font-medium`}>
                    2
                  </div>
                  <div className={`w-16 h-1 ${currentStep >= 3 ? 'bg-primary' : 'bg-gray-200'}`}></div>
                  <div className={`w-8 h-8 rounded-full ${currentStep >= 3 ? 'bg-primary' : 'bg-gray-200'} flex items-center justify-center text-white font-medium`}>
                    3
                  </div>
                </div>
              </div>

              {/* Step 1: Origin and Destination */}
              {currentStep === 1 && (
                <div className="p-6">
                  <h2 className="text-xl font-semibold mb-4">انتخاب مبدا و مقصد</h2>
                  
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <div className="mb-4">
                        <Label className="block text-gray-700 mb-2 font-medium">کشور مبدا</Label>
                        <Select value={originCountry} onValueChange={setOriginCountry}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="انتخاب کشور" />
                          </SelectTrigger>
                          <SelectContent>
                            {countries.map((country: string, index: number) => (
                              <SelectItem key={`country-origin-${index}`} value={country}>
                                {country}
                              </SelectItem>
                            ))}
                            <SelectItem value="all">همه کشورها</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label className="block text-gray-700 mb-2 font-medium">محل دقیق مبدا</Label>
                        <div className="border rounded-md relative">
                          <Input
                            type="text"
                            placeholder="جستجوی مبدا..."
                            value={originSearch}
                            onChange={(e) => setOriginSearch(e.target.value)}
                            onFocus={() => setOpenOrigin(true)}
                            className="w-full"
                          />
                          {(originSearch.length > 0 || openOrigin) && (
                            <div className="absolute z-50 w-full max-h-[300px] overflow-y-auto bg-white border rounded-md shadow-lg mt-1">
                              {searchFilteredOriginLocations.length > 0 ? (
                                searchFilteredOriginLocations.map((location: Location) => (
                                  <div
                                    key={`origin-${location.id}`}
                                    className={`px-3 py-2 hover:bg-gray-100 cursor-pointer ${
                                      originId === location.id.toString() ? "bg-primary/10" : ""
                                    }`}
                                    onClick={() => {
                                      setOriginId(location.id.toString());
                                      setOpenOrigin(false);
                                      setOriginSearch("");
                                    }}
                                  >
                                    {location.name}، {location.country} ({location.type === "port" ? "بندر" : "شهر"})
                                  </div>
                                ))
                              ) : (
                                <div className="px-3 py-2 text-gray-500">هیچ مکانی یافت نشد.</div>
                              )}
                            </div>
                          )}
                          {originId && (
                            <div className="mt-2 px-2 py-1 bg-primary/10 text-primary rounded flex items-center justify-between">
                              <span>{getLocationNameById(originId)}</span>
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="h-6 w-6 p-0" 
                                onClick={() => {
                                  setOriginId("");
                                  setOriginSearch("");
                                }}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="mt-4">
                        <Label className="block text-gray-700 mb-2 font-medium">آدرس دقیق</Label>
                        <Input 
                          value={originAddress} 
                          onChange={(e) => setOriginAddress(e.target.value)}
                          placeholder="آدرس کامل را وارد کنید" 
                        />
                      </div>
                    </div>
                    
                    <div>
                      <div className="mb-4">
                        <Label className="block text-gray-700 mb-2 font-medium">کشور مقصد</Label>
                        <Select value={destinationCountry} onValueChange={setDestinationCountry}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="انتخاب کشور" />
                          </SelectTrigger>
                          <SelectContent>
                            {countries.map((country: string, index: number) => (
                              <SelectItem key={`country-dest-${index}`} value={country}>
                                {country}
                              </SelectItem>
                            ))}
                            <SelectItem value="all">همه کشورها</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label className="block text-gray-700 mb-2 font-medium">محل دقیق مقصد</Label>
                        <div className="border rounded-md relative">
                          <Input
                            type="text"
                            placeholder="جستجوی مقصد..."
                            value={destinationSearch}
                            onChange={(e) => setDestinationSearch(e.target.value)}
                            onFocus={() => setOpenDestination(true)}
                            className="w-full"
                          />
                          {(destinationSearch.length > 0 || openDestination) && (
                            <div className="absolute z-50 w-full max-h-[300px] overflow-y-auto bg-white border rounded-md shadow-lg mt-1">
                              {searchFilteredDestinationLocations.length > 0 ? (
                                searchFilteredDestinationLocations.map((location: Location) => (
                                  <div
                                    key={`dest-${location.id}`}
                                    className={`px-3 py-2 hover:bg-gray-100 cursor-pointer ${
                                      destinationId === location.id.toString() ? "bg-primary/10" : ""
                                    }`}
                                    onClick={() => {
                                      setDestinationId(location.id.toString());
                                      setOpenDestination(false);
                                      setDestinationSearch("");
                                    }}
                                  >
                                    {location.name}، {location.country} ({location.type === "port" ? "بندر" : "شهر"})
                                  </div>
                                ))
                              ) : (
                                <div className="px-3 py-2 text-gray-500">هیچ مکانی یافت نشد.</div>
                              )}
                            </div>
                          )}
                          {destinationId && (
                            <div className="mt-2 px-2 py-1 bg-primary/10 text-primary rounded flex items-center justify-between">
                              <span>{getLocationNameById(destinationId)}</span>
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="h-6 w-6 p-0" 
                                onClick={() => {
                                  setDestinationId("");
                                  setDestinationSearch("");
                                }}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="mt-4">
                        <Label className="block text-gray-700 mb-2 font-medium">آدرس دقیق</Label>
                        <Input 
                          value={destinationAddress} 
                          onChange={(e) => setDestinationAddress(e.target.value)}
                          placeholder="آدرس کامل را وارد کنید" 
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Cargo Details */}
              {currentStep === 2 && (
                <div className="p-6">
                  <h2 className="text-xl font-semibold mb-4">چه چیزی را ارسال می‌کنید؟</h2>
                  
                  <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mb-6">
                    <TabsList className="grid grid-cols-2 mb-6">
                      <TabsTrigger value="loose-cargo" className="py-3 font-medium">
                        <Package className="ml-2" size={18} />
                        بار عادی
                      </TabsTrigger>
                      <TabsTrigger value="container" className="py-3 font-medium">
                        <Ship className="ml-2" size={18} />
                        کانتینر
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="loose-cargo">
                      <div className="grid md:grid-cols-2 gap-6 mb-6">
                        <div>
                          <Label className="block text-gray-700 mb-2 font-medium">نوع بار</Label>
                          <Select value={cargoType} onValueChange={setCargoType}>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="انتخاب نوع بار" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="food">مواد غذایی</SelectItem>
                              <SelectItem value="industrial">مواد صنعتی</SelectItem>
                              <SelectItem value="chemical">مواد شیمیایی</SelectItem>
                              <SelectItem value="perishable">کالای فاسد شدنی</SelectItem>
                              <SelectItem value="clothes">پوشاک</SelectItem>
                              <SelectItem value="electronics">لوازم الکترونیکی</SelectItem>
                              <SelectItem value="furniture">مبلمان</SelectItem>
                              <SelectItem value="vehicles">خودرو و قطعات</SelectItem>
                              <SelectItem value="other">سایر</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label className="block text-gray-700 mb-2 font-medium">وزن بار</Label>
                          <div className="flex">
                            <Input 
                              type="number" 
                              min={0}
                              value={cargoWeight} 
                              onChange={(e) => setCargoWeight(e.target.value)}
                              className="flex-grow rounded-l-none" 
                              placeholder="وزن" 
                            />
                            <Select value={weightUnit} onValueChange={setWeightUnit}>
                              <SelectTrigger className="w-24 rounded-r-none border-l-0">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="kg">کیلوگرم</SelectItem>
                                <SelectItem value="ton">تن</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        
                        <div className="md:col-span-2">
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <Checkbox 
                              id="show-advanced" 
                              checked={showAdvanced}
                              onCheckedChange={(checked) => setShowAdvanced(checked as boolean)}
                            />
                            <Label 
                              htmlFor="show-advanced" 
                              className="font-medium text-blue-600 cursor-pointer"
                            >
                              افزودن جزئیات بیشتر
                            </Label>
                          </div>
                        </div>
                        
                        {showAdvanced && (
                          <div className="md:col-span-2 grid md:grid-cols-3 gap-4 p-4 border rounded-lg bg-gray-50">
                            <div>
                              <Label className="block text-gray-700 mb-2 font-medium">طول</Label>
                              <div className="flex">
                                <Input 
                                  type="number" 
                                  min={0}
                                  value={cargoLength} 
                                  onChange={(e) => setCargoLength(e.target.value)}
                                  className="flex-grow rounded-l-none" 
                                  placeholder="طول" 
                                />
                                <Select value={cargoUnit} onValueChange={setCargoUnit}>
                                  <SelectTrigger className="w-20 rounded-r-none border-l-0">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="cm">سانتی‌متر</SelectItem>
                                    <SelectItem value="m">متر</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            
                            <div>
                              <Label className="block text-gray-700 mb-2 font-medium">عرض</Label>
                              <Input 
                                type="number" 
                                min={0}
                                value={cargoWidth} 
                                onChange={(e) => setCargoWidth(e.target.value)}
                                className="w-full" 
                                placeholder="عرض" 
                              />
                            </div>
                            
                            <div>
                              <Label className="block text-gray-700 mb-2 font-medium">ارتفاع</Label>
                              <Input 
                                type="number" 
                                min={0}
                                value={cargoHeight} 
                                onChange={(e) => setCargoHeight(e.target.value)}
                                className="w-full" 
                                placeholder="ارتفاع" 
                              />
                            </div>
                            
                            <div className="md:col-span-3 flex items-center mt-2">
                              <Checkbox 
                                id="with-insurance" 
                                checked={withInsurance}
                                onCheckedChange={(checked) => setWithInsurance(checked as boolean)}
                              />
                              <Label 
                                htmlFor="with-insurance" 
                                className="ml-2"
                              >
                                نیاز به بیمه حمل و نقل دارم
                              </Label>
                            </div>
                          </div>
                        )}
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="container">
                      <div className="grid md:grid-cols-2 gap-6 mb-6">
                        <div>
                          <Label className="block text-gray-700 mb-2 font-medium">نوع کانتینر</Label>
                          <Select value={containerType} onValueChange={setContainerType}>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="انتخاب نوع کانتینر" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="20_standard">کانتینر 20 فوت استاندارد</SelectItem>
                              <SelectItem value="40_standard">کانتینر 40 فوت استاندارد</SelectItem>
                              <SelectItem value="40_high_cube">کانتینر 40 فوت های کیوب</SelectItem>
                              <SelectItem value="20_refrigerated">کانتینر یخچالی 20 فوت</SelectItem>
                              <SelectItem value="40_refrigerated">کانتینر یخچالی 40 فوت</SelectItem>
                              <SelectItem value="20_open_top">کانتینر روباز 20 فوت</SelectItem>
                              <SelectItem value="40_open_top">کانتینر روباز 40 فوت</SelectItem>
                              <SelectItem value="flat_rack">فلت رک</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label className="block text-gray-700 mb-2 font-medium">تعداد کانتینر</Label>
                          <Input 
                            type="number" 
                            min={1}
                            value={cargoQuantity} 
                            onChange={(e) => setCargoQuantity(e.target.value)}
                            className="w-full" 
                            placeholder="تعداد" 
                          />
                        </div>
                        
                        <div>
                          <Label className="block text-gray-700 mb-2 font-medium">نوع بار</Label>
                          <Select value={cargoType} onValueChange={setCargoType}>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="انتخاب نوع بار" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="food">مواد غذایی</SelectItem>
                              <SelectItem value="industrial">مواد صنعتی</SelectItem>
                              <SelectItem value="chemical">مواد شیمیایی</SelectItem>
                              <SelectItem value="perishable">کالای فاسد شدنی</SelectItem>
                              <SelectItem value="clothes">پوشاک</SelectItem>
                              <SelectItem value="electronics">لوازم الکترونیکی</SelectItem>
                              <SelectItem value="furniture">مبلمان</SelectItem>
                              <SelectItem value="vehicles">خودرو و قطعات</SelectItem>
                              <SelectItem value="other">سایر</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="flex items-center">
                          <Checkbox 
                            id="with-insurance-container" 
                            checked={withInsurance}
                            onCheckedChange={(checked) => setWithInsurance(checked as boolean)}
                          />
                          <Label 
                            htmlFor="with-insurance-container" 
                            className="ml-2"
                          >
                            نیاز به بیمه حمل و نقل دارم
                          </Label>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              )}

              {/* Step 3: Shipping Dates and Transportation Preferences */}
              {currentStep === 3 && (
                <div className="p-6">
                  <h2 className="text-xl font-semibold mb-4">چه زمانی و با چه روشی می‌خواهید محموله را ارسال کنید؟</h2>
                  
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <Label className="block text-gray-700 mb-2 font-medium">تاریخ حمل</Label>
                      <DatePicker
                        value={departureDate}
                        onChange={setDepartureDate}
                        placeholder="انتخاب تاریخ حمل"
                        className="w-full"
                      />
                      <p className="mt-2 text-sm text-gray-500">
                        تاریخ دقیق یا بازه زمانی مورد نظر برای ارسال کالا
                      </p>
                    </div>
                    
                    <div>
                      <Label className="block text-gray-700 mb-2 font-medium">روش حمل و نقل ترجیحی</Label>
                      <Select
                        value={preferredTransportType}
                        onValueChange={setPreferredTransportType}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="انتخاب روش حمل و نقل" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">
                            <div className="flex items-center">
                              <PackageCheck className="ml-2 text-gray-500" size={18} />
                              همه روش‌ها (هوشمند)
                            </div>
                          </SelectItem>
                          <SelectItem value="land">
                            <div className="flex items-center">
                              <TruckIcon className="ml-2 text-gray-500" size={18} />
                              حمل و نقل زمینی
                            </div>
                          </SelectItem>
                          <SelectItem value="rail">
                            <div className="flex items-center">
                              <Package className="ml-2 text-gray-500" size={18} />
                              حمل و نقل ریلی
                            </div>
                          </SelectItem>
                          <SelectItem value="sea">
                            <div className="flex items-center">
                              <Ship className="ml-2 text-gray-500" size={18} />
                              حمل و نقل دریایی
                            </div>
                          </SelectItem>
                          <SelectItem value="mixed">
                            <div className="flex items-center">
                              <ArrowRight className="ml-2 text-gray-500" size={18} />
                              ترکیبی (چندوجهی)
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="mt-2 text-sm text-gray-500">
                        سیستم بهترین مسیر را پیشنهاد می‌دهد، اما می‌توانید روش ترجیحی خود را انتخاب کنید
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="p-6 border-t flex items-center justify-between">
                {currentStep > 1 ? (
                  <Button 
                    onClick={prevStep}
                    variant="outline"
                  >
                    <ArrowRight className="ml-2" size={18} />
                    مرحله قبل
                  </Button>
                ) : (
                  <div></div>
                )}
                
                <Button 
                  onClick={nextStep}
                  className={`${currentStep === 3 ? 'bg-green-600 hover:bg-green-700' : ''}`}
                >
                  {currentStep < 3 ? 'مرحله بعد' : 'جستجوی حمل‌ونقل'}
                  {currentStep < 3 ? null : <Search className="mr-2" size={18} />}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </Layout>
  );
};

export default SearchPage;