import Layout from "@/components/layout/Layout";
import Hero from "@/components/home/Hero";
import QuickSearch from "@/components/home/QuickSearch";
import Services from "@/components/home/Services";
import HowItWorks from "@/components/home/HowItWorks";
import Features from "@/components/home/Features";
import Testimonials from "@/components/home/Testimonials";
import CTA from "@/components/home/CTA";
import BlogPreview from "@/components/home/BlogPreview";
import NewServices from "@/components/home/NewServices";

const HomePage = () => {
  return (
    <Layout>
      <Hero />
      
      {/* Quick Search Section */}
      <section className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-3">جستجوی سریع</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              مبدا، مقصد و تاریخ مورد نظر خود را انتخاب کنید تا سریعاً به بهترین گزینه‌های حمل‌ونقل دسترسی پیدا کنید
            </p>
          </div>
          <QuickSearch />
        </div>
      </section>
      
      <Services />
      <NewServices />
      <HowItWorks />
      <Features />
      <Testimonials />
      <CTA />
      <BlogPreview />
    </Layout>
  );
};

export default HomePage;