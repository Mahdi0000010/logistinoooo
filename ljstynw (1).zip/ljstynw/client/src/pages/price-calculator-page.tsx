import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Ship,
  Train,
  Calculator,
  PackageCheck,
  ChevronRight,
  DollarSign,
  Loader2
} from "lucide-react";

interface Location {
  id: number;
  name: string;
  type: string;
  country: string;
  city: string;
  coordinates?: string | null;
}

interface ShippingRate {
  id: number;
  originId: number;
  destinationId: number;
  transportType: string;
  pricePerKg: number;
  distance?: number | null;
}

interface CalculationResult {
  railCost: number;
  seaCost: number | null;
  totalCost: number;
  railDistance: number;
  seaDistance?: number | null;
  estimatedDays?: number | null;
  availableShipments?: ShipmentByRoute[];
  seaAvailable?: boolean;
}

interface ShipmentByRoute {
  id: number;
  transporterId: number;
  originId: number;
  destinationId: number;
  departureDate: string;
  arrivalDate: string;
  transportType: string;
  containerType: string | null;
  capacity: number;
  price: number;
  active: boolean;
  isComposite: boolean;
  originName?: string;
  destinationName?: string;
  transporterName?: string;
}

const trainRatePerKgKm = 34; // ریال به ازای هر کیلوگرم در هر کیلومتر

// مسافت‌های مبدا تا بندرعباس (کیلومتر)
const railDistances: Record<string, number> = {
  "تهران": 1300,
  "مشهد": 1400,
  "اصفهان": 1050,
  "تبریز": 1750,
  "شیراز": 800,
  "کرمان": 450,
  "اهواز": 1100,
  "قم": 1150,
  "کرمانشاه": 1550,
  "رشت": 1600,
  "همدان": 1400,
  "اراک": 1250,
  "یزد": 800,
  "زاهدان": 950,
  "اردبیل": 1800,
  "بندرعباس": 0,
};

// مسافت‌های دریایی بین بندرها (کیلومتر)
const seaDistances: Record<string, Record<string, number>> = {
  "بندرعباس": {
    "دبی": 450,
    "شانگهای": 9500,
    "سنگاپور": 6200,
    "روتردام": 12500,
    "بمبئی": 1800,
    "انتورپ": 12200,
    "حایفا": 3800,
    "چابهار": 350,
  }
};

const PriceCalculatorPage = () => {
  const { toast } = useToast();
  const [originCity, setOriginCity] = useState<string>("");
  const [destinationPort, setDestinationPort] = useState<string>("");
  const [cargoWeight, setCargoWeight] = useState<number>(1000);
  const [calculationResult, setCalculationResult] = useState<CalculationResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  // Fetch domestic locations
  const { data: domesticLocations = [] } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
    select: (data) => 
      data.filter((location) => location.country === "ایران" && location.type !== "port") || []
  });

  // Fetch foreign ports
  const { data: foreignPorts = [] } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
    select: (data) => 
      data.filter((location) => location.country !== "ایران" && location.type === "port") || []
  });

  // Fetch shipping rates
  const { data: shippingRates = [] } = useQuery<ShippingRate[]>({
    queryKey: ["/api/shipping-rates"],
  });

  // State to store bandar abbas port id for searches
  const [bandarAbbasId, setBandarAbbasId] = useState<number | null>(null);
  const [selectedDestPortId, setSelectedDestPortId] = useState<number | null>(null);
  
  // Find Bandar Abbas port ID
  const { data: iranianPorts = [] } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
    select: (data) => data.filter(loc => loc.country === "ایران" && loc.type === "port")
  });
  
  // Set Bandar Abbas ID on iranianPorts load
  useEffect(() => {
    if (iranianPorts.length > 0) {
      const bandarAbbas = iranianPorts.find(port => port.name === "بندرعباس");
      if (bandarAbbas) {
        setBandarAbbasId(bandarAbbas.id);
      }
    }
  }, [iranianPorts]);
  
  // Update destination port ID when selection changes
  useEffect(() => {
    if (destinationPort) {
      const destPort = foreignPorts.find(port => port.name === destinationPort);
      if (destPort) {
        setSelectedDestPortId(destPort.id);
      }
    } else {
      setSelectedDestPortId(null);
    }
  }, [destinationPort, foreignPorts]);
  
  // Fetch available shipments between Bandar Abbas and destination using our new API route
  const { data: availableShipments = [], isLoading: isLoadingShipments } = useQuery<ShipmentByRoute[]>({
    queryKey: ["/api/shipments/route", bandarAbbasId, selectedDestPortId],
    queryFn: async () => {
      if (!bandarAbbasId || !selectedDestPortId) return [];
      const response = await fetch(`/api/shipments/route?originId=${bandarAbbasId}&destinationId=${selectedDestPortId}`);
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!bandarAbbasId && !!selectedDestPortId
  });

  // Calculation mutation with API
  const calculationMutation = useMutation({
    mutationFn: async (data: { originId: number, destinationId: number, weight: number }) => {
      const response = await apiRequest("POST", "/api/calculate-price", data);
      return response.json();
    },
    onSuccess: (data) => {
      setCalculationResult(data);
      setIsCalculating(false);
    },
    onError: (error) => {
      console.error("Error calculating price:", error);
      toast({
        title: "خطا در محاسبه",
        description: "متأسفانه در هنگام محاسبه قیمت خطایی رخ داد.",
        variant: "destructive"
      });
      setIsCalculating(false);
    }
  });

  const calculatePrice = () => {
    if (!originCity || !destinationPort || !cargoWeight || cargoWeight <= 0) {
      toast({
        title: "خطا در محاسبه",
        description: "لطفاً تمام فیلدها را به درستی پر کنید.",
        variant: "destructive"
      });
      return;
    }

    setIsCalculating(true);

    // پیدا کردن ID مبدأ
    const originLocation = domesticLocations.find(loc => loc.name === originCity);
    // پیدا کردن ID مقصد
    const destinationLocation = foreignPorts.find(loc => loc.name === destinationPort);

    if (!originLocation || !destinationLocation) {
      toast({
        title: "خطا در محاسبه",
        description: "مبدأ یا مقصد در سیستم یافت نشد.",
        variant: "destructive"
      });
      setIsCalculating(false);
      return;
    }

    // درخواست API برای محاسبه قیمت - سیستم به طور خودکار نوع حمل و نقل را تشخیص می‌دهد
    calculationMutation.mutate({
      originId: originLocation.id,
      destinationId: destinationLocation.id,
      weight: cargoWeight
    });
  };

  // تبدیل عدد به فرمت پول ایران
  const formatPrice = (price: number) => {
    return price.toLocaleString("fa-IR");
  };

  return (
    <Layout>
      <div className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <div className="flex items-center text-sm text-gray-500 mb-6">
            <a href="/" className="hover:text-primary transition">صفحه اصلی</a>
            <ChevronRight size={16} className="mx-2" />
            <span className="text-gray-700">محاسبه قیمت حمل و نقل ترکیبی</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Calculator Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calculator className="ml-2" size={20} />
                    محاسبه قیمت حمل و نقل ترکیبی (ریلی + دریایی)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* مبدأ داخلی */}
                      <div className="space-y-2">
                        <Label htmlFor="originCity">شهر مبدأ (ایران)</Label>
                        <Select value={originCity} onValueChange={setOriginCity}>
                          <SelectTrigger id="originCity">
                            <SelectValue placeholder="شهر مبدأ را انتخاب کنید" />
                          </SelectTrigger>
                          <SelectContent>
                            {domesticLocations
                              .filter(city => city.type === "inland")
                              .map((city) => (
                                <SelectItem key={city.id} value={city.name}>{city.name}</SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* مقصد خارجی */}
                      <div className="space-y-2">
                        <Label htmlFor="destinationPort">بندر مقصد (خارجی)</Label>
                        <Select value={destinationPort} onValueChange={setDestinationPort}>
                          <SelectTrigger id="destinationPort">
                            <SelectValue placeholder="بندر مقصد را انتخاب کنید" />
                          </SelectTrigger>
                          <SelectContent>
                            {foreignPorts
                              .filter(port => port.type === "port")
                              .map((port) => (
                                <SelectItem key={port.id} value={port.name}>{port.name}</SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* وزن بار */}
                    <div className="space-y-2">
                      <Label htmlFor="cargoWeight">وزن بار (کیلوگرم)</Label>
                      <Input
                        id="cargoWeight"
                        type="number"
                        min="1"
                        value={cargoWeight}
                        onChange={(e) => setCargoWeight(Number(e.target.value))}
                      />
                    </div>

                    {/* توضیحات */}
                    <div className="bg-blue-50 p-4 rounded-lg text-sm text-blue-800">
                      <p>
                        <strong>توجه:</strong> این سیستم هزینه حمل و نقل ترکیبی از شهر مبدأ به بندرعباس با قطار و سپس از بندرعباس به بندر مقصد خارجی با کشتی را محاسبه می‌کند.
                      </p>
                      <p className="mt-2">
                        فرمول محاسبه هزینه حمل با قطار: هزینه = فاصله (کیلومتر) × وزن بار (کیلوگرم) × ۳۴ ریال
                      </p>
                    </div>

                    {/* دکمه محاسبه */}
                    <Button 
                      onClick={calculatePrice} 
                      disabled={isCalculating}
                      size="lg" 
                      className="w-full"
                    >
                      {isCalculating ? (
                        <>
                          <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                          در حال محاسبه...
                        </>
                      ) : (
                        <>
                          <Calculator className="ml-2" size={18} />
                          محاسبه قیمت
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* نتیجه محاسبه */}
              {calculationResult && (
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <DollarSign className="ml-2" size={20} />
                      نتیجه محاسبه قیمت
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* مسیر اول - حمل ریلی */}
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <Train className="ml-2 text-primary" size={20} />
                          <h3 className="font-bold">حمل ریلی: {originCity} به بندرعباس</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p className="text-gray-500 text-sm">فاصله:</p>
                            <p className="font-medium">{formatPrice(calculationResult.railDistance)} کیلومتر</p>
                          </div>
                          <div>
                            <p className="text-gray-500 text-sm">وزن بار:</p>
                            <p className="font-medium">{formatPrice(cargoWeight)} کیلوگرم</p>
                          </div>
                          <div>
                            <p className="text-gray-500 text-sm">هزینه حمل:</p>
                            <p className="font-medium">{formatPrice(calculationResult.railCost)} ریال</p>
                          </div>
                        </div>
                      </div>

                      {/* مسیر دوم - حمل دریایی */}
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex items-center mb-3">
                          <Ship className="ml-2 text-primary" size={20} />
                          <h3 className="font-bold">حمل دریایی: بندرعباس به {destinationPort}</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p className="text-gray-500 text-sm">فاصله تقریبی:</p>
                            <p className="font-medium">
                              {calculationResult.seaDistance 
                                ? `${formatPrice(calculationResult.seaDistance)} کیلومتر` 
                                : "نامشخص"}
                            </p>
                          </div>
                          <div>
                            <p className="text-gray-500 text-sm">وزن بار:</p>
                            <p className="font-medium">{formatPrice(cargoWeight)} کیلوگرم</p>
                          </div>
                          <div>
                            <p className="text-gray-500 text-sm">هزینه حمل:</p>
                            <p className="font-medium">
                              {calculationResult.seaCost 
                                ? `${formatPrice(calculationResult.seaCost)} ریال` 
                                : calculationResult.seaAvailable === false 
                                  ? "موجود نیست" 
                                  : "نامشخص (نیاز به استعلام)"}
                            </p>
                          </div>
                        </div>
                        
                        {/* سرویس‌های حمل و نقل موجود */}
                        {availableShipments && availableShipments.length > 0 && (
                          <div className="mt-4 border-t pt-4">
                            <h4 className="font-bold mb-3">سرویس‌های حمل و نقل دریایی موجود:</h4>
                            <div className="space-y-3">
                              {availableShipments.map((shipment) => (
                                <div key={shipment.id} className="bg-white rounded-lg p-3 border border-green-100 shadow-sm">
                                  <div className="flex justify-between items-center mb-2">
                                    <h5 className="font-semibold text-primary">
                                      {shipment.transporterName} - {shipment.transportType === 'sea' ? 'کشتی' : 'ترکیبی'}
                                    </h5>
                                    <span className="inline-flex items-center py-1 px-2 rounded-md bg-green-50 text-green-700 text-sm">
                                      <PackageCheck size={14} className="ml-1" />
                                      فعال
                                    </span>
                                  </div>
                                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                    <div>
                                      <p className="text-gray-500">تاریخ حرکت:</p>
                                      <p>{new Date(shipment.departureDate).toLocaleDateString('fa-IR')}</p>
                                    </div>
                                    <div>
                                      <p className="text-gray-500">تاریخ رسیدن:</p>
                                      <p>{new Date(shipment.arrivalDate).toLocaleDateString('fa-IR')}</p>
                                    </div>
                                    <div>
                                      <p className="text-gray-500">ظرفیت:</p>
                                      <p>{formatPrice(shipment.capacity)} کیلوگرم</p>
                                    </div>
                                    <div>
                                      <p className="text-gray-500">قیمت پایه:</p>
                                      <p className="font-bold text-primary">{formatPrice(shipment.price)} ریال</p>
                                    </div>
                                  </div>
                                  <div className="mt-3">
                                    <Button variant="outline" size="sm" className="w-full md:w-auto">
                                      مشاهده جزئیات
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                            {isLoadingShipments && (
                              <div className="flex justify-center py-3">
                                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      <Separator />

                      {/* جمع کل */}
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-gray-700 font-medium">مجموع هزینه حمل و نقل:</p>
                          <p className="text-xs text-gray-500">شامل حمل ریلی و دریایی</p>
                        </div>
                        <div className="text-xl font-bold text-primary">
                          {formatPrice(calculationResult.totalCost)} ریال
                        </div>
                      </div>

                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-gray-700 font-medium">مدت زمان تقریبی:</p>
                          <p className="text-xs text-gray-500">از مبدأ تا مقصد</p>
                        </div>
                        <div className="text-lg font-medium">
                          {calculationResult.estimatedDays} روز
                        </div>
                      </div>
                      
                      <div className="bg-yellow-50 p-3 rounded-lg text-sm text-yellow-800">
                        <p>
                          <strong>توجه:</strong> محاسبات فوق تقریبی هستند و ممکن است بر اساس شرایط واقعی (زمان سفر، شرایط آب و هوایی، تعرفه‌های دقیق و...) تغییر کنند.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* محموله‌های موجود */}
              {calculationResult?.availableShipments && calculationResult.availableShipments.length > 0 && (
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <PackageCheck className="ml-2" size={20} />
                      محموله‌های فعال در این مسیر
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {calculationResult.availableShipments.map((shipment: any) => (
                        <div key={shipment.id} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h3 className="font-bold">{shipment.description || `حمل و نقل ${shipment.transportType === "sea" ? "دریایی" : "هوایی"}`}</h3>
                              <p className="text-sm text-gray-500">شرکت: {shipment.transporter?.companyName || "نامشخص"}</p>
                            </div>
                            <div className="bg-primary text-white px-3 py-1 rounded-full text-sm">
                              {formatPrice(shipment.price)} ریال
                            </div>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                            <div>
                              <p className="text-xs text-gray-500">تاریخ حرکت:</p>
                              <p className="font-medium">{shipment.departureDate}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">تاریخ رسیدن:</p>
                              <p className="font-medium">{shipment.arrivalDate}</p>
                            </div>
                          </div>
                          <div className="flex justify-end">
                            <Button variant="outline" size="sm" asChild>
                              <a href={`/shipment/${shipment.id}`}>
                                مشاهده جزئیات
                                <ChevronRight className="mr-1" size={16} />
                              </a>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* راهنما و اطلاعات */}
            <div>
              <Card className="sticky top-4">
                <CardHeader>
                  <CardTitle>راهنمای محاسبه قیمت</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-bold text-base mb-2">نحوه محاسبه</h3>
                      <p className="text-gray-600 text-sm">
                        محاسبه قیمت برای حمل و نقل ترکیبی ریلی-دریایی در دو مرحله انجام می‌شود:
                      </p>
                      <ol className="mt-2 text-sm space-y-1 list-decimal list-inside">
                        <li>حمل ریلی از شهر مبدأ تا بندرعباس</li>
                        <li>حمل دریایی از بندرعباس تا بندر مقصد خارجی</li>
                      </ol>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-bold text-base mb-2">مزایای حمل و نقل ترکیبی</h3>
                      <ul className="mt-2 text-sm space-y-1">
                        <li className="flex items-start">
                          <div className="flex-shrink-0 h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mt-0.5 ml-2">
                            <svg className="h-3 w-3 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          </div>
                          <span className="text-gray-700">کاهش هزینه‌های کلی حمل و نقل</span>
                        </li>
                        <li className="flex items-start">
                          <div className="flex-shrink-0 h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mt-0.5 ml-2">
                            <svg className="h-3 w-3 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          </div>
                          <span className="text-gray-700">بهینه‌سازی مسیر و کاهش زمان حمل</span>
                        </li>
                        <li className="flex items-start">
                          <div className="flex-shrink-0 h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mt-0.5 ml-2">
                            <svg className="h-3 w-3 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          </div>
                          <span className="text-gray-700">کاهش اثرات زیست‌محیطی حمل و نقل</span>
                        </li>
                        <li className="flex items-start">
                          <div className="flex-shrink-0 h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mt-0.5 ml-2">
                            <svg className="h-3 w-3 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          </div>
                          <span className="text-gray-700">امکان حمل مقادیر بیشتر بار</span>
                        </li>
                      </ul>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-bold text-base mb-2">نیاز به کمک بیشتر؟</h3>
                      <p className="text-gray-600 text-sm">
                        برای دریافت اطلاعات دقیق‌تر یا استعلام قیمت ویژه، با کارشناسان ما تماس بگیرید.
                      </p>
                      <Button variant="outline" className="w-full mt-3">
                        تماس با کارشناسان
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default PriceCalculatorPage;