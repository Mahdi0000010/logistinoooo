import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { formatPrice, formatCurrency } from "@/lib/utils";

// تعریف انواع داده‌ها
interface Location {
  id: number;
  name: string;
  type: string;
  country: string;
  city: string;
  coordinates?: string | null;
}

interface Transporter {
  id: number;
  name?: string;
  companyName: string;
  userId: number;
  transporterType: string;
  contactEmail: string;
  contactPhone: string;
  address?: string | null;
  companyDescription?: string | null;
  verified?: boolean | null;
  rating?: number;
  reviewCount?: number;
}

interface ShipmentSegment {
  id: number;
  shipmentId: number;
  originId: number;
  destinationId: number;
  origin?: Location;
  destination?: Location;
  departureDate: string;
  arrivalDate: string;
  transportType: string;
  containerType: string | null;
  capacity: number;
  price: number;
  description?: string | null;
  segmentOrder: number;
  createdAt?: Date | null;
}

interface SegmentInfo {
  from: string;
  to: string;
  distance: number;
  duration: number;
  transportType: string;
}

interface Shipment {
  id: number | string;
  transporterId: number;
  originId: number;
  destinationId: number;
  origin?: Location;
  destination?: Location;
  departureDate: string;
  arrivalDate: string;
  transportType: string;
  containerType: string | null;
  capacity: number;
  price: number;
  insuranceAvailable: boolean;
  insurancePrice: number;
  active: boolean;
  description?: string;
  isComposite: boolean;
  transporter?: Transporter;
  features?: string[];
  specifications?: Record<string, string>;
  rating?: number;
  distance?: number | null; // فاصله (کیلومتر) برای حمل و نقل ریلی
  duration?: number | null; // مدت زمان (دقیقه) برای مسیر
  calculatedPrice?: number | null; // قیمت محاسبه شده براساس وزن و فاصله
  smartRouting?: boolean; // آیا این نتیجه از مسیریابی هوشمند آمده است
  suggested?: boolean; // آیا این مسیر پیشنهادی است
  segmentInfo?: SegmentInfo; // اطلاعات سگمنت برای مسیرهای ترکیبی
  transportPrice?: {
    priceRial: number | null;
    priceToman: number | null;
    usedWeight?: number;
    weightInTons?: number;
    rate?: number;
    vehicleType?: string;
    vehicleDisplayName?: string;
    formulaDescription?: string | null;
  }; // قیمت محاسبه شده با جزئیات کامل
  transportDetails?: {
    vehicleType: string;
    vehicleDisplayName: string;
    baseRate: number;
    baseRateDescription: string;
  }; // جزئیات حمل و نقل
  
  // اطلاعات اضافی برای نمایش در صفحه جزئیات
  originName?: string;
  destinationName?: string;
  originCountry?: string;
  destinationCountry?: string;
  transporterName?: string;
}
import {
  Ship,
  Truck,
  Train,
  Calendar,
  Clock,
  MapPin,
  Box,
  DollarSign,
  ShieldCheck,
  Layers,
  FileText,
  Star,
  ChevronRight
} from "lucide-react";

const ShipmentDetailsPage = () => {
  const [, params] = useRoute("/shipment/:id");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [quantity, setQuantity] = useState(1);
  const [withInsurance, setWithInsurance] = useState(false);
  
  const shipmentId = params?.id ? parseInt(params.id) : 0;

  // دریافت پارامترهای URL برای وزن محموله
  const searchParams = new URLSearchParams(window.location.search);
  const cargoWeight = searchParams.get('cargoWeight') || '7000'; // مقدار پیش‌فرض برای وزن: 7 تن

  // Check if the ID is a smart routing ID (starts with 'smart-')
  const isSmartRouting = (params?.id || '').toString().startsWith('smart-');
  
  // Fetch shipment details with cargo weight parameter
  const { data: shipment, isLoading: isLoadingShipment } = useQuery<Shipment>({
    queryKey: [`/api/shipments/${isSmartRouting ? 'smart' : shipmentId}`, cargoWeight],
    queryFn: async () => {
      const urlParams = new URLSearchParams();
      urlParams.append('cargoWeight', cargoWeight);
      
      // If it's a smart routing ID, use the smart routing endpoint
      if (isSmartRouting) {
        const [_, fromId, toId, transportType] = (params?.id || '').toString().split('-');
        
        // اطمینان از معتبر بودن پارامترها
        if (!fromId || !toId) {
          toast({
            title: "خطا در بارگیری اطلاعات",
            description: "مشکلی در شناسایی مبدا و مقصد رخ داده است",
            variant: "destructive",
          });
          navigate('/search');
          return {};
        }
        
        urlParams.append('fromLocationId', fromId);
        urlParams.append('toLocationId', toId);
        if (transportType) urlParams.append('transportType', transportType);
        
        const requestUrl = `/api/smart-routing/shipment?${urlParams.toString()}`;
        console.log('Smart Routing Shipment request URL:', requestUrl);
        
        try {
          const response = await fetch(requestUrl);
          if (!response.ok) {
            throw new Error(`خطای ${response.status}: ${response.statusText}`);
          }
          const data = await response.json();
          return data;
        } catch (error) {
          console.error("Error fetching smart routing shipment:", error);
          toast({
            title: "خطا در بارگیری اطلاعات",
            description: "مشکلی در دریافت اطلاعات مسیر رخ داده است",
            variant: "destructive",
          });
          navigate('/search');
          return {};
        }
      } else {
        const requestUrl = `/api/shipments/${shipmentId}${urlParams.toString() ? `?${urlParams.toString()}` : ''}`;
        const response = await fetch(requestUrl);
        return await response.json();
      }
    },
    enabled: shipmentId > 0 || isSmartRouting
  });

  // Fetch shipment segments if it's a composite shipment
  const { data: segments = [], isLoading: isLoadingSegments } = useQuery<ShipmentSegment[]>({
    queryKey: [`/api/shipments/${shipmentId}/segments`],
    enabled: shipmentId > 0 && shipment?.isComposite === true
  });

  // For loading state we need to check both shipment and segments loading states
  const isLoading = isLoadingShipment || (shipment?.isComposite && isLoadingSegments);

  const handleQuantityChange = (value: number) => {
    if (value >= 1 && value <= (shipment?.capacity || 10)) {
      setQuantity(value);
    }
  };

  const calculateTotal = () => {
    if (!shipment) return 0;
    
    // استفاده از قیمت محاسبه شده در transportPrice در صورت وجود
    if (shipment.transportPrice && shipment.transportPrice.priceToman !== null) {
      let total = shipment.transportPrice.priceToman * quantity;
      if (withInsurance && shipment.insuranceAvailable) {
        total += shipment.insurancePrice * quantity;
      }
      return total;
    }
    // استفاده از قیمت محاسبه شده در calculatedPrice در صورت وجود
    else if (shipment.calculatedPrice) {
      let total = shipment.calculatedPrice * quantity;
      if (withInsurance && shipment.insuranceAvailable) {
        total += shipment.insurancePrice * quantity;
      }
      return total;
    }
    // در غیر این صورت از قیمت پایه استفاده کن
    else {
      let total = shipment.price * quantity;
      if (withInsurance && shipment.insuranceAvailable) {
        total += shipment.insurancePrice * quantity;
      }
      return total;
    }
  };

  const handleBooking = () => {
    if (!user) {
      toast({
        title: "لطفاً وارد حساب کاربری خود شوید",
        description: "برای رزرو محموله، ابتدا باید وارد حساب کاربری خود شوید.",
        variant: "destructive"
      });
      navigate("/auth");
      return;
    }

    // This would be an API call in a real app
    toast({
      title: "رزرو با موفقیت انجام شد",
      description: "درخواست رزرو شما با موفقیت ثبت شد و در انتظار تأیید است.",
    });
    navigate("/dashboard?tab=shipments");
  };

  // استفاده از تابع formatPrice از ماژول utils برای استاندارد سازی نمایش قیمت در کل سیستم

  // Function to get transport icon
  const getTransportIcon = (type: string) => {
    switch (type) {
      case "sea":
        return <Ship size={20} className="ml-2" />;
      case "land":
        return <Truck size={20} className="ml-2" />;
      case "rail":
        return <Train size={20} className="ml-2" />;
      case "mixed":
        return (
          <div className="flex">
            <Ship size={20} className="ml-1" />
            <Truck size={20} className="ml-1" />
            <Train size={20} className="ml-1" />
          </div>
        );
      default:
        return <Ship size={20} className="ml-2" />;
    }
  };

  // Function to get container type name or vehicle type name
  const getContainerTypeName = (type: string) => {
    // اگر اطلاعات نوع وسیله نقلیه از transportDetails موجود است، از آن استفاده کن
    if (shipment?.transportDetails?.vehicleDisplayName) {
      return shipment.transportDetails.vehicleDisplayName;
    }
    
    switch (type) {
      // کانتینرها
      case "20_standard":
        return "کانتینر ۲۰ فوت استاندارد";
      case "40_standard":
        return "کانتینر ۴۰ فوت استاندارد";
      case "20_refrigerated":
        return "کانتینر ۲۰ فوت یخچالی";
      case "40_refrigerated":
        return "کانتینر ۴۰ فوت یخچالی";
      
      // وسایل نقلیه زمینی
      case "وانت":
        return "وانت‌بار (مناسب برای بارهای تا ۲ تن)";
      case "نیسان":
        return "نیسان (مناسب برای بارهای تا ۵ تن)";
      case "خاور":
        return "خاور (مناسب برای بارهای تا ۱۰ تن)";
      case "کامیون":
        return "کامیون (مناسب برای بارهای تا ۲۰ تن)";
      case "تریلی":
        return "تریلی (مناسب برای بارهای بیش از ۲۰ تن)";
      case "تریلی کشنده":
        return "تریلی کشنده (مناسب برای کانتینرها)";
        
      // وسایل نقلیه ریلی
      case "واگن باری":
        return "واگن باری قطار";
        
      // وسایل نقلیه دریایی
      case "کشتی حمل بار":
        return "کشتی باری";
        
      default:
        return type;
    }
  };

  return (
    <Layout>
      <div className="py-8 bg-gray-50">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <div className="flex items-center text-sm text-gray-500 mb-6">
            <a href="/" className="hover:text-primary transition">صفحه اصلی</a>
            <ChevronRight size={16} className="mx-2" />
            <a href="/search" className="hover:text-primary transition">جستجوی محموله</a>
            <ChevronRight size={16} className="mx-2" />
            <span className="text-gray-700">جزئیات محموله</span>
          </div>

          {isLoading ? (
            // Loading skeleton
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="mb-6">
                  <CardContent className="p-6">
                    <Skeleton className="h-10 w-3/4 mb-6" />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <Skeleton className="h-28" />
                      <Skeleton className="h-28" />
                    </div>
                    <Skeleton className="h-8 w-1/3 mb-4" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-3/4 mb-6" />
                    <Skeleton className="h-8 w-1/3 mb-4" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div>
                <Card>
                  <CardContent className="p-6">
                    <Skeleton className="h-8 w-1/2 mb-4" />
                    <Skeleton className="h-6 w-full mb-3" />
                    <Skeleton className="h-6 w-full mb-3" />
                    <Skeleton className="h-6 w-full mb-6" />
                    <Skeleton className="h-10 w-full" />
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : shipment ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Shipment Details */}
              <div className="lg:col-span-2">
                <Card className="mb-6">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
                      <h1 className="text-2xl font-bold">{shipment.description || "حمل و نقل محموله"}</h1>
                      {shipment.rating && (
                        <div className="flex items-center">
                          <div className="flex items-center text-amber-500">
                            <Star className="fill-amber-500" size={18} />
                            <span className="mr-1 font-medium">{shipment.rating}</span>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      {/* Origin/Destination */}
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex items-center mb-4">
                          <MapPin className="ml-2 text-primary" size={20} />
                          <h3 className="font-bold">مسیر حمل</h3>
                        </div>
                        <div className="flex items-center">
                          <div className="text-center flex-1">
                            <p className="text-gray-500 text-sm mb-1">مبدا</p>
                            <p className="font-medium">{shipment.origin?.name || "-"}</p>
                            <p className="text-xs text-gray-500">{shipment.origin?.country || "-"}</p>
                          </div>
                          <div className="w-16 h-0.5 bg-gray-300 mx-2 relative">
                            {getTransportIcon(shipment.transportType)}
                          </div>
                          <div className="text-center flex-1">
                            <p className="text-gray-500 text-sm mb-1">مقصد</p>
                            <p className="font-medium">{shipment.destination?.name || "-"}</p>
                            <p className="text-xs text-gray-500">{shipment.destination?.country || "-"}</p>
                          </div>
                        </div>
                      </div>

                      {/* Schedule */}
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex items-center mb-4">
                          <Calendar className="ml-2 text-primary" size={20} />
                          <h3 className="font-bold">زمان‌بندی</h3>
                        </div>
                        <div className="flex items-center">
                          <div className="text-center flex-1">
                            <p className="text-gray-500 text-sm mb-1">تاریخ حرکت</p>
                            <p className="font-medium">{shipment.departureDate}</p>
                          </div>
                          <div className="w-16 h-0.5 bg-gray-300 mx-2 relative">
                            <Clock className="absolute -top-2.5 left-1/2 transform -translate-x-1/2 text-gray-500" size={16} />
                          </div>
                          <div className="text-center flex-1">
                            <p className="text-gray-500 text-sm mb-1">تاریخ رسیدن</p>
                            <p className="font-medium">{shipment.arrivalDate}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Transporter Info */}
                    <div className="mb-6">
                      <h3 className="font-bold text-lg mb-3">اطلاعات شرکت حمل و نقل</h3>
                      <div className="flex items-center bg-gray-50 p-4 rounded-lg">
                        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center ml-4">
                          <Ship className="text-primary" size={20} />
                        </div>
                        <div>
                          <h4 className="font-medium flex items-center">
                            {shipment.transporter?.name || shipment.transporter?.companyName || "شرکت حمل و نقل"}
                            {shipment.transporter?.verified && (
                              <span className="mr-2 bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">تأیید شده</span>
                            )}
                          </h4>
                          <div className="flex items-center text-sm text-gray-500 mt-1">
                            <Star className="fill-amber-500 text-amber-500" size={14} />
                            <span className="mr-1">{shipment.transporter?.rating || 0}</span>
                            <span className="mr-1">({shipment.transporter?.reviewCount || 0} نظر)</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Shipment Description */}
                    <div className="mb-6">
                      <h3 className="font-bold text-lg mb-3">توضیحات</h3>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <div className="text-gray-700">
                          <div>
                            خدمات حمل و نقل {shipment.transportType === "sea" ? "دریایی" : 
                            shipment.transportType === "land" ? "زمینی" : 
                            shipment.transportType === "rail" ? "ریلی" : "ترکیبی"} از {shipment.origin?.name || "-"} به {shipment.destination?.name || "-"} 
                            {shipment.containerType && ` با استفاده از ${getContainerTypeName(shipment.containerType)}`}.
                            این سرویس با تضمین تحویل به موقع و پشتیبانی ۲۴ ساعته ارائه می‌شود.
                          </div>
                          {shipment.description && <div className="mt-2">{shipment.description}</div>}
                          {shipment.transportType === "rail" && (
                            <div className="mt-4 pt-4 border-t border-gray-200">
                              <div className="font-medium text-primary mb-2">قیمت‌گذاری حمل و نقل ریلی:</div>
                              <div>قیمت هر کیلوگرم بار در هر کیلومتر: <strong>۳۴ ریال</strong></div>
                              {shipment.origin && shipment.destination && (
                                <div className="mt-2">
                                  <div><span className="font-medium">مسیر فعلی: </span>{shipment.origin.name} به {shipment.destination.name}</div>
                                  <div className="mt-1">ظرفیت: {shipment.capacity} تن</div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Features */}
                    {shipment.features && shipment.features.length > 0 && (
                      <div className="mb-6">
                        <h3 className="font-bold text-lg mb-3">ویژگی‌ها</h3>
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <ul className="space-y-2">
                            {shipment.features.map((feature, index) => (
                              <li key={index} className="flex items-start">
                                <div className="flex-shrink-0 h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mt-0.5 ml-2">
                                  <svg className="h-3 w-3 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                  </svg>
                                </div>
                                <span className="text-gray-700">{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}

                    {/* Technical Specifications */}
                    <Tabs defaultValue={shipment.isComposite ? "segments" : (shipment.transportType === "rail" || shipment.transportType === "mixed" || shipment.smartRouting ? "rail_route" : "specifications")}>
                      <TabsList className="mb-4">
                        {shipment.isComposite && (
                          <TabsTrigger value="segments">قطعات مسیر</TabsTrigger>
                        )}
                        {(shipment.transportType === "rail" || shipment.transportType === "mixed" || shipment.smartRouting) && (
                          <TabsTrigger value="rail_route">
                            {shipment.smartRouting ? "مسیر هوشمند" : 
                            shipment.transportType === "rail" ? "مسیر ریلی" : 
                            "مسیر ترکیبی"}
                          </TabsTrigger>
                        )}
                        <TabsTrigger value="specifications">مشخصات فنی</TabsTrigger>
                        <TabsTrigger value="documents">مدارک لازم</TabsTrigger>
                        <TabsTrigger value="insurance">اطلاعات بیمه</TabsTrigger>
                      </TabsList>
                      
                      {shipment.isComposite && (
                        <TabsContent value="segments" className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-medium mb-4">قطعات مسیر حمل و نقل ترکیبی:</h4>
                          {segments && segments.length > 0 ? (
                            <div className="space-y-4">
                              {segments.map((segment, index) => (
                                <div key={segment.id} className="border border-gray-200 rounded-lg p-4 bg-white">
                                  <div className="flex items-center justify-between mb-3">
                                    <div className="flex items-center">
                                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center ml-2">
                                        <span className="font-bold text-primary">{index + 1}</span>
                                      </div>
                                      <h5 className="font-medium">قطعه {index + 1}: حمل و نقل {
                                        segment.transportType === "sea" ? "دریایی" : 
                                        segment.transportType === "land" ? "زمینی" : 
                                        segment.transportType === "rail" ? "ریلی" : "هوایی"
                                      }</h5>
                                    </div>
                                    <div className="flex items-center">
                                      {getTransportIcon(segment.transportType)}
                                    </div>
                                  </div>
                                  
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="flex items-center">
                                      <MapPin className="ml-2 text-gray-500" size={16} />
                                      <div>
                                        <div className="text-sm text-gray-500">مسیر:</div>
                                        <div className="font-medium">{segment.origin?.name} به {segment.destination?.name}</div>
                                      </div>
                                    </div>
                                    <div className="flex items-center">
                                      <Calendar className="ml-2 text-gray-500" size={16} />
                                      <div>
                                        <div className="text-sm text-gray-500">تاریخ حرکت/رسیدن:</div>
                                        <div className="font-medium">{segment.departureDate} - {segment.arrivalDate}</div>
                                      </div>
                                    </div>
                                    <div className="flex items-center">
                                      <Box className="ml-2 text-gray-500" size={16} />
                                      <div>
                                        <div className="text-sm text-gray-500">نوع کانتینر:</div>
                                        <div className="font-medium">{getContainerTypeName(segment.containerType || "")}</div>
                                      </div>
                                    </div>
                                    <div className="flex items-center">
                                      <DollarSign className="ml-2 text-gray-500" size={16} />
                                      <div>
                                        <div className="text-sm text-gray-500">قیمت:</div>
                                        <div className="font-medium">{formatPrice(segment.price)} تومان</div>
                                      </div>
                                    </div>
                                  </div>
                                  
                                  {segment.description && (
                                    <div className="mt-3 pt-3 border-t border-gray-100">
                                      <div className="text-sm text-gray-700">{segment.description}</div>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="text-center py-4">
                              <p className="text-gray-500">هیچ قطعه‌ای برای این مسیر ثبت نشده است.</p>
                            </div>
                          )}
                        </TabsContent>
                      )}

                      {(shipment.transportType === "rail" || shipment.transportType === "mixed" || shipment.smartRouting) && (
                        <TabsContent value="rail_route" className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-medium mb-4">جزئیات مسیر {shipment.smartRouting ? "هوشمند" : shipment.transportType === "rail" ? "ریلی" : "ترکیبی"}:</h4>
                          
                          <div className="space-y-6">
                            {/* اطلاعات مسیر */}
                            <div className="bg-white border border-gray-200 rounded-lg p-4">
                              <div className="flex items-center mb-3">
                                {shipment.transportType === "rail" ? (
                                  <Train className="ml-2 text-primary" size={20} />
                                ) : shipment.transportType === "sea" ? (
                                  <Ship className="ml-2 text-primary" size={20} />
                                ) : shipment.transportType === "land" ? (
                                  <Truck className="ml-2 text-primary" size={20} />
                                ) : (
                                  <div className="flex ml-2">
                                    <Train className="text-primary" size={20} />
                                    <Ship className="text-primary ml-1" size={20} />
                                    <Truck className="text-primary" size={20} />
                                  </div>
                                )}
                                <h5 className="font-medium">مسیر حمل و نقل {
                                  shipment.transportType === "rail" ? "ریلی" :
                                  shipment.transportType === "sea" ? "دریایی" :
                                  shipment.transportType === "land" ? "زمینی" : "ترکیبی"
                                }</h5>
                                {shipment.smartRouting && <span className="mr-2 text-sm text-green-600 bg-green-50 px-2 py-0.5 rounded">مسیریابی هوشمند</span>}
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                  <p className="text-gray-500 text-sm mb-1">مبدا:</p>
                                  <p className="font-medium">{shipment.origin?.name || shipment.originName || "-"}</p>
                                  <p className="text-xs text-gray-500">{shipment.origin?.country || shipment.originCountry || "-"}</p>
                                </div>
                                <div>
                                  <p className="text-gray-500 text-sm mb-1">مقصد:</p>
                                  <p className="font-medium">{shipment.destination?.name || shipment.destinationName || "-"}</p>
                                  <p className="text-xs text-gray-500">{shipment.destination?.country || shipment.destinationCountry || "-"}</p>
                                </div>
                              </div>
                              
                              {shipment.segmentInfo && (
                                <div className="mt-4 border-t pt-4">
                                  <h6 className="font-medium text-sm mb-3 text-primary">اطلاعات قطعه مسیر:</h6>
                                  <div className="bg-gray-50 p-3 rounded">
                                    <div className="flex items-center mb-2">
                                      <MapPin size={16} className="ml-1 text-primary" />
                                      <span className="text-sm">{shipment.segmentInfo.from} به {shipment.segmentInfo.to}</span>
                                    </div>
                                    <div className="grid grid-cols-3 gap-2 text-sm mt-2">
                                      <div className="flex items-center">
                                        <span className="text-gray-600 ml-1">فاصله:</span> 
                                        <span>{shipment.segmentInfo.distance.toLocaleString("fa-IR")} کیلومتر</span>
                                      </div>
                                      <div className="flex items-center">
                                        <span className="text-gray-600 ml-1">زمان:</span> 
                                        <span>{Math.floor(shipment.segmentInfo.duration / 60)} ساعت و {shipment.segmentInfo.duration % 60} دقیقه</span>
                                      </div>
                                      <div className="flex items-center">
                                        <span className="text-gray-600 ml-1">وسیله:</span>
                                        <span>{
                                          shipment.segmentInfo.transportType === "sea" ? "دریایی" : 
                                          shipment.segmentInfo.transportType === "land" ? "زمینی" : 
                                          shipment.segmentInfo.transportType === "rail" ? "ریلی" : "ترکیبی"
                                        }</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                            
                            {/* اطلاعات قیمت‌گذاری */}
                            <div className="bg-white border border-gray-200 rounded-lg p-4">
                              <div className="flex items-center mb-3">
                                <DollarSign className="ml-2 text-primary" size={20} />
                                <h5 className="font-medium">جزئیات قیمت‌گذاری</h5>
                              </div>
                              
                              <div className="space-y-3">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  {shipment.transportType === 'rail' ? (
                                    <div>
                                      <p className="text-gray-500 text-sm mb-1">قیمت هر کیلوگرم-کیلومتر:</p>
                                      <p className="font-medium">۳۴ ریال</p>
                                    </div>
                                  ) : shipment.transportType === 'land' ? (
                                    <div>
                                      <p className="text-gray-500 text-sm mb-1">نوع وسیله نقلیه:</p>
                                      <p className="font-medium">{shipment.containerType || 'کامیون'}</p>
                                    </div>
                                  ) : (
                                    <div>
                                      <p className="text-gray-500 text-sm mb-1">نوع حمل و نقل:</p>
                                      <p className="font-medium">
                                        {shipment.transportType === 'sea' ? 'دریایی' : 'ترکیبی'}
                                      </p>
                                    </div>
                                  )}
                                  <div>
                                    <p className="text-gray-500 text-sm mb-1">مسافت مسیر:</p>
                                    <p className="font-medium">{shipment.distance ? shipment.distance.toLocaleString("fa-IR") : "نامشخص"} کیلومتر</p>
                                  </div>
                                  <div>
                                    <p className="text-gray-500 text-sm mb-1">ظرفیت کل:</p>
                                    <p className="font-medium">{shipment.capacity.toLocaleString("fa-IR")} کیلوگرم</p>
                                  </div>
                                  <div>
                                    <p className="text-gray-500 text-sm mb-1">قیمت پایه:</p>
                                    <p className="font-medium">{formatPrice(shipment.price)} تومان</p>
                                  </div>
                                </div>
                                
                                {cargoWeight && (shipment.transportPrice?.priceToman || shipment.calculatedPrice) && (
                                  <div className="bg-primary/10 rounded-lg p-3 mt-3">
                                    <div className="flex justify-between items-center">
                                      <div className="font-medium text-primary">قیمت محاسبه شده برای محموله شما:</div>
                                      <div className="text-lg font-bold text-primary">
                                        {shipment.transportPrice?.priceToman ? formatPrice(shipment.transportPrice.priceToman) : 
                                         shipment.calculatedPrice ? formatPrice(shipment.calculatedPrice) : 
                                         formatPrice(shipment.price)} تومان
                                      </div>
                                    </div>
                                    {shipment.transportType === 'rail' ? (
                                      <div className="text-xs text-gray-600 mt-2 text-center">
                                        <span className="inline-block ml-1">{parseInt(cargoWeight).toLocaleString("fa-IR")} کیلوگرم</span> × 
                                        <span className="inline-block mx-1">{shipment.distance?.toLocaleString("fa-IR") || 0} کیلومتر</span> × 
                                        <span className="inline-block mx-1">۳۴ ریال</span> ÷ 
                                        <span className="inline-block mr-1">۱۰</span> = 
                                        <span className="inline-block mr-1 font-medium">{formatPrice(shipment.calculatedPrice || 0)} تومان</span>
                                      </div>
                                    ) : shipment.transportType === 'land' ? (
                                      <div className="text-xs text-gray-600 mt-2 text-center">
                                        <span className="inline-block ml-1">
                                          {shipment.transportType === 'land' && shipment.containerType 
                                            ? shipment.containerType === 'land_trailer' || shipment.containerType.includes('trailer')
                                              ? '30'
                                              : shipment.containerType === 'land_truck' || shipment.containerType.includes('truck')
                                                ? '20'
                                                : shipment.containerType === 'land_small_truck' || shipment.containerType.includes('small')
                                                  ? '10'
                                                  : shipment.containerType === 'van' || shipment.containerType.includes('van')
                                                    ? '2'
                                                    : '20'
                                            : '20'} تن
                                        </span> × 
                                        <span className="inline-block mx-1">{shipment.distance?.toLocaleString("fa-IR") || 0} کیلومتر</span> × 
                                        <span className="inline-block mx-1">
                                          {shipment.transportType === 'land' && shipment.containerType
                                            ? shipment.containerType === 'land_trailer' || shipment.containerType.includes('trailer')
                                              ? '9,500'
                                              : shipment.containerType === 'land_truck' || shipment.containerType.includes('truck')
                                                ? '10,000'
                                                : shipment.containerType === 'land_small_truck' || shipment.containerType.includes('small')
                                                  ? '13,500'
                                                  : shipment.containerType === 'van' || shipment.containerType.includes('van')
                                                    ? '17,500'
                                                    : '10,000'
                                            : '10,000'} ریال
                                        </span> ÷ 
                                        <span className="inline-block mr-1">۱۰</span> = 
                                        <span className="inline-block mr-1 font-medium">{formatPrice(shipment.transportPrice?.priceToman || shipment.calculatedPrice || 0)} تومان</span>
                                      </div>
                                    ) : (
                                      <div className="text-xs text-gray-600 mt-2 text-center">
                                        قیمت بر اساس ظرفیت استاندارد و فاصله مسیر محاسبه شده است
                                      </div>
                                    )}
                                  </div>
                                )}
                                
                                <div className="mt-3 pt-3 border-t border-gray-100">
                                  <p className="text-sm text-gray-700">
                                    {cargoWeight 
                                      ? shipment.transportType === 'rail'
                                        ? "قیمت محاسبه شده بر اساس وزن واقعی محموله و مسافت دقیق مسیر ریلی محاسبه شده است."
                                        : shipment.transportType === 'land'
                                          ? "قیمت محاسبه شده بر اساس حداکثر ظرفیت وسیله نقلیه و مسافت دقیق مسیر زمینی محاسبه شده است."
                                          : "قیمت محاسبه شده بر اساس ظرفیت استاندارد حمل و نقل و مسافت مسیر محاسبه شده است."
                                      : "برای محاسبه قیمت دقیق، لطفاً وزن محموله را در صفحه جستجو وارد کنید."}
                                  </p>
                                </div>
                              </div>
                            </div>
                            
                            {/* زمان‌بندی */}
                            <div className="bg-white border border-gray-200 rounded-lg p-4">
                              <div className="flex items-center mb-3">
                                <Calendar className="ml-2 text-primary" size={20} />
                                <h5 className="font-medium">زمان‌بندی حرکت</h5>
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                  <p className="text-gray-500 text-sm mb-1">تاریخ حرکت:</p>
                                  <p className="font-medium">{shipment.departureDate}</p>
                                </div>
                                <div>
                                  <p className="text-gray-500 text-sm mb-1">تاریخ رسیدن:</p>
                                  <p className="font-medium">{shipment.arrivalDate}</p>
                                </div>
                              </div>
                            </div>
                            
                            {/* نکات مهم */}
                            <div className="bg-white border border-gray-200 rounded-lg p-4">
                              <div className="flex items-center mb-3">
                                <svg className="ml-2 text-primary" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                  <circle cx="12" cy="12" r="10"></circle>
                                  <line x1="12" y1="8" x2="12" y2="12"></line>
                                  <line x1="12" y1="16" x2="12.01" y2="16"></line>
                                </svg>
                                <h5 className="font-medium">
                                  {shipment.transportType === 'rail' 
                                    ? 'نکات مهم حمل و نقل ریلی'
                                    : shipment.transportType === 'land'
                                      ? 'نکات مهم حمل و نقل زمینی'
                                      : shipment.transportType === 'sea'
                                        ? 'نکات مهم حمل و نقل دریایی'
                                        : 'نکات مهم حمل و نقل'
                                  }
                                </h5>
                              </div>
                              
                              <ul className="space-y-2 list-disc list-inside text-gray-700">
                                {shipment.transportType === 'rail' ? (
                                  <>
                                    <li>محموله‌ها باید حداقل ۲۴ ساعت قبل از حرکت قطار در ایستگاه مبدا آماده باشند.</li>
                                    <li>حداکثر زمان تحویل محموله در مقصد ۲۴ ساعت پس از رسیدن قطار است.</li>
                                    <li>مسیرهای ریلی دارای برنامه حرکت منظم هستند و تاخیرات احتمالی به اطلاع مشتریان خواهد رسید.</li>
                                    <li>بیمه حمل و نقل ریلی شامل جبران خسارات ناشی از سوانح و تصادفات است.</li>
                                  </>
                                ) : shipment.transportType === 'land' ? (
                                  <>
                                    <li>محموله‌ها باید حداقل ۶ ساعت قبل از حرکت وسیله نقلیه در محل بارگیری آماده باشند.</li>
                                    <li>زمان تحویل محموله بستگی به مسافت، شرایط جوی و ترافیک مسیر دارد.</li>
                                    <li>تمامی وسایل نقلیه مجهز به سیستم ردیابی آنلاین (GPS) هستند.</li>
                                    <li>رعایت محدودیت وزن بار برای هر وسیله نقلیه الزامی است.</li>
                                  </>
                                ) : shipment.transportType === 'sea' ? (
                                  <>
                                    <li>محموله‌ها باید حداقل ۷۲ ساعت قبل از حرکت کشتی در بندر مبدا آماده باشند.</li>
                                    <li>زمان‌بندی حرکت کشتی‌ها ممکن است بر اساس شرایط آب و هوایی تغییر کند.</li>
                                    <li>مدارک گمرکی کامل برای حمل و نقل دریایی الزامی است.</li>
                                    <li>کلیه محموله‌های دریایی به صورت پیش‌فرض بیمه پایه دارند.</li>
                                  </>
                                ) : (
                                  <>
                                    <li>برنامه‌ریزی دقیق حمل و نقل ترکیبی نیازمند هماهنگی قبلی است.</li>
                                    <li>زمان‌بندی ممکن است براساس شرایط مختلف مسیر تغییر کند.</li>
                                    <li>مسئولیت تهیه مدارک لازم برای هر بخش از مسیر با فرستنده محموله است.</li>
                                    <li>پشتیبانی ۲۴ ساعته در طول مسیر برای مسیرهای ترکیبی ارائه می‌شود.</li>
                                  </>
                                )}
                              </ul>
                            </div>
                          </div>
                        </TabsContent>
                      )}
                      
                      <TabsContent value="specifications" className="bg-gray-50 p-4 rounded-lg">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {shipment.specifications && Object.entries(shipment.specifications).map(([key, value]) => (
                            <div key={key} className="flex justify-between">
                              <span className="text-gray-500">{key === "vesselName" ? "نام شناور" : 
                                key === "vesselType" ? "نوع شناور" : 
                                key === "capacity" ? "ظرفیت" : 
                                key === "flag" ? "پرچم" : 
                                key === "yearBuilt" ? "سال ساخت" : 
                                key === "routeFrequency" ? "تناوب مسیر" : key}</span>
                              <span className="font-medium">{value}</span>
                            </div>
                          ))}
                        </div>
                      </TabsContent>
                      <TabsContent value="documents" className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-medium mb-3">مدارک مورد نیاز برای حمل محموله:</h4>
                        <ul className="space-y-2">
                          <li className="flex items-start">
                            <FileText className="ml-2 text-gray-500" size={16} />
                            <span>فاکتور رسمی یا پیش فاکتور</span>
                          </li>
                          <li className="flex items-start">
                            <FileText className="ml-2 text-gray-500" size={16} />
                            <span>بارنامه یا مانیفست بار</span>
                          </li>
                          <li className="flex items-start">
                            <FileText className="ml-2 text-gray-500" size={16} />
                            <span>گواهی مبدا (در صورت نیاز)</span>
                          </li>
                          <li className="flex items-start">
                            <FileText className="ml-2 text-gray-500" size={16} />
                            <span>مدارک گمرکی (برای محموله‌های بین‌المللی)</span>
                          </li>
                        </ul>
                      </TabsContent>
                      <TabsContent value="insurance" className="bg-gray-50 p-4 rounded-lg">
                        <div className="mb-3">
                          <h4 className="font-medium mb-1">پوشش بیمه‌ای:</h4>
                          <p className="text-gray-700">بیمه تمام خطر حمل و نقل با پوشش خسارت‌های فیزیکی، سرقت، آتش‌سوزی و آسیب‌های ناشی از حوادث طبیعی</p>
                        </div>
                        <div>
                          <h4 className="font-medium mb-1">شرایط بیمه:</h4>
                          <p className="text-gray-700">بیمه به صورت اختیاری با هزینه {formatPrice(shipment.insurancePrice)} تومان برای هر کانتینر ارائه می‌شود</p>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              </div>

              {/* Booking Panel */}
              <div>
                <Card className="sticky top-4">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-bold mb-4">رزرو محموله</h2>
                    
                    <div className="space-y-4 mb-6">
                      <div className="flex justify-between">
                        <span className="text-gray-600">قیمت پایه:</span>
                        <span className="font-medium">
                          {shipment.transportPrice?.priceToman 
                            ? formatPrice(shipment.transportPrice.priceToman)
                            : shipment.calculatedPrice 
                              ? formatPrice(shipment.calculatedPrice)
                              : formatPrice(shipment.price)} تومان
                        </span>
                      </div>
                      
                      <div>
                        <label className="block text-gray-600 mb-2">تعداد کانتینر:</label>
                        <div className="flex">
                          <button 
                            className="bg-gray-200 px-3 py-2 rounded-r-lg" 
                            onClick={() => handleQuantityChange(quantity - 1)}
                            disabled={quantity <= 1}
                          >
                            -
                          </button>
                          <Input 
                            type="number" 
                            value={quantity} 
                            onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                            className="w-20 text-center rounded-none border-t border-b border-gray-300 py-2" 
                            min={1}
                            max={shipment.capacity}
                          />
                          <button 
                            className="bg-gray-200 px-3 py-2 rounded-l-lg"
                            onClick={() => handleQuantityChange(quantity + 1)}
                            disabled={quantity >= shipment.capacity}
                          >
                            +
                          </button>
                        </div>
                      </div>
                      
                      {shipment.insuranceAvailable && (
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id="insurance" 
                            checked={withInsurance}
                            onChange={(e) => setWithInsurance(e.target.checked)}
                            className="ml-2"
                          />
                          <label htmlFor="insurance" className="cursor-pointer">
                            <div className="flex items-center">
                              <ShieldCheck className="ml-1 text-green-600" size={18} />
                              <span>بیمه محموله</span>
                            </div>
                            <div className="text-sm text-gray-500 mr-7">
                              {formatPrice(shipment.insurancePrice)} تومان برای هر کانتینر
                            </div>
                          </label>
                        </div>
                      )}
                    </div>
                    
                    <div className="border-t border-gray-200 pt-4 mb-6">
                      <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center">
                          <span className="text-gray-700 font-medium ml-1">جمع کل:</span>
                          <Layers className="text-gray-500" size={16} />
                        </div>
                        <div className="text-xl font-bold text-primary">
                          {formatPrice(calculateTotal())} تومان
                        </div>
                      </div>
                      <div className="text-gray-500 text-sm mb-4">
                        {withInsurance && shipment.insuranceAvailable ? (
                          <div className="flex items-center justify-end">
                            <ShieldCheck className="ml-1 text-green-600" size={14} />
                            <span>محموله شما با بیمه تمام خطر ارسال خواهد شد</span>
                          </div>
                        ) : (
                          <div className="text-left">قیمت شامل مالیات بر ارزش افزوده می‌باشد</div>
                        )}
                      </div>
                      <Button 
                        className="w-full"
                        onClick={handleBooking}
                        size="lg"
                      >
                        <DollarSign className="ml-2" size={18} />
                        رزرو و پرداخت
                      </Button>
                    </div>
                    
                    <div className="text-xs text-gray-500">
                      با کلیک بر روی دکمه "رزرو و پرداخت"، شما <a href="/terms" className="text-primary hover:underline">قوانین و مقررات</a> سایت لجستینو را می‌پذیرید.
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <div className="mx-auto w-16 h-16 bg-gray-100 flex items-center justify-center rounded-full mb-4">
                <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium mb-2">محموله مورد نظر یافت نشد</h3>
              <p className="text-gray-600 mb-4">
                متأسفانه اطلاعات محموله مورد نظر شما در سیستم موجود نیست.
              </p>
              <Button onClick={() => navigate("/search")}>بازگشت به صفحه جستجو</Button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default ShipmentDetailsPage;
