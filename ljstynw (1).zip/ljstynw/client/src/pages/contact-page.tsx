import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Mail, Phone, MessageCircle } from "lucide-react";

const formSchema = z.object({
  name: z.string().min(2, {
    message: "نام باید حداقل 2 حرف باشد",
  }),
  email: z.string().email({
    message: "لطفاً یک ایمیل معتبر وارد کنید",
  }),
  phone: z.string().min(10, {
    message: "شماره تلفن باید حداقل 10 رقم باشد",
  }),
  subject: z.string().min(5, {
    message: "موضوع باید حداقل 5 حرف باشد",
  }),
  message: z.string().min(10, {
    message: "پیام باید حداقل 10 حرف باشد",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const ContactPage = () => {
  const { toast } = useToast();
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    },
  });

  function onSubmit(data: FormValues) {
    toast({
      title: "پیام شما با موفقیت ارسال شد",
      description: "کارشناسان ما در اسرع وقت با شما تماس خواهند گرفت.",
    });
    form.reset();
  }

  return (
    <Layout>
      <div className="py-12 bg-white">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-6">تماس با ما</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              سوالی دارید؟ ما آماده پاسخگویی هستیم.
              از طریق فرم زیر یا راه‌های ارتباطی دیگر با ما در تماس باشید.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
            {/* Contact Information */}
            <div className="lg:col-span-1">
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm h-full">
                <h3 className="text-xl font-bold mb-6">اطلاعات تماس</h3>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <MapPin className="h-6 w-6 text-primary ml-3" />
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">آدرس:</h4>
                      <p className="text-gray-600">
                        تهران، خیابان آزادی، برج تجاری آزادی، طبقه ۱۰، واحد ۴
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <Mail className="h-6 w-6 text-primary ml-3" />
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">ایمیل:</h4>
                      <p className="text-gray-600 hover:text-primary transition">
                        <a href="mailto:info@logistino.ir">info@logistino.ir</a>
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <Phone className="h-6 w-6 text-primary ml-3" />
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">تلفن:</h4>
                      <p className="text-gray-600 hover:text-primary transition" dir="ltr">
                        <a href="tel:+982188776655">021-88776655</a>
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <MessageCircle className="h-6 w-6 text-primary ml-3" />
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">ساعات پاسخگویی:</h4>
                      <p className="text-gray-600">
                        شنبه تا چهارشنبه: ۹ صبح تا ۵ عصر<br />
                        پنجشنبه: ۹ صبح تا ۱ بعد از ظهر
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8">
                  <h4 className="font-medium mb-3">ما را در شبکه‌های اجتماعی دنبال کنید:</h4>
                  <div className="flex space-x-4 space-x-reverse">
                    <a href="#" className="bg-gray-200 hover:bg-primary hover:text-white transition p-2 rounded-full">
                      <i className="fab fa-instagram text-lg"></i>
                    </a>
                    <a href="#" className="bg-gray-200 hover:bg-primary hover:text-white transition p-2 rounded-full">
                      <i className="fab fa-twitter text-lg"></i>
                    </a>
                    <a href="#" className="bg-gray-200 hover:bg-primary hover:text-white transition p-2 rounded-full">
                      <i className="fab fa-linkedin text-lg"></i>
                    </a>
                    <a href="#" className="bg-gray-200 hover:bg-primary hover:text-white transition p-2 rounded-full">
                      <i className="fab fa-telegram text-lg"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-white border border-gray-200 p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold mb-6">ارسال پیام به ما</h3>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نام و نام خانوادگی</FormLabel>
                            <FormControl>
                              <Input placeholder="نام و نام خانوادگی" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ایمیل</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="example@domain.com" dir="ltr" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>شماره تماس</FormLabel>
                            <FormControl>
                              <Input placeholder="۰۹۱۲۳۴۵۶۷۸۹" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="subject"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>موضوع</FormLabel>
                            <FormControl>
                              <Input placeholder="موضوع پیام شما" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>پیام</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="پیام خود را بنویسید..." 
                              className="min-h-[150px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full sm:w-auto"
                      disabled={form.formState.isSubmitting}
                    >
                      {form.formState.isSubmitting ? "در حال ارسال..." : "ارسال پیام"}
                    </Button>
                  </form>
                </Form>
              </div>
            </div>
          </div>

          {/* Map Section */}
          <div className="mb-8 h-96 rounded-lg overflow-hidden shadow-sm border border-gray-200">
            {/* Map would be implemented here - using placeholder div */}
            <div className="w-full h-full bg-gray-200 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="h-12 w-12 mx-auto mb-2 text-primary" />
                <p className="text-gray-600">نقشه موقعیت دفتر مرکزی لجستینو</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ContactPage;
