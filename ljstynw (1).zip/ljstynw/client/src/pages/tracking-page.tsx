import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  Truck, 
  Package, 
  MapPin, 
  Calendar, 
  CheckCircle,
  Clock,
  AlertCircle
} from "lucide-react";

const TrackingPage = () => {
  const { toast } = useToast();
  const [trackingCode, setTrackingCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [trackingResult, setTrackingResult] = useState<any | null>(null);
  const [error, setError] = useState("");

  // Mock tracking data structure
  interface TrackingData {
    bookingId: string;
    status: "pending" | "confirmed" | "in_transit" | "delivered" | "cancelled";
    origin: string;
    destination: string;
    departureDate: string;
    estimatedArrival: string;
    currentLocation?: string;
    cargoType: string;
    transporterName: string;
    withInsurance: boolean;
    trackingHistory: {
      date: string;
      status: string;
      location: string;
      description: string;
    }[];
  }

  // Mock tracking result
  const mockTrackingResult: TrackingData = {
    bookingId: "LGT-12345",
    status: "in_transit",
    origin: "تهران",
    destination: "دبی",
    departureDate: "۱۰ مهر ۱۴۰۲",
    estimatedArrival: "۱۶ مهر ۱۴۰۲",
    currentLocation: "بندرعباس",
    cargoType: "کالای صنعتی",
    transporterName: "شرکت حمل و نقل خلیج پارس",
    withInsurance: true,
    trackingHistory: [
      {
        date: "۱۰ مهر ۱۴۰۲ - ۱۰:۳۰",
        status: "دریافت بار",
        location: "تهران",
        description: "بار از مبدا دریافت شد."
      },
      {
        date: "۱۱ مهر ۱۴۰۲ - ۰۸:۴۵",
        status: "حمل زمینی",
        location: "تهران به بندرعباس",
        description: "در حال انتقال از طریق جاده به بندرعباس"
      },
      {
        date: "۱۳ مهر ۱۴۰۲ - ۱۶:۲۰",
        status: "رسیدن به بندر",
        location: "بندرعباس",
        description: "بار به بندر رسید و در انتظار بارگیری در کشتی"
      }
    ]
  };

  const handleTracking = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!trackingCode.trim()) {
      setError("لطفاً کد پیگیری را وارد کنید");
      return;
    }

    setIsLoading(true);

    // In a real app, this would call the API
    setTimeout(() => {
      if (trackingCode === "LGT-12345") {
        setTrackingResult(mockTrackingResult);
      } else {
        setError("محموله‌ای با این کد پیگیری یافت نشد");
        toast({
          title: "محموله یافت نشد",
          description: "محموله‌ای با کد پیگیری وارد شده در سیستم ثبت نشده است",
          variant: "destructive",
        });
      }
      setIsLoading(false);
    }, 1500);
  };

  // Function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">در انتظار تأیید</span>;
      case "confirmed":
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">تأیید شده</span>;
      case "in_transit":
        return <span className="px-2 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-medium">در حال ارسال</span>;
      case "delivered":
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">تحویل داده شده</span>;
      case "cancelled":
        return <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">لغو شده</span>;
      default:
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">نامشخص</span>;
    }
  };

  return (
    <Layout>
      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <h1 className="text-3xl font-bold mb-4">پیگیری محموله</h1>
              <p className="text-gray-600">
                با وارد کردن کد پیگیری، می‌توانید از وضعیت فعلی محموله خود مطلع شوید
              </p>
            </div>

            <Card className="mb-8">
              <CardContent className="pt-6">
                <form onSubmit={handleTracking} className="flex flex-col sm:flex-row items-center gap-4">
                  <div className="relative w-full">
                    <Search className="absolute right-3 top-3 text-gray-400" size={18} />
                    <Input
                      type="text"
                      placeholder="کد پیگیری محموله را وارد کنید"
                      value={trackingCode}
                      onChange={(e) => setTrackingCode(e.target.value)}
                      className="pr-10"
                    />
                  </div>
                  <Button type="submit" disabled={isLoading} className="whitespace-nowrap">
                    {isLoading ? "در حال جستجو..." : "پیگیری محموله"}
                  </Button>
                </form>
                {error && (
                  <div className="mt-4 text-red-500 text-sm flex items-center">
                    <AlertCircle className="ml-1" size={16} />
                    {error}
                  </div>
                )}
              </CardContent>
            </Card>

            {trackingResult && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
                <div className="flex justify-between items-center mb-6 flex-wrap gap-3">
                  <div>
                    <div className="flex items-center mb-2">
                      <Package className="ml-2 text-primary" size={20} />
                      <h2 className="text-xl font-bold">اطلاعات محموله</h2>
                    </div>
                    <p className="text-sm text-gray-500">
                      کد پیگیری: <span className="font-medium text-gray-700">{trackingResult.bookingId}</span>
                    </p>
                  </div>
                  <div>
                    {getStatusBadge(trackingResult.status)}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <MapPin className="ml-2 text-secondary" size={18} />
                      <h3 className="font-semibold">مسیر حمل</h3>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-center">
                        <div className="text-gray-600 text-sm mb-1">مبدا</div>
                        <div className="font-medium">{trackingResult.origin}</div>
                      </div>
                      <div className="w-16 h-0.5 bg-gray-300 mx-2 relative">
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                          <Truck className="text-gray-400" size={14} />
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-gray-600 text-sm mb-1">مقصد</div>
                        <div className="font-medium">{trackingResult.destination}</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <Calendar className="ml-2 text-accent" size={18} />
                      <h3 className="font-semibold">زمان‌بندی</h3>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-center">
                        <div className="text-gray-600 text-sm mb-1">تاریخ ارسال</div>
                        <div className="font-medium">{trackingResult.departureDate}</div>
                      </div>
                      <div className="w-16 h-0.5 bg-gray-300 mx-2 relative">
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                          <Clock className="text-gray-400" size={14} />
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-gray-600 text-sm mb-1">تاریخ تحویل</div>
                        <div className="font-medium">{trackingResult.estimatedArrival}</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-gray-600 text-sm mb-1">نوع کالا</div>
                    <div className="font-medium">{trackingResult.cargoType}</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-gray-600 text-sm mb-1">شرکت حمل و نقل</div>
                    <div className="font-medium">{trackingResult.transporterName}</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-gray-600 text-sm mb-1">بیمه محموله</div>
                    <div className="font-medium flex items-center">
                      {trackingResult.withInsurance ? (
                        <>
                          <CheckCircle className="ml-1 text-green-500" size={16} />
                          <span>دارد</span>
                        </>
                      ) : (
                        <span>ندارد</span>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center mb-4">
                    <Package className="ml-2 text-primary" size={20} />
                    <h2 className="text-xl font-bold">تاریخچه وضعیت محموله</h2>
                  </div>

                  <div className="relative">
                    {trackingResult.trackingHistory.map((item, index) => (
                      <div key={index} className="relative flex items-start mb-8 last:mb-0">
                        <div className="flex flex-col items-center ml-6">
                          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                            <CheckCircle className="text-white" size={16} />
                          </div>
                          {index !== trackingResult.trackingHistory.length - 1 && (
                            <div className="h-full border-r-2 border-dashed border-gray-300 absolute top-8"></div>
                          )}
                        </div>
                        <div className="bg-gray-50 rounded-lg p-4 flex-grow shadow-sm">
                          <div className="flex justify-between items-center mb-2 flex-wrap gap-2">
                            <h4 className="font-semibold">{item.status}</h4>
                            <span className="text-sm text-gray-500">{item.date}</span>
                          </div>
                          <div className="text-gray-600 text-sm mb-1">مکان: {item.location}</div>
                          <p className="text-gray-700">{item.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-bold mb-4">راهنمای پیگیری محموله</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-lg">کد پیگیری چیست؟</h3>
                  <p className="text-gray-700">
                    کد پیگیری یک شناسه منحصر به فرد است که پس از تأیید سفارش حمل و نقل شما در سیستم لجستینو، 
                    از طریق ایمیل و پیامک برای شما ارسال می‌شود. این کد با پیشوند LGT شروع می‌شود.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">چگونه محموله خود را پیگیری کنم؟</h3>
                  <p className="text-gray-700">
                    کد پیگیری خود را در فیلد بالا وارد کرده و بر روی دکمه "پیگیری محموله" کلیک کنید. 
                    سیستم به صورت خودکار آخرین وضعیت محموله شما را نمایش می‌دهد.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">برای آزمایش از کد زیر استفاده کنید:</h3>
                  <p className="text-gray-700">
                    برای مشاهده نمونه، کد <span className="font-medium">LGT-12345</span> را وارد کنید.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default TrackingPage;
