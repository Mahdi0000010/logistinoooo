import React from "react";
import Layout from "@/components/layout/Layout";
import UserTickets from "@/components/support/UserTickets";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Headset, PhoneCall, Mail } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const SupportPage = () => {
  const { user } = useAuth();

  return (
    <Layout>
      <div className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold mb-4">پشتیبانی و خدمات مشتریان</h1>
            <p className="text-gray-600 max-w-3xl mx-auto">
              کارشناسان ما آماده پاسخگویی به سوالات و حل مشکلات شما هستند.
              از طریق ارسال تیکت یا تماس مستقیم با ما در ارتباط باشید.
            </p>
          </div>

          {user ? (
            <div className="max-w-5xl mx-auto">
              <UserTickets />
            </div>
          ) : (
            <div className="text-center max-w-xl mx-auto mb-12">
              <Card>
                <CardContent className="pt-6">
                  <Headset className="w-16 h-16 mx-auto mb-4 text-primary" />
                  <h2 className="text-xl font-bold mb-3">برای ارسال تیکت پشتیبانی، ابتدا وارد حساب کاربری خود شوید</h2>
                  <p className="text-gray-600 mb-6">
                    با ورود به حساب کاربری خود می‌توانید تیکت‌های پشتیبانی ارسال کنید و تاریخچه تیکت‌های خود را مشاهده نمایید.
                  </p>
                  <Link href="/auth">
                    <Button className="w-full">ورود به حساب کاربری</Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="max-w-5xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">راه‌های ارتباطی دیگر</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center mb-4">
                  <PhoneCall className="w-10 h-10 text-primary ml-3" />
                  <div>
                    <h3 className="text-lg font-bold">تماس تلفنی</h3>
                    <p className="text-gray-600">با کارشناسان ما در تماس باشید</p>
                  </div>
                </div>
                <p className="mb-3">شماره تماس: <span className="font-medium">۰۲۱-۸۸۷۷۶۶۵۵</span></p>
                <p className="mb-3">تلفن پشتیبانی: <span className="font-medium">۰۲۱-۸۸۷۷۶۶۵۶</span></p>
                <p>ساعات پاسخگویی: شنبه تا چهارشنبه از ۹ صبح تا ۵ عصر، پنجشنبه از ۹ صبح تا ۱ بعد از ظهر</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div className="flex items-center mb-4">
                  <Mail className="w-10 h-10 text-primary ml-3" />
                  <div>
                    <h3 className="text-lg font-bold">ارتباط از طریق ایمیل</h3>
                    <p className="text-gray-600">ایمیل خود را برای ما ارسال کنید</p>
                  </div>
                </div>
                <p className="mb-3">ایمیل پشتیبانی: <a href="mailto:support@logistino.ir" className="font-medium text-primary">support@logistino.ir</a></p>
                <p className="mb-3">ایمیل فروش: <a href="mailto:sales@logistino.ir" className="font-medium text-primary">sales@logistino.ir</a></p>
                <p>زمان پاسخگویی: حداکثر ۲۴ ساعت کاری</p>
              </div>
            </div>
          </div>

          <div className="max-w-5xl mx-auto mt-12">
            <h2 className="text-2xl font-bold mb-6">سوالات متداول</h2>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="space-y-6">
                <div>
                  <h3 className="font-bold text-lg mb-2">چگونه می‌توانم وضعیت محموله خود را پیگیری کنم؟</h3>
                  <p className="text-gray-700">
                    برای پیگیری وضعیت محموله خود، می‌توانید با استفاده از کد پیگیری که پس از ثبت سفارش دریافت کرده‌اید،
                    به بخش "پیگیری محموله" در سایت مراجعه کنید. همچنین می‌توانید از طریق پنل کاربری خود در بخش "سفارش‌های من"،
                    وضعیت تمامی محموله‌های خود را مشاهده نمایید.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-bold text-lg mb-2">چگونه می‌توانم محموله خود را بیمه کنم؟</h3>
                  <p className="text-gray-700">
                    در هنگام ثبت سفارش، گزینه "بیمه محموله" را انتخاب کنید. هزینه بیمه بر اساس ارزش اظهار شده محموله
                    و نوع کالا محاسبه می‌شود و به هزینه کل حمل و نقل اضافه می‌گردد. بیمه شامل پوشش خسارت‌های احتمالی
                    در مسیر حمل و نقل می‌باشد.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-bold text-lg mb-2">چه مدارکی برای ارسال محموله نیاز است؟</h3>
                  <p className="text-gray-700">
                    مدارک مورد نیاز برای ارسال محموله بسته به نوع کالا و مقصد متفاوت است. به طور کلی، برای ارسال‌های
                    داخلی به فاکتور خرید یا مجوز حمل و برای ارسال‌های بین‌المللی به اسناد گمرکی، مجوزهای صادراتی و
                    بارنامه نیاز خواهید داشت. برای اطلاعات دقیق‌تر، با کارشناسان ما تماس بگیرید.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-bold text-lg mb-2">چگونه می‌توانم هزینه حمل و نقل را پرداخت کنم؟</h3>
                  <p className="text-gray-700">
                    پرداخت هزینه حمل و نقل از طریق درگاه‌های پرداخت آنلاین در سایت انجام می‌شود. همچنین امکان پرداخت
                    به صورت واریز به حساب شرکت نیز وجود دارد. برای سفارش‌های با حجم بالا، امکان پرداخت به صورت
                    اعتباری (با ارائه ضمانت‌نامه) نیز فراهم می‌باشد.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default SupportPage;
