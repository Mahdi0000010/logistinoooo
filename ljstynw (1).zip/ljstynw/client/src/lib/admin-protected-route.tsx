import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";

export function AdminProtectedRoute({
  path,
  component: Component,
}: {
  path: string;
  component: React.ComponentType<any>;
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <Route path={path}>
        {() => (
          <div className="flex items-center justify-center min-h-screen">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        )}
      </Route>
    );
  }

  if (!user) {
    return (
      <Route path={path}>
        {() => <Redirect to="/admin-login" />}
      </Route>
    );
  }

  // Check if user is admin
  if (user.role !== "admin") {
    return (
      <Route path={path}>
        {() => (
          <div className="flex items-center justify-center min-h-screen flex-col">
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              <h2 className="text-xl font-bold mb-2">دسترسی محدود</h2>
              <p>شما مجاز به دسترسی به این بخش نیستید.</p>
              <p className="mt-2 text-sm">این بخش فقط برای مدیران سیستم در دسترس است.</p>
            </div>
            <div className="mt-4">
              <a 
                href="/" 
                className="px-4 py-2 bg-primary text-white rounded hover:bg-primary-dark"
              >
                بازگشت به صفحه اصلی
              </a>
            </div>
          </div>
        )}
      </Route>
    );
  }

  return <Route path={path} component={Component} />;
}