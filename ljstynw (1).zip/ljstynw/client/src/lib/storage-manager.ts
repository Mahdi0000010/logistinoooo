// مدیریت کننده ذخیره‌سازی محلی با یک ساختار مشخص
class StorageManager {
  private prefix: string;

  constructor(prefix: string = 'logistino_') {
    this.prefix = prefix;
  }

  // ذخیره یک مقدار
  set(key: string, value: any): void {
    try {
      if (value === undefined || value === null) {
        this.remove(key);
        return;
      }
      
      // تبدیل اشیاء به رشته JSON
      const valueToStore = typeof value === 'object' ? JSON.stringify(value) : String(value);
      localStorage.setItem(this.prefix + key, valueToStore);
    } catch (error) {
      console.error('خطا در ذخیره داده در localStorage:', error);
    }
  }

  // بازیابی یک مقدار
  get(key: string, defaultValue: any = null): any {
    try {
      const item = localStorage.getItem(this.prefix + key);
      
      if (item === null) {
        return defaultValue;
      }
      
      // سعی در تبدیل به JSON
      try {
        return JSON.parse(item);
      } catch {
        // اگر قابل تبدیل به JSON نباشد، همان مقدار رشته را برمی‌گرداند
        return item;
      }
    } catch (error) {
      console.error('خطا در بازیابی داده از localStorage:', error);
      return defaultValue;
    }
  }

  // حذف یک مقدار
  remove(key: string): void {
    try {
      localStorage.removeItem(this.prefix + key);
    } catch (error) {
      console.error('خطا در حذف داده از localStorage:', error);
    }
  }

  // ذخیره یک آبجکت کامل از مقادیر جستجو
  setSearchValues(values: SearchValues): void {
    this.set('search_values', values);
  }

  // بازیابی آبجکت کامل مقادیر جستجو
  getSearchValues(): SearchValues {
    const defaultValues: SearchValues = {
      originId: '',
      destinationId: '',
      departureDate: '',
      cargoType: '',
      originCountry: '',
      originType: '',
      destinationCountry: '',
      destinationType: '',
      containerType: '',
      cargoWeight: '',
      cargoQuantity: '',
      withInsurance: false,
      preferredTransportType: 'all'
    };
    
    return this.get('search_values', defaultValues);
  }
  
  // بروزرسانی بخشی از مقادیر جستجو
  updateSearchValues(partialValues: Partial<SearchValues>): void {
    const currentValues = this.getSearchValues();
    this.setSearchValues({
      ...currentValues,
      ...partialValues
    });
  }
}

// تعریف نوع آبجکت ذخیره‌سازی
export interface SearchValues {
  originId: string;
  destinationId: string;
  departureDate: string;
  cargoType: string;
  originCountry: string;
  originType: string;
  destinationCountry: string;
  destinationType: string;
  containerType: string;
  cargoWeight: string;
  cargoQuantity: string;
  withInsurance: boolean;
  preferredTransportType?: string; // اضافه کردن فیلد نوع حمل و نقل ترجیحی
}

// صادر کردن یک نمونه واحد از مدیریت کننده ذخیره‌سازی
export const storageManager = new StorageManager();