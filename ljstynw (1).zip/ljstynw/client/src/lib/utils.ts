import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * تابع تبدیل عدد به فرمت پولی با گرد کردن به نزدیکترین مضرب 1,000 تومان (مطابق با سرور)
 * @param value - مقدار عددی
 * @param currency - واحد پولی (پیش‌فرض: "تومان")
 * @param roundToThousands - آیا عدد به نزدیکترین مضرب 1,000 گرد شود؟
 * @returns عدد فرمت‌شده به همراه واحد پولی
 */
export function formatCurrency(value: number | null, currency = "تومان", roundToThousands = false) {
  // در صورتی که مقدار null باشد، نمایش پیام عدم وجود قیمت
  if (value === null) {
    return 'قیمت موجود نیست'; // "Price not available" in Persian
  }
  
  // در صورت نیاز به گرد کردن (فقط برای تومان استفاده می‌شود)
  if (roundToThousands && currency === "تومان") {
    value = Math.round(value / 1000) * 1000;
  }
  
  // اضافه کردن کاما به عدد و در نهایت نمایش واحد پولی
  return new Intl.NumberFormat("fa-IR").format(value) + " " + currency;
}

/**
 * تابع تبدیل عدد به فرمت پولی - نام جایگزین برای formatCurrency
 * استفاده شده در برخی از فایل‌ها
 * به طور پیش‌فرض، قیمت‌ها به تومان نمایش داده می‌شوند
 * و به نزدیکترین مضرب 1,000 تومان گرد می‌شوند (مطابق با سرور)
 */
export function formatPrice(value: number | null, currency = "تومان") {
  return formatCurrency(value, currency, true);
}

/**
 * تابع تبدیل مدت زمان (دقیقه) به فرمت خوانا
 * @param minutes - مدت زمان به دقیقه
 * @returns مدت زمان فرمت شده به صورت ساعت و دقیقه
 */
export function formatDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (hours > 0) {
    return `${hours} ساعت و ${mins} دقیقه`;
  }
  
  return `${mins} دقیقه`;
}