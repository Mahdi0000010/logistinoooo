import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import { AdminProtectedRoute, TransporterProtectedRoute } from "./lib/protected-route";
import SecretAdminAccess from "@/components/admin/SecretAdminAccess";

// Pages
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import UserRegisterPage from "@/pages/user-register-page";
import TransporterRegisterPage from "@/pages/transporter-register-page";
import NotFound from "@/pages/not-found";
import AboutPage from "@/pages/about-page";
import ContactPage from "@/pages/contact-page";
import DashboardPage from "@/pages/dashboard-page";
import AdminDashboardPage from "@/pages/admin-dashboard-page";
import AdminLoginPage from "@/pages/admin-login-page";
import TrackingPage from "@/pages/tracking-page";
import SupportPage from "@/pages/support-page";
import TermsPage from "@/pages/terms-page";
import BlogPage from "@/pages/blog-page";
import SearchPage from "@/pages/search-page";
import SearchResultsPage from "@/pages/search-results-page";
import ShipmentDetailsPage from "@/pages/shipment-details-page";
import SmartRoutingPage from "@/pages/smart-routing-page";
import RecentServicesPage from "@/pages/recent-services-page"; // صفحه سرویس‌های یک ماه اخیر

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/admin-login" component={AdminLoginPage} />
      <Route path="/user-register" component={UserRegisterPage} />
      <Route path="/transporter-register" component={TransporterRegisterPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/tracking" component={TrackingPage} />
      <Route path="/search" component={SearchPage} />
      <Route path="/search-results" component={SearchResultsPage} />
      <Route path="/shipment/:id" component={ShipmentDetailsPage} />
      <Route path="/smart-routing" component={SmartRoutingPage} />
      <Route path="/recent-services" component={RecentServicesPage} />
      <ProtectedRoute path="/dashboard" component={DashboardPage} />
      <AdminProtectedRoute path="/admin" component={AdminDashboardPage} />
      <ProtectedRoute path="/support" component={SupportPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <SecretAdminAccess />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
