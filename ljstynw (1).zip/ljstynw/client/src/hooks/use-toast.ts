import { type ToastActionElement, type ToastProps } from "@/components/ui/toast";
import {
  useToast as useToastImported,
  toast,
} from "@/components/ui/use-toast";

type ToastOptions = Omit<
  ToastProps,
  "id" | "className" | "toast"
> & {
  action?: ToastActionElement;
};

/**
 * از این هوک برای نمایش توست‌ها استفاده می‌شود
 */
export const useToast = () => {
  const { toast: showToast, ...restToast } = useToastImported();

  const showSuccessToast = (message: string) => {
    showToast({
      description: message,
    });
  };

  const showErrorToast = (error: Error | string) => {
    const errorMessage = typeof error === "string" ? error : error.message;
    showToast({
      title: "خطا",
      description: errorMessage,
      variant: "destructive",
    });
  };

  return {
    toast: showToast,
    successToast: showSuccessToast,
    errorToast: showErrorToast,
    ...restToast,
  };
};

export { toast };