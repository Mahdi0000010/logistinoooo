import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { apiRequest, queryClient } from "../lib/queryClient";

export function useAuth() {
  const { 
    data: user, 
    isLoading, 
    error 
  } = useQuery<User | null>({
    queryKey: ["/api/auth/user"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/auth/user");
        if (res.status === 401) {
          return null;
        }
        return await res.json();
      } catch (err) {
        return null;
      }
    },
    retry: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const login = () => {
    // برای استفاده از Replit Auth، کاربر را به آدرس /api/login هدایت می‌کنیم
    window.location.href = "/api/login";
  };

  const logout = () => {
    // برای خروج از سیستم، کاربر را به آدرس /api/logout هدایت می‌کنیم
    window.location.href = "/api/logout";
    // پاک کردن داده‌های کاربر از کش
    queryClient.setQueryData(["/api/auth/user"], null);
  };

  return {
    user: user || null,
    isLoading,
    error,
    isAuthenticated: !!user,
    login,
    logout,
  };
}