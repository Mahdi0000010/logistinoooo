import { useEffect, useState } from "react";
import { useLocation } from "wouter";

/**
 * کامپوننت مخفی برای دسترسی به صفحه مدیریت
 * این کامپوننت فقط با فشردن ترکیب کلیدهای Ctrl+Alt+A فعال می‌شود
 */
const SecretAdminAccess = () => {
  const [_, setLocation] = useLocation();
  const [ctrlPressed, setCtrlPressed] = useState(false);
  const [altPressed, setAltPressed] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Control" || e.key === "Meta") {
        setCtrlPressed(true);
      }
      if (e.key === "Alt") {
        setAltPressed(true);
      }

      // اگر ترکیب Ctrl+Alt+A فشرده شد، به صفحه ورود مدیریت هدایت شود
      if ((ctrlPressed || e.ctrlKey) && (altPressed || e.altKey) && e.key === "a") {
        e.preventDefault(); // جلوگیری از انتخاب همه متن
        setLocation("/admin-login");
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "Control" || e.key === "Meta") {
        setCtrlPressed(false);
      }
      if (e.key === "Alt") {
        setAltPressed(false);
      }
    };

    // اضافه کردن event listener به document
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("keyup", handleKeyUp);

    return () => {
      // پاک کردن event listener ها هنگام unmount
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("keyup", handleKeyUp);
    };
  }, [ctrlPressed, altPressed, setLocation]);

  // این کامپوننت هیچ چیزی را رندر نمی‌کند
  return null;
};

export default SecretAdminAccess;