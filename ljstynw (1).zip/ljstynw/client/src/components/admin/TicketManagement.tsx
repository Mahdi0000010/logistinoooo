import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Ticket, TicketResponse } from '@shared/schema';
import { format } from 'date-fns-jalali';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

// UI Components
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Eye, MessageSquare, LifeBuoy, Loader2 } from 'lucide-react';

// Ticket status badges
const getStatusBadge = (status: string) => {
  switch (status) {
    case 'open':
      return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">باز</Badge>;
    case 'in_progress':
      return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">در حال بررسی</Badge>;
    case 'resolved':
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">حل شده</Badge>;
    case 'closed':
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">بسته شده</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

// Form schema for ticket response
const responseSchema = z.object({
  message: z.string().min(1, { message: 'پاسخ نمی‌تواند خالی باشد' }),
  status: z.enum(['open', 'in_progress', 'resolved', 'closed'], {
    required_error: 'لطفاً وضعیت تیکت را انتخاب کنید',
  }),
});

type ResponseFormValues = z.infer<typeof responseSchema>;
type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed';

interface TicketDetailProps {
  ticket: Ticket;
  onClose: () => void;
}

// Ticket detail dialog component
const TicketDetailDialog: React.FC<TicketDetailProps> = ({ ticket, onClose }) => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form setup
  const form = useForm<ResponseFormValues>({
    resolver: zodResolver(responseSchema),
    defaultValues: {
      message: '',
      status: ticket.status as TicketStatus,
    },
  });

  // Fetch ticket responses
  const { data: responses, isLoading: isLoadingResponses } = useQuery<TicketResponse[]>({
    queryKey: ['/api/tickets', ticket.id, 'responses'],
    queryFn: () => apiRequest('GET', `/api/tickets/${ticket.id}`).then(res => res.json()).then(data => data.responses),
  });

  // Submit response mutation
  const submitResponse = async (data: ResponseFormValues) => {
    setIsSubmitting(true);
    try {
      await apiRequest('POST', `/api/admin/tickets/${ticket.id}/responses`, data);
      toast({
        title: 'پاسخ ارسال شد',
        description: 'پاسخ شما با موفقیت ثبت شد',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tickets', ticket.id, 'responses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/tickets'] });
      form.reset({ message: '', status: data.status });
    } catch (error) {
      toast({
        title: 'خطا',
        description: 'مشکلی در ارسال پاسخ رخ داد. لطفاً دوباره تلاش کنید.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatDate = (date: Date | null) => {
    if (!date) return 'تاریخ نامشخص';
    return format(new Date(date), 'yyyy/MM/dd HH:mm');
  };

  return (
    <DialogContent className="max-w-3xl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <LifeBuoy className="h-5 w-5 text-primary" />
          <span>تیکت #{ticket.id}: {ticket.subject}</span>
        </DialogTitle>
        <DialogDescription>
          {formatDate(ticket.createdAt)} | {getStatusBadge(ticket.status)}
        </DialogDescription>
      </DialogHeader>

      <div className="space-y-4">
        {/* Original ticket message */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between">
              <CardTitle className="text-sm font-medium">پیام اصلی</CardTitle>
              <span className="text-xs text-gray-500">{formatDate(ticket.createdAt)}</span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-3 rounded-md text-sm">
              {ticket.description}
            </div>
          </CardContent>
        </Card>

        {/* Ticket responses */}
        <div className="border rounded-md">
          <div className="p-3 border-b bg-gray-50">
            <h3 className="font-medium">تاریخچه گفتگو</h3>
          </div>
          
          <ScrollArea className="h-64">
            {isLoadingResponses ? (
              <div className="flex justify-center items-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : responses && responses.length > 0 ? (
              <div className="space-y-3 p-3">
                {responses.map((response) => (
                  <Card key={response.id} className={`border ${response.userId === ticket.userId ? 'border-gray-200' : 'border-primary/20 bg-primary/5'}`}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${response.userId === ticket.userId ? 'bg-gray-200' : 'bg-primary'}`}>
                            <span className={`text-sm font-bold ${response.userId === ticket.userId ? 'text-gray-700' : 'text-white'}`}>
                              {response.userId === ticket.userId ? 'ک' : 'پ'}
                            </span>
                          </div>
                          <span className="text-sm font-medium">
                            {response.userId === ticket.userId ? 'کاربر' : 'پشتیبان'}
                          </span>
                        </div>
                        <span className="text-xs text-gray-500">{formatDate(response.createdAt)}</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm">{response.message}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center p-8 text-gray-500">
                <MessageSquare className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                <p>هنوز پاسخی ثبت نشده است</p>
              </div>
            )}
          </ScrollArea>
        </div>

        {/* Response form */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">ثبت پاسخ</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(submitResponse)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>پاسخ شما</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="پاسخ خود را بنویسید..."
                          className="min-h-[100px] resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>وضعیت تیکت</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب وضعیت" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="open">باز</SelectItem>
                          <SelectItem value="in_progress">در حال بررسی</SelectItem>
                          <SelectItem value="resolved">حل شده</SelectItem>
                          <SelectItem value="closed">بسته شده</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2">
                  <Button variant="outline" type="button" onClick={onClose}>
                    انصراف
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                    ثبت پاسخ
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </DialogContent>
  );
};

// Main ticket management component
const TicketManagement: React.FC = () => {
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Fetch all tickets
  const { data: tickets, isLoading } = useQuery<Ticket[]>({
    queryKey: ['/api/admin/tickets'],
  });

  const handleViewTicket = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
  };

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>مدیریت تیکت‌های پشتیبانی</CardTitle>
            <CardDescription>پاسخگویی به درخواست‌های پشتیبانی کاربران</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : tickets && tickets.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px]">شناسه</TableHead>
                <TableHead>موضوع</TableHead>
                <TableHead>کاربر</TableHead>
                <TableHead>تاریخ</TableHead>
                <TableHead>وضعیت</TableHead>
                <TableHead className="w-[100px]">عملیات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tickets.map((ticket) => (
                <TableRow key={ticket.id}>
                  <TableCell className="font-medium">{ticket.id}</TableCell>
                  <TableCell>{ticket.subject}</TableCell>
                  <TableCell>{ticket.userId}</TableCell>
                  <TableCell>{ticket.createdAt ? format(new Date(ticket.createdAt), 'yyyy/MM/dd') : 'تاریخ نامشخص'}</TableCell>
                  <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={() => handleViewTicket(ticket)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center py-8">
            <LifeBuoy className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p className="text-gray-500">هیچ تیکت پشتیبانی یافت نشد</p>
          </div>
        )}
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        {selectedTicket && <TicketDetailDialog ticket={selectedTicket} onClose={handleCloseDialog} />}
      </Dialog>
    </Card>
  );
};

export default TicketManagement;