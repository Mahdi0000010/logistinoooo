import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2 } from "lucide-react";
import { insertBlogPostSchema, InsertBlogPost } from "@shared/schema";

// Extend the Zod schema for client-side validation
const blogPostFormSchema = insertBlogPostSchema.extend({
  title: z.string().min(5, { message: "عنوان حداقل باید 5 کاراکتر باشد" }),
  slug: z.string().min(3, { message: "نامک حداقل باید 3 کاراکتر باشد" }).regex(/^[a-z0-9-]+$/, { message: "نامک باید فقط شامل حروف انگلیسی کوچک، اعداد و خط تیره باشد" }),
  content: z.string().min(30, { message: "محتوا حداقل باید 30 کاراکتر باشد" }),
  excerpt: z.string().optional().nullable(),
  featuredImage: z.string().optional().nullable(),
  published: z.boolean().optional().nullable(),
});

interface BlogPostFormProps {
  post?: InsertBlogPost & { id?: number };
  onSuccess?: () => void;
}

const BlogPostForm: React.FC<BlogPostFormProps> = ({ post, onSuccess }) => {
  const { toast } = useToast();
  const { user } = useAuth();
  
  const defaultValues: Partial<InsertBlogPost> = {
    title: post?.title || "",
    slug: post?.slug || "",
    content: post?.content || "",
    excerpt: post?.excerpt || "",
    featuredImage: post?.featuredImage || "",
    published: post?.published || false,
    authorId: user?.id || 0,
  };

  const form = useForm<InsertBlogPost>({
    resolver: zodResolver(blogPostFormSchema),
    defaultValues,
  });

  const createPost = useMutation({
    mutationFn: async (data: InsertBlogPost) => {
      const res = await apiRequest("POST", "/api/blog", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "عملیات موفق",
        description: "مقاله با موفقیت ذخیره شد",
      });
      form.reset(defaultValues);
      if (onSuccess) onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "خطا",
        description: error.message || "خطا در ذخیره مقاله",
        variant: "destructive",
      });
    },
  });
  
  const updatePost = useMutation({
    mutationFn: async (data: InsertBlogPost & { id?: number }) => {
      // If we have post id (passed from parent) add it to PUT request
      const id = post?.id;
      if (!id) throw new Error("شناسه پست یافت نشد");
      
      const res = await apiRequest("PUT", `/api/blog/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "عملیات موفق",
        description: "مقاله با موفقیت بروزرسانی شد",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "خطا",
        description: error.message || "خطا در بروزرسانی مقاله",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertBlogPost) => {
    // Make sure authorId is set
    data.authorId = user?.id || 0;
    
    // If we have a post already, update it, otherwise create new
    if (post?.id) {
      updatePost.mutate({ ...data, id: post.id });
    } else {
      createPost.mutate(data);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 p-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>عنوان</FormLabel>
              <FormControl>
                <Input placeholder="عنوان مقاله" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="slug"
          render={({ field }) => (
            <FormItem>
              <FormLabel>نامک (slug)</FormLabel>
              <FormControl>
                <Input placeholder="نامک-مقاله" dir="ltr" {...field} />
              </FormControl>
              <FormDescription className="text-xs">
                نامک یک شناسه منحصربفرد برای مقاله است که در URL استفاده می‌شود
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="excerpt"
          render={({ field }) => (
            <FormItem>
              <FormLabel>چکیده</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="خلاصه‌ای از مقاله..."
                  className="resize-none"
                  rows={3}
                  {...field}
                  value={field.value || ""}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="content"
          render={({ field }) => (
            <FormItem>
              <FormLabel>محتوا</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="متن کامل مقاله..."
                  className="resize-none"
                  rows={10}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="featuredImage"
          render={({ field }) => (
            <FormItem>
              <FormLabel>تصویر شاخص</FormLabel>
              <FormControl>
                <Input
                  placeholder="آدرس تصویر شاخص"
                  dir="ltr"
                  {...field}
                  value={field.value || ""}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="published"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0 rtl:space-x-reverse">
              <FormControl>
                <Checkbox
                  checked={field.value || false}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel>انتشار فوری</FormLabel>
                <FormDescription className="text-xs">
                  اگر این گزینه را انتخاب کنید، مقاله بلافاصله منتشر می‌شود
                </FormDescription>
              </div>
            </FormItem>
          )}
        />
        
        <Button 
          type="submit" 
          disabled={createPost.isPending || updatePost.isPending}
          className="w-full"
        >
          {(createPost.isPending || updatePost.isPending) ? (
            <Loader2 className="h-4 w-4 animate-spin me-2" />
          ) : null}
          {post?.id ? 'ویرایش' : 'ذخیره'}
        </Button>
      </form>
    </Form>
  );
};

export default BlogPostForm;