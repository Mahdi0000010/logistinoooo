import { useState } from "react";
import { Star, StarHalf } from "lucide-react";

interface Testimonial {
  id: number;
  content: string;
  rating: number;
  author: {
    name: string;
    company: string;
    avatar: string;
  };
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    content: "با استفاده از لجستینو توانستم به راحتی محموله‌های صادراتی خود را ارسال کنم. قیمت‌های مناسب و خدمات عالی. حتما باز هم از خدمات لجستینو استفاده خواهم کرد.",
    rating: 5,
    author: {
      name: "علی محمدی",
      company: "شرکت صادرات کالای ایرانیان",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg"
    }
  },
  {
    id: 2,
    content: "سرعت عمل و دقت در ارسال بار عالی بود. پشتیبانی سایت همیشه پاسخگو بودند و تمام مراحل ارسال را به دقت پیگیری کردند. قطعا برای حمل محموله‌های بعدی هم از لجستینو استفاده خواهم کرد.",
    rating: 4.5,
    author: {
      name: "مریم احمدی",
      company: "مدیر بازرگانی شرکت تجارت گستر",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg"
    }
  },
  {
    id: 3,
    content: "برای اولین بار از خدمات لجستینو استفاده کردم و از سهولت استفاده از سایت و قیمت‌های مناسب آن شگفت‌زده شدم. مقایسه قیمت‌ها و انتخاب بهترین گزینه بسیار راحت بود. حتما به همکارانم هم معرفی می‌کنم.",
    rating: 5,
    author: {
      name: "حسین رضایی",
      company: "صاحب شرکت واردات مواد غذایی",
      avatar: "https://randomuser.me/api/portraits/men/67.jpg"
    }
  }
];

const Testimonials = () => {
  // Function to render stars based on rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-amber-400 text-amber-400" size={16} />);
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="fill-amber-400 text-amber-400" size={16} />);
    }
    
    return stars;
  };

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">نظرات مشتریان ما</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            آنچه مشتریان ما درباره خدمات لجستینو می‌گویند
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="text-amber-400 flex">
                  {renderStars(testimonial.rating)}
                </div>
                <span className="mr-2 text-gray-500">{testimonial.rating}</span>
              </div>
              
              <p className="text-gray-700 mb-6">"{testimonial.content}"</p>
              
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-300 rounded-full overflow-hidden">
                  <svg className="w-full h-full text-gray-500" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                  </svg>
                </div>
                <div className="mr-3">
                  <h4 className="font-medium">{testimonial.author.name}</h4>
                  <p className="text-sm text-gray-500">{testimonial.author.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
