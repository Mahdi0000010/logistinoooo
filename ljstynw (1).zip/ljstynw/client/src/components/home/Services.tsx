import {
  Ship,
  Truck,
  Train,
  ChevronLeft
} from "lucide-react";

const services = [
  {
    icon: <Ship className="text-2xl" />,
    title: "حمل و نقل دریایی",
    description: "حمل و نقل دریایی با کشتی‌های باری و لنج‌های مختلف از بنادر ایران به بنادر کشورهای حوزه خلیج فارس",
    color: "primary"
  },
  {
    icon: <Truck className="text-2xl" />,
    title: "حمل و نقل زمینی",
    description: "حمل و نقل زمینی با کامیون و تریلی از مبادی مختلف داخل کشور به بنادر جنوبی و بالعکس",
    color: "secondary"
  },
  {
    icon: <Train className="text-2xl" />,
    title: "حمل و نقل ریلی",
    description: "حمل و نقل ریلی با قطارهای باری از مبادی مختلف داخل کشور به بنادر جنوبی و بالعکس",
    color: "accent"
  }
];

const Services = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">خدمات حمل و نقل ما</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            با بهره‌گیری از شبکه گسترده حمل و نقل دریایی، زمینی و ریلی، خدمات متنوعی را برای انتقال بار شما ارائه می‌دهیم
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-lg p-6 shadow-sm hover:shadow-md transition text-center"
            >
              <div className={`w-16 h-16 bg-${service.color}/10 text-${service.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{service.title}</h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <a href="#" className="text-primary font-medium hover:text-primary-dark flex items-center justify-center">
                اطلاعات بیشتر 
                <ChevronLeft className="mr-1" size={16} />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
