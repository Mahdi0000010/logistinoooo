import { useMobile } from "@/hooks/use-mobile";
import { Search, ListFilter, CreditCard, PackageSearch, ArrowRight } from "lucide-react";

const steps = [
  {
    number: "1",
    title: "جستجو",
    description: "مبدا، مقصد و مشخصات بار خود را وارد کنید",
    iconType: "search"
  },
  {
    number: "2",
    title: "مقایسه",
    description: "بین گزینه‌های مختلف مقایسه کنید و بهترین را انتخاب کنید",
    iconType: "filter"
  },
  {
    number: "3",
    title: "رزرو",
    description: "سفارش خود را ثبت کنید و هزینه را پرداخت نمایید",
    iconType: "payment"
  },
  {
    number: "4",
    title: "پیگیری",
    description: "محموله خود را از طریق سیستم پیگیری ردیابی کنید",
    iconType: "track"
  }
];

const HowItWorks = () => {
  const isMobile = useMobile();

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-gray-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">چگونه کار می‌کند؟</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            در چند مرحله ساده می‌توانید بار خود را ارسال کنید
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 px-4">
          {steps.map((step, index) => (
            <div 
              key={index} 
              className="text-center group bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <div className="relative">
                <div 
                  className="w-24 h-24 bg-primary text-white rounded-full flex flex-col items-center justify-center mx-auto mb-8 relative
                            group-hover:shadow-lg group-hover:shadow-primary/30 transition-all duration-300"
                >
                  {/* آیکون */}
                  <div className="mb-1">
                    {step.iconType === "search" && <Search size={28} className="group-hover:scale-110 transition-transform duration-300" />}
                    {step.iconType === "filter" && <ListFilter size={28} className="group-hover:scale-110 transition-transform duration-300" />}
                    {step.iconType === "payment" && <CreditCard size={28} className="group-hover:scale-110 transition-transform duration-300" />}
                    {step.iconType === "track" && <PackageSearch size={28} className="group-hover:scale-110 transition-transform duration-300" />}
                  </div>
                  {/* شماره */}
                  <span className="text-lg font-bold">{step.number}</span>
                  
                  {/* خط اتصال بین مراحل */}
                  {!isMobile && index < steps.length - 1 && (
                    <div className="absolute w-full h-1 bg-primary right-full top-1/2 -translate-y-1/2 hidden md:block">
                      <ArrowRight className="absolute -right-3 -top-[7px] text-primary" size={16} />
                    </div>
                  )}
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-3 group-hover:text-primary transition-colors duration-300">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;