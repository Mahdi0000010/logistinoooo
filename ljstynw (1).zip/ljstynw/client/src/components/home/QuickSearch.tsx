import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from "@/components/ui/popover";
import { Check, ChevronsUpDown, Search, X } from "lucide-react";
import DatePicker from "@/components/shared/DatePicker";
import { Location } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { storageManager, SearchValues } from '@/lib/storage-manager';
import { cn } from "@/lib/utils";

const QuickSearch = () => {
  const [, navigate] = useLocation();
  
  // استفاده از مدیریت کننده ذخیره‌سازی برای بازیابی مقادیر اولیه
  const storedValues = storageManager.getSearchValues();
  
  const [originId, setOriginId] = useState<string>(storedValues.originId || "");
  const [destinationId, setDestinationId] = useState<string>(storedValues.destinationId || "");
  const [departureDate, setDepartureDate] = useState<string>(storedValues.departureDate || "");
  const [cargoType, setCargoType] = useState<string>(storedValues.cargoType || "");

  // Fetch locations
  const { data: locations, isLoading: isLoadingLocations } = useQuery({
    queryKey: ['/api/locations'],
    queryFn: async () => {
      const res = await fetch('/api/locations');
      return await res.json();
    },
  });

  const ports = locations?.filter((loc: Location) => loc.type === "port") || [];
  const inlandLocations = locations?.filter((loc: Location) => loc.type === "inland") || [];
  const allLocations = locations || [];

  // Get unique countries with standard JS
  const countryMap: Record<string, boolean> = {};
  const countries = allLocations
    .map((loc: Location) => loc.country)
    .filter((country: string) => {
      if (!countryMap[country]) {
        countryMap[country] = true;
        return true;
      }
      return false;
    });
  
  // مدیریت تغییر مبدا با ذخیره در storage manager
  const handleOriginChange = (value: string) => {
    setOriginId(value);
    if (value && value !== "placeholder") {
      const selectedLocation = allLocations.find(
        (loc: Location) => loc.id.toString() === value
      );
      
      if (selectedLocation) {
        // ذخیره همه مقادیر مرتبط
        storageManager.updateSearchValues({
          originId: value,
          originCountry: selectedLocation.country,
          originType: selectedLocation.type
        });
      } else {
        storageManager.updateSearchValues({ originId: value });
      }
    }
  };
  
  // مدیریت تغییر مقصد با ذخیره در storage manager
  const handleDestinationChange = (value: string) => {
    setDestinationId(value);
    if (value && value !== "placeholder") {
      const selectedLocation = allLocations.find(
        (loc: Location) => loc.id.toString() === value
      );
      
      if (selectedLocation) {
        // ذخیره همه مقادیر مرتبط
        storageManager.updateSearchValues({
          destinationId: value,
          destinationCountry: selectedLocation.country,
          destinationType: selectedLocation.type
        });
      } else {
        storageManager.updateSearchValues({ destinationId: value });
      }
    }
  };
  
  // مدیریت تغییر تاریخ حمل
  const handleDepartureDateChange = (value: string) => {
    setDepartureDate(value);
    storageManager.updateSearchValues({ departureDate: value });
  };
  
  // مدیریت تغییر نوع بار
  const handleCargoTypeChange = (value: string) => {
    setCargoType(value);
    storageManager.updateSearchValues({ cargoType: value });
  };

  const handleSearch = () => {
    // ذخیره مقادیر نهایی قبل از هدایت
    // این حالت برای زمانی است که کاربر مقادیر را تغییر داده ولی هنوز تابع handleChange اجرا نشده
    if (originId) handleOriginChange(originId);
    if (destinationId) handleDestinationChange(destinationId);
    if (departureDate) handleDepartureDateChange(departureDate);
    if (cargoType) handleCargoTypeChange(cargoType);
    
    // ایجاد پارامترهای URL
    const params = new URLSearchParams();
    if (originId && originId !== "placeholder") params.append("originId", originId);
    if (destinationId && destinationId !== "placeholder") params.append("destinationId", destinationId);
    if (departureDate) params.append("departureDate", departureDate);
    if (cargoType && cargoType !== "all") params.append("cargoType", cargoType);
    
    navigate(`/search?${params.toString()}`);
  };

  const [openOrigin, setOpenOrigin] = useState(false);
  const [openDestination, setOpenDestination] = useState(false);
  const [originSearch, setOriginSearch] = useState("");
  const [destinationSearch, setDestinationSearch] = useState("");

  // تابع کمکی برای چک کردن تطابق کاراکتر به کاراکتر
  const perCharacterMatch = (locationText: string, searchText: string): boolean => {
    if (!searchText.trim()) return true;
    
    // هر کاراکتر در جستجو را بررسی کن
    for (const char of searchText) {
      if (!locationText.includes(char)) {
        return false;
      }
    }
    return true;
  };

  const filteredOriginLocations = allLocations.filter((location: Location) => {
    if (!originSearch.trim()) return true;
    
    // روش ساده - هر کاراکتر را جداگانه چک کن
    return (
      // بررسی بر اساس تطابق دقیق (شامل بودن رشته)
      location.name.includes(originSearch) || 
      location.country.includes(originSearch) ||
      
      // بررسی بر اساس تطابق کاراکتر به کاراکتر
      perCharacterMatch(location.name, originSearch) || 
      perCharacterMatch(location.country, originSearch)
    );
  });

  const filteredDestinationLocations = allLocations.filter((location: Location) => {
    if (!destinationSearch.trim()) return true;
    
    // روش ساده - هر کاراکتر را جداگانه چک کن
    return (
      // بررسی بر اساس تطابق دقیق (شامل بودن رشته)
      location.name.includes(destinationSearch) || 
      location.country.includes(destinationSearch) ||
      
      // بررسی بر اساس تطابق کاراکتر به کاراکتر
      perCharacterMatch(location.name, destinationSearch) || 
      perCharacterMatch(location.country, destinationSearch)
    );
  });

  // جستجوی مکان با شناسه
  const getLocationNameById = (locationId: string) => {
    const location = allLocations.find((loc: Location) => loc.id.toString() === locationId);
    return location ? `${location.name}، ${location.country}` : "انتخاب مکان";
  };

  return (
    <Card className="border shadow-lg">
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div>
            <Label className="block text-gray-700 mb-2 font-medium">مبدا</Label>
            <div className="border rounded-md relative">
              <Input
                type="text"
                placeholder="جستجوی مبدا..."
                value={originSearch}
                onChange={(e) => setOriginSearch(e.target.value)}
                onFocus={() => setOpenOrigin(true)}
                className="w-full"
              />
              {(originSearch.length > 0 || openOrigin) && (
                <div className="absolute z-50 w-full max-h-[300px] overflow-y-auto bg-white border rounded-md shadow-lg mt-1">
                  {filteredOriginLocations.length > 0 ? (
                    filteredOriginLocations.map((location: Location) => (
                      <div
                        key={`origin-${location.id}`}
                        className={`px-3 py-2 hover:bg-gray-100 cursor-pointer ${
                          originId === location.id.toString() ? "bg-primary/10" : ""
                        }`}
                        onClick={() => {
                          handleOriginChange(location.id.toString());
                          setOpenOrigin(false);
                          setOriginSearch("");
                        }}
                      >
                        {location.name}، {location.country} ({location.type === "port" ? "بندر" : "شهر"})
                      </div>
                    ))
                  ) : (
                    <div className="px-3 py-2 text-gray-500">هیچ مکانی یافت نشد.</div>
                  )}
                </div>
              )}
              {originId && (
                <div className="mt-2 px-2 py-1 bg-primary/10 text-primary rounded flex items-center justify-between">
                  <span>{getLocationNameById(originId)}</span>
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    className="h-6 w-6 p-0" 
                    onClick={() => {
                      setOriginId("");
                      setOriginSearch("");
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
          
          <div>
            <Label className="block text-gray-700 mb-2 font-medium">مقصد</Label>
            <div className="border rounded-md relative">
              <Input
                type="text"
                placeholder="جستجوی مقصد..."
                value={destinationSearch}
                onChange={(e) => setDestinationSearch(e.target.value)}
                onFocus={() => setOpenDestination(true)}
                className="w-full"
              />
              {(destinationSearch.length > 0 || openDestination) && (
                <div className="absolute z-50 w-full max-h-[300px] overflow-y-auto bg-white border rounded-md shadow-lg mt-1">
                  {filteredDestinationLocations.length > 0 ? (
                    filteredDestinationLocations.map((location: Location) => (
                      <div
                        key={`dest-${location.id}`}
                        className={`px-3 py-2 hover:bg-gray-100 cursor-pointer ${
                          destinationId === location.id.toString() ? "bg-primary/10" : ""
                        }`}
                        onClick={() => {
                          handleDestinationChange(location.id.toString());
                          setOpenDestination(false);
                          setDestinationSearch("");
                        }}
                      >
                        {location.name}، {location.country} ({location.type === "port" ? "بندر" : "شهر"})
                      </div>
                    ))
                  ) : (
                    <div className="px-3 py-2 text-gray-500">هیچ مکانی یافت نشد.</div>
                  )}
                </div>
              )}
              {destinationId && (
                <div className="mt-2 px-2 py-1 bg-primary/10 text-primary rounded flex items-center justify-between">
                  <span>{getLocationNameById(destinationId)}</span>
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    className="h-6 w-6 p-0" 
                    onClick={() => {
                      setDestinationId("");
                      setDestinationSearch("");
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
          
          <div>
            <Label className="block text-gray-700 mb-2 font-medium">تاریخ حمل</Label>
            <DatePicker
              value={departureDate}
              onChange={handleDepartureDateChange}
              placeholder="انتخاب تاریخ حمل"
              className="w-full"
            />
          </div>
          
          <div className="flex flex-col">
            <div className="flex-grow">
              <Label className="block text-gray-700 mb-2 font-medium">نوع بار</Label>
              <Select value={cargoType} onValueChange={handleCargoTypeChange}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="انتخاب نوع بار" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه انواع</SelectItem>
                  <SelectItem value="food">مواد غذایی</SelectItem>
                  <SelectItem value="industrial">مواد صنعتی</SelectItem>
                  <SelectItem value="chemical">مواد شیمیایی</SelectItem>
                  <SelectItem value="perishable">کالای فاسد شدنی</SelectItem>
                  <SelectItem value="clothes">پوشاک</SelectItem>
                  <SelectItem value="electronics">لوازم الکترونیکی</SelectItem>
                  <SelectItem value="furniture">مبلمان</SelectItem>
                  <SelectItem value="vehicles">خودرو و قطعات</SelectItem>
                  <SelectItem value="other">سایر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="mt-auto pt-6 flex justify-end">
              <Button 
                onClick={handleSearch}
                className="w-full md:w-auto"
                size="lg"
              >
                جستجوی پیشرفته
                <Search className="mr-2" size={18} />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickSearch;