import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface Location {
  id: number;
  name: string;
  type: string;
  country: string;
}

interface LocationsDropdownProps {
  selectedLocationId?: number;
  onLocationSelect: (locationId: number | undefined) => void;
  placeholder?: string;
  countryFilter?: string | null;
}

export default function LocationsDropdown({
  selectedLocationId,
  onLocationSelect,
  placeholder = "انتخاب مکان",
  countryFilter = null,
}: LocationsDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
    queryFn: async () => {
      const res = await fetch("/api/locations");
      if (!res.ok) {
        throw new Error("Failed to fetch locations");
      }
      return res.json();
    },
  });
  
  // Filter locations based on country filter and search term
  const filteredLocations = locations
    .filter(location => !countryFilter || location.country === countryFilter)
    .filter(location => {
      // For Farsi/Arabic text, we need to handle search differently
      const normalizeForSearch = (text: string) => {
        return text.replace(/\s*\(.*?\)\s*/g, "").trim().replace(/أ|آ|إ/g, "ا");
      };
      
      const normalizedName = normalizeForSearch(location.name.toLowerCase());
      const normalizedSearchTerm = normalizeForSearch(searchTerm.toLowerCase());
      
      return normalizedName.includes(normalizedSearchTerm);
    });
  
  // Sort locations: first by country, then by type (port first), then by name
  const sortedLocations = [...filteredLocations].sort((a, b) => {
    // Sort by country
    if (a.country !== b.country) {
      return a.country.localeCompare(b.country);
    }
    
    // Then by type (port first)
    if (a.type !== b.type) {
      return a.type === "port" ? -1 : 1;
    }
    
    // Then by name
    return a.name.localeCompare(b.name);
  });
  
  // Get the selected location name for display
  const selectedLocation = locations.find(loc => loc.id === selectedLocationId);
  
  // Handle outside click to close dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  
  // Map location type to a friendly display name
  const getLocationTypeLabel = (type: string) => {
    switch (type) {
      case "port":
        return "بندر";
      case "inland":
        return "شهر";
      default:
        return type;
    }
  };
  
  return (
    <div className="relative w-full" ref={dropdownRef}>
      <div
        className={`flex w-full rounded-md border ${
          isOpen ? "border-primary ring-2 ring-primary/5" : "border-input"
        } bg-background px-3 py-2 text-sm shadow-sm transition-colors hover:border-primary focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer`}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex-1 flex items-center">
          {isOpen ? (
            <Input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="جستجو..."
              className="w-full border-none outline-none focus-visible:ring-0 focus-visible:ring-offset-0 p-0"
              onClick={(e) => e.stopPropagation()}
              autoFocus
            />
          ) : selectedLocation ? (
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="mr-1 font-normal">
                {getLocationTypeLabel(selectedLocation.type)}
              </Badge>
              <span>{selectedLocation.name}</span>
              <span className="text-gray-500 text-xs">({selectedLocation.country})</span>
            </div>
          ) : (
            <span className="text-muted-foreground">{placeholder}</span>
          )}
        </div>
        <Search className="h-4 w-4 text-muted-foreground" />
      </div>
      
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-y-auto">
          {sortedLocations.length > 0 ? (
            <div className="p-1">
              {sortedLocations.map((location) => (
                <div
                  key={location.id}
                  className={`px-2 py-1.5 text-sm hover:bg-primary/5 rounded cursor-pointer ${
                    selectedLocationId === location.id ? "bg-primary/10 text-primary" : ""
                  }`}
                  onClick={() => {
                    onLocationSelect(location.id);
                    setIsOpen(false);
                    setSearchTerm("");
                  }}
                >
                  <div className="flex items-center">
                    <Badge variant="outline" className="mr-1 font-normal">
                      {getLocationTypeLabel(location.type)}
                    </Badge>
                    <span className="mr-1">{location.name}</span>
                    <span className="text-gray-500 text-xs">({location.country})</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-2 text-center text-sm text-gray-500">
              موردی یافت نشد
            </div>
          )}
          
          <div className="p-1 border-t mt-1">
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-muted-foreground hover:text-primary"
              onClick={() => {
                onLocationSelect(undefined);
                setIsOpen(false);
                setSearchTerm("");
              }}
            >
              پاک کردن انتخاب
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}