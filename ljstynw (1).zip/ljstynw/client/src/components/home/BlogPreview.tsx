import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, Calendar, User } from "lucide-react";
import { BlogPost } from "@shared/schema";

// Date formatter
const formatDate = (date: Date) => {
  try {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString('fa-IR', options);
  } catch (error) {
    return 'تاریخ نامشخص';
  }
};

const BlogPreview = () => {
  // Fetch blog posts
  const { data: posts, isLoading } = useQuery({
    queryKey: ['/api/blog'],
    queryFn: async () => {
      // In a real app, this would be an API call
      const res = await fetch('/api/blog?limit=3');
      return await res.json();
    },
  });

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold">آخرین مقالات وبلاگ</h2>
          <Link href="/blog" className="text-primary font-medium hover:text-primary-dark flex items-center">
            مشاهده همه مقالات
            <ChevronLeft className="mr-1" size={16} />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {isLoading ? (
            // Loading skeletons
            Array(3).fill(0).map((_, index) => (
              <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                <Skeleton className="h-48 w-full" />
                <div className="p-5">
                  <Skeleton className="h-4 w-32 mb-2" />
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-4 w-3/4 mb-4" />
                  <Skeleton className="h-4 w-28" />
                </div>
              </div>
            ))
          ) : (
            posts?.slice(0, 3).map((post: BlogPost) => (
              <div key={post.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition">
                <div className="h-48 overflow-hidden">
                  <div className="w-full h-full bg-gray-300 flex items-center justify-center">
                    <svg className="w-12 h-12 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                    </svg>
                  </div>
                </div>
                <div className="p-5">
                  <div className="flex items-center text-gray-500 text-sm mb-2">
                    <div className="flex items-center ml-3">
                      <Calendar className="ml-1" size={14} />
                      <span>{post.createdAt ? formatDate(new Date(post.createdAt)) : 'بدون تاریخ'}</span>
                    </div>
                    <div className="flex items-center">
                      <User className="ml-1" size={14} />
                      <span>{"ادمین"}</span>
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{post.title}</h3>
                  <p className="text-gray-600 mb-4">{post.excerpt}</p>
                  <Link href={`/blog/${post.slug}`}>
                    <span className="text-primary font-medium hover:text-primary-dark flex items-center w-fit">
                      ادامه مطلب 
                      <ChevronLeft className="mr-1" size={16} />
                    </span>
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default BlogPreview;
