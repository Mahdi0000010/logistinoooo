import { useQuery } from "@tanstack/react-query";
import { Loader2, Ship, Truck, Train, Package } from "lucide-react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type NewService = {
  id: number;
  transporterId: number;
  transporterName: string;
  transporterDescription: string;
  originId: number;
  originName: string;
  originCountry: string;
  destinationId: number;
  destinationName: string;
  destinationCountry: string;
  departureDate: string;
  arrivalDate: string;
  transportType: "sea" | "land" | "rail" | "mixed";
  containerType: string;
  capacity: number;
  price: number;
  insuranceAvailable: boolean;
  insurancePrice: number;
  specialNotes: string;
};

// تابع برای تبدیل تاریخ به فرمت فارسی
const formatPersianDate = (dateString: string): string => {
  try {
    return new Date(dateString).toLocaleDateString('fa-IR');
  } catch (e) {
    return 'تاریخ نامشخص';
  }
};

// تابع برای نمایش آیکون مناسب برای نوع حمل و نقل
const TransportIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'sea':
      return <Ship className="h-5 w-5 text-blue-500" />;
    case 'land':
      return <Truck className="h-5 w-5 text-green-500" />;
    case 'rail':
      return <Train className="h-5 w-5 text-orange-500" />;
    default:
      return <Package className="h-5 w-5 text-purple-500" />;
  }
};

// تابع برای نمایش متن نوع حمل و نقل
const getTransportTypeText = (type: string): string => {
  switch (type) {
    case 'sea':
      return 'حمل و نقل دریایی';
    case 'land':
      return 'حمل و نقل زمینی';
    case 'rail':
      return 'حمل و نقل ریلی';
    case 'mixed':
      return 'حمل و نقل ترکیبی';
    default:
      return 'نامشخص';
  }
};

// تابع برای نمایش متن نوع کانتینر
const getContainerTypeText = (containerType: string): string => {
  switch (containerType) {
    case '20_standard':
      return 'کانتینر ۲۰ فوت استاندارد';
    case '40_standard':
      return 'کانتینر ۴۰ فوت استاندارد';
    case '40_high_cube':
      return 'کانتینر ۴۰ فوت های‌کیوب';
    case 'refrigerated':
      return 'کانتینر یخچالی';
    case 'open_top':
      return 'کانتینر روباز';
    case 'bulk':
      return 'فله';
    case 'general':
      return 'عمومی';
    default:
      return containerType || 'نامشخص';
  }
};

export default function NewServices() {
  const [location, setLocation] = useLocation();
  
  const { data, isLoading, error } = useQuery<NewService[]>({
    queryKey: ['/api/new-shipments'],
    queryFn: async () => {
      const res = await fetch('/api/new-shipments');
      if (!res.ok) {
        throw new Error('خطا در دریافت اطلاعات سرویس‌های جدید');
      }
      return res.json();
    }
  });
  
  // ریدایرکت به صفحه جزئیات سرویس
  const handleViewDetails = (id: number) => {
    setLocation(`/shipment/${id}`);
  };
  
  if (isLoading) {
    return (
      <div className="w-full py-8 flex justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="w-full py-8 text-center text-red-500">
        خطا در بارگذاری سرویس‌های جدید. لطفاً مجدداً تلاش کنید.
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="w-full py-8 text-center text-muted-foreground">
        در حال حاضر سرویس جدیدی موجود نیست.
      </div>
    );
  }

  return (
    <section className="py-12 bg-gradient-to-b from-white to-slate-50">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <div className="inline-block px-4 py-2 mb-4 bg-primary/10 text-primary rounded-full text-md font-bold">
            تازه‌ترین سرویس‌ها
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">سرویس‌های جدید حمل و نقل</h2>
          <p className="text-slate-600 max-w-2xl mx-auto text-lg">تازه‌ترین سرویس‌های حمل و نقل اضافه شده توسط شرکت‌های معتبر با بهترین قیمت‌ها</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {data.map((service) => (
            <Card key={service.id} className="overflow-hidden hover:shadow-xl transition-all duration-300 relative border-slate-200 group">
              
              <CardHeader className="bg-gradient-to-r from-primary/90 to-primary-dark/90 text-white p-6 pb-16 relative overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.1),transparent)] z-0"></div>
                <div className="absolute inset-0 bg-black/25 z-5"></div>
                <div className="relative z-10">
                  <div className="flex justify-between items-center mb-4">
                    <Badge variant="secondary" className="bg-white/20 text-white hover:bg-white/30 flex items-center gap-1 text-sm font-semibold">
                      <TransportIcon type={service.transportType} />
                      {getTransportTypeText(service.transportType)}
                    </Badge>
                    <Badge variant="secondary" className="bg-white/20 text-white hover:bg-white/30 text-sm font-semibold">
                      {formatPersianDate(service.departureDate)}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl font-extrabold text-yellow-300 drop-shadow-sm">{service.originName} به {service.destinationName}</CardTitle>
                  <CardDescription className="text-white text-md font-semibold mt-1">{service.transporterName}</CardDescription>
                </div>
              </CardHeader>
              
              <div className="relative -mt-10 mx-5 bg-white rounded-lg shadow-lg p-5 z-10 border border-slate-100">
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center bg-slate-50 px-3 py-2 rounded-md">
                    <Package className="h-5 w-5 text-primary ml-2" />
                    <span className="text-md font-semibold text-slate-800">{getContainerTypeText(service.containerType)}</span>
                  </div>
                  <Badge variant="outline" className="rounded-md text-md font-semibold py-2 px-3 bg-slate-50 border-slate-200">
                    ظرفیت: {service.capacity} تن
                  </Badge>
                </div>
                
                {service.specialNotes && (
                  <div className="text-md text-slate-700 mb-5 p-3 bg-yellow-50 border-r-4 border-yellow-400 rounded">
                    <span className="ml-2 font-bold">توضیحات:</span>
                    {service.specialNotes}
                  </div>
                )}
                
                <div className="flex flex-col items-center bg-primary/5 rounded-lg p-4 mb-4 mt-4 border border-primary/10">
                  <span className="text-md font-bold text-slate-700 mb-2">قیمت حمل و نقل</span>
                  <span className="text-3xl font-extrabold text-primary">
                    {service.price.toLocaleString('fa-IR')}
                    <span className="text-sm font-medium mr-2">تومان</span>
                  </span>
                  {service.insuranceAvailable && (
                    <div className="flex items-center gap-2 text-sm text-green-600 mt-3 bg-green-50 px-3 py-1 rounded-full">
                      <span className="font-semibold">امکان بیمه محموله</span>
                      <span className="font-bold">{service.insurancePrice.toLocaleString('fa-IR')} تومان</span>
                    </div>
                  )}
                </div>
              </div>
              
              <CardFooter className="flex justify-between pt-2 px-6 pb-6">
                <Button variant="outline" onClick={() => handleViewDetails(service.id)}
                  className="transition-all hover:bg-slate-50 text-md font-semibold px-4 py-2">
                  مشاهده جزئیات
                </Button>
                
                <Button variant="default" 
                  className="bg-primary hover:bg-primary-dark transition-all hover:scale-105 text-md font-semibold px-4 py-2">
                  ثبت سفارش
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-14">
          <Button
            variant="outline"
            className="px-8 py-6 text-lg font-bold border-2 border-primary text-primary hover:bg-primary/5"
            onClick={() => setLocation('/search')}
          >
            مشاهده همه سرویس‌های حمل و نقل
          </Button>
        </div>
      </div>
    </section>
  );
}