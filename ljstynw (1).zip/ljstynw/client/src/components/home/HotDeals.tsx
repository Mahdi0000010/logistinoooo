import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Ship, Truck, Train, ChevronLeft } from "lucide-react";
import { Link } from "wouter";

interface Deal {
  id: number;
  route: string;
  description: string;
  departureDate: string;
  companyName: string;
  price: number;
  badge: {
    text: string;
    color: string;
  };
  transportType: "sea" | "land" | "rail" | "mixed";
}

const HotDeals = () => {
  const [deals, setDeals] = useState<Deal[]>([]);
  
  // Fetch hot deals from API
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/hot-deals'],
    queryFn: async () => {
      const response = await fetch('/api/hot-deals');
      if (!response.ok) {
        throw new Error('Failed to fetch hot deals');
      }
      return await response.json();
    }
  });
  
  useEffect(() => {
    if (data && Array.isArray(data)) {
      setDeals(data);
    } else if (data) {
      console.error('Hot deals data is not an array:', data);
      setDeals([]);
    }
  }, [data]);

  // Function to format price in Persian
  const formatPrice = (price: number) => {
    return price.toLocaleString("fa-IR");
  };
  
  // Get icon based on transport type
  const getTransportIcon = (type: string) => {
    switch(type) {
      case "sea":
        return <Ship className="ml-2 text-primary" size={18} />;
      case "land":
        return <Truck className="ml-2 text-secondary" size={18} />;
      case "rail":
        return <Train className="ml-2 text-accent" size={18} />;
      case "mixed":
        if (type.includes("rail")) {
          return (
            <>
              <Train className="ml-2 text-accent" size={18} />
              <Ship className="ml-2 text-primary" size={18} />
            </>
          );
        } else {
          return (
            <>
              <Truck className="ml-2 text-secondary" size={18} />
              <Ship className="ml-2 text-primary" size={18} />
            </>
          );
        }
      default:
        return <Ship className="ml-2 text-primary" size={18} />;
    }
  };
  
  // Function to get badge color
  const getBadgeColor = (color: string) => {
    switch(color) {
      case "red":
        return "bg-red-100 text-red-600";
      case "amber":
        return "bg-amber-100 text-amber-600";
      case "green":
        return "bg-green-100 text-green-600";
      default:
        return "bg-blue-100 text-blue-600";
    }
  };

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold">قیمت‌های ویژه و لحظه‌ای</h2>
          <Link href="/search" className="text-primary font-medium hover:text-primary-dark flex items-center">
            مشاهده همه
            <ChevronLeft className="mr-1" size={16} />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {isLoading ? (
            Array(3).fill(0).map((_, index) => (
              <div key={index} className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                <div className="bg-gray-100 p-4 flex justify-between items-center border-b">
                  <Skeleton className="h-6 w-32" />
                  <Skeleton className="h-6 w-16" />
                </div>
                <div className="p-4">
                  <div className="space-y-3">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                  <div className="mt-6">
                    <Skeleton className="h-9 w-full rounded" />
                  </div>
                </div>
              </div>
            ))
          ) : deals.length === 0 ? (
            <div className="col-span-1 md:col-span-3 py-8 text-center">
              <div className="text-gray-500 mb-4">در حال حاضر پیشنهاد ویژه‌ای وجود ندارد.</div>
              <Link href="/search">
                <Button variant="outline">
                  جستجوی سرویس‌ها
                </Button>
              </Link>
            </div>
          ) : (
            deals.map((deal) => (
              <div key={deal.id} className="border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition">
                <div className="bg-gray-100 p-4 flex justify-between items-center border-b">
                  <div>
                    <div className="flex items-center">
                      {deal.transportType === "mixed" ? (
                        <>
                          {deal.description.includes("ریلی") ? (
                            <Train className="ml-2 text-accent" size={18} />
                          ) : (
                            <Truck className="ml-2 text-secondary" size={18} />
                          )}
                          <Ship className="ml-2 text-primary" size={18} />
                        </>
                      ) : (
                        getTransportIcon(deal.transportType)
                      )}
                      <span className="font-medium">{deal.route}</span>
                    </div>
                    <div className="text-sm text-gray-500 mt-1">{deal.description}</div>
                  </div>
                  <div className="text-left">
                    <div className={`${getBadgeColor(deal.badge.color)} text-sm font-medium px-2 py-1 rounded`}>
                      {deal.badge.text}
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex justify-between text-sm mb-3">
                    <span className="text-gray-600">زمان حرکت:</span>
                    <span className="font-medium">{deal.departureDate}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-3">
                    <span className="text-gray-600">شرکت حمل و نقل:</span>
                    <span className="font-medium">{deal.companyName}</span>
                  </div>
                  <div className="flex justify-between mb-4">
                    <span className="text-gray-600">قیمت:</span>
                    <div>
                      <span className="text-lg font-bold text-primary block">
                        {formatPrice(deal.price)} تومان
                      </span>
                    </div>
                  </div>
                  <Link href={`/shipment/${deal.id}`}>
                    <Button className="w-full bg-accent hover:bg-accent-dark text-white">
                      رزرو کنید
                    </Button>
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default HotDeals;
