import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, Truck, Ship, Train, Plane, ArrowLeft, Headphones, Map, BarChart3, Radar } from "lucide-react";

const Hero = () => {
  const [, navigate] = useLocation();

  const navigateToSearch = () => {
    navigate('/search');
  };

  const navigateToRegister = () => {
    navigate('/auth?type=transporter');
  };

  const navigateToSupport = () => {
    navigate('/support');
  };

  return (
    <section className="relative overflow-hidden">
      {/* Modern Gradient Background - More modern #332e8c */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_#4a41c8_0%,_#332e8c_50%,_#1e1854_100%)]"></div>
      
      {/* Pattern Overlay for Texture */}
      <div className="absolute inset-0 opacity-10" 
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          backgroundSize: '24px 24px'
        }}
      ></div>
      
      {/* Dark Overlay for Better Text Contrast */}
      <div className="absolute inset-0 bg-black opacity-25"></div>
      
      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
        <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-white/5 blur-2xl"></div>
        <div className="absolute top-1/4 right-1/3 w-64 h-64 rounded-full bg-white/5 blur-xl"></div>
        <div className="absolute bottom-0 left-1/2 w-80 h-80 rounded-full bg-white/5 blur-xl"></div>
        <div className="absolute -bottom-20 -right-20 w-72 h-72 rounded-full bg-white/5 blur-2xl"></div>
        
        {/* Animated Transport Icons in Background */}
        <div className="absolute top-20 left-20 text-white/15 animate-float delay-300">
          <Ship size={60} />
        </div>
        <div className="absolute top-40 right-40 text-white/15 animate-float delay-700">
          <Truck size={50} />
        </div>
        <div className="absolute bottom-20 left-1/3 text-white/15 animate-float delay-500">
          <Train size={55} />
        </div>
        <div className="absolute bottom-40 right-1/4 text-white/15 animate-float">
          <Plane size={45} />
        </div>
      </div>
      
      {/* Main Content */}
      <div className="container mx-auto px-4 py-12 md:py-24 relative z-10">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between">
          {/* Text Column */}
          <div className="text-white lg:w-1/2 mb-12 lg:mb-0">
            <div className="animate-slideInRight">
              <div className="inline-block px-3 py-1 rounded-full bg-white/10 text-white text-sm font-medium mb-4">
                #بهترین_سیستم_حمل_و_نقل_ایران
              </div>
              <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
                سامانه جامع و هوشمند <br />
                <span className="text-yellow-300">حمل و نقل</span> بین‌المللی
              </h1>
              <p className="text-lg md:text-xl mb-6 max-w-lg text-gray-100 leading-relaxed">
                با لجستینو، محموله خود را با بهترین قیمت ارسال کنید و با <span className="text-yellow-300 font-semibold">ردیابی آنلاین</span> و <span className="text-yellow-300 font-semibold">مدیریت هوشمند</span>، کنترل کامل داشته باشید.
              </p>
              
              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  onClick={navigateToSearch}
                  className="bg-yellow-400 hover:bg-yellow-500 text-[#332e8c] font-bold py-3 px-6 rounded-lg text-base transition-all hover:scale-105 hover:shadow-lg shadow-md"
                  size="default"
                >
                  جستجوی حمل و نقل
                  <Search className="mr-2" size={18} />
                </Button>
                
                <Button 
                  onClick={navigateToRegister}
                  className="bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/30 text-white font-bold py-3 px-6 rounded-lg text-base transition-all hover:scale-105 hover:shadow-lg shadow-md"
                  variant="outline"
                  size="default"
                >
                  ثبت‌نام شرکت‌های حمل و نقل
                  <Truck className="mr-2" size={18} />
                </Button>
              </div>
              
              {/* Support Link */}
              <div className="mt-6">
                <button 
                  onClick={navigateToSupport}
                  className="inline-flex items-center text-white hover:text-yellow-200 transition-all text-sm"
                >
                  <Headphones className="ml-2" size={14} />
                  <span>نیاز به راهنمایی دارید؟ با پشتیبانی تماس بگیرید</span>
                  <ArrowLeft className="mr-1" size={14} />
                </button>
              </div>
            </div>
          </div>
          
          {/* Feature Cards */}
          <div className="lg:w-1/2 flex flex-col md:flex-row flex-wrap gap-4 animate-slideInLeft">
            {/* Special Features Cards (New) */}
            <div className="w-full flex flex-col sm:flex-row gap-3 mb-3">
              <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-4 rounded-xl border border-white/20 shadow-lg flex-1 hover:scale-105 hover:shadow-xl duration-300">
                <div className="bg-yellow-500/20 w-10 h-10 rounded-full flex items-center justify-center mb-2 shadow-inner">
                  <Radar className="text-yellow-400" size={20} />
                </div>
                <h3 className="text-base font-bold text-white mb-1">ردیابی آنلاین</h3>
                <p className="text-gray-100 text-xs">پیگیری لحظه‌ای موقعیت محموله‌ها در مسیر حمل و نقل</p>
              </div>
              
              <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-4 rounded-xl border border-white/20 shadow-lg flex-1 hover:scale-105 hover:shadow-xl duration-300">
                <div className="bg-yellow-500/20 w-10 h-10 rounded-full flex items-center justify-center mb-2 shadow-inner">
                  <BarChart3 className="text-yellow-400" size={20} />
                </div>
                <h3 className="text-base font-bold text-white mb-1">مدیریت هوشمند</h3>
                <p className="text-gray-100 text-xs">سیستم مدیریت پیشرفته با داشبورد تحلیلی و هوش مصنوعی</p>
              </div>
            </div>
            
            {/* Transport Type Cards */}
            <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-4 rounded-xl border border-white/20 shadow-lg w-full md:w-[calc(50%-0.5rem)] hover:scale-105 hover:shadow-xl duration-300">
              <div className="bg-yellow-500/20 w-12 h-12 rounded-full flex items-center justify-center mb-3 shadow-inner">
                <Ship className="text-yellow-400" size={24} />
              </div>
              <h3 className="text-lg font-bold text-white mb-1">حمل و نقل دریایی</h3>
              <p className="text-gray-100 text-sm">ارسال کانتینری، فله و بارهای سنگین با معتبرترین شرکت‌های کشتیرانی</p>
            </div>
            
            <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-4 rounded-xl border border-white/20 shadow-lg w-full md:w-[calc(50%-0.5rem)] hover:scale-105 hover:shadow-xl duration-300">
              <div className="bg-yellow-500/20 w-12 h-12 rounded-full flex items-center justify-center mb-3 shadow-inner">
                <Truck className="text-yellow-400" size={24} />
              </div>
              <h3 className="text-lg font-bold text-white mb-1">حمل و نقل جاده‌ای</h3>
              <p className="text-gray-100 text-sm">حمل بار به تمام نقاط ایران و کشورهای همسایه با ناوگان مجهز</p>
            </div>
            
            <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-4 rounded-xl border border-white/20 shadow-lg w-full md:w-[calc(50%-0.5rem)] hover:scale-105 hover:shadow-xl duration-300">
              <div className="bg-yellow-500/20 w-12 h-12 rounded-full flex items-center justify-center mb-3 shadow-inner">
                <Train className="text-yellow-400" size={24} />
              </div>
              <h3 className="text-lg font-bold text-white mb-1">حمل و نقل ریلی</h3>
              <p className="text-gray-100 text-sm">حمل و نقل اقتصادی برای محموله‌های سنگین در مسیرهای طولانی</p>
            </div>
            
            <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-4 rounded-xl border border-white/20 shadow-lg w-full md:w-[calc(50%-0.5rem)] hover:scale-105 hover:shadow-xl duration-300">
              <div className="bg-yellow-500/20 w-12 h-12 rounded-full flex items-center justify-center mb-3 shadow-inner">
                <Plane className="text-yellow-400" size={24} />
              </div>
              <h3 className="text-lg font-bold text-white mb-1">حمل و نقل هوایی</h3>
              <p className="text-gray-100 text-sm">ارسال سریع و مطمئن بارهای فوری به تمام نقاط جهان</p>
            </div>
          </div>
        </div>
        
        {/* Stats Row */}
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-white/10">
          <h4 className="text-lg font-semibold text-center text-white mb-6">اعداد و ارقام لجستینو</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-3 rounded-xl transform hover:scale-105 duration-300 border border-white/20 shadow-lg">
              <div className="text-3xl font-bold text-yellow-400 mb-1">۱۵۰۰+</div>
              <div className="text-white text-sm font-medium">شرکت حمل و نقل</div>
            </div>
            <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-3 rounded-xl transform hover:scale-105 duration-300 border border-white/20 shadow-lg">
              <div className="text-3xl font-bold text-yellow-400 mb-1">۵۰۰۰+</div>
              <div className="text-white text-sm font-medium">مسیر حمل و نقل</div>
            </div>
            <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-3 rounded-xl transform hover:scale-105 duration-300 border border-white/20 shadow-lg">
              <div className="text-3xl font-bold text-yellow-400 mb-1">۲۵۰۰۰+</div>
              <div className="text-white text-sm font-medium">محموله ارسال شده</div>
            </div>
            <div className="bg-[#4a41c8]/40 hover:bg-[#4a41c8]/50 transition-all backdrop-blur-sm p-3 rounded-xl transform hover:scale-105 duration-300 border border-white/20 shadow-lg">
              <div className="text-3xl font-bold text-yellow-400 mb-1">۲۰+</div>
              <div className="text-white text-sm font-medium">کشور مقصد</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
