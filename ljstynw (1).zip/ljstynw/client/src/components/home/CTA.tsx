import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const CTA = () => {
  return (
    <section className="py-16 bg-primary text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">آماده ارسال بار خود هستید؟</h2>
        <p className="max-w-3xl mx-auto mb-8">
          با لجستینو، تجربه‌ای متفاوت از حمل و نقل بار را تجربه کنید. همین حالا ثبت‌نام کنید و از مزایای ویژه بهره‌مند شوید.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link href="/auth" className="inline-block">
            <Button 
              size="lg"
              className="w-full sm:w-auto bg-white text-primary hover:bg-gray-100"
            >
              ثبت‌نام به عنوان صاحب بار
            </Button>
          </Link>
          <Link href="/auth" className="inline-block">
            <Button 
              size="lg"
              className="w-full sm:w-auto bg-accent hover:bg-accent-dark text-white"
            >
              ثبت‌نام به عنوان شرکت حمل و نقل
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CTA;
