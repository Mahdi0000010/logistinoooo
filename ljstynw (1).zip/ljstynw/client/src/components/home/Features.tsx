import { 
  CircleDollarSign, 
  ShieldCheck, 
  Clock, 
  Headphones
} from "lucide-react";

const features = [
  {
    icon: <CircleDollarSign className="text-2xl" />,
    title: "قیمت‌های رقابتی",
    description: "بهترین قیمت‌ها با مقایسه آنی بین ده‌ها شرکت حمل و نقل",
    color: "blue"
  },
  {
    icon: <ShieldCheck className="text-2xl" />,
    title: "امنیت و ایمنی",
    description: "محموله‌های شما با بالاترین استانداردهای امنیتی حمل می‌شوند",
    color: "green"
  },
  {
    icon: <Clock className="text-2xl" />,
    title: "سرعت ارسال",
    description: "ارسال سریع و به موقع با امکان پیگیری لحظه‌ای بار",
    color: "purple"
  },
  {
    icon: <Headphones className="text-2xl" />,
    title: "پشتیبانی ۲۴/۷",
    description: "پشتیبانی شبانه‌روزی آماده پاسخگویی به سوالات شما",
    color: "orange"
  }
];

const Features = () => {
  // Function to get color based on the color name
  const getColorClass = (color: string) => {
    switch (color) {
      case "blue":
        return "bg-blue-100 text-blue-600";
      case "green":
        return "bg-green-100 text-green-600";
      case "purple":
        return "bg-purple-100 text-purple-600";
      case "orange":
        return "bg-orange-100 text-orange-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">چرا لجستینو را انتخاب کنید؟</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            ما با ارائه خدمات متنوع و با کیفیت، تجربه‌ای منحصر به فرد در حمل و نقل بار به شما ارائه می‌دهیم
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <div className={`w-16 h-16 ${getColorClass(feature.color)} rounded-full flex items-center justify-center mb-4`}>
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
