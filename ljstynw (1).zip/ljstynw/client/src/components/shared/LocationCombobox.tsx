import { useState, useEffect, useCallback } from "react";
import { Location } from "@shared/schema";
import { Check, ChevronsUpDown, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface LocationComboboxProps {
  locations: Location[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  filterType?: string[];
  className?: string;
  label?: string;
}

const LocationCombobox = ({
  locations,
  value,
  onChange,
  placeholder = "یک مکان را انتخاب کنید...",
  filterType = ["port", "inland"],
  className = "",
  label = ""
}: LocationComboboxProps) => {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Filter locations based on type
  const filteredByType = locations.filter(location => 
    filterType.includes(location.type)
  );
  
  // Group locations by country
  const groupedLocations = filteredByType.reduce<Record<string, Location[]>>(
    (groups, location) => {
      const country = location.country;
      if (!groups[country]) {
        groups[country] = [];
      }
      groups[country].push(location);
      return groups;
    },
    {}
  );
  
  // Filter based on search query
  const filterLocations = useCallback(() => {
    if (!searchQuery) return groupedLocations;
    
    const filtered: Record<string, Location[]> = {};
    
    Object.keys(groupedLocations).forEach(country => {
      const matchingLocations = groupedLocations[country].filter(location => 
        location.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        country.toLowerCase().includes(searchQuery.toLowerCase())
      );
      
      if (matchingLocations.length > 0) {
        filtered[country] = matchingLocations;
      }
    });
    
    return filtered;
  }, [searchQuery, groupedLocations]);
  
  // Get selected location name
  const getSelectedLocationName = () => {
    if (!value) return placeholder;
    const selectedLocation = locations.find(loc => loc.id.toString() === value);
    if (!selectedLocation) return placeholder;
    return `${selectedLocation.name} (${selectedLocation.country})`;
  };
  
  const filteredLocations = filterLocations();
  
  return (
    <div className={className}>
      {label && <div className="text-sm font-medium mb-2">{label}</div>}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-full justify-between h-[42px] border-gray-300 bg-gray-50"
          >
            <div className="flex items-center">
              <MapPin className="ml-2 h-4 w-4 shrink-0 opacity-50" />
              <span className="truncate">{getSelectedLocationName()}</span>
            </div>
            <ChevronsUpDown className="ms-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0" align="start">
          <Command dir="rtl">
            <CommandInput 
              placeholder="جستجوی نام شهر یا کشور..." 
              onValueChange={setSearchQuery}
              className="h-9"
            />
            <CommandList>
              <CommandEmpty>مکانی یافت نشد</CommandEmpty>
              {Object.keys(filteredLocations).map(country => (
                <CommandGroup key={country} heading={country}>
                  {filteredLocations[country].map(location => (
                    <CommandItem
                      key={location.id}
                      value={location.id.toString()}
                      onSelect={(currentValue) => {
                        onChange(currentValue === value ? "" : currentValue);
                        setOpen(false);
                      }}
                    >
                      <div className="flex items-center">
                        <Check
                          className={cn(
                            "ml-2 h-4 w-4",
                            value === location.id.toString() ? "opacity-100" : "opacity-0"
                          )}
                        />
                        <MapPin className="ml-2 h-4 w-4 text-gray-500" />
                        <span>{location.name}</span>
                        {location.type === "port" && (
                          <span className="mr-2 text-xs px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full">بندر</span>
                        )}
                      </div>
                    </CommandItem>
                  ))}
                </CommandGroup>
              ))}
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default LocationCombobox;