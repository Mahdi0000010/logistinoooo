interface ContainerOptionProps {
  id: string;
  type: string;
  name: string;
  description: string;
  selected: boolean;
  onChange: () => void;
}

const ContainerOption = ({
  id,
  type,
  name,
  description,
  selected,
  onChange
}: ContainerOptionProps) => {
  return (
    <div 
      className={`flex items-center p-3 border rounded-lg cursor-pointer ${
        selected ? 'border-primary bg-blue-50' : 'border-gray-300'
      }`}
      onClick={onChange}
    >
      <input 
        type="radio" 
        name="container_type" 
        id={id} 
        className="ml-2"
        checked={selected}
        onChange={onChange}
      />
      <label htmlFor={id} className="flex flex-col flex-1 cursor-pointer">
        <span className="font-medium">{name}</span>
        <span className="text-sm text-gray-500">{description}</span>
      </label>
    </div>
  );
};

export default ContainerOption;
