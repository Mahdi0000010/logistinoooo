import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { formatCurrency, formatPrice } from "@/lib/utils";
import { Ship, TruckIcon, Calendar, Clock, Banknote, Clipboard, Route, Train, PackageOpen } from "lucide-react";
import { useLocation } from "wouter";

interface ShipmentResultsProps {
  results: any[];
  isLoading: boolean;
  withInsurance: boolean;
  containerCount: number;
  cargoWeight?: string | null; // اضافه کردن وزن محموله به props، شامل مقدار null
}

const ShipmentResults = ({ results, isLoading, withInsurance, containerCount, cargoWeight }: ShipmentResultsProps) => {
  const [, setLocation] = useLocation();
  
  // در اینجا فانکشنی برای انتقال پارامترهای جستجو به صفحه جزئیات محموله تعریف می‌کنیم
  const viewShipmentDetails = (id: number | string) => {
    // اگر وزن محموله داشته باشیم، آن را به URL اضافه می‌کنیم
    const params = new URLSearchParams();
    if (cargoWeight) params.append('cargoWeight', cargoWeight);
    
    const queryString = params.toString();
    setLocation(`/shipment/${id}${queryString ? `?${queryString}` : ''}`);
  };

  // Helper function to determine transport icon
  const getTransportIcon = (type: string) => {
    switch (type) {
      case 'sea':
        return <Ship className="ml-2" size={18} />;
      case 'land':
        return <TruckIcon className="ml-2" size={18} />;
      case 'rail':
        return <Train className="ml-2" size={18} />; // استفاده از آیکون Train برای حمل و نقل ریلی
      default:
        return <Route className="ml-2" size={18} />;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={`skeleton-${i}`} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="p-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="w-full md:w-3/4">
                    <Skeleton className="h-6 w-1/3 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-2" />
                    <div className="flex gap-3 mt-3">
                      <Skeleton className="h-8 w-24" />
                      <Skeleton className="h-8 w-24" />
                    </div>
                  </div>
                  <div className="w-full md:w-1/4 border-t md:border-t-0 md:border-r pt-3 md:pt-0 md:pr-4">
                    <Skeleton className="h-6 w-24 mx-auto mb-2" />
                    <Skeleton className="h-9 w-full" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <Card className="bg-gray-50 border-dashed border-2">
        <CardContent className="p-8 text-center">
          <div className="mx-auto mb-4 bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center">
            <Clipboard className="text-gray-400" size={24} />
          </div>
          <h3 className="text-lg font-semibold mb-2">نتیجه‌ای یافت نشد</h3>
          <p className="text-gray-500 mb-4">
            برای مسیر و تاریخ انتخاب شده نتیجه‌ای یافت نشد. لطفا معیارهای جستجو را تغییر دهید.
          </p>
          <Button variant="outline" className="mx-auto">
            تغییر معیارهای جستجو
          </Button>
        </CardContent>
      </Card>
    );
  }

  // فیلتر کردن محموله‌های دریایی بدون قیمت
  const filteredResults = results.filter(shipment => {
    // برای حمل و نقل دریایی با قیمت null، آیتم را حذف کن
    if (shipment.transportType === 'sea' && shipment.price === null) {
      return false;
    }
    return true;
  });
  
  // برای اهداف دیباگ، لاگ کردن نتایج
  console.log(`Filtered shipment results count: ${filteredResults.length}`);
  console.log('Shipment types available:', filteredResults.map(s => s.transportType + ' - ' + (s.transportDetails?.vehicleDisplayName || s.containerType)));


  // اگر هیچ نتیجه‌ای باقی نمانده باشد، پیام مناسب نمایش دهیم
  if (filteredResults.length === 0) {
    return (
      <Card className="bg-gray-50 border-dashed border-2">
        <CardContent className="p-8 text-center">
          <div className="mx-auto mb-4 bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center">
            <TruckIcon className="text-gray-400" size={24} />
          </div>
          <h3 className="text-lg font-semibold mb-2">برای این مسیر هیچ حمل و نقلی پیدا نشد</h3>
          <p className="text-gray-500 mb-4">
            لطفا مسیر دیگری را انتخاب کنید یا روش حمل و نقل دیگری را امتحان کنید.
          </p>
          <Button variant="outline" className="mx-auto" onClick={() => window.history.back()}>
            بازگشت به جستجو
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {filteredResults.map((shipment) => {
        // محاسبه قیمت با توجه به نوع حمل و نقل
        let calculatedPrice;

        // استفاده از قیمت محاسبه شده در API در صورت وجود
        if (shipment.transportPrice && shipment.transportPrice.priceToman !== null) {
          // استفاده از قیمت محاسبه شده توسط سرور
          calculatedPrice = shipment.transportPrice.priceToman * (withInsurance ? 1.05 : 1);
        } 
        // در صورت وجود calculatedPrice از API
        else if (shipment.calculatedPrice) {
          // دیگر نیازی به تقسیم بر 10 نیست چون قیمت درست است
          calculatedPrice = shipment.calculatedPrice * (withInsurance ? 1.05 : 1);
        }
        // برای حمل و نقل ریلی، محاسبه براساس وزن
        else if (shipment.transportType === 'rail' && cargoWeight && shipment.distance) {
          // تعیین نرخ پایه برای ریل - استفاده از vehicle.baseRate در صورت وجود
          const baseRatePerKgKm = shipment.transportDetails?.baseRate || 34; // نرخ پایه به ازای هر کیلوگرم-کیلومتر (ریال)
          const distanceKm = shipment.distance || 0; // فاصله بر حسب کیلومتر
          const weight = parseFloat(cargoWeight) || 0; // وزن بر حسب کیلوگرم
          
          // محاسبه قیمت پایه (ریال)
          const basePriceRial = distanceKm * weight * baseRatePerKgKm;
          
          // تبدیل به تومان (تومان) - بعد از اصلاحات آخرین نیازی به تقسیم اضافی بر 10 نیست
          calculatedPrice = basePriceRial / 10;
          
          // محاسبه قیمت نهایی با در نظر گرفتن بیمه
          calculatedPrice = calculatedPrice * (withInsurance ? 1.05 : 1);
        } else {
          // برای سایر انواع حمل و نقل، از قیمت پایه استفاده می‌کنیم
          // بررسی مجدد قیمت null برای اطمینان
          if (shipment.price === null) {
            calculatedPrice = null;
          } else {
            calculatedPrice = shipment.price * containerCount * (withInsurance ? 1.05 : 1);
          }
        }
        
        return (
          <Card key={shipment.id} className="overflow-hidden hover:shadow-md transition-shadow">
            <CardContent className="p-0">
              <div className="p-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="w-full md:w-3/4">
                    <div className="flex items-center mb-1">
                      <h3 className="text-lg font-semibold">
                        {shipment.originName} به {shipment.destinationName}
                      </h3>
                      <Badge className="mr-2" variant={shipment.transportType === 'sea' ? 'default' : 'outline'}>
                        {getTransportIcon(shipment.transportType)}
                        {shipment.transportType === 'sea' ? 'دریایی' : 
                         shipment.transportType === 'land' ? 'زمینی' :
                         shipment.transportType === 'rail' ? 'ریلی' : 'ترکیبی'}
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-gray-500 mb-3">
                      ارائه شده توسط: {shipment.transporterName || 'شرکت حمل و نقل'}
                    </p>
                    
                    <div className="flex flex-wrap gap-4 text-sm">
                      <div className="flex items-center">
                        <Calendar size={16} className="ml-1 text-gray-500" />
                        <span>تاریخ حرکت: {shipment.departureDate}</span>
                      </div>
                      
                      <div className="flex items-center">
                        <Clock size={16} className="ml-1 text-gray-500" />
                        <span>مدت حمل: {Math.ceil((new Date(shipment.arrivalDate).getTime() - new Date(shipment.departureDate).getTime()) / (1000 * 60 * 60 * 24))} روز</span>
                      </div>
                      
                      <div className="flex items-center">
                        <PackageOpen size={16} className="ml-1 text-gray-500" />
                        <span>ظرفیت: {shipment.capacity} {shipment.transportType === 'sea' ? 'TEU' : 'تن'}</span>
                      </div>
                      
                      {/* نمایش فاصله برای حمل و نقل ریلی */}
                      {shipment.transportType === 'rail' && shipment.distance && (
                        <div className="flex items-center">
                          <Route size={16} className="ml-1 text-gray-500" />
                          <span>فاصله: {shipment.distance} کیلومتر</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="w-full md:w-1/4 border-t md:border-t-0 md:border-r pt-3 md:pt-0 md:pr-4 flex flex-col items-center">
                    <div className="text-center mb-2">
                      <div className="flex items-center justify-center font-semibold text-lg text-primary">
                        <Banknote size={18} className="ml-1" />
                        {formatPrice(calculatedPrice)}
                      </div>
                      {shipment.transportType === 'rail' ? (
                        <p className="text-xs text-gray-500">
                          {withInsurance ? 'شامل بیمه' : 'بدون بیمه'} • {cargoWeight || '؟'} کیلوگرم
                        </p>
                      ) : (
                        <p className="text-xs text-gray-500">
                          {withInsurance ? 'شامل بیمه' : 'بدون بیمه'} • {containerCount} {shipment.containerType || 'کانتینر'}
                        </p>
                      )}
                    </div>
                    
                    <Button 
                      className="w-full"
                      onClick={() => viewShipmentDetails(shipment.id)}
                    >
                      مشاهده جزئیات
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default ShipmentResults;