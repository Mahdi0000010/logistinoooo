import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Ship, Truck, Train, Calendar, Clock, MapPin, DollarSign, ShieldCheck, Star } from "lucide-react";
import { Link } from "wouter";
import { formatPrice, formatCurrency } from "@/lib/utils";

interface ShipmentCardProps {
  shipment: {
    id: number;
    originName: string;
    destinationName: string;
    departureDate: string;
    arrivalDate: string;
    transportType: string;
    transporterName: string;
    containerType: string;
    price: number;
    insuranceAvailable: boolean;
    insurancePrice: number;
    description?: string;
    rating: number;
  };
  withInsurance?: boolean;
  containerCount?: number;
}

const ShipmentCard = ({ 
  shipment, 
  withInsurance = false,
  containerCount = 1 
}: ShipmentCardProps) => {

  // Function to get transport icon
  const getTransportIcon = (type: string) => {
    switch (type) {
      case "sea":
        return <Ship className="ml-2" size={20} />;
      case "land":
        return <Truck className="ml-2" size={20} />;
      case "rail":
        return <Train className="ml-2" size={20} />;
      case "mixed":
        return (
          <div className="flex">
            <Ship className="ml-2" size={20} />
            <Truck className="ml-2" size={20} />
          </div>
        );
      default:
        return <Ship className="ml-2" size={20} />;
    }
  };

  // Function to get transport type name
  const getTransportTypeName = (type: string) => {
    switch (type) {
      case "sea":
        return "حمل و نقل دریایی";
      case "land":
        return "حمل و نقل زمینی";
      case "rail":
        return "حمل و نقل ریلی";
      case "mixed":
        return "حمل و نقل ترکیبی";
      default:
        return type;
    }
  };

  // Function to get container type name
  const getContainerTypeName = (type: string) => {
    switch (type) {
      case "20_standard":
        return "کانتینر ۲۰ فوت";
      case "40_standard":
        return "کانتینر ۴۰ فوت";
      case "20_refrigerated":
        return "کانتینر ۲۰ فوت یخچالی";
      case "40_refrigerated":
        return "کانتینر ۴۰ فوت یخچالی";
      default:
        return type;
    }
  };

  // Calculate total price
  const calculateTotalPrice = () => {
    let total = shipment.price * containerCount;
    if (withInsurance && shipment.insuranceAvailable) {
      total += shipment.insurancePrice * containerCount;
    }
    return total;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 hover:shadow-md transition-shadow">
      <div className="flex flex-col lg:flex-row justify-between gap-4 mb-4">
        <div className="flex items-start">
          <div className="flex-shrink-0 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center ml-3">
            {getTransportIcon(shipment.transportType)}
          </div>
          <div>
            <h3 className="font-bold text-lg mb-1 flex items-center">
              {shipment.transporterName}
              <div className="flex items-center mr-2 text-amber-500">
                <Star className="fill-amber-500" size={16} />
                <span className="mr-1 text-sm">{shipment.rating}</span>
              </div>
            </h3>
            <div className="flex items-center text-gray-700 flex-wrap gap-x-4 gap-y-1">
              <Badge variant="outline" className="font-normal">
                {getTransportTypeName(shipment.transportType)}
              </Badge>
              <Badge variant="outline" className="font-normal">
                {getContainerTypeName(shipment.containerType)}
              </Badge>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col items-end">
          <div className="font-bold text-xl text-primary">{formatPrice(calculateTotalPrice())} تومان</div>
          {containerCount > 1 && (
            <div className="text-sm text-gray-500">{containerCount} x {formatPrice(shipment.price)} تومان</div>
          )}
          {withInsurance && shipment.insuranceAvailable && (
            <div className="flex items-center text-sm text-green-600 mt-1">
              <ShieldCheck size={14} className="ml-1" />
              <span>شامل بیمه محموله</span>
            </div>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="flex items-center mb-2">
            <MapPin className="ml-2 text-gray-500" size={16} />
            <h4 className="font-medium">مسیر</h4>
          </div>
          <div className="flex items-center justify-between">
            <div className="text-center flex-1">
              <p className="text-gray-500 text-xs mb-1">مبدا</p>
              <p className="font-medium text-sm">{shipment.originName}</p>
            </div>
            <div className="w-8 h-0.5 bg-gray-300 mx-1"></div>
            <div className="text-center flex-1">
              <p className="text-gray-500 text-xs mb-1">مقصد</p>
              <p className="font-medium text-sm">{shipment.destinationName}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="flex items-center mb-2">
            <Calendar className="ml-2 text-gray-500" size={16} />
            <h4 className="font-medium">تاریخ</h4>
          </div>
          <div className="flex items-center justify-between">
            <div className="text-center flex-1">
              <p className="text-gray-500 text-xs mb-1">حرکت</p>
              <p className="font-medium text-sm">{shipment.departureDate}</p>
            </div>
            <div className="w-8 h-0.5 bg-gray-300 mx-1"></div>
            <div className="text-center flex-1">
              <p className="text-gray-500 text-xs mb-1">رسیدن</p>
              <p className="font-medium text-sm">{shipment.arrivalDate}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 p-3 rounded-lg flex flex-col justify-between">
          <div className="flex items-center mb-2">
            <Clock className="ml-2 text-gray-500" size={16} />
            <h4 className="font-medium">زمان تحویل تقریبی</h4>
          </div>
          <div className="text-center">
            <p className="text-gray-500 text-xs mb-1">مدت زمان سفر</p>
            <p className="font-medium">۵ روز</p>
          </div>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
        <div className="text-gray-600 text-sm flex items-center">
          <DollarSign className="ml-1" size={16} />
          {withInsurance ? "قیمت شامل هزینه حمل و نقل و بیمه می‌باشد" : "قیمت شامل هزینه حمل و نقل می‌باشد"}
        </div>
        
        <div className="flex gap-2">
          <Link href={`/shipment/${shipment.id}`}>
            <Button variant="outline">مشاهده جزئیات</Button>
          </Link>
          <Link href={`/shipment/${shipment.id}`}>
            <Button>رزرو و پرداخت</Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ShipmentCard;
