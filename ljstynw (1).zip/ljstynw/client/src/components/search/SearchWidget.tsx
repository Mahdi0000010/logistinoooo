import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ContainerOption from "@/components/search/ContainerOption";
import DatePicker from "@/components/shared/DatePicker";
import LocationCombobox from "@/components/shared/LocationCombobox";
import { Search, Calendar, Map, Ship, Truck, Train, CircleDollarSign, Package, Weight, Shield } from "lucide-react";
import { Location } from "@shared/schema";

interface SearchWidgetProps {
  onSearch: (data: any) => void;
  initialValues?: any;
  isCompact?: boolean;
}

const SearchWidget = ({ onSearch, initialValues = {}, isCompact = false }: SearchWidgetProps) => {
  const [activeTab, setActiveTab] = useState<string>("search");
  const [originId, setOriginId] = useState<string>(initialValues.originId?.toString() || "");
  const [destinationId, setDestinationId] = useState<string>(initialValues.destinationId?.toString() || "");
  const [departureDate, setDepartureDate] = useState<string>(initialValues.departureDate || "");
  const [cargoType, setCargoType] = useState<string>(initialValues.cargoType || "");
  const [cargoWeight, setCargoWeight] = useState<string>(initialValues.cargoWeight?.toString() || "");
  const [containerType, setContainerType] = useState<string>(initialValues.containerType || "20_standard");
  const [containerCount, setContainerCount] = useState<number>(initialValues.containerCount || 1);
  const [withInsurance, setWithInsurance] = useState<boolean>(initialValues.withInsurance || false);

  // Fetch locations
  const { data: locations, isLoading: isLoadingLocations } = useQuery({
    queryKey: ['/api/locations'],
    queryFn: async () => {
      const res = await fetch('/api/locations');
      return await res.json();
    },
  });

  // Increment and decrement container count
  const decreaseCount = () => {
    if (containerCount > 1) {
      setContainerCount(containerCount - 1);
    }
  };

  const increaseCount = () => {
    setContainerCount(containerCount + 1);
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const searchData = {
      originId: originId ? parseInt(originId) : undefined,
      destinationId: destinationId ? parseInt(destinationId) : undefined,
      departureDate,
      cargoType,
      cargoWeight: cargoWeight ? parseFloat(cargoWeight) : undefined,
      containerType,
      containerCount,
      withInsurance
    };
    
    onSearch(searchData);
  };

  // Filter ports and inland locations
  const ports = locations?.filter((loc: Location) => loc.type === "port") || [];
  const inlandLocations = locations?.filter((loc: Location) => loc.type === "inland") || [];
  const allLocations = locations || [];

  return (
    <Card className={`${isCompact ? 'shadow-sm' : 'shadow-lg'} bg-white`}>
      <CardContent className={`${isCompact ? 'p-4' : 'p-6'}`}>
        <form onSubmit={handleSubmit}>
          <Tabs defaultValue="search" onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid grid-cols-2">
              <TabsTrigger value="search" className="py-3 font-medium">
                جستجوی حمل و نقل
              </TabsTrigger>
              <TabsTrigger value="tracking" className="py-3 font-medium">
                پیگیری محموله
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="search" className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="flex items-center mb-2">
                    <Ship className="ml-2 text-primary" size={18} />
                    <Label className="text-gray-700 font-medium">مبدا</Label>
                  </div>
                  <LocationCombobox
                    locations={allLocations}
                    value={originId}
                    onChange={setOriginId}
                    placeholder="شهر یا بندر مبدا را جستجو کنید..."
                    label=""
                  />
                </div>
                
                <div>
                  <div className="flex items-center mb-2">
                    <Ship className="ml-2 text-primary" size={18} />
                    <Label className="text-gray-700 font-medium">مقصد</Label>
                  </div>
                  <LocationCombobox
                    locations={allLocations}
                    value={destinationId}
                    onChange={setDestinationId}
                    placeholder="شهر یا بندر مقصد را جستجو کنید..."
                    label=""
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div>
                  <div className="flex items-center mb-2">
                    <Package className="ml-2 text-primary" size={18} />
                    <Label className="text-gray-700 font-medium">نوع بار</Label>
                  </div>
                  <Select value={cargoType} onValueChange={setCargoType}>
                    <SelectTrigger className="w-full bg-gray-50 border border-gray-300 text-gray-900 rounded-lg p-3 focus:ring-primary focus:border-primary">
                      <SelectValue placeholder="انتخاب نوع بار" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="placeholder">انتخاب نوع بار</SelectItem>
                      <SelectItem value="food">مواد غذایی</SelectItem>
                      <SelectItem value="industrial">مواد صنعتی</SelectItem>
                      <SelectItem value="chemical">مواد شیمیایی</SelectItem>
                      <SelectItem value="perishable">کالای فاسد شدنی</SelectItem>
                      <SelectItem value="dangerous">کالای خطرناک</SelectItem>
                      <SelectItem value="other">سایر</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <div className="flex items-center mb-2">
                    <Calendar className="ml-2 text-primary" size={18} />
                    <Label className="text-gray-700 font-medium">تاریخ ارسال</Label>
                  </div>
                  <div className="relative">
                    <DatePicker 
                      value={departureDate} 
                      onChange={setDepartureDate} 
                      placeholder="انتخاب تاریخ"
                      className="w-full bg-gray-50 border border-gray-300 text-gray-900 rounded-lg p-3 focus:ring-primary focus:border-primary"
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center mb-2">
                    <Weight className="ml-2 text-primary" size={18} />
                    <Label className="text-gray-700 font-medium">وزن بار (کیلوگرم)</Label>
                  </div>
                  <div className="relative">
                    <Input 
                      type="number" 
                      className="w-full bg-gray-50 border border-gray-300 text-gray-900 rounded-lg p-3 focus:ring-primary focus:border-primary" 
                      placeholder="مثال: 1000"
                      value={cargoWeight}
                      onChange={(e) => setCargoWeight(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <div className="flex items-center mb-2">
                    <Truck className="ml-2 text-primary" size={18} />
                    <Label className="text-gray-700 font-medium">نوع کانتینر</Label>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <ContainerOption
                      id="container_20"
                      type="20_standard"
                      name="کانتینر ۲۰ فوت"
                      description="مناسب برای بارهای سبک و متوسط"
                      selected={containerType === "20_standard"}
                      onChange={() => setContainerType("20_standard")}
                    />
                    <ContainerOption
                      id="container_40"
                      type="40_standard"
                      name="کانتینر ۴۰ فوت"
                      description="مناسب برای بارهای سنگین و حجیم"
                      selected={containerType === "40_standard"}
                      onChange={() => setContainerType("40_standard")}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center mb-2">
                    <Package className="ml-2 text-primary" size={18} />
                    <Label className="text-gray-700 font-medium">تعداد و بیمه</Label>
                  </div>
                  <div className="flex items-center">
                    <button 
                      type="button"
                      className="bg-gray-200 px-3 py-2 rounded-r-lg" 
                      onClick={decreaseCount}
                    >
                      -
                    </button>
                    <Input 
                      type="number" 
                      className="w-20 text-center border-t border-b border-gray-300 py-2 rounded-none" 
                      value={containerCount} 
                      onChange={(e) => setContainerCount(parseInt(e.target.value) || 1)}
                      min={1}
                    />
                    <button 
                      type="button"
                      className="bg-gray-200 px-3 py-2 rounded-l-lg"
                      onClick={increaseCount}
                    >
                      +
                    </button>
                    <div className="mr-4">
                      <label className="flex items-center">
                        <Checkbox 
                          className="ml-2" 
                          checked={withInsurance}
                          onCheckedChange={(checked) => setWithInsurance(checked as boolean)}
                        />
                        <div className="flex items-center">
                          <Shield className="ml-1 text-primary" size={16} />
                          <span>بیمه محموله</span>
                        </div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="tracking" className="pt-4">
              <div className="py-6 text-center">
                <div className="flex items-center justify-center mb-6">
                  <Search className="ml-3 text-primary" size={24} />
                  <h3 className="text-lg font-medium text-gray-800">پیگیری وضعیت محموله</h3>
                </div>
                <p className="mb-4 text-gray-700">برای پیگیری بار خود، کد پیگیری را وارد کنید</p>
                <div className="flex flex-col sm:flex-row max-w-md mx-auto space-y-3 sm:space-y-0 sm:space-x-reverse sm:space-x-3">
                  <div className="relative flex-grow">
                    <Input
                      type="text"
                      placeholder="کد پیگیری خود را وارد کنید"
                      className="flex-grow bg-gray-50 pr-10 h-11"
                    />
                    <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none">
                      <Package className="text-gray-400" size={18} />
                    </div>
                  </div>
                  <Button 
                    type="button" 
                    onClick={() => window.location.href = '/tracking'}
                    className="bg-primary hover:bg-primary-dark h-11"
                  >
                    <Search className="ml-2" size={18} />
                    پیگیری
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          {activeTab === "search" && (
            <div className="text-center">
              <Button 
                type="submit" 
                className="bg-accent hover:bg-accent-dark text-white font-medium py-3 px-8 rounded-lg transition"
              >
                جستجو
                <Search className="mr-2" size={18} />
              </Button>
            </div>
          )}
        </form>
      </CardContent>
    </Card>
  );
};

export default SearchWidget;
