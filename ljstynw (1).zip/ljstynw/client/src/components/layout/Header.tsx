import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { 
  Ship, 
  Menu,
  X, 
  Search, 
  UserCircle, 
  LogOut,
  Shield,
  LifeBuoy
} from "lucide-react";

const Header = () => {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const isMobile = useMobile();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
  };

  const navLinks = [
    { path: "/", label: "صفحه اصلی" },
    { path: "/search", label: "جستجوی حمل و نقل" },
    { path: "/recent-services", label: "سرویس‌های یک ماه اخیر" },
    { path: "/support", label: "پشتیبانی", icon: <LifeBuoy size={16} className="ml-1" /> },
    { path: "/about", label: "درباره ما" },
    { path: "/contact", label: "تماس با ما" },
    { path: "/blog", label: "وبلاگ" },
  ];

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-4 space-x-reverse">
            <Link to="/" className="text-2xl font-bold text-primary flex items-center">
              <Ship className="ml-2" size={24} />
              <span>لجستینو</span>
            </Link>
            
            {!isMobile && (
              <nav className="hidden md:flex space-x-6 space-x-reverse mr-10">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    href={link.path}
                    className={`text-gray-700 hover:text-primary transition flex items-center ${
                      location === link.path ? "text-primary font-medium" : ""
                    }`}
                  >
                    {link.icon && link.icon}
                    {link.label}
                  </Link>
                ))}
              </nav>
            )}
          </div>
          
          <div className="flex items-center space-x-4 space-x-reverse">
            <Link 
              to="/tracking" 
              className="text-gray-700 hover:text-primary transition hidden sm:flex items-center"
            >
              <Search size={16} className="ml-1" />
              پیگیری محموله
            </Link>
            
            {user ? (
              <div className="flex items-center space-x-3 space-x-reverse">
                <Link to="/dashboard">
                  <Button variant="ghost" className="flex items-center">
                    <UserCircle className="ml-2" size={18} />
                    پنل کاربری
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleLogout}
                  className="hidden md:flex items-center"
                >
                  <LogOut className="ml-1" size={16} />
                  خروج
                </Button>
              </div>
            ) : (
              <Link to="/auth">
                <Button className="bg-primary hover:bg-primary-dark text-white">
                  ورود / ثبت‌نام
                </Button>
              </Link>
            )}
            
            {isMobile && (
              <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[280px] sm:w-[350px]">
                  <div className="flex justify-between items-center mb-6">
                    <div className="text-xl font-bold text-primary flex items-center">
                      <Ship className="ml-2" size={24} />
                      <span>لجستینو</span>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(false)}>
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                  
                  <nav className="flex flex-col space-y-4">
                    {navLinks.map((link) => (
                      <Link
                        key={link.path}
                        href={link.path}
                        onClick={() => setIsMenuOpen(false)}
                        className={`py-2 px-4 rounded-md hover:bg-gray-100 flex items-center ${
                          location === link.path ? "text-primary font-medium bg-gray-50" : "text-gray-700"
                        }`}
                      >
                        {link.icon && link.icon}
                        {link.label}
                      </Link>
                    ))}
                    
                    {user ? (
                      <>
                        <Link
                          href="/dashboard"
                          onClick={() => setIsMenuOpen(false)}
                          className="py-2 px-4 rounded-md hover:bg-gray-100"
                        >
                          پنل کاربری
                        </Link>
                        <button
                          onClick={() => {
                            handleLogout();
                            setIsMenuOpen(false);
                          }}
                          className="py-2 px-4 rounded-md hover:bg-gray-100 text-right w-full text-red-500"
                        >
                          خروج از حساب کاربری
                        </button>
                      </>
                    ) : (
                      <Link 
                        to="/auth"
                        onClick={() => setIsMenuOpen(false)}
                        className="py-2 px-4 rounded-md hover:bg-gray-100 text-right w-full text-primary font-medium block"
                      >
                        ورود / ثبت‌نام
                      </Link>
                    )}
                  </nav>
                </SheetContent>
              </Sheet>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
