import { Link } from "wouter";
import { Ship, Mail, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center text-xl font-bold mb-6">
              <Ship className="ml-2" size={22} />
              <h3>لجستینو</h3>
            </div>
            <p className="text-gray-400 mb-6">
              سامانه جامع حمل و نقل دریایی و زمینی برای صادرات و واردات کالا به تمام نقاط دنیا
            </p>
            <div className="flex space-x-4 space-x-reverse">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <i className="fab fa-instagram text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <i className="fab fa-linkedin text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <i className="fab fa-telegram text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">خدمات ما</h3>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  حمل و نقل دریایی
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  حمل و نقل زمینی
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  حمل و نقل ریلی
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  بیمه محموله
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  بسته‌بندی کالا
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  خدمات گمرکی
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">لینک‌های مفید</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/about" className="text-gray-400 hover:text-white transition">
                  درباره ما
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-white transition">
                  تماس با ما
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-gray-400 hover:text-white transition">
                  وبلاگ
                </Link>
              </li>
              <li>
                <Link href="/tracking" className="text-gray-400 hover:text-white transition">
                  پیگیری محموله
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-gray-400 hover:text-white transition">
                  قوانین و مقررات
                </Link>
              </li>
              <li>
                <Link href="/support" className="text-gray-400 hover:text-white transition">
                  پشتیبانی
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">تماس با ما</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="ml-2 mt-1 text-gray-400" size={18} />
                <span className="text-gray-400">
                  تهران، خیابان آزادی، برج تجاری آزادی، طبقه ۱۰، واحد ۴
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="ml-2 text-gray-400" size={18} />
                <span className="text-gray-400" dir="ltr">
                  ۰۲۱-۸۸۷۷۶۶۵۵
                </span>
              </li>
              <li className="flex items-center">
                <Mail className="ml-2 text-gray-400" size={18} />
                <span className="text-gray-400">
                  info@logistino.ir
                </span>
              </li>
            </ul>
            
            <div className="mt-6">
              <h4 className="font-medium mb-3">خبرنامه</h4>
              <div className="flex">
                <Input 
                  type="email" 
                  placeholder="ایمیل شما" 
                  className="bg-gray-800 border-gray-700 rounded-l-none text-white" 
                  dir="ltr" 
                />
                <Button className="bg-primary hover:bg-primary-dark rounded-r-none">
                  عضویت
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-center md:text-right">
              © ۱۴۰۲ لجستینو. تمامی حقوق محفوظ است.
            </p>
            <div className="flex mt-4 md:mt-0">
              <svg className="h-8 ml-3" viewBox="0 0 50 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="50" height="30" rx="4" fill="#f8f9fa"/>
                <path d="M10 15h30M25 5v20" stroke="#4a5568" strokeWidth="1.5"/>
                <path d="M15 10h20v10H15z" fill="#4299e1"/>
              </svg>
              <svg className="h-8 ml-3" viewBox="0 0 50 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="50" height="30" rx="4" fill="#f8f9fa"/>
                <path d="M15 8h20v14H15z" fill="#48bb78"/>
                <path d="M25 15m-5 0a5 5 0 1 0 10 0a5 5 0 1 0 -10 0" fill="#f8f9fa"/>
              </svg>
              <svg className="h-8" viewBox="0 0 50 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="50" height="30" rx="4" fill="#f8f9fa"/>
                <path d="M15 8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2H15z" fill="#f59e0b"/>
                <path d="M30 15l-5-5v10l5-5z" fill="#f8f9fa"/>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
