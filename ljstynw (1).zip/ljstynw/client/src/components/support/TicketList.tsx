import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Ticket, Clock, MessageCircle, Calendar } from "lucide-react";

interface TicketResponse {
  id: number;
  ticketId: number;
  userId: number;
  message: string;
  createdAt: string;
  user: {
    fullName: string;
  };
}

interface TicketType {
  id: number;
  userId: number;
  subject: string;
  category: string;
  priority: "low" | "medium" | "high";
  status: "open" | "in_progress" | "closed";
  createdAt: string;
  responses?: TicketResponse[];
}

const TicketList = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedTicket, setSelectedTicket] = useState<TicketType | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [replyText, setReplyText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch tickets
  const { data: tickets, isLoading } = useQuery({
    queryKey: ['/api/tickets'],
    queryFn: async () => {
      const res = await fetch('/api/tickets');
      if (!res.ok) throw new Error('Failed to fetch tickets');
      return await res.json();
    },
  });
  
  // Fetch ticket details
  const fetchTicketDetails = async (ticketId: number) => {
    try {
      const res = await fetch(`/api/tickets/${ticketId}`);
      if (!res.ok) throw new Error('Failed to fetch ticket details');
      const data = await res.json();
      setSelectedTicket(data.ticket);
      setDetailsOpen(true);
    } catch (error) {
      toast({
        title: "خطا در بارگیری جزئیات تیکت",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  };
  
  // Submit reply
  const handleReplySubmit = async () => {
    if (!selectedTicket || !replyText.trim()) return;
    
    setIsSubmitting(true);
    try {
      await apiRequest("POST", `/api/tickets/${selectedTicket.id}/responses`, {
        message: replyText
      });
      
      toast({
        title: "پاسخ با موفقیت ثبت شد",
        description: "پاسخ شما با موفقیت به تیکت اضافه شد.",
      });
      
      // Refetch ticket details
      queryClient.invalidateQueries({ queryKey: [`/api/tickets/${selectedTicket.id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      
      // Clear reply text
      setReplyText("");
      setDetailsOpen(false);
    } catch (error) {
      toast({
        title: "خطا در ثبت پاسخ",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">باز</Badge>;
      case "in_progress":
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">در حال بررسی</Badge>;
      case "closed":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">بسته شده</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">نامشخص</Badge>;
    }
  };
  
  // Function to get priority badge
  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "low":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">کم</Badge>;
      case "medium":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">متوسط</Badge>;
      case "high":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">زیاد</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">نامشخص</Badge>;
    }
  };
  
  // Function to get category name
  const getCategoryName = (category: string) => {
    switch (category) {
      case "shipping":
        return "حمل و نقل";
      case "booking":
        return "رزرو محموله";
      case "payment":
        return "پرداخت";
      case "technical":
        return "مشکلات فنی";
      case "other":
        return "سایر";
      default:
        return category;
    }
  };
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array(3).fill(0).map((_, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex justify-between mb-4">
                <Skeleton className="h-6 w-64" />
                <Skeleton className="h-6 w-24" />
              </div>
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }
  
  if (!tickets || tickets.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center py-10">
          <Ticket className="h-12 w-12 mx-auto mb-4 text-gray-300" />
          <p className="text-gray-500 mb-2">شما هنوز تیکتی ثبت نکرده‌اید</p>
          <p className="text-sm text-gray-500 mb-4">برای دریافت پشتیبانی، یک تیکت جدید ایجاد کنید</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="space-y-4">
      {tickets.map((ticket: TicketType) => (
        <Card key={ticket.id} className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row justify-between gap-2 mb-4">
              <div>
                <h3 className="font-bold text-lg">{ticket.subject}</h3>
                <div className="flex items-center text-sm text-gray-500 mt-1">
                  <div className="flex items-center ml-4">
                    <Calendar className="ml-1" size={14} />
                    <span>{new Date(ticket.createdAt).toLocaleDateString('fa-IR')}</span>
                  </div>
                  <div>دسته‌بندی: {getCategoryName(ticket.category)}</div>
                </div>
              </div>
              <div className="flex items-center">
                {getStatusBadge(ticket.status)}
                <div className="mr-2">{getPriorityBadge(ticket.priority)}</div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => fetchTicketDetails(ticket.id)}
              >
                <MessageCircle className="ml-2" size={16} />
                مشاهده و پاسخ
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
      
      {/* Ticket Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              {selectedTicket?.subject}
            </DialogTitle>
            <DialogDescription className="flex items-center gap-2">
              <div>{getStatusBadge(selectedTicket?.status || "open")}</div>
              <div>{getPriorityBadge(selectedTicket?.priority || "medium")}</div>
              <div className="flex items-center text-sm text-gray-500">
                <Clock className="ml-1" size={14} />
                <span>{selectedTicket ? new Date(selectedTicket.createdAt).toLocaleDateString('fa-IR') : ""}</span>
              </div>
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 my-4 max-h-96 overflow-y-auto">
            {/* Original ticket message will be shown here */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center mb-2">
                <span className="font-bold ml-2">{user?.fullName}</span>
                <span className="text-xs text-gray-500">
                  {selectedTicket ? new Date(selectedTicket.createdAt).toLocaleTimeString('fa-IR') : ""}
                </span>
              </div>
              <p>
                {/* In a real app, the ticket would include a message property */}
                این متن اصلی تیکت است که توسط کاربر ارسال شده است. در حالت واقعی، این متن از API دریافت می‌شود.
              </p>
            </div>
            
            {/* Ticket responses */}
            {selectedTicket?.responses?.map((response) => (
              <div 
                key={response.id} 
                className={`p-4 rounded-lg ${response.userId === user?.id ? "bg-blue-50 mr-4" : "bg-gray-50 ml-4"}`}
              >
                <div className="flex items-center mb-2">
                  <span className="font-bold ml-2">{response.user?.fullName || "پشتیبان"}</span>
                  <span className="text-xs text-gray-500">
                    {new Date(response.createdAt).toLocaleTimeString('fa-IR')}
                  </span>
                </div>
                <p>{response.message}</p>
              </div>
            ))}
          </div>
          
          <div className="space-y-4">
            <Textarea
              placeholder="پاسخ خود را بنویسید..."
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              className="min-h-24"
            />
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setDetailsOpen(false)}>
                انصراف
              </Button>
              <Button 
                disabled={!replyText.trim() || isSubmitting}
                onClick={handleReplySubmit}
              >
                {isSubmitting ? "در حال ارسال..." : "ارسال پاسخ"}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TicketList;