import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Ticket, TicketResponse } from '@shared/schema';
import { format } from 'date-fns-jalali';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '@/hooks/use-auth';

// UI Components
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertCircle, Eye, MessageSquare, LifeBuoy, Loader2, Plus } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

// Ticket status badges
const getStatusBadge = (status: string) => {
  switch (status) {
    case 'open':
      return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">باز</Badge>;
    case 'in_progress':
      return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">در حال بررسی</Badge>;
    case 'resolved':
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">حل شده</Badge>;
    case 'closed':
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">بسته شده</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

// Form schema for new ticket
const newTicketSchema = z.object({
  subject: z.string().min(5, { message: 'موضوع باید حداقل ۵ کاراکتر باشد' }),
  description: z.string().min(10, { message: 'توضیحات باید حداقل ۱۰ کاراکتر باشد' }),
});

// Form schema for ticket response
const responseSchema = z.object({
  message: z.string().min(1, { message: 'پاسخ نمی‌تواند خالی باشد' }),
});

type NewTicketValues = z.infer<typeof newTicketSchema>;
type ResponseFormValues = z.infer<typeof responseSchema>;

interface TicketDetailProps {
  ticket: Ticket;
  onClose: () => void;
}

// Ticket detail dialog component
const TicketDetailDialog: React.FC<TicketDetailProps> = ({ ticket, onClose }) => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form setup for responses
  const form = useForm<ResponseFormValues>({
    resolver: zodResolver(responseSchema),
    defaultValues: {
      message: '',
    },
  });

  // Fetch ticket responses
  const { data: ticketData, isLoading: isLoadingResponses } = useQuery({
    queryKey: ['/api/tickets', ticket.id],
    queryFn: () => apiRequest('GET', `/api/tickets/${ticket.id}`).then(res => res.json()),
  });

  const responses = ticketData?.responses || [];

  // Submit response mutation
  const submitResponse = async (data: ResponseFormValues) => {
    setIsSubmitting(true);
    try {
      await apiRequest('POST', `/api/tickets/${ticket.id}/responses`, data);
      toast({
        title: 'پاسخ ارسال شد',
        description: 'پاسخ شما با موفقیت ثبت شد',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tickets', ticket.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      form.reset({ message: '' });
    } catch (error) {
      toast({
        title: 'خطا',
        description: 'مشکلی در ارسال پاسخ رخ داد. لطفاً دوباره تلاش کنید.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatDate = (date: Date | null) => {
    if (!date) return 'تاریخ نامشخص';
    return format(new Date(date), 'yyyy/MM/dd HH:mm');
  };

  return (
    <DialogContent className="max-w-3xl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <LifeBuoy className="h-5 w-5 text-primary" />
          <span>تیکت #{ticket.id}: {ticket.subject}</span>
        </DialogTitle>
        <DialogDescription>
          {formatDate(ticket.createdAt)} | {getStatusBadge(ticket.status)}
        </DialogDescription>
      </DialogHeader>

      <div className="space-y-4">
        {/* Original ticket message */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between">
              <CardTitle className="text-sm font-medium">پیام اصلی</CardTitle>
              <span className="text-xs text-gray-500">{formatDate(ticket.createdAt)}</span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-3 rounded-md text-sm">
              {ticket.description}
            </div>
          </CardContent>
        </Card>

        {/* Ticket responses */}
        <div className="border rounded-md">
          <div className="p-3 border-b bg-gray-50">
            <h3 className="font-medium">تاریخچه گفتگو</h3>
          </div>
          
          <ScrollArea className="h-64">
            {isLoadingResponses ? (
              <div className="flex justify-center items-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : responses && responses.length > 0 ? (
              <div className="space-y-3 p-3">
                {responses.map((response: TicketResponse) => (
                  <Card key={response.id} className={`border ${response.userId === ticket.userId ? 'border-gray-200' : 'border-primary/20 bg-primary/5'}`}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${response.userId === ticket.userId ? 'bg-gray-200' : 'bg-primary'}`}>
                            <span className={`text-sm font-bold ${response.userId === ticket.userId ? 'text-gray-700' : 'text-white'}`}>
                              {response.userId === ticket.userId ? 'ک' : 'پ'}
                            </span>
                          </div>
                          <span className="text-sm font-medium">
                            {response.userId === ticket.userId ? 'شما' : 'پشتیبان'}
                          </span>
                        </div>
                        <span className="text-xs text-gray-500">{formatDate(response.createdAt)}</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm">{response.message}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center p-8 text-gray-500">
                <MessageSquare className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                <p>هنوز پاسخی ثبت نشده است</p>
              </div>
            )}
          </ScrollArea>
        </div>

        {/* Response form - only if ticket status is 'open' or 'in_progress' */}
        {(ticket.status === 'open' || ticket.status === 'in_progress') && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">پاسخ شما</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(submitResponse)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea
                            placeholder="پاسخ خود را بنویسید..."
                            className="min-h-[100px] resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end gap-2">
                    <Button variant="outline" type="button" onClick={onClose}>
                      بستن
                    </Button>
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
                      ارسال پاسخ
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        )}

        {/* If ticket is resolved or closed, show info message */}
        {(ticket.status === 'resolved' || ticket.status === 'closed') && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>این تیکت بسته شده است</AlertTitle>
            <AlertDescription>
              این تیکت توسط پشتیبانی بسته شده است و امکان پاسخ به آن وجود ندارد. در صورت نیاز، تیکت جدیدی ایجاد کنید.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </DialogContent>
  );
};

// New Ticket Dialog component
const NewTicketDialog: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form setup for new ticket
  const form = useForm<NewTicketValues>({
    resolver: zodResolver(newTicketSchema),
    defaultValues: {
      subject: '',
      description: '',
    },
  });

  // Submit new ticket mutation
  const submitNewTicket = async (data: NewTicketValues) => {
    setIsSubmitting(true);
    try {
      await apiRequest('POST', '/api/tickets', data);
      toast({
        title: 'تیکت ارسال شد',
        description: 'تیکت شما با موفقیت ثبت شد و به زودی توسط کارشناسان پشتیبانی بررسی خواهد شد.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      onClose();
    } catch (error) {
      toast({
        title: 'خطا',
        description: 'مشکلی در ارسال تیکت رخ داد. لطفاً دوباره تلاش کنید.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>ایجاد تیکت پشتیبانی جدید</DialogTitle>
        <DialogDescription>
          درخواست خود را با جزئیات کامل شرح دهید تا تیم پشتیبانی بتواند سریعتر به شما کمک کند.
        </DialogDescription>
      </DialogHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(submitNewTicket)} className="space-y-4">
          <FormField
            control={form.control}
            name="subject"
            render={({ field }) => (
              <FormItem>
                <FormLabel>موضوع</FormLabel>
                <FormControl>
                  <Input placeholder="موضوع تیکت خود را وارد کنید" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>توضیحات</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="مشکل یا درخواست خود را با جزئیات شرح دهید..."
                    className="min-h-[150px] resize-none"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  لطفا تمام جزئیات لازم را ذکر کنید تا بتوانیم سریع‌تر به شما کمک کنیم.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" type="button" onClick={onClose}>
              انصراف
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
              ارسال تیکت
            </Button>
          </div>
        </form>
      </Form>
    </DialogContent>
  );
};

// Main user tickets component
const UserTickets: React.FC = () => {
  const { user } = useAuth();
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [isTicketDialogOpen, setIsTicketDialogOpen] = useState(false);
  const [isNewTicketDialogOpen, setIsNewTicketDialogOpen] = useState(false);

  // Fetch user tickets
  const { data: tickets, isLoading } = useQuery<Ticket[]>({
    queryKey: ['/api/tickets'],
    enabled: !!user, // Only fetch if user is logged in
  });

  const handleViewTicket = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setIsTicketDialogOpen(true);
  };

  const handleCloseTicketDialog = () => {
    setIsTicketDialogOpen(false);
  };

  const handleOpenNewTicketDialog = () => {
    setIsNewTicketDialogOpen(true);
  };

  const handleCloseNewTicketDialog = () => {
    setIsNewTicketDialogOpen(false);
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="text-center">
            <p>لطفا برای مشاهده تیکت‌های خود وارد حساب کاربری شوید.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>تیکت‌های پشتیبانی</CardTitle>
            <CardDescription>همه درخواست‌های پشتیبانی شما</CardDescription>
          </div>
          <Button size="sm" onClick={handleOpenNewTicketDialog}>
            <Plus className="h-4 w-4 ml-1" />
            تیکت جدید
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : tickets && tickets.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px]">شناسه</TableHead>
                <TableHead>موضوع</TableHead>
                <TableHead>تاریخ</TableHead>
                <TableHead>وضعیت</TableHead>
                <TableHead className="w-[100px]">عملیات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tickets.map((ticket) => (
                <TableRow key={ticket.id}>
                  <TableCell className="font-medium">{ticket.id}</TableCell>
                  <TableCell>{ticket.subject}</TableCell>
                  <TableCell>
                    {ticket.createdAt ? format(new Date(ticket.createdAt), 'yyyy/MM/dd') : 'تاریخ نامشخص'}
                  </TableCell>
                  <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={() => handleViewTicket(ticket)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center py-8">
            <LifeBuoy className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p className="text-gray-500 mb-4">هنوز تیکتی ثبت نکرده‌اید</p>
            <Button onClick={handleOpenNewTicketDialog}>
              <Plus className="h-4 w-4 ml-1" />
              ایجاد تیکت جدید
            </Button>
          </div>
        )}
      </CardContent>

      {/* Ticket detail dialog */}
      <Dialog open={isTicketDialogOpen} onOpenChange={setIsTicketDialogOpen}>
        {selectedTicket && <TicketDetailDialog ticket={selectedTicket} onClose={handleCloseTicketDialog} />}
      </Dialog>

      {/* New ticket dialog */}
      <Dialog open={isNewTicketDialogOpen} onOpenChange={setIsNewTicketDialogOpen}>
        <NewTicketDialog onClose={handleCloseNewTicketDialog} />
      </Dialog>
    </Card>
  );
};

export default UserTickets;