import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, User, Mail, Phone, Building, Lock, FileText } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Registration form schema for transporters
const transporterRegisterSchema = z.object({
  username: z.string().min(3, "نام کاربری باید حداقل 3 کاراکتر باشد"),
  password: z.string().min(6, "رمز عبور باید حداقل 6 کاراکتر باشد"),
  confirmPassword: z.string().min(1, "تکرار رمز عبور الزامی است"),
  email: z.string().email("ایمیل نامعتبر است"),
  phone: z.string().min(10, "شماره تلفن باید حداقل 10 رقم باشد"),
  fullName: z.string().min(3, "نام و نام خانوادگی باید حداقل 3 کاراکتر باشد"),
  userType: z.literal("transporter"),
  company: z.string().min(3, "نام شرکت باید حداقل 3 کاراکتر باشد"),
  transporterType: z.string().min(1, "نوع حمل و نقل الزامی است"),
  registrationNumber: z.string().min(1, "شماره ثبت شرکت الزامی است"),
  licenseNumber: z.string().min(1, "شماره مجوز فعالیت الزامی است"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "رمز عبور و تکرار آن یکسان نیستند",
  path: ["confirmPassword"],
});

type TransporterRegisterFormValues = z.infer<typeof transporterRegisterSchema>;

const TransporterRegisterForm = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const { registerWithCredentials } = useAuth();
  const { toast } = useToast();

  const form = useForm<TransporterRegisterFormValues>({
    resolver: zodResolver(transporterRegisterSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      email: "",
      phone: "",
      fullName: "",
      userType: "transporter",
      company: "",
      transporterType: "",
      registrationNumber: "",
      licenseNumber: "",
    },
  });

  const onSubmit = (data: TransporterRegisterFormValues) => {
    console.log("Submitting transporter registration:", data);
    // Remove confirmPassword as it's not needed for the API
    const { confirmPassword, ...registrationData } = data;
    registerWithCredentials.mutate(registrationData);
  };
  
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  
  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <h3 className="text-blue-800 font-semibold mb-2">ثبت‌نام شرکت حمل و نقل</h3>
          <p className="text-blue-700 text-sm">
            با ثبت‌نام به عنوان شرکت حمل و نقل، شما می‌توانید خدمات خود را به صاحبان کالا ارائه دهید و از مزایای افزایش مشتری بهره‌مند شوید.
          </p>
        </div>

        {/* Company Information */}
        <div className="bg-gray-50 rounded-lg p-4 mb-4">
          <h3 className="font-semibold text-gray-700 mb-4">اطلاعات شرکت</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="company"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>نام شرکت</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Building className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        placeholder="نام شرکت حمل و نقل" 
                        className="pr-10" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="transporterType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>نوع حمل و نقل</FormLabel>
                  <FormControl>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="نوع حمل و نقل را انتخاب کنید" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ship">حمل و نقل دریایی</SelectItem>
                        <SelectItem value="truck">حمل و نقل زمینی</SelectItem>
                        <SelectItem value="train">حمل و نقل ریلی</SelectItem>
                        <SelectItem value="air">حمل و نقل هوایی</SelectItem>
                        <SelectItem value="multi">حمل و نقل چندوجهی</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <FormField
              control={form.control}
              name="registrationNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>شماره ثبت شرکت</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <FileText className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        placeholder="شماره ثبت شرکت" 
                        className="pr-10" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="licenseNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>شماره مجوز فعالیت</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <FileText className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        placeholder="شماره مجوز فعالیت" 
                        className="pr-10" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        {/* User Information */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold text-gray-700 mb-4">اطلاعات مدیر/رابط</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>نام و نام خانوادگی</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <User className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        placeholder="نام و نام خانوادگی" 
                        className="pr-10" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>نام کاربری</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <User className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        placeholder="نام کاربری" 
                        className="pr-10" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ایمیل</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Mail className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        type="email" 
                        placeholder="example@domain.com" 
                        className="pr-10" 
                        dir="ltr" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>شماره تماس</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Phone className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        placeholder="۰۹۱۲۳۴۵۶۷۸۹" 
                        className="pr-10" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>رمز عبور</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        type={showPassword ? "text" : "password"} 
                        placeholder="رمز عبور" 
                        className="pr-10" 
                        {...field} 
                      />
                      <Button 
                        type="button"
                        variant="ghost" 
                        size="icon"
                        className="absolute left-2 top-2 h-6 w-6 p-0" 
                        onClick={togglePasswordVisibility}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </Button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>تکرار رمز عبور</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute right-3 top-3 text-gray-400" size={16} />
                      <Input 
                        type={showConfirmPassword ? "text" : "password"} 
                        placeholder="تکرار رمز عبور" 
                        className="pr-10" 
                        {...field} 
                      />
                      <Button 
                        type="button"
                        variant="ghost" 
                        size="icon"
                        className="absolute left-2 top-2 h-6 w-6 p-0" 
                        onClick={toggleConfirmPasswordVisibility}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </Button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
        
        <div className="pt-4">
          <Button 
            type="submit" 
            className="w-full" 
            disabled={registerWithCredentials.isPending}
          >
            {registerWithCredentials.isPending ? "در حال ثبت‌نام..." : "ثبت‌نام شرکت حمل و نقل"}
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default TransporterRegisterForm;