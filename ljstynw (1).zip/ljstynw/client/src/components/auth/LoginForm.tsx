import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useAuth } from "@/hooks/use-auth";
import { Eye, EyeOff, User, Lock } from "lucide-react";

// Login form schema
const loginSchema = z.object({
  username: z.string().min(1, "نام کاربری الزامی است"),
  password: z.string().min(1, "رمز عبور الزامی است"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

const LoginForm = () => {
  const [showPassword, setShowPassword] = useState(false);
  
  const { loginMutation } = useAuth();

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };
  
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>نام کاربری یا ایمیل</FormLabel>
              <FormControl>
                <div className="relative">
                  <User className="absolute right-3 top-3 text-gray-400" size={16} />
                  <Input 
                    placeholder="نام کاربری یا ایمیل خود را وارد کنید" 
                    className="pr-10" 
                    {...field} 
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>رمز عبور</FormLabel>
              <FormControl>
                <div className="relative">
                  <Lock className="absolute right-3 top-3 text-gray-400" size={16} />
                  <Input 
                    type={showPassword ? "text" : "password"} 
                    placeholder="رمز عبور خود را وارد کنید" 
                    className="pr-10" 
                    {...field} 
                  />
                  <Button 
                    type="button"
                    variant="ghost" 
                    size="icon"
                    className="absolute left-2 top-2 h-6 w-6 p-0" 
                    onClick={togglePasswordVisibility}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </Button>
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input
              id="remember-me"
              name="remember-me"
              type="checkbox"
              className="h-4 w-4 rounded border-gray-300 ml-2"
            />
            <label htmlFor="remember-me" className="text-sm text-gray-600">
              مرا به خاطر بسپار
            </label>
          </div>
          <a href="#" className="text-sm text-primary hover:text-primary-dark">
            فراموشی رمز عبور
          </a>
        </div>
        
        <Button 
          type="submit" 
          className="w-full" 
          disabled={loginMutation.isPending}
        >
          {loginMutation.isPending ? "در حال ورود..." : "ورود به حساب کاربری"}
        </Button>
      </form>
      
      <div className="mt-6 pt-6 border-t border-gray-200 text-center">
        <p className="text-gray-600 mb-4">یا ورود با</p>
        <div className="flex justify-center space-x-4 space-x-reverse">
          <Button variant="outline" size="icon" className="rounded-full">
            <i className="fab fa-google"></i>
          </Button>
          <Button variant="outline" size="icon" className="rounded-full">
            <i className="fab fa-linkedin-in"></i>
          </Button>
        </div>
      </div>
    </Form>
  );
};

export default LoginForm;