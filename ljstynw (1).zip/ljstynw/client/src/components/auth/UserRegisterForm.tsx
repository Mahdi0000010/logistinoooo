import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useAuth } from "@/hooks/use-auth";
import { Eye, EyeOff, User, Mail, Phone, Lock } from "lucide-react";

// Registration form schema for regular users
const userRegisterSchema = z.object({
  username: z.string().min(3, "نام کاربری باید حداقل 3 کاراکتر باشد"),
  password: z.string().min(6, "رمز عبور باید حداقل 6 کاراکتر باشد"),
  confirmPassword: z.string().min(1, "تکرار رمز عبور الزامی است"),
  email: z.string().email("ایمیل نامعتبر است"),
  phone: z.string().min(10, "شماره تلفن باید حداقل 10 رقم باشد"),
  fullName: z.string().min(3, "نام و نام خانوادگی باید حداقل 3 کاراکتر باشد"),
  userType: z.literal("cargo_owner"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "رمز عبور و تکرار آن یکسان نیستند",
  path: ["confirmPassword"],
});

type UserRegisterFormValues = z.infer<typeof userRegisterSchema>;

const UserRegisterForm = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const { registerWithCredentials } = useAuth();

  const form = useForm<UserRegisterFormValues>({
    resolver: zodResolver(userRegisterSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      email: "",
      phone: "",
      fullName: "",
      userType: "cargo_owner",
    },
  });

  const onSubmit = (data: UserRegisterFormValues) => {
    // Remove confirmPassword as it's not needed for the API
    const { confirmPassword, ...registrationData } = data;
    registerWithCredentials.mutate(registrationData);
  };
  
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  
  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>نام و نام خانوادگی</FormLabel>
                <FormControl>
                  <div className="relative">
                    <User className="absolute right-3 top-3 text-gray-400" size={16} />
                    <Input 
                      placeholder="نام و نام خانوادگی" 
                      className="pr-10" 
                      {...field} 
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>نام کاربری</FormLabel>
                <FormControl>
                  <div className="relative">
                    <User className="absolute right-3 top-3 text-gray-400" size={16} />
                    <Input 
                      placeholder="نام کاربری" 
                      className="pr-10" 
                      {...field} 
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>ایمیل</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Mail className="absolute right-3 top-3 text-gray-400" size={16} />
                    <Input 
                      type="email" 
                      placeholder="example@domain.com" 
                      className="pr-10" 
                      dir="ltr" 
                      {...field} 
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>شماره تماس</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Phone className="absolute right-3 top-3 text-gray-400" size={16} />
                    <Input 
                      placeholder="۰۹۱۲۳۴۵۶۷۸۹" 
                      className="pr-10" 
                      {...field} 
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>رمز عبور</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Lock className="absolute right-3 top-3 text-gray-400" size={16} />
                    <Input 
                      type={showPassword ? "text" : "password"} 
                      placeholder="رمز عبور" 
                      className="pr-10" 
                      {...field} 
                    />
                    <Button 
                      type="button"
                      variant="ghost" 
                      size="icon"
                      className="absolute left-2 top-2 h-6 w-6 p-0" 
                      onClick={togglePasswordVisibility}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="confirmPassword"
            render={({ field }) => (
              <FormItem>
                <FormLabel>تکرار رمز عبور</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Lock className="absolute right-3 top-3 text-gray-400" size={16} />
                    <Input 
                      type={showConfirmPassword ? "text" : "password"} 
                      placeholder="تکرار رمز عبور" 
                      className="pr-10" 
                      {...field} 
                    />
                    <Button 
                      type="button"
                      variant="ghost" 
                      size="icon"
                      className="absolute left-2 top-2 h-6 w-6 p-0" 
                      onClick={toggleConfirmPasswordVisibility}
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <Button 
          type="submit" 
          className="w-full" 
          disabled={registerWithCredentials.isPending}
        >
          {registerWithCredentials.isPending ? "در حال ثبت‌نام..." : "ثبت‌نام صاحب کالا"}
        </Button>
      </form>
    </Form>
  );
};

export default UserRegisterForm;