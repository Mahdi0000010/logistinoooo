import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  LayoutDashboard,
  Package,
  FileText,
  UserCircle,
  Settings,
  LogOut,
  Menu,
  Plus,
  FileCheck,
  Ship,
  Inbox,
  X,
  ChevronLeft
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar = ({ activeTab, setActiveTab }: SidebarProps) => {
  const { user, logoutMutation } = useAuth();
  const isMobile = useMobile();
  const [, navigate] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  if (!user) return null;

  const handleLogout = () => {
    logoutMutation.mutate();
    navigate("/");
  };

  const handleTabClick = (tab: string) => {
    setActiveTab(tab);
    setIsOpen(false);
  };

  const isCargoOwner = user.userType === "cargo_owner";

  // Get URL params to check if we're in edit mode
  const params = new URLSearchParams(window.location.search);
  const isEditMode = activeTab === "edit";
  const shipmentIdFromUrl = params.get("shipmentId");
  
  const menuItems = [
    {
      id: "overview",
      label: "داشبورد",
      icon: <LayoutDashboard size={20} className="ml-2" />,
      show: true
    },
    {
      id: "shipments",
      label: isCargoOwner ? "محموله‌های من" : "سرویس‌های ارائه شده",
      icon: <Package size={20} className="ml-2" />,
      show: true
    },
    {
      id: "create",
      label: "ثبت سرویس جدید",
      icon: <Plus size={20} className="ml-2" />,
      show: !isCargoOwner && !isEditMode
    },
    // Special menu item for edit mode
    {
      id: "edit",
      label: "ویرایش سرویس",
      icon: <FileText size={20} className="ml-2" />,
      show: !isCargoOwner && isEditMode
    },
    {
      id: "bookings",
      label: "رزروهای دریافتی",
      icon: <Inbox size={20} className="ml-2" />,
      show: !isCargoOwner
    },
    {
      id: "profile",
      label: "پروفایل",
      icon: <UserCircle size={20} className="ml-2" />,
      show: true
    },
    {
      id: "documents",
      label: "مدارک",
      icon: <FileCheck size={20} className="ml-2" />,
      show: true
    },
    {
      id: "settings",
      label: "تنظیمات",
      icon: <Settings size={20} className="ml-2" />,
      show: true
    }
  ];

  const sidebarContent = (
    <div className="space-y-6 py-4">
      <div className="px-4 py-2">
        <div className="flex items-center space-x-4 space-x-reverse">
          <Avatar className="h-10 w-10 border-2 border-primary/10">
            <AvatarFallback className="bg-primary/10 text-primary">
              {user.fullName ? user.fullName.substring(0, 2) : "کا"}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium">{user.fullName || "کاربر"}</div>
            <div className="text-xs text-gray-500">
              {isCargoOwner ? "صاحب کالا" : "شرکت حمل و نقل"}
            </div>
          </div>
        </div>
      </div>
      
      <div className="px-3">
        <div className="space-y-1">
          {menuItems
            .filter(item => item.show)
            .map(item => (
              <Button
                key={item.id}
                variant={activeTab === item.id ? "default" : "ghost"}
                className={`w-full justify-start ${activeTab === item.id ? "bg-primary text-white" : ""}`}
                onClick={() => handleTabClick(item.id)}
              >
                {item.icon} {item.label}
              </Button>
            ))
          }
        </div>
      </div>
      
      <div className="px-3 py-2">
        <div className="space-y-1">
          <Link to="/support">
            <Button variant="ghost" className="w-full justify-start">
              <FileText size={20} className="ml-2" /> تیکت‌های پشتیبانی
            </Button>
          </Link>
          <Button 
            variant="ghost" 
            className="w-full justify-start text-red-500 hover:bg-red-50 hover:text-red-500"
            onClick={handleLogout}
          >
            <LogOut size={20} className="ml-2" /> خروج از حساب
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {isMobile ? (
        <div className="flex items-center h-14 px-4 border-b justify-between">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
            <ChevronLeft size={20} className="ml-2" /> بازگشت به سایت
          </Button>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu size={20} />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64 p-0">
              <div className="flex justify-between items-center h-14 px-4 border-b">
                <div className="font-bold text-lg">پنل کاربری</div>
                <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                  <X size={18} />
                </Button>
              </div>
              {sidebarContent}
            </SheetContent>
          </Sheet>
        </div>
      ) : (
        <div className="w-64 border-l bg-white overflow-y-auto">
          <div className="flex items-center h-14 px-4 border-b">
            <Link to="/" className="flex items-center">
              <Ship className="ml-2" size={20} />
              <span className="font-bold text-lg">لجستینو</span>
            </Link>
          </div>
          {sidebarContent}
        </div>
      )}
    </>
  );
};

export default Sidebar;
