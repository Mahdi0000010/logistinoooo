import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import DatePicker from "@/components/shared/DatePicker";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Ship, Truck, Train, Plus, Trash2, Edit, Check, X, InfoIcon, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger
} from "@/components/ui/dialog";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";

// Form schema for segments
const segmentSchema = z.object({
  originId: z.string().min(1, "انتخاب مبدا الزامی است"),
  destinationId: z.string().min(1, "انتخاب مقصد الزامی است"),
  departureDate: z.string().min(1, "انتخاب تاریخ حرکت الزامی است"),
  arrivalDate: z.string().min(1, "انتخاب تاریخ رسیدن الزامی است"),
  transportType: z.string().min(1, "انتخاب نوع حمل و نقل الزامی است"),
  containerType: z.string().optional(),
  capacity: z.string().min(1, "وارد کردن ظرفیت الزامی است"),
  price: z.string().min(1, "وارد کردن قیمت الزامی است"),
  description: z.string().optional(),
  segmentOrder: z.number(),
});

type SegmentFormValues = z.infer<typeof segmentSchema>;

interface ShipmentSegmentsProps {
  shipmentId: string;
}

const ShipmentSegments: React.FC<ShipmentSegmentsProps> = ({ shipmentId }) => {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSegmentId, setEditingSegmentId] = useState<number | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  
  // Fetch locations
  const { data: locations, isLoading: isLoadingLocations } = useQuery({
    queryKey: ['/api/locations'],
    queryFn: async () => {
      const res = await fetch('/api/locations');
      return await res.json();
    },
  });
  
  // Fetch segments for this shipment
  const { 
    data: segments, 
    isLoading: isLoadingSegments,
    refetch: refetchSegments
  } = useQuery({
    queryKey: ['/api/shipments', shipmentId, 'segments'],
    queryFn: async () => {
      if (!shipmentId) return [];
      const res = await fetch(`/api/shipments/${shipmentId}/segments`);
      if (!res.ok) {
        throw new Error("Failed to fetch segments");
      }
      return await res.json();
    },
    enabled: !!shipmentId,
  });
  
  // Create segment mutation
  const createSegmentMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", `/api/shipments/${shipmentId}/segments`, data);
    },
    onSuccess: () => {
      toast({
        title: "قطعه مسیر با موفقیت اضافه شد",
        description: "قطعه جدید به مسیر حمل و نقل اضافه شد",
      });
      refetchSegments();
      setDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "خطا در افزودن قطعه مسیر",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  });
  
  // Update segment mutation
  const updateSegmentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      return await apiRequest("PUT", `/api/segments/${id}`, data);
    },
    onSuccess: () => {
      toast({
        title: "قطعه مسیر با موفقیت بروزرسانی شد",
        description: "تغییرات قطعه مسیر با موفقیت ذخیره شد",
      });
      refetchSegments();
      setDialogOpen(false);
      setEditingSegmentId(null);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "خطا در بروزرسانی قطعه مسیر",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  });
  
  // Delete segment mutation
  const deleteSegmentMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/segments/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "قطعه مسیر با موفقیت حذف شد",
      });
      refetchSegments();
      setConfirmDeleteId(null);
    },
    onError: (error) => {
      toast({
        title: "خطا در حذف قطعه مسیر",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  });
  
  // Form for segment creation/editing
  const form = useForm<SegmentFormValues>({
    resolver: zodResolver(segmentSchema),
    defaultValues: {
      originId: "",
      destinationId: "",
      departureDate: "",
      arrivalDate: "",
      transportType: "",
      containerType: "",
      capacity: "",
      price: "",
      description: "",
      segmentOrder: 1,
    },
  });
  
  // Load segment data when editing
  useEffect(() => {
    if (editingSegmentId && segments) {
      const segment = segments.find((s: any) => s.id === editingSegmentId);
      if (segment) {
        form.reset({
          originId: segment.originId.toString(),
          destinationId: segment.destinationId.toString(),
          departureDate: segment.departureDate,
          arrivalDate: segment.arrivalDate,
          transportType: segment.transportType,
          containerType: segment.containerType || "",
          capacity: segment.capacity.toString(),
          price: segment.price.toString(),
          description: segment.description || "",
          segmentOrder: segment.segmentOrder,
        });
      }
    } else {
      // Reset form when not editing
      form.reset({
        originId: "",
        destinationId: "",
        departureDate: "",
        arrivalDate: "",
        transportType: "",
        containerType: "",
        capacity: "",
        price: "",
        description: "",
        segmentOrder: segments?.length ? segments.length + 1 : 1,
      });
    }
  }, [editingSegmentId, segments, form]);
  
  const onSubmit = async (data: SegmentFormValues) => {
    // Convert string values to appropriate types
    const segmentData = {
      originId: parseInt(data.originId),
      destinationId: parseInt(data.destinationId),
      departureDate: data.departureDate,
      arrivalDate: data.arrivalDate,
      transportType: data.transportType,
      containerType: data.containerType || null,
      capacity: parseInt(data.capacity),
      price: parseInt(data.price),
      description: data.description || null,
      segmentOrder: data.segmentOrder,
    };
    
    if (editingSegmentId) {
      updateSegmentMutation.mutate({ id: editingSegmentId, data: segmentData });
    } else {
      createSegmentMutation.mutate(segmentData);
    }
  };
  
  const startAddSegment = () => {
    setEditingSegmentId(null);
    form.reset({
      originId: "",
      destinationId: "",
      departureDate: "",
      arrivalDate: "",
      transportType: "",
      containerType: "",
      capacity: "",
      price: "",
      description: "",
      segmentOrder: segments?.length ? segments.length + 1 : 1,
    });
    setDialogOpen(true);
  };
  
  const startEditSegment = (id: number) => {
    setEditingSegmentId(id);
    setDialogOpen(true);
  };
  
  const getTransportTypeIcon = (type: string) => {
    switch (type) {
      case "sea":
        return <Ship size={16} className="ml-2" />;
      case "land":
        return <Truck size={16} className="ml-2" />;
      case "rail":
        return <Train size={16} className="ml-2" />;
      default:
        return null;
    }
  };
  
  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString("fa-IR");
    } catch (e) {
      return dateString;
    }
  };
  
  if (isLoadingSegments) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-semibold text-lg">قطعات مسیر حمل و نقل</h3>
        <Button onClick={startAddSegment} size="sm">
          <Plus className="ml-2" size={16} />
          افزودن قطعه مسیر
        </Button>
      </div>
      
      {(!segments || segments.length === 0) ? (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>هنوز قطعه‌ای تعریف نشده است</AlertTitle>
          <AlertDescription>
            برای حمل و نقل ترکیبی، نیاز به تعریف حداقل دو قطعه مسیر دارید.
            هر قطعه می‌تواند نوع حمل و نقل متفاوتی داشته باشد.
          </AlertDescription>
        </Alert>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ترتیب</TableHead>
              <TableHead>مبدا</TableHead>
              <TableHead>مقصد</TableHead>
              <TableHead>نوع حمل</TableHead>
              <TableHead>تاریخ حرکت</TableHead>
              <TableHead>قیمت</TableHead>
              <TableHead>عملیات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {segments.map((segment: any) => (
              <TableRow key={segment.id}>
                <TableCell>{segment.segmentOrder}</TableCell>
                <TableCell>{segment.originName}</TableCell>
                <TableCell>{segment.destinationName}</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    {getTransportTypeIcon(segment.transportType)}
                    {segment.transportType === "sea" ? "دریایی" : 
                     segment.transportType === "land" ? "زمینی" : 
                     segment.transportType === "rail" ? "ریلی" : "نامشخص"}
                  </div>
                </TableCell>
                <TableCell>{formatDate(segment.departureDate)}</TableCell>
                <TableCell>{segment.price.toLocaleString("fa-IR")} تومان</TableCell>
                <TableCell>
                  <div className="flex space-x-2 space-x-reverse">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => startEditSegment(segment.id)}
                    >
                      <Edit size={16} />
                    </Button>
                    
                    {confirmDeleteId === segment.id ? (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteSegmentMutation.mutate(segment.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Check size={16} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setConfirmDeleteId(null)}
                        >
                          <X size={16} />
                        </Button>
                      </>
                    ) : (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setConfirmDeleteId(segment.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 size={16} />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingSegmentId ? "ویرایش قطعه مسیر" : "افزودن قطعه مسیر جدید"}
            </DialogTitle>
            <DialogDescription>
              {editingSegmentId 
                ? "اطلاعات قطعه مسیر را ویرایش کنید" 
                : "مشخصات قطعه جدید مسیر را وارد کنید"}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="originId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>مبدا</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب مبدا" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {locations?.map((location: any) => (
                            <SelectItem key={location.id} value={location.id.toString()}>
                              {location.name} ({location.country})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="destinationId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>مقصد</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب مقصد" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {locations?.map((location: any) => (
                            <SelectItem key={location.id} value={location.id.toString()}>
                              {location.name} ({location.country})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="departureDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تاریخ حرکت</FormLabel>
                      <FormControl>
                        <DatePicker
                          value={field.value}
                          onChange={field.onChange}
                          placeholder="انتخاب تاریخ حرکت"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="arrivalDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تاریخ رسیدن</FormLabel>
                      <FormControl>
                        <DatePicker
                          value={field.value}
                          onChange={field.onChange}
                          placeholder="انتخاب تاریخ رسیدن"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="transportType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع حمل و نقل</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب نوع حمل و نقل" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="sea">
                            <div className="flex items-center">
                              <Ship className="ml-2" size={16} />
                              دریایی
                            </div>
                          </SelectItem>
                          <SelectItem value="land">
                            <div className="flex items-center">
                              <Truck className="ml-2" size={16} />
                              زمینی
                            </div>
                          </SelectItem>
                          <SelectItem value="rail">
                            <div className="flex items-center">
                              <Train className="ml-2" size={16} />
                              ریلی
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="containerType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع کانتینر</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب نوع کانتینر" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="20_standard">کانتینر 20 فوت استاندارد</SelectItem>
                          <SelectItem value="40_standard">کانتینر 40 فوت استاندارد</SelectItem>
                          <SelectItem value="20_refrigerated">کانتینر 20 فوت یخچالی</SelectItem>
                          <SelectItem value="40_refrigerated">کانتینر 40 فوت یخچالی</SelectItem>
                          <SelectItem value="bulk">فله</SelectItem>
                          <SelectItem value="liquid">مایع</SelectItem>
                          <SelectItem value="breakbulk">خرده بار</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="capacity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ظرفیت</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="تعداد" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>قیمت (تومان)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="قیمت به تومان" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>توضیحات</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="توضیحات اضافی درباره این قطعه مسیر"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="submit" disabled={createSegmentMutation.isPending || updateSegmentMutation.isPending}>
                  {editingSegmentId ? "بروزرسانی" : "افزودن"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ShipmentSegments;