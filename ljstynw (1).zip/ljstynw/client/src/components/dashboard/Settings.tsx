import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator"; 
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  KeyRound, 
  Bell, 
  UserCog, 
  ShieldAlert, 
  LogOut,
  Mail
} from "lucide-react";

// Password change form schema
const passwordSchema = z.object({
  currentPassword: z.string().min(6, "رمز عبور فعلی باید حداقل ۶ کاراکتر باشد"),
  newPassword: z.string().min(8, "رمز عبور جدید باید حداقل ۸ کاراکتر باشد"),
  confirmPassword: z.string().min(8, "تکرار رمز عبور جدید باید حداقل ۸ کاراکتر باشد"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "رمز عبور جدید و تکرار آن باید یکسان باشند",
  path: ["confirmPassword"],
});

// Notification settings schema
const notificationSchema = z.object({
  emailNotifications: z.boolean().default(true),
  smsNotifications: z.boolean().default(false),
  newBookingNotification: z.boolean().default(true),
  statusChangeNotification: z.boolean().default(true),
  marketingNotification: z.boolean().default(false),
});

// Account settings schema
const accountSchema = z.object({
  email: z.string().email("ایمیل وارد شده معتبر نیست"),
  phone: z.string().optional(),
  receiveNewsletters: z.boolean().default(false),
  language: z.string().default("fa"),
});

// Form types
type PasswordFormValues = z.infer<typeof passwordSchema>;
type NotificationFormValues = z.infer<typeof notificationSchema>;
type AccountFormValues = z.infer<typeof accountSchema>;

interface SettingsProps {
  isTransporter?: boolean;
}

const Settings = ({ isTransporter = false }: SettingsProps) => {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("account");
  
  // Password change form
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });
  
  // Notification settings form
  const notificationForm = useForm<NotificationFormValues>({
    resolver: zodResolver(notificationSchema),
    defaultValues: {
      emailNotifications: true,
      smsNotifications: false,
      newBookingNotification: true,
      statusChangeNotification: true,
      marketingNotification: false,
    },
  });
  
  // Account settings form
  const accountForm = useForm<AccountFormValues>({
    resolver: zodResolver(accountSchema),
    defaultValues: {
      email: user?.email || "",
      phone: "",
      receiveNewsletters: false,
      language: "fa",
    },
  });
  
  // Handle password change submission
  const onPasswordSubmit = async (data: PasswordFormValues) => {
    try {
      // Call API to change password
      await apiRequest("POST", "/api/user/change-password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
      
      // Show success message
      toast({
        title: "رمز عبور با موفقیت تغییر کرد",
        description: "رمز عبور شما با موفقیت به‌روزرسانی شد.",
      });
      
      // Reset form
      passwordForm.reset();
    } catch (error) {
      toast({
        title: "خطا در تغییر رمز عبور",
        description: "لطفاً از صحت رمز عبور فعلی اطمینان حاصل کنید و دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  };
  
  // Handle notification settings submission
  const onNotificationSubmit = async (data: NotificationFormValues) => {
    try {
      // Call API to update notification settings
      await apiRequest("POST", "/api/user/notification-settings", data);
      
      // Show success message
      toast({
        title: "تنظیمات اطلاع‌رسانی به‌روز شد",
        description: "تنظیمات اطلاع‌رسانی شما با موفقیت ذخیره شد.",
      });
    } catch (error) {
      toast({
        title: "خطا در به‌روزرسانی تنظیمات",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  };
  
  // Handle account settings submission
  const onAccountSubmit = async (data: AccountFormValues) => {
    try {
      // Call API to update account settings
      await apiRequest("POST", "/api/user/account-settings", data);
      
      // Show success message
      toast({
        title: "تنظیمات حساب کاربری به‌روز شد",
        description: "تنظیمات حساب کاربری شما با موفقیت ذخیره شد.",
      });
      
      // Update user data in cache
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    } catch (error) {
      toast({
        title: "خطا در به‌روزرسانی تنظیمات",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  };
  
  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left sidebar with tabs */}
        <Card className="col-span-1">
          <CardContent className="p-4">
            <Tabs
              defaultValue="account"
              value={activeTab}
              onValueChange={setActiveTab}
              className="space-y-1"
              orientation="vertical"
            >
              <TabsList className="flex flex-col h-auto space-y-1 bg-transparent">
                <TabsTrigger
                  value="account"
                  className="justify-start py-2 text-right w-full"
                >
                  <UserCog className="ml-2 h-4 w-4" />
                  تنظیمات حساب کاربری
                </TabsTrigger>
                <TabsTrigger
                  value="password"
                  className="justify-start py-2 text-right w-full"
                >
                  <KeyRound className="ml-2 h-4 w-4" />
                  تغییر رمز عبور
                </TabsTrigger>
                <TabsTrigger
                  value="notifications"
                  className="justify-start py-2 text-right w-full"
                >
                  <Bell className="ml-2 h-4 w-4" />
                  تنظیمات اطلاع‌رسانی
                </TabsTrigger>
                <TabsTrigger
                  value="privacy"
                  className="justify-start py-2 text-right w-full"
                >
                  <ShieldAlert className="ml-2 h-4 w-4" />
                  حریم خصوصی و امنیت
                </TabsTrigger>
              </TabsList>
            </Tabs>
            
            <Separator className="my-4" />
            
            <Button
              variant="destructive"
              className="w-full justify-start"
              onClick={handleLogout}
            >
              <LogOut className="ml-2 h-4 w-4" />
              خروج از حساب کاربری
            </Button>
          </CardContent>
        </Card>
        
        {/* Main content area */}
        <div className="col-span-1 md:col-span-2 space-y-6">
          {/* Account Settings Tab */}
          {activeTab === "account" && (
            <Card>
              <CardHeader>
                <CardTitle>تنظیمات حساب کاربری</CardTitle>
                <CardDescription>
                  مشخصات و تنظیمات حساب کاربری خود را مدیریت کنید
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...accountForm}>
                  <form onSubmit={accountForm.handleSubmit(onAccountSubmit)} className="space-y-4">
                    <FormField
                      control={accountForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>آدرس ایمیل</FormLabel>
                          <FormControl>
                            <Input 
                              type="email" 
                              placeholder="example@domain.com" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            این ایمیل برای ارسال اطلاعیه‌ها و هشدارهای مهم استفاده می‌شود.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={accountForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>شماره تلفن همراه</FormLabel>
                          <FormControl>
                            <Input 
                              type="tel" 
                              placeholder="09123456789" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            این شماره برای ارسال پیامک‌های مهم استفاده می‌شود.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={accountForm.control}
                      name="language"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>زبان</FormLabel>
                          <Select
                            value={field.value}
                            onValueChange={field.onChange}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="انتخاب زبان" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="fa">فارسی</SelectItem>
                              <SelectItem value="en">English</SelectItem>
                              <SelectItem value="ar">العربية</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            زبان مورد نظر خود را برای نمایش سایت انتخاب کنید.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={accountForm.control}
                      name="receiveNewsletters"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-x-reverse space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>دریافت خبرنامه</FormLabel>
                            <FormDescription>
                              اخبار و اطلاعات جدید خدمات لجستیک را دریافت کنید.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="mt-4">
                      ذخیره تغییرات
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
          
          {/* Password Change Tab */}
          {activeTab === "password" && (
            <Card>
              <CardHeader>
                <CardTitle>تغییر رمز عبور</CardTitle>
                <CardDescription>
                  رمز عبور خود را تغییر دهید. توصیه می‌شود از رمز عبور قوی استفاده کنید و آن را به صورت دوره‌ای تغییر دهید.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...passwordForm}>
                  <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                    <FormField
                      control={passwordForm.control}
                      name="currentPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>رمز عبور فعلی</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="رمز عبور فعلی خود را وارد کنید" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={passwordForm.control}
                      name="newPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>رمز عبور جدید</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="رمز عبور جدید را وارد کنید" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            رمز عبور باید حداقل ۸ کاراکتر و شامل حروف بزرگ و کوچک، اعداد و علائم باشد.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={passwordForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>تکرار رمز عبور جدید</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="رمز عبور جدید را مجدداً وارد کنید" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="mt-4">
                      تغییر رمز عبور
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
          
          {/* Notification Settings Tab */}
          {activeTab === "notifications" && (
            <Card>
              <CardHeader>
                <CardTitle>تنظیمات اطلاع‌رسانی</CardTitle>
                <CardDescription>
                  نحوه دریافت اطلاعیه‌ها و اعلان‌ها را مدیریت کنید.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...notificationForm}>
                  <form onSubmit={notificationForm.handleSubmit(onNotificationSubmit)} className="space-y-4">
                    <div className="space-y-4">
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">روش‌های اطلاع‌رسانی</h3>
                        
                        <FormField
                          control={notificationForm.control}
                          name="emailNotifications"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>اطلاع‌رسانی از طریق ایمیل</FormLabel>
                                <FormDescription>
                                  دریافت اطلاعیه‌ها از طریق ایمیل
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={notificationForm.control}
                          name="smsNotifications"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>اطلاع‌رسانی از طریق پیامک</FormLabel>
                                <FormDescription>
                                  دریافت اطلاعیه‌ها از طریق پیامک
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">انواع اطلاعیه‌ها</h3>
                        
                        <FormField
                          control={notificationForm.control}
                          name="newBookingNotification"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>رزرو جدید</FormLabel>
                                <FormDescription>
                                  اطلاع از درخواست‌های رزرو جدید 
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={notificationForm.control}
                          name="statusChangeNotification"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>تغییر وضعیت محموله</FormLabel>
                                <FormDescription>
                                  اطلاع از تغییر وضعیت محموله‌ها
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={notificationForm.control}
                          name="marketingNotification"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>اطلاعیه‌های تبلیغاتی</FormLabel>
                                <FormDescription>
                                  دریافت پیشنهادات ویژه و اخبار تبلیغاتی
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Button type="submit" className="mt-4">
                      ذخیره تنظیمات
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
          
          {/* Privacy & Security Tab */}
          {activeTab === "privacy" && (
            <Card>
              <CardHeader>
                <CardTitle>حریم خصوصی و امنیت</CardTitle>
                <CardDescription>
                  تنظیمات حریم خصوصی و امنیت حساب کاربری خود را مدیریت کنید
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-3">امنیت حساب کاربری</h3>
                    <div className="space-y-4 border rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">تأیید دو مرحله‌ای</h4>
                          <p className="text-sm text-gray-500">با فعال کردن این گزینه، برای ورود به حساب کاربری خود نیاز به تأیید دو مرحله‌ای خواهید داشت</p>
                        </div>
                        <Switch />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">هشدار ورود از دستگاه جدید</h4>
                          <p className="text-sm text-gray-500">با فعال کردن این گزینه، در صورت ورود به حساب کاربری از دستگاه جدید، به شما اطلاع داده می‌شود</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">نمایش آخرین زمان فعالیت</h4>
                          <p className="text-sm text-gray-500">آخرین زمان فعالیت شما به دیگران نمایش داده شود</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-3">تنظیمات حریم خصوصی</h3>
                    <div className="space-y-4 border rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">نمایش اطلاعات تماس</h4>
                          <p className="text-sm text-gray-500">مشخص کنید چه کسانی می‌توانند اطلاعات تماس شما را ببینند</p>
                        </div>
                        <Select defaultValue="verified">
                          <SelectTrigger className="w-[140px]">
                            <SelectValue placeholder="انتخاب کنید" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">همه</SelectItem>
                            <SelectItem value="verified">فقط افراد تأیید شده</SelectItem>
                            <SelectItem value="none">هیچکس</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">نمایش تاریخچه فعالیت</h4>
                          <p className="text-sm text-gray-500">مشخص کنید چه کسانی می‌توانند تاریخچه فعالیت شما را ببینند</p>
                        </div>
                        <Select defaultValue="none">
                          <SelectTrigger className="w-[140px]">
                            <SelectValue placeholder="انتخاب کنید" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">همه</SelectItem>
                            <SelectItem value="verified">فقط افراد تأیید شده</SelectItem>
                            <SelectItem value="none">هیچکس</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <Button variant="outline" className="w-full text-red-600 hover:text-red-700 hover:bg-red-50">
                    درخواست حذف حساب کاربری
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;