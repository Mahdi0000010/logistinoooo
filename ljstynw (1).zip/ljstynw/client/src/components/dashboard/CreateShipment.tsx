import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DatePicker from "@/components/shared/DatePicker";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Ship, Truck, Train, Info, Layers } from "lucide-react";
import ShipmentSegments from "./ShipmentSegments";

// Shipment form schema
const shipmentSchema = z.object({
  originId: z.string().min(1, "انتخاب مبدا الزامی است"),
  destinationId: z.string().min(1, "انتخاب مقصد الزامی است"),
  departureDate: z.string().min(1, "انتخاب تاریخ حرکت الزامی است"),
  arrivalDate: z.string().min(1, "انتخاب تاریخ رسیدن الزامی است"),
  transportType: z.string().min(1, "انتخاب نوع حمل و نقل الزامی است"),
  containerType: z.string().min(1, "انتخاب نوع کانتینر الزامی است"),
  capacity: z.string().min(1, "وارد کردن ظرفیت الزامی است"),
  price: z.string().min(1, "وارد کردن قیمت الزامی است"),

  description: z.string().min(10, "توضیحات باید حداقل 10 کاراکتر باشد"),
  insuranceAvailable: z.boolean().optional().default(false),
  insurancePrice: z.string().optional(),
});

type ShipmentFormValues = z.infer<typeof shipmentSchema>;

const CreateShipment = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [transportType, setTransportType] = useState<string>("");
  const [createdShipmentId, setCreatedShipmentId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>("general");
  
  // Fetch locations
  const { data: locations, isLoading: isLoadingLocations } = useQuery({
    queryKey: ['/api/locations'],
    queryFn: async () => {
      const res = await fetch('/api/locations');
      return await res.json();
    },
  });
  
  const form = useForm<ShipmentFormValues>({
    resolver: zodResolver(shipmentSchema),
    defaultValues: {
      originId: "",
      destinationId: "",
      departureDate: "",
      arrivalDate: "",
      transportType: "",
      containerType: "",
      capacity: "",
      price: "",

      description: "",
      insuranceAvailable: false,
      insurancePrice: "",
    },
  });
  
  const insuranceAvailable = form.watch("insuranceAvailable");
  
  const onSubmit = async (data: ShipmentFormValues) => {
    setIsSubmitting(true);
    try {
      // Convert string values to appropriate types
      const shipmentData = {
        originId: parseInt(data.originId),
        destinationId: parseInt(data.destinationId),
        departureDate: data.departureDate,
        arrivalDate: data.arrivalDate,
        transportType: data.transportType,
        containerType: data.containerType,
        capacity: parseInt(data.capacity),
        price: parseInt(data.price),

        description: data.description,
        insuranceAvailable: data.insuranceAvailable,
        insurancePrice: data.insuranceAvailable ? parseInt(data.insurancePrice || "0") : 0,
        active: true,
        isComposite: data.transportType === "mixed"
      };
      
      const response = await apiRequest("POST", "/api/shipments", shipmentData);
      const shipment = await response.json();
      
      toast({
        title: "سرویس با موفقیت ثبت شد",
        description: "سرویس حمل و نقل جدید با موفقیت ایجاد شد و در سیستم ثبت گردید",
      });
      
      // Invalidate shipments query
      queryClient.invalidateQueries({ queryKey: ['/api/shipments/own'] });
      
      // اگر حمل و نقل ترکیبی است، به تب قطعات مسیر انتقال می‌دهیم
      if (data.transportType === "mixed") {
        setCreatedShipmentId(shipment.id.toString());
        setActiveTab("segments");
      } else {
        // Reset form for non-composite shipments
        form.reset();
        setTransportType("");
      }
    } catch (error) {
      toast({
        title: "خطا در ثبت سرویس",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const getTransportTypeIcon = (type: string) => {
    switch (type) {
      case "sea":
        return <Ship size={20} className="ml-2" />;
      case "land":
        return <Truck size={20} className="ml-2" />;
      case "rail":
        return <Train size={20} className="ml-2" />;
      default:
        return null;
    }
  };
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>ثبت سرویس حمل و نقل جدید</CardTitle>
        </CardHeader>
        <CardContent>
          {createdShipmentId ? (
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="general">اطلاعات کلی</TabsTrigger>
                <TabsTrigger value="segments">قطعات مسیر</TabsTrigger>
              </TabsList>
              <TabsContent value="general">
                <Alert className="mb-4">
                  <Info className="h-4 w-4" />
                  <AlertTitle>سرویس حمل و نقل ثبت شده است</AlertTitle>
                  <AlertDescription>
                    سرویس حمل و نقل ترکیبی با موفقیت ثبت شده است. اکنون می‌توانید قطعات مسیر را اضافه کنید.
                  </AlertDescription>
                </Alert>
                <div className="flex justify-center mt-4">
                  <Button onClick={() => setActiveTab("segments")}>
                    <Layers className="ml-2" size={16} />
                    رفتن به بخش قطعات مسیر
                  </Button>
                </div>
              </TabsContent>
              <TabsContent value="segments">
                <ShipmentSegments shipmentId={createdShipmentId} />
              </TabsContent>
            </Tabs>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="originId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>مبدا</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="انتخاب مبدا" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="placeholder">انتخاب مبدا</SelectItem>
                            {locations?.map((location: any) => (
                              <SelectItem key={location.id} value={location.id.toString()}>
                                {location.name} ({location.country})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="destinationId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>مقصد</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="انتخاب مقصد" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="placeholder">انتخاب مقصد</SelectItem>
                            {locations?.map((location: any) => (
                              <SelectItem key={location.id} value={location.id.toString()}>
                                {location.name} ({location.country})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="departureDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تاریخ حرکت</FormLabel>
                        <FormControl>
                          <DatePicker
                            value={field.value}
                            onChange={field.onChange}
                            placeholder="انتخاب تاریخ حرکت"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="arrivalDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تاریخ رسیدن</FormLabel>
                        <FormControl>
                          <DatePicker
                            value={field.value}
                            onChange={field.onChange}
                            placeholder="انتخاب تاریخ رسیدن"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <FormField
                    control={form.control}
                    name="transportType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>نوع حمل و نقل</FormLabel>
                        <Select
                          onValueChange={(value) => {
                            field.onChange(value);
                            setTransportType(value);
                          }}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="انتخاب نوع حمل و نقل" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="placeholder">انتخاب نوع حمل و نقل</SelectItem>
                            <SelectItem value="sea">
                              <div className="flex items-center">
                                <Ship className="ml-2" size={16} />
                                دریایی
                              </div>
                            </SelectItem>
                            <SelectItem value="land">
                              <div className="flex items-center">
                                <Truck className="ml-2" size={16} />
                                زمینی
                              </div>
                            </SelectItem>
                            <SelectItem value="rail">
                              <div className="flex items-center">
                                <Train className="ml-2" size={16} />
                                ریلی
                              </div>
                            </SelectItem>
                            <SelectItem value="mixed">
                              <div className="flex items-center">
                                <Layers className="ml-2" size={16} />
                                ترکیبی
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="containerType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>نوع کانتینر</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="انتخاب نوع کانتینر" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="placeholder">انتخاب نوع کانتینر</SelectItem>
                            <SelectItem value="20_standard">کانتینر ۲۰ فوت استاندارد</SelectItem>
                            <SelectItem value="40_standard">کانتینر ۴۰ فوت استاندارد</SelectItem>
                            <SelectItem value="20_refrigerated">کانتینر ۲۰ فوت یخچالی</SelectItem>
                            <SelectItem value="40_refrigerated">کانتینر ۴۰ فوت یخچالی</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="capacity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ظرفیت (تعداد کانتینر)</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" placeholder="مثال: 10" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>قیمت (تومان)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="0" 
                            placeholder="مثال: 15000000" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>قیمت اصلی برای هر کانتینر</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex flex-col space-y-4">
                    <FormField
                      control={form.control}
                      name="insuranceAvailable"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-x-reverse space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>امکان بیمه محموله</FormLabel>
                            <FormDescription>
                              محموله می‌تواند با پرداخت هزینه اضافی بیمه شود
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    {insuranceAvailable && (
                      <FormField
                        control={form.control}
                        name="insurancePrice"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>هزینه بیمه (تومان)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="0" 
                                placeholder="مثال: 2000000" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>
                </div>
                
                {transportType === "mixed" && (
                  <Alert className="mb-4">
                    <AlertTitle className="flex items-center">
                      <Layers className="ml-2" size={18} />
                      اطلاعات حمل و نقل ترکیبی
                    </AlertTitle>
                    <AlertDescription>
                      برای حمل و نقل ترکیبی، پس از ثبت اطلاعات اولیه، می‌توانید قطعات مسیر را با نوع‌های مختلف حمل و نقل (دریایی، زمینی، ریلی) تعریف کنید.
                      حداقل دو قطعه مسیر برای تکمیل فرآیند نیاز است.
                    </AlertDescription>
                  </Alert>
                )}

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>توضیحات</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="توضیحات سرویس حمل و نقل..."
                          className="min-h-32"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        توضیحات مربوط به سرویس، ویژگی‌ها و شرایط خاص
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end">
                  <Button type="submit" disabled={isSubmitting} className="w-full md:w-auto">
                    {isSubmitting ? "در حال ثبت..." : "ثبت سرویس جدید"}
                  </Button>
                </div>
                
                <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg flex items-start">
                  <Info className="text-blue-500 mt-1 ml-3 flex-shrink-0" size={18} />
                  <div className="text-sm text-blue-700">
                    <p className="font-medium mb-1">نکات مهم:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>قیمت‌ها باید به تومان وارد شوند</li>
                      <li>تاریخ حرکت باید حداقل یک روز بعد از امروز باشد</li>
                      <li>ظرفیت نشان دهنده تعداد کانتینرهایی است که می‌توانید حمل کنید</li>
                      <li>سرویس پس از تأیید مدیر سیستم قابل مشاهده برای کاربران خواهد بود</li>
                    </ul>
                  </div>
                </div>
              </form>
            </Form>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CreateShipment;