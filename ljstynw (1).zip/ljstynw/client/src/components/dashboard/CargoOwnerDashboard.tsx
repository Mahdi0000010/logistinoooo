import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import ShipmentList from "@/components/dashboard/ShipmentList";
import Profile from "@/components/dashboard/Profile";
import Documentation from "@/components/dashboard/Documentation";
import Settings from "@/components/dashboard/Settings";
import { Package, AlertTriangle, ChevronsRight, Ship, Search } from "lucide-react";

interface CargoOwnerDashboardProps {
  activeTab: string;
}

const CargoOwnerDashboard = ({ activeTab }: CargoOwnerDashboardProps) => {
  const { user } = useAuth();
  const [statusFilter, setStatusFilter] = useState<string>("all");

  // Fetch bookings
  const { data: bookings, isLoading: isLoadingBookings } = useQuery({
    queryKey: ['/api/bookings/user'],
    queryFn: async () => {
      const res = await fetch('/api/bookings/user');
      if (!res.ok) throw new Error('Failed to fetch bookings');
      return await res.json();
    },
  });

  if (activeTab === "profile") {
    return <Profile />;
  }

  if (activeTab === "documents") {
    return <Documentation />;
  }

  if (activeTab === "settings") {
    return <Settings />;
  }

  // Default view - Overview or Shipments
  return (
    <div className="space-y-6">
      {activeTab === "overview" && (
        <>
          {/* Welcome card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h2 className="text-2xl font-bold mb-2">خوش آمدید، {user?.fullName}</h2>
                  <p className="text-gray-600">به پنل کاربری خود در لجستینو خوش آمدید. از اینجا می‌توانید محموله‌های خود را مدیریت کنید.</p>
                </div>
                <Link href="/search">
                  <Button>
                    جستجو و ارسال محموله جدید
                    <ChevronsRight className="mr-2" size={16} />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Overview stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">محموله‌های در حال انتقال</p>
                    {isLoadingBookings ? (
                      <Skeleton className="h-9 w-16" />
                    ) : (
                      <h3 className="text-3xl font-bold">{bookings?.filter((b: any) => b.status === 'in_transit')?.length || 0}</h3>
                    )}
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Ship className="text-blue-600" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">محموله‌های تحویل شده</p>
                    {isLoadingBookings ? (
                      <Skeleton className="h-9 w-16" />
                    ) : (
                      <h3 className="text-3xl font-bold">{bookings?.filter((b: any) => b.status === 'delivered')?.length || 0}</h3>
                    )}
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Package className="text-green-600" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">محموله‌های در انتظار تأیید</p>
                    {isLoadingBookings ? (
                      <Skeleton className="h-9 w-16" />
                    ) : (
                      <h3 className="text-3xl font-bold">{bookings?.filter((b: any) => b.status === 'pending')?.length || 0}</h3>
                    )}
                  </div>
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <AlertTriangle className="text-yellow-600" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent bookings */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>آخرین محموله‌ها</CardTitle>
                <Button variant="outline" size="sm" onClick={() => setStatusFilter("all")}>
                  مشاهده همه
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ShipmentList 
                isLoading={isLoadingBookings} 
                bookings={bookings?.slice(0, 5) || []}
                isCargoOwner={true}
              />
            </CardContent>
          </Card>
        </>
      )}

      {activeTab === "shipments" && (
        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <CardTitle>محموله‌های من</CardTitle>
              <div className="w-full md:w-64 relative">
                <Search className="absolute right-3 top-3 text-gray-400" size={16} />
                <Input
                  type="text"
                  placeholder="جستجو در محموله‌ها..."
                  className="pr-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" className="mb-6" onValueChange={setStatusFilter}>
              <TabsList>
                <TabsTrigger value="all">همه</TabsTrigger>
                <TabsTrigger value="pending">در انتظار تأیید</TabsTrigger>
                <TabsTrigger value="confirmed">تأیید شده</TabsTrigger>
                <TabsTrigger value="in_transit">در حال انتقال</TabsTrigger>
                <TabsTrigger value="delivered">تحویل شده</TabsTrigger>
                <TabsTrigger value="cancelled">لغو شده</TabsTrigger>
              </TabsList>
            </Tabs>
            
            <ShipmentList 
              isLoading={isLoadingBookings} 
              bookings={statusFilter === "all" 
                ? bookings || [] 
                : (bookings || []).filter((booking: any) => booking.status === statusFilter)
              }
              isCargoOwner={true}
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default CargoOwnerDashboard;
