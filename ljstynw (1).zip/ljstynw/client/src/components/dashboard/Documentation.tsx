import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { FileText, Upload, CheckCircle, AlertCircle, FilePlus, PlusCircle, Calendar, X } from "lucide-react";

interface Document {
  id: number;
  userId: number;
  type: string;
  name: string;
  fileUrl: string;
  isVerified: boolean;
  createdAt: string;
}

interface DocumentationProps {
  isTransporter?: boolean;
}

const Documentation = ({ isTransporter = false }: DocumentationProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [documentType, setDocumentType] = useState("");
  const [documentName, setDocumentName] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  
  // Fetch user documents
  const { data: documents, isLoading } = useQuery({
    queryKey: ['/api/documents'],
    queryFn: async () => {
      const res = await fetch('/api/documents');
      if (!res.ok) throw new Error('Failed to fetch documents');
      return await res.json();
    },
  });
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };
  
  const handleUpload = async () => {
    if (!documentType || !documentName || !file) {
      toast({
        title: "اطلاعات ناقص",
        description: "لطفاً تمام فیلدها را پر کنید",
        variant: "destructive",
      });
      return;
    }
    
    setUploading(true);
    
    try {
      // In a real app, we would upload the file to a storage service and then save the URL
      // For now, we'll just simulate the upload
      const fileUrl = URL.createObjectURL(file);
      
      // Save document metadata
      await apiRequest("POST", "/api/documents", {
        type: documentType,
        name: documentName,
        fileUrl,
      });
      
      toast({
        title: "سند با موفقیت آپلود شد",
        description: "سند شما با موفقیت آپلود شد و در انتظار تأیید است",
      });
      
      // Reset form
      setDocumentType("");
      setDocumentName("");
      setFile(null);
      
      // Close dialog
      setShowUploadDialog(false);
      
      // Refetch documents
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
    } catch (error) {
      toast({
        title: "خطا در آپلود سند",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };
  
  // Function to get document type title
  const getDocumentTypeTitle = (type: string) => {
    switch (type) {
      case "identity":
        return "مدارک هویتی";
      case "company":
        return "اسناد شرکت";
      case "commercial":
        return "مدارک تجاری";
      case "custom":
        return "اسناد گمرکی";
      case "insurance":
        return "بیمه‌نامه";
      case "other":
        return "سایر";
      default:
        return type;
    }
  };
  
  // Group documents by type for better organization
  const groupedDocuments: { [key: string]: Document[] } = {};
  if (documents) {
    documents.forEach((doc: Document) => {
      if (!groupedDocuments[doc.type]) {
        groupedDocuments[doc.type] = [];
      }
      groupedDocuments[doc.type].push(doc);
    });
  }
  
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-10 w-32" />
        </div>
        
        {Array(3).fill(0).map((_, index) => (
          <Card key={index}>
            <CardHeader>
              <Skeleton className="h-6 w-40 mb-2" />
              <Skeleton className="h-4 w-full" />
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Array(2).fill(0).map((_, idx) => (
                <Skeleton key={idx} className="h-24 w-full" />
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">مدارک و اسناد</h2>
        <Button onClick={() => setShowUploadDialog(true)}>
          <FilePlus className="ml-2" size={18} />
          آپلود سند جدید
        </Button>
      </div>
      
      {(!documents || documents.length === 0) ? (
        <Card>
          <CardContent className="p-6 text-center py-12">
            <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p className="text-gray-500 mb-2">هیچ سندی آپلود نشده است</p>
            <p className="text-sm text-gray-500 mb-6">برای ارسال مدارک و اسناد مورد نیاز، از دکمه آپلود استفاده کنید</p>
            <Button onClick={() => setShowUploadDialog(true)}>
              <PlusCircle className="ml-2" size={16} />
              آپلود سند جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {Object.keys(groupedDocuments).map((docType) => (
            <Card key={docType}>
              <CardHeader>
                <CardTitle>{getDocumentTypeTitle(docType)}</CardTitle>
                <CardDescription>
                  تعداد اسناد: {groupedDocuments[docType].length}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {groupedDocuments[docType].map((doc: Document) => (
                    <Card key={doc.id} className="overflow-hidden">
                      <div className="relative">
                        <div className="absolute top-2 left-2 z-10">
                          {doc.isVerified ? (
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                              <CheckCircle className="ml-1" size={14} />
                              تأیید شده
                            </Badge>
                          ) : (
                            <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                              <AlertCircle className="ml-1" size={14} />
                              در انتظار تأیید
                            </Badge>
                          )}
                        </div>
                        
                        <div className="h-40 bg-gray-100 flex items-center justify-center">
                          <FileText className="h-16 w-16 text-gray-400" />
                        </div>
                      </div>
                      
                      <CardContent className="pt-4">
                        <h3 className="font-bold mb-1 truncate">{doc.name}</h3>
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar className="ml-1" size={14} />
                          <span>{new Date(doc.createdAt).toLocaleDateString('fa-IR')}</span>
                        </div>
                      </CardContent>
                      
                      <CardFooter className="pt-0">
                        <a 
                          href={doc.fileUrl} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-primary text-sm hover:underline"
                        >
                          مشاهده سند
                        </a>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* Upload Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>آپلود سند جدید</DialogTitle>
            <DialogDescription>
              لطفاً اطلاعات سند و فایل مورد نظر خود را بارگذاری کنید.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div>
              <Label htmlFor="document-type">نوع سند</Label>
              <Select value={documentType} onValueChange={setDocumentType}>
                <SelectTrigger id="document-type">
                  <SelectValue placeholder="انتخاب نوع سند" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="identity">مدارک هویتی</SelectItem>
                  <SelectItem value="company">اسناد شرکت</SelectItem>
                  <SelectItem value="commercial">مدارک تجاری</SelectItem>
                  <SelectItem value="custom">اسناد گمرکی</SelectItem>
                  <SelectItem value="insurance">بیمه‌نامه</SelectItem>
                  <SelectItem value="other">سایر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="document-name">نام سند</Label>
              <Input
                id="document-name"
                value={documentName}
                onChange={(e) => setDocumentName(e.target.value)}
                placeholder="مثال: کارت ملی / گواهینامه / پروانه کسب"
              />
            </div>
            
            <div>
              <Label htmlFor="document-file">فایل</Label>
              <div className="mt-1">
                <div className="border border-dashed border-gray-300 rounded-md px-6 pt-5 pb-6 flex justify-center">
                  <div className="space-y-1 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label
                        htmlFor="document-file"
                        className="relative cursor-pointer rounded-md bg-white font-medium text-primary hover:text-primary/80 focus-within:outline-none focus-within:ring-2 focus-within:ring-primary focus-within:ring-offset-2"
                      >
                        <span>انتخاب فایل</span>
                        <input
                          id="document-file"
                          name="document-file"
                          type="file"
                          className="sr-only"
                          onChange={handleFileChange}
                        />
                      </label>
                      <p className="pr-1">یا فایل را به این محدوده بکشید</p>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG, PDF تا 10MB</p>
                  </div>
                </div>
                
                {file && (
                  <div className="mt-2 flex items-center justify-between bg-gray-50 p-2 rounded">
                    <div className="flex items-center">
                      <FileText className="ml-2 text-gray-500" size={16} />
                      <span className="text-sm text-gray-700 truncate max-w-[200px]">
                        {file.name}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setFile(null)}
                      className="h-6 w-6 p-0 rounded-full"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
              انصراف
            </Button>
            <Button onClick={handleUpload} disabled={uploading}>
              {uploading ? "در حال آپلود..." : "آپلود سند"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Documentation;