import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, Mail, Phone, Building, Lock, FilePen, Shield } from "lucide-react";

// Profile form schema
const profileSchema = z.object({
  fullName: z.string().min(3, "نام و نام خانوادگی باید حداقل 3 کاراکتر باشد"),
  email: z.string().email("ایمیل نامعتبر است"),
  phone: z.string().min(10, "شماره تلفن باید حداقل 10 رقم باشد"),
  company: z.string().optional(),
});

// Password change schema
const passwordSchema = z.object({
  currentPassword: z.string().min(1, "وارد کردن رمز عبور فعلی الزامی است"),
  newPassword: z.string().min(6, "رمز عبور جدید باید حداقل 6 کاراکتر باشد"),
  confirmPassword: z.string().min(1, "تکرار رمز عبور جدید الزامی است"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "رمز عبور جدید و تکرار آن یکسان نیستند",
  path: ["confirmPassword"],
});

type ProfileFormValues = z.infer<typeof profileSchema>;
type PasswordFormValues = z.infer<typeof passwordSchema>;

interface ProfileProps {
  isTransporter?: boolean;
}

const Profile = ({ isTransporter = false }: ProfileProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isUpdating, setIsUpdating] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phone: user?.phone || "",
      company: isTransporter ? user?.company || "" : undefined,
    },
  });
  
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });
  
  const onProfileSubmit = async (data: ProfileFormValues) => {
    setIsUpdating(true);
    try {
      // In a real app, this would be an API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "اطلاعات پروفایل با موفقیت به‌روزرسانی شد",
        description: "تغییرات در پروفایل کاربری شما اعمال شد",
      });
    } catch (error) {
      toast({
        title: "خطا در به‌روزرسانی پروفایل",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };
  
  const onPasswordSubmit = async (data: PasswordFormValues) => {
    setIsChangingPassword(true);
    try {
      // In a real app, this would be an API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "رمز عبور با موفقیت تغییر کرد",
        description: "رمز عبور جدید شما با موفقیت ثبت شد",
      });
      
      passwordForm.reset();
    } catch (error) {
      toast({
        title: "خطا در تغییر رمز عبور",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    } finally {
      setIsChangingPassword(false);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Card */}
        <Card className="md:col-span-1">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center">
              <Avatar className="h-24 w-24 mb-4">
                <AvatarFallback className="text-lg bg-primary/10 text-primary">
                  {user?.fullName ? user.fullName.substring(0, 2) : "کا"}
                </AvatarFallback>
              </Avatar>
              <h2 className="text-xl font-bold mb-1">{user?.fullName}</h2>
              <p className="text-gray-500 mb-4">
                {isTransporter ? "شرکت حمل و نقل" : "صاحب کالا"}
              </p>
              
              <div className="w-full space-y-3 text-right">
                <div className="flex items-center">
                  <Mail className="ml-2 text-gray-400" size={18} />
                  <span className="text-gray-700">{user?.email}</span>
                </div>
                <div className="flex items-center">
                  <Phone className="ml-2 text-gray-400" size={18} />
                  <span className="text-gray-700">{user?.phone || "تنظیم نشده"}</span>
                </div>
                {isTransporter && (
                  <div className="flex items-center">
                    <Building className="ml-2 text-gray-400" size={18} />
                    <span className="text-gray-700">{user?.company || "تنظیم نشده"}</span>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Settings */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>تنظیمات پروفایل</CardTitle>
            <CardDescription>اطلاعات پروفایل خود را ویرایش کنید</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="profile">
              <TabsList className="mb-6">
                <TabsTrigger value="profile" className="flex items-center">
                  <FilePen className="ml-2" size={16} />
                  اطلاعات شخصی
                </TabsTrigger>
                <TabsTrigger value="security" className="flex items-center">
                  <Shield className="ml-2" size={16} />
                  امنیت و رمز عبور
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="profile">
                <Form {...profileForm}>
                  <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-6">
                    <FormField
                      control={profileForm.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>نام و نام خانوادگی</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <User className="absolute right-3 top-3 text-gray-400" size={16} />
                              <Input className="pr-10" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={profileForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ایمیل</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Mail className="absolute right-3 top-3 text-gray-400" size={16} />
                                <Input className="pr-10" dir="ltr" {...field} />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={profileForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>شماره تماس</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Phone className="absolute right-3 top-3 text-gray-400" size={16} />
                                <Input className="pr-10" {...field} />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    {isTransporter && (
                      <FormField
                        control={profileForm.control}
                        name="company"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نام شرکت</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Building className="absolute right-3 top-3 text-gray-400" size={16} />
                                <Input className="pr-10" {...field} />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                    
                    <div className="flex justify-end">
                      <Button type="submit" disabled={isUpdating}>
                        {isUpdating ? "در حال ذخیره..." : "ذخیره تغییرات"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </TabsContent>
              
              <TabsContent value="security">
                <Form {...passwordForm}>
                  <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-6">
                    <FormField
                      control={passwordForm.control}
                      name="currentPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>رمز عبور فعلی</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Lock className="absolute right-3 top-3 text-gray-400" size={16} />
                              <Input type="password" className="pr-10" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={passwordForm.control}
                        name="newPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>رمز عبور جدید</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Lock className="absolute right-3 top-3 text-gray-400" size={16} />
                                <Input type="password" className="pr-10" {...field} />
                              </div>
                            </FormControl>
                            <FormDescription>
                              رمز عبور باید حداقل 6 کاراکتر باشد
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={passwordForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>تکرار رمز عبور جدید</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Lock className="absolute right-3 top-3 text-gray-400" size={16} />
                                <Input type="password" className="pr-10" {...field} />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex justify-end">
                      <Button type="submit" disabled={isChangingPassword}>
                        {isChangingPassword ? "در حال تغییر..." : "تغییر رمز عبور"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Profile;