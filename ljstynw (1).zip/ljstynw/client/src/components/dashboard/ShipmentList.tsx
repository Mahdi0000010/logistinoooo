import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Package, Navigation, Calendar, CircleDollarSign, Info, ShieldCheck, FileText } from "lucide-react";

interface Booking {
  id: number;
  status: "pending" | "confirmed" | "in_transit" | "delivered" | "cancelled";
  shipmentId: number;
  shipment: {
    origin: { name: string };
    destination: { name: string };
    departureDate: string;
    arrivalDate: string;
    transporterName: string;
    containerType: string;
  };
  cargoType: string;
  cargoWeight: number;
  quantity: number;
  withInsurance: boolean;
  totalPrice: number;
  createdAt: string;
}

interface ShipmentListProps {
  isLoading: boolean;
  bookings: Booking[];
  isCargoOwner: boolean;
}

const ShipmentList = ({ isLoading, bookings, isCargoOwner }: ShipmentListProps) => {
  const { toast } = useToast();
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [processingStatus, setProcessingStatus] = useState(false);

  // Function to format price in Persian
  const formatPrice = (price: number) => {
    return price.toLocaleString("fa-IR");
  };

  // Function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">در انتظار تأیید</span>;
      case "confirmed":
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">تأیید شده</span>;
      case "in_transit":
        return <span className="px-2 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-medium">در حال ارسال</span>;
      case "delivered":
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">تحویل داده شده</span>;
      case "cancelled":
        return <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">لغو شده</span>;
      default:
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-medium">نامشخص</span>;
    }
  };

  // Function to get container type name
  const getContainerTypeName = (type: string) => {
    switch (type) {
      case "20_standard":
        return "کانتینر ۲۰ فوت";
      case "40_standard":
        return "کانتینر ۴۰ فوت";
      case "20_refrigerated":
        return "کانتینر ۲۰ فوت یخچالی";
      case "40_refrigerated":
        return "کانتینر ۴۰ فوت یخچالی";
      default:
        return type;
    }
  };

  // Handle status change
  const handleStatusChange = async (newStatus: string) => {
    if (!selectedBooking) return;
    
    setProcessingStatus(true);
    try {
      // In a real app, this would be an API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "وضعیت با موفقیت تغییر کرد",
        description: `وضعیت محموله به "${
          newStatus === "confirmed" ? "تأیید شده" :
          newStatus === "in_transit" ? "در حال ارسال" :
          newStatus === "delivered" ? "تحویل داده شده" :
          newStatus === "cancelled" ? "لغو شده" : newStatus
        }" تغییر یافت.`
      });
      
      setStatusDialogOpen(false);
    } catch (error) {
      toast({
        title: "خطا در تغییر وضعیت",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive"
      });
    } finally {
      setProcessingStatus(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array(3).fill(0).map((_, index) => (
          <div key={index} className="border rounded-lg p-4">
            <div className="flex justify-between mb-4">
              <Skeleton className="h-6 w-64" />
              <Skeleton className="h-6 w-24" />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Skeleton className="h-10" />
              <Skeleton className="h-10" />
              <Skeleton className="h-10" />
              <Skeleton className="h-10" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!bookings || bookings.length === 0) {
    return (
      <div className="text-center py-10 text-gray-500">
        <Package className="h-12 w-12 mx-auto mb-4 text-gray-300" />
        <p className="mb-2">هیچ محموله‌ای یافت نشد</p>
        <p className="text-sm">محموله‌های شما در این قسمت نمایش داده خواهند شد</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {bookings.map((booking) => (
        <div key={booking.id} className="border rounded-lg p-4 hover:bg-gray-50">
          <div className="flex flex-col md:flex-row justify-between mb-4">
            <div>
              <h3 className="font-medium text-lg">{booking.shipment.origin.name} به {booking.shipment.destination.name}</h3>
              <div className="text-sm text-gray-500 mt-1">
                <div className="flex items-center flex-wrap gap-x-4 gap-y-1 mt-1">
                  <span className="flex items-center">
                    <Calendar className="ml-1" size={14} />
                    تاریخ حرکت: {booking.shipment.departureDate}
                  </span>
                  <span className="flex items-center">
                    <Package className="ml-1" size={14} />
                    {getContainerTypeName(booking.shipment.containerType)} &times; {booking.quantity}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center mt-2 md:mt-0">
              {getStatusBadge(booking.status)}
              <div className="mr-3 text-lg font-bold text-primary">{formatPrice(booking.totalPrice)} تومان</div>
            </div>
          </div>
          
          <div className="flex justify-end gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => {
                setSelectedBooking(booking);
                setDetailsOpen(true);
              }}
            >
              <Info className="ml-1" size={16} />
              جزئیات
            </Button>
            
            {!isCargoOwner && booking.status !== "delivered" && booking.status !== "cancelled" && (
              <Button 
                size="sm" 
                onClick={() => {
                  setSelectedBooking(booking);
                  setStatusDialogOpen(true);
                }}
              >
                تغییر وضعیت
              </Button>
            )}
          </div>
        </div>
      ))}

      {/* Booking Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>جزئیات محموله</DialogTitle>
            <DialogDescription>
              اطلاعات کامل محموله و وضعیت فعلی آن
            </DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-3 flex items-center">
                  <Navigation className="ml-2 text-primary" size={18} />
                  اطلاعات مسیر
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">مبدا:</span>
                    <span className="font-medium">{selectedBooking.shipment.origin.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">مقصد:</span>
                    <span className="font-medium">{selectedBooking.shipment.destination.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">تاریخ حرکت:</span>
                    <span className="font-medium">{selectedBooking.shipment.departureDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">تاریخ رسیدن:</span>
                    <span className="font-medium">{selectedBooking.shipment.arrivalDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">شرکت حمل و نقل:</span>
                    <span className="font-medium">{selectedBooking.shipment.transporterName}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3 flex items-center">
                  <Package className="ml-2 text-primary" size={18} />
                  اطلاعات محموله
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">نوع کالا:</span>
                    <span className="font-medium">{selectedBooking.cargoType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">وزن کالا:</span>
                    <span className="font-medium">{selectedBooking.cargoWeight} کیلوگرم</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">نوع کانتینر:</span>
                    <span className="font-medium">{getContainerTypeName(selectedBooking.shipment.containerType)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">تعداد کانتینر:</span>
                    <span className="font-medium">{selectedBooking.quantity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">بیمه محموله:</span>
                    <span className="font-medium flex items-center">
                      {selectedBooking.withInsurance ? (
                        <>
                          <ShieldCheck className="ml-1 text-green-500" size={14} />
                          دارد
                        </>
                      ) : "ندارد"}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="md:col-span-2">
                <h4 className="font-medium mb-3 flex items-center">
                  <CircleDollarSign className="ml-2 text-primary" size={18} />
                  اطلاعات مالی
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">قیمت کل:</span>
                    <span className="font-medium">{formatPrice(selectedBooking.totalPrice)} تومان</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">وضعیت سفارش:</span>
                    <span>{getStatusBadge(selectedBooking.status)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">تاریخ ثبت سفارش:</span>
                    <span className="font-medium">{new Date(selectedBooking.createdAt).toLocaleDateString('fa-IR')}</span>
                  </div>
                </div>
              </div>
              
              <div className="md:col-span-2 flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <FileText className="ml-2 text-gray-500" size={18} />
                  <span className="text-gray-700">برای مشاهده اسناد و مدارک این محموله از منوی "مدارک" استفاده کنید</span>
                </div>
                <Button variant="outline" size="sm">
                  مدارک
                </Button>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailsOpen(false)}>بستن</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Status Change Dialog */}
      {!isCargoOwner && (
        <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>تغییر وضعیت محموله</DialogTitle>
              <DialogDescription>
                وضعیت جدید محموله را انتخاب کنید
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-3 my-4">
              {selectedBooking?.status !== "confirmed" && selectedBooking?.status === "pending" && (
                <Button className="w-full justify-start" onClick={() => handleStatusChange("confirmed")} disabled={processingStatus}>
                  <span className="h-2 w-2 rounded-full bg-blue-500 ml-2"></span>
                  تأیید سفارش
                </Button>
              )}
              
              {selectedBooking?.status !== "in_transit" && (selectedBooking?.status === "confirmed" || selectedBooking?.status === "pending") && (
                <Button className="w-full justify-start" onClick={() => handleStatusChange("in_transit")} disabled={processingStatus}>
                  <span className="h-2 w-2 rounded-full bg-amber-500 ml-2"></span>
                  شروع ارسال
                </Button>
              )}
              
              {selectedBooking?.status !== "delivered" && selectedBooking?.status === "in_transit" && (
                <Button className="w-full justify-start" onClick={() => handleStatusChange("delivered")} disabled={processingStatus}>
                  <span className="h-2 w-2 rounded-full bg-green-500 ml-2"></span>
                  تحویل داده شده
                </Button>
              )}
              
              {selectedBooking?.status !== "cancelled" && selectedBooking?.status !== "delivered" && (
                <Button className="w-full justify-start" variant="destructive" onClick={() => handleStatusChange("cancelled")} disabled={processingStatus}>
                  <span className="h-2 w-2 rounded-full bg-red-500 ml-2"></span>
                  لغو سفارش
                </Button>
              )}
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setStatusDialogOpen(false)} disabled={processingStatus}>انصراف</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default ShipmentList;
