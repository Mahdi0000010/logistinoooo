import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import ShipmentList from "./ShipmentList";
import CreateShipment from "./CreateShipment";
import EditShipment from "../dashboard/EditShipment";
import Profile from "./Profile";
import Documentation from "./Documentation";
import Settings from "./Settings";
import { Package, ChevronsRight, Users, BarChart, Search, Truck } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface TransporterDashboardProps {
  activeTab: string;
}

const TransporterDashboard = ({ activeTab }: TransporterDashboardProps) => {
  const { user } = useAuth();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedShipmentId, setSelectedShipmentId] = useState<number | null>(null);
  const { toast } = useToast();

  // Get shipment ID from URL if present
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shipmentId = params.get("shipmentId");
    if (shipmentId) {
      setSelectedShipmentId(parseInt(shipmentId));
    }
  }, []);

  // Handle toggling shipment active status
  const handleToggleShipmentStatus = async (shipmentId: number, active: boolean) => {
    try {
      await apiRequest("PUT", `/api/shipments/${shipmentId}/status`, { active });
      
      // Show success message
      toast({
        title: active ? "سرویس فعال شد" : "سرویس غیرفعال شد",
        description: active 
          ? "سرویس حمل و نقل با موفقیت فعال شد و در جستجوها نمایش داده خواهد شد." 
          : "سرویس حمل و نقل با موفقیت غیرفعال شد و دیگر در جستجوها نمایش داده نخواهد شد.",
        variant: "default",
      });
      
      // Refresh shipments data
      queryClient.invalidateQueries({ queryKey: ['/api/shipments/own'] });
    } catch (error) {
      toast({
        title: "خطا در تغییر وضعیت سرویس",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    }
  };

  // Fetch transporter data
  const { data: transporter, isLoading: isLoadingTransporter } = useQuery({
    queryKey: ['/api/transporters/me'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/transporters/me');
        if (!res.ok) return null;
        return await res.json();
      } catch (error) {
        console.error("Error fetching transporter data:", error);
        return null;
      }
    },
  });

  // Fetch shipments
  const { data: shipments, isLoading: isLoadingShipments } = useQuery({
    queryKey: ['/api/shipments/own'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/shipments/own');
        if (!res.ok) return [];
        return await res.json();
      } catch (error) {
        console.error("Error fetching shipments:", error);
        return [];
      }
    },
  });

  // Fetch bookings
  const { data: bookings, isLoading: isLoadingBookings } = useQuery({
    queryKey: ['/api/bookings/transporter'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/bookings/transporter');
        if (!res.ok) return [];
        return await res.json();
      } catch (error) {
        console.error("Error fetching bookings:", error);
        return [];
      }
    },
  });

  if (activeTab === "profile") {
    return <Profile isTransporter />;
  }

  if (activeTab === "documents") {
    return <Documentation isTransporter />;
  }

  if (activeTab === "create") {
    return <CreateShipment />;
  }

  if (activeTab === "settings") {
    return <Settings isTransporter />;
  }
  
  // Handle edit tab
  if (activeTab === "edit") {
    const shipmentIdFromUrl = new URLSearchParams(window.location.search).get("shipmentId");
    console.log("Edit tab with shipmentId =", shipmentIdFromUrl);
    return <EditShipment />;
  }

  // Default view - Overview or Shipments or Bookings
  return (
    <div className="space-y-6">
      {activeTab === "overview" && (
        <>
          {/* Welcome card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h2 className="text-2xl font-bold mb-2">خوش آمدید، {transporter?.companyName || user?.fullName}</h2>
                  <p className="text-gray-600">به پنل مدیریت خدمات حمل و نقل خود در لجستینو خوش آمدید.</p>
                </div>
                <div className="flex gap-2">
                  <Link to="/dashboard?tab=create">
                    <Button>
                      ثبت سرویس جدید
                      <ChevronsRight className="mr-2" size={16} />
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Overview stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">سرویس‌های فعال</p>
                    {isLoadingShipments ? (
                      <Skeleton className="h-9 w-16" />
                    ) : (
                      <h3 className="text-3xl font-bold">{shipments?.filter((s: any) => s.active)?.length || 0}</h3>
                    )}
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Truck className="text-blue-600" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">رزروهای دریافتی</p>
                    {isLoadingBookings ? (
                      <Skeleton className="h-9 w-16" />
                    ) : (
                      <h3 className="text-3xl font-bold">{bookings?.length || 0}</h3>
                    )}
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Users className="text-green-600" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">محموله‌های در انتقال</p>
                    {isLoadingBookings ? (
                      <Skeleton className="h-9 w-16" />
                    ) : (
                      <h3 className="text-3xl font-bold">{bookings?.filter((b: any) => b.status === 'in_transit')?.length || 0}</h3>
                    )}
                  </div>
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Package className="text-orange-600" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent statistics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>سرویس‌های اخیر</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingShipments ? (
                  <div className="space-y-2">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                ) : shipments?.length > 0 ? (
                  <div className="space-y-2">
                    {shipments.slice(0, 5).map((shipment: any) => (
                      <div key={shipment.id} className="flex justify-between items-center p-3 border rounded-lg hover:bg-gray-50">
                        <div>
                          <div className="font-medium">{shipment.origin?.name} به {shipment.destination?.name}</div>
                          <div className="text-sm text-gray-500">تاریخ حرکت: {shipment.departureDate}</div>
                        </div>
                        <Badge variant={shipment.active ? "success" : "secondary"}>
                          {shipment.active ? "فعال" : "غیرفعال"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    هنوز سرویسی ثبت نکرده‌اید
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>آمار بازدید سرویس‌ها</CardTitle>
                <CardDescription>نمودار بازدید سرویس‌های شما در ۳۰ روز گذشته</CardDescription>
              </CardHeader>
              <CardContent className="h-60 flex items-center justify-center">
                <div className="flex items-center justify-center h-full w-full bg-gray-50 rounded-lg border border-dashed">
                  <div className="text-center">
                    <BarChart className="mx-auto h-10 w-10 text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">اطلاعات آماری در حال جمع‌آوری است</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {activeTab === "shipments" && (
        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <CardTitle>سرویس‌های ارائه شده</CardTitle>
              <div className="flex gap-4 w-full md:w-auto">
                <div className="relative flex-grow md:w-64">
                  <Search className="absolute right-3 top-3 text-gray-400" size={16} />
                  <Input
                    type="text"
                    placeholder="جستجو در سرویس‌ها..."
                    className="pr-10"
                  />
                </div>
                <Link to="/dashboard?tab=create">
                  <Button>ثبت سرویس جدید</Button>
                </Link>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="active" className="mb-6">
              <TabsList>
                <TabsTrigger value="active">فعال</TabsTrigger>
                <TabsTrigger value="inactive">غیرفعال</TabsTrigger>
                <TabsTrigger value="all">همه</TabsTrigger>
              </TabsList>
            </Tabs>
            
            {isLoadingShipments ? (
              <div className="space-y-2">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
              </div>
            ) : shipments?.length > 0 ? (
              <div className="space-y-4">
                {shipments.map((shipment: any) => (
                  <div key={shipment.id} className="border rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex flex-col md:flex-row justify-between mb-4">
                      <div>
                        <h3 className="font-medium text-lg">{shipment.origin?.name} به {shipment.destination?.name}</h3>
                        <div className="text-sm text-gray-500 mt-1">تاریخ حرکت: {shipment.departureDate} | تاریخ رسیدن: {shipment.arrivalDate}</div>
                      </div>
                      <div className="flex items-center mt-2 md:mt-0">
                        <Badge className="ml-2" variant={shipment.active ? "default" : "secondary"}>
                          {shipment.active ? "فعال" : "غیرفعال"}
                        </Badge>
                        <div className="text-lg font-bold text-primary">{shipment.price.toLocaleString("fa-IR")} تومان</div>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2">
                      <Link to={`/dashboard?tab=edit&shipmentId=${shipment.id}`}>
                        <Button variant="outline" size="sm">ویرایش</Button>
                      </Link>
                      <Button 
                        variant={shipment.active ? "destructive" : "default"} 
                        size="sm"
                        onClick={() => handleToggleShipmentStatus(shipment.id, !shipment.active)}
                      >
                        {shipment.active ? "غیرفعال کردن" : "فعال کردن"}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-gray-500">
                هنوز سرویسی ثبت نکرده‌اید
                <div className="mt-4">
                  <Link to="/dashboard?tab=create">
                    <Button>ثبت سرویس جدید</Button>
                  </Link>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {activeTab === "bookings" && (
        <Card>
          <CardHeader>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <CardTitle>رزروهای دریافتی</CardTitle>
              <div className="w-full md:w-64 relative">
                <Search className="absolute right-3 top-3 text-gray-400" size={16} />
                <Input
                  type="text"
                  placeholder="جستجو در رزروها..."
                  className="pr-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" className="mb-6" onValueChange={setStatusFilter}>
              <TabsList>
                <TabsTrigger value="all">همه</TabsTrigger>
                <TabsTrigger value="pending">در انتظار تأیید</TabsTrigger>
                <TabsTrigger value="confirmed">تأیید شده</TabsTrigger>
                <TabsTrigger value="in_transit">در حال انتقال</TabsTrigger>
                <TabsTrigger value="delivered">تحویل شده</TabsTrigger>
                <TabsTrigger value="cancelled">لغو شده</TabsTrigger>
              </TabsList>
            </Tabs>
            
            <ShipmentList 
              isLoading={isLoadingBookings} 
              bookings={statusFilter === "all" 
                ? bookings || [] 
                : (bookings || []).filter((booking: any) => booking.status === statusFilter)
              }
              isCargoOwner={false}
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
};



export default TransporterDashboard;
