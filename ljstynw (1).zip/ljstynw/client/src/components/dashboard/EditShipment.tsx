import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link, useLocation } from "wouter";
import DatePicker from "@/components/shared/DatePicker";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Ship, Truck, Train, Info, ArrowLeft, Layers } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import ShipmentSegments from "./ShipmentSegments";

// Shipment form schema
const shipmentSchema = z.object({
  originId: z.string().min(1, "انتخاب مبدا الزامی است"),
  destinationId: z.string().min(1, "انتخاب مقصد الزامی است"),
  departureDate: z.string().min(1, "انتخاب تاریخ حرکت الزامی است"),
  arrivalDate: z.string().min(1, "انتخاب تاریخ رسیدن الزامی است"),
  transportType: z.string().min(1, "انتخاب نوع حمل و نقل الزامی است"),
  containerType: z.string().min(1, "انتخاب نوع کانتینر الزامی است"),
  capacity: z.string().min(1, "وارد کردن ظرفیت الزامی است"),
  price: z.string().min(1, "وارد کردن قیمت الزامی است"),

  description: z.string().min(10, "توضیحات باید حداقل 10 کاراکتر باشد"),
  insuranceAvailable: z.boolean().optional().default(false),
  insurancePrice: z.string().optional(),
  active: z.boolean().optional().default(true),
});

type ShipmentFormValues = z.infer<typeof shipmentSchema>;

// No props, getting shipmentId directly from URL
const EditShipment = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Extract shipment ID directly from URL query
  const params = new URLSearchParams(window.location.search);
  const shipmentIdParam = params.get("shipmentId");
  const currentShipmentId = shipmentIdParam && shipmentIdParam !== "null" ? shipmentIdParam : "";
  
  console.log("EditShipment: currentShipmentId =", currentShipmentId);
  
  // Fetch all shipments to select from if no shipmentId is provided
  const { data: ownShipments, isLoading: isLoadingOwnShipments } = useQuery({
    queryKey: ['/api/shipments/own'],
    queryFn: async () => {
      const res = await fetch('/api/shipments/own');
      if (!res.ok) return [];
      return await res.json();
    },
  });
  
  // Fetch locations
  const { data: locations, isLoading: isLoadingLocations } = useQuery({
    queryKey: ['/api/locations'],
    queryFn: async () => {
      const res = await fetch('/api/locations');
      return await res.json();
    },
  });
  
  // Fetch the shipment data
  const { data: shipment, isLoading: isLoadingShipment } = useQuery({
    queryKey: ['/api/shipments', currentShipmentId],
    queryFn: async () => {
      if (!currentShipmentId) return null;
      const res = await fetch(`/api/shipments/${currentShipmentId}`);
      if (!res.ok) {
        throw new Error("Failed to fetch shipment");
      }
      return await res.json();
    },
    retry: false,
    enabled: !!currentShipmentId,
  });
  
  const form = useForm<ShipmentFormValues>({
    resolver: zodResolver(shipmentSchema),
    defaultValues: {
      originId: "",
      destinationId: "",
      departureDate: "",
      arrivalDate: "",
      transportType: "",
      containerType: "",
      capacity: "",
      price: "",

      description: "",
      insuranceAvailable: false,
      insurancePrice: "",
      active: true,
    },
  });
  
  // Update form values when shipment data is loaded
  useEffect(() => {
    if (shipment) {
      form.reset({
        originId: shipment.originId.toString(),
        destinationId: shipment.destinationId.toString(),
        departureDate: shipment.departureDate,
        arrivalDate: shipment.arrivalDate,
        transportType: shipment.transportType,
        containerType: shipment.containerType,
        capacity: shipment.capacity.toString(),
        price: shipment.price.toString(),

        description: shipment.description,
        insuranceAvailable: shipment.insuranceAvailable,
        insurancePrice: shipment.insurancePrice ? shipment.insurancePrice.toString() : "",
        active: shipment.active,
      });
    }
  }, [shipment, form]);
  
  const insuranceAvailable = form.watch("insuranceAvailable");
  const transportType = form.watch("transportType");
  
  const onSubmit = async (data: ShipmentFormValues) => {
    setIsSubmitting(true);
    try {
      // Convert string values to appropriate types
      const shipmentData = {
        originId: parseInt(data.originId),
        destinationId: parseInt(data.destinationId),
        departureDate: data.departureDate,
        arrivalDate: data.arrivalDate,
        transportType: data.transportType,
        containerType: data.containerType,
        capacity: parseInt(data.capacity),
        price: parseInt(data.price),

        description: data.description,
        insuranceAvailable: data.insuranceAvailable,
        insurancePrice: data.insuranceAvailable ? parseInt(data.insurancePrice || "0") : 0,
        active: data.active
      };
      
      await apiRequest("PUT", `/api/shipments/${currentShipmentId}`, shipmentData);
      
      toast({
        title: "سرویس با موفقیت ویرایش شد",
        description: "تغییرات سرویس حمل و نقل با موفقیت ذخیره شد",
      });
      
      // Invalidate shipments query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/shipments/own'] });
      
      // Redirect back to edit list
      setLocation("/dashboard?tab=edit");
    } catch (error) {
      toast({
        title: "خطا در ویرایش سرویس",
        description: "متأسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const getTransportTypeIcon = (type: string) => {
    switch (type) {
      case "sea":
        return <Ship size={20} className="ml-2" />;
      case "land":
        return <Truck size={20} className="ml-2" />;
      case "rail":
        return <Train size={20} className="ml-2" />;
      case "mixed":
        return <Layers size={20} className="ml-2" />;
      default:
        return null;
    }
  };
  
  if (isLoadingShipment) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>ویرایش سرویس حمل و نقل</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Show shipment selection UI if no shipment is selected
  if (!currentShipmentId && !isLoadingShipment) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>انتخاب سرویس برای ویرایش</CardTitle>
            <p className="text-gray-500 text-sm">لطفاً یکی از سرویس‌های خود را برای ویرایش انتخاب کنید.</p>
          </CardHeader>
          <CardContent>
            {isLoadingOwnShipments ? (
              <div className="space-y-4">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
              </div>
            ) : ownShipments && ownShipments.length > 0 ? (
              <div className="space-y-4">
                {ownShipments.map((item: any) => {
                  // Find origin and destination names
                  const origin = locations?.find((loc: any) => loc.id === item.originId)?.name || "نامشخص";
                  const destination = locations?.find((loc: any) => loc.id === item.destinationId)?.name || "نامشخص";
                  
                  return (
                    <div 
                      key={item.id} 
                      className="border rounded-lg p-4 hover:border-primary hover:bg-primary/5 cursor-pointer transition-all"
                      onClick={() => setLocation(`/dashboard?tab=edit&shipmentId=${item.id}`)}
                    >
                      <div className="flex justify-between mb-2">
                        <div className="flex items-center">
                          {getTransportTypeIcon(item.transportType)}
                          <span className="font-medium">{origin} به {destination}</span>
                        </div>
                        <div className={`px-2 py-1 rounded-full text-xs ${item.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                          {item.active ? 'فعال' : 'غیرفعال'}
                        </div>
                      </div>
                      <div className="flex justify-between text-sm text-gray-500">
                        <div>تاریخ حرکت: {item.departureDate}</div>
                        <div className="font-bold text-primary">{item.price.toLocaleString("fa-IR")} تومان</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-10">
                <div className="text-gray-500 mb-4">شما هنوز هیچ سرویس حمل و نقلی ایجاد نکرده‌اید.</div>
                <Link to="/dashboard?tab=create">
                  <Button>
                    ایجاد سرویس جدید
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // If a shipment ID was provided but the shipment wasn't found
  if (!shipment && !isLoadingShipment && currentShipmentId) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>سرویس یافت نشد</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-6">
              <div className="text-gray-500 mb-4">سرویس مورد نظر یافت نشد یا شما دسترسی به ویرایش آن ندارید.</div>
              <Link to="/dashboard?tab=edit">
                <Button variant="outline">
                  <ArrowLeft className="ml-2" size={16} />
                  بازگشت به لیست سرویس‌ها
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex md:flex-row justify-between items-center">
          <CardTitle>ویرایش سرویس حمل و نقل</CardTitle>
          <Link to="/dashboard?tab=edit">
            <Button variant="outline" size="sm">
              <ArrowLeft className="ml-2" size={16} />
              بازگشت به لیست سرویس‌ها
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="originId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>مبدا</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب مبدا" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="placeholder" disabled>انتخاب مبدا</SelectItem>
                          {locations?.map((location: any) => (
                            <SelectItem key={location.id} value={location.id.toString()}>
                              {location.name} ({location.country})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="destinationId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>مقصد</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب مقصد" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="placeholder" disabled>انتخاب مقصد</SelectItem>
                          {locations?.map((location: any) => (
                            <SelectItem key={location.id} value={location.id.toString()}>
                              {location.name} ({location.country})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="departureDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تاریخ حرکت</FormLabel>
                      <FormControl>
                        <DatePicker
                          value={field.value}
                          onChange={field.onChange}
                          placeholder="انتخاب تاریخ حرکت"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="arrivalDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تاریخ رسیدن</FormLabel>
                      <FormControl>
                        <DatePicker
                          value={field.value}
                          onChange={field.onChange}
                          placeholder="انتخاب تاریخ رسیدن"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="transportType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع حمل و نقل</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب نوع حمل و نقل" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="placeholder" disabled>انتخاب نوع حمل و نقل</SelectItem>
                          <SelectItem value="sea">
                            <div className="flex items-center">
                              <Ship className="ml-2" size={16} />
                              دریایی
                            </div>
                          </SelectItem>
                          <SelectItem value="land">
                            <div className="flex items-center">
                              <Truck className="ml-2" size={16} />
                              زمینی
                            </div>
                          </SelectItem>
                          <SelectItem value="rail">
                            <div className="flex items-center">
                              <Train className="ml-2" size={16} />
                              ریلی
                            </div>
                          </SelectItem>
                          <SelectItem value="mixed">
                            <div className="flex items-center">
                              ترکیبی
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="containerType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع کانتینر</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="انتخاب نوع کانتینر" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="placeholder" disabled>انتخاب نوع کانتینر</SelectItem>
                          <SelectItem value="20_standard">کانتینر ۲۰ فوت استاندارد</SelectItem>
                          <SelectItem value="40_standard">کانتینر ۴۰ فوت استاندارد</SelectItem>
                          <SelectItem value="20_refrigerated">کانتینر ۲۰ فوت یخچالی</SelectItem>
                          <SelectItem value="40_refrigerated">کانتینر ۴۰ فوت یخچالی</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="capacity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ظرفیت (تعداد کانتینر)</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" placeholder="مثال: 10" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>قیمت (تومان)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="0" 
                          placeholder="مثال: 15000000" 
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>قیمت اصلی برای هر کانتینر</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />


              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col space-y-4">
                  <FormField
                    control={form.control}
                    name="insuranceAvailable"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-x-reverse space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>امکان بیمه محموله</FormLabel>
                          <FormDescription>
                            محموله می‌تواند با پرداخت هزینه اضافی بیمه شود
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  {insuranceAvailable && (
                    <FormField
                      control={form.control}
                      name="insurancePrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>قیمت بیمه (تومان)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="0" 
                              placeholder="مثال: 2000000" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>قیمت بیمه برای هر کانتینر</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                </div>
              </div>
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>توضیحات</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="توضیحات سرویس حمل و نقل..."
                        className="min-h-32"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      توضیحات مربوط به سرویس، ویژگی‌ها و شرایط خاص
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="active"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-x-reverse space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>فعال</FormLabel>
                      <FormDescription>
                        سرویس‌های فعال در نتایج جستجو نمایش داده می‌شوند
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              {transportType === "mixed" && currentShipmentId && (
                <>
                  <Separator className="my-6" />
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-2">تعریف قطعات مسیر حمل و نقل ترکیبی</h3>
                    <Alert className="mb-4">
                      <AlertTitle className="flex items-center">
                        <Layers className="ml-2" size={18} />
                        اطلاعات حمل و نقل ترکیبی
                      </AlertTitle>
                      <AlertDescription>
                        برای حمل و نقل ترکیبی، نیاز به تعریف حداقل دو قطعه مسیر دارید. هر قطعه می‌تواند نوع حمل و نقل متفاوتی (دریایی، زمینی، ریلی) داشته باشد.
                        پس از ذخیره تغییرات اصلی، می‌توانید قطعات مسیر را مدیریت کنید.
                      </AlertDescription>
                    </Alert>
                    
                    <ShipmentSegments shipmentId={currentShipmentId} />
                  </div>
                </>
              )}
              
              <div className="flex justify-end">
                <Button type="submit" disabled={isSubmitting} className="w-full md:w-auto">
                  {isSubmitting ? "در حال ذخیره..." : "ذخیره تغییرات"}
                </Button>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg flex items-start">
                <Info className="text-blue-500 mt-1 ml-3 flex-shrink-0" size={18} />
                <div className="text-sm text-blue-700">
                  <p className="font-medium mb-1">نکات مهم:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>قیمت‌ها باید به تومان وارد شوند</li>
                    <li>تاریخ حرکت باید حداقل یک روز بعد از امروز باشد</li>
                    <li>ظرفیت نشان دهنده تعداد کانتینرهایی است که می‌توانید حمل کنید</li>
                    <li>سرویس پس از تأیید مدیر سیستم قابل مشاهده برای کاربران خواهد بود</li>
                  </ul>
                </div>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default EditShipment;