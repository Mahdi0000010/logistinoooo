import { Loader2 } from "lucide-react";

interface LoadingIndicatorProps {
  text?: string;
}

export default function LoadingIndicator({ text = "در حال بارگذاری..." }: LoadingIndicatorProps) {
  return (
    <div className="w-full flex flex-col items-center justify-center py-10">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
      <p className="mt-2 text-sm text-gray-500">{text}</p>
    </div>
  );
}