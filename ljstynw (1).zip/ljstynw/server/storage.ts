import {
  users, User, InsertUser,
  transporters, Transporter, InsertTransporter,
  locations, Location, InsertLocation,
  shipments, Shipment, InsertShipment,
  shipmentSegments, ShipmentSegment, InsertShipmentSegment,
  bookings, Booking, InsertBooking,
  tickets, Ticket, InsertTicket,
  ticketResponses, TicketResponse, InsertTicketResponse,
  documents, Document, InsertDocument,
  blogPosts, BlogPost, InsertBlogPost,
  shippingRates, ShippingRate, InsertShippingRate,
  verificationCodes, VerificationCode, InsertVerificationCode
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { db, pool } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import { Store } from "express-session";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByRole(role: string): Promise<User[]>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<User>): Promise<User | undefined>;
  upsertUser(userData: any): Promise<User>;
  
  // Transporter operations
  getTransporter(id: number): Promise<Transporter | undefined>;
  getTransporterByUserId(userId: string): Promise<Transporter | undefined>;
  getAllTransporters(): Promise<Transporter[]>;
  createTransporter(transporter: InsertTransporter): Promise<Transporter>;
  updateTransporter(id: number, transporter: Partial<Transporter>): Promise<Transporter | undefined>;
  
  // Location operations
  getLocation(id: number): Promise<Location | undefined>;
  getAllLocations(): Promise<Location[]>;
  getLocationsByType(type: string): Promise<Location[]>;
  createLocation(location: InsertLocation): Promise<Location>;
  updateLocation(id: number, location: Partial<Location>): Promise<Location | undefined>;
  
  // Shipment operations
  getShipment(id: number): Promise<Shipment | undefined>;
  getShipmentsByTransporterId(transporterId: number): Promise<Shipment[]>;
  getAllShipments(): Promise<Shipment[]>;
  getNewShipments(limit: number): Promise<any[]>; // جدید: دریافت سرویس‌های جدید با اطلاعات شرکت
  searchShipments(params: {
    originId?: number,
    destinationId?: number,
    departureDate?: Date,
    transportType?: string,
    containerType?: string,
    containerCount?: number,
    cargoWeight?: string
  }): Promise<Shipment[]>;
  createShipment(shipment: InsertShipment): Promise<Shipment>;
  updateShipment(id: number, shipment: Partial<Shipment>): Promise<Shipment | undefined>;
  
  // Shipment Segment operations
  getShipmentSegments(shipmentId: number): Promise<ShipmentSegment[]>;
  getShipmentSegment(id: number): Promise<ShipmentSegment | undefined>;
  createShipmentSegment(segment: InsertShipmentSegment): Promise<ShipmentSegment>;
  updateShipmentSegment(id: number, segment: Partial<ShipmentSegment>): Promise<ShipmentSegment | undefined>;
  deleteShipmentSegment(id: number): Promise<boolean>;
  
  // Booking operations
  getBooking(id: number): Promise<Booking | undefined>;
  getBookingsByUserId(userId: string): Promise<Booking[]>;
  getBookingsByShipmentId(shipmentId: number): Promise<Booking[]>;
  getAllBookings(): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: number, status: string): Promise<Booking | undefined>;
  
  // Ticket operations
  getTicket(id: number): Promise<Ticket | undefined>;
  getTicketsByUserId(userId: string): Promise<Ticket[]>;
  getAllTickets(): Promise<Ticket[]>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicketStatus(id: number, status: string): Promise<Ticket | undefined>;
  
  // Ticket Response operations
  getTicketResponses(ticketId: number): Promise<TicketResponse[]>;
  createTicketResponse(response: InsertTicketResponse): Promise<TicketResponse>;
  
  // Document operations
  getDocumentsByUserId(userId: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocumentVerification(id: number, verified: boolean): Promise<Document | undefined>;
  
  // Blog operations
  getBlogPost(id: number): Promise<BlogPost | undefined>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  getAllBlogPosts(publishedOnly: boolean): Promise<BlogPost[]>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: number, post: Partial<BlogPost>): Promise<BlogPost | undefined>;
  
  // Shipping rate operations
  getShippingRate(id: number): Promise<ShippingRate | undefined>;
  getShippingRateByRoute(originId: number, destinationId: number, transportType: string): Promise<ShippingRate | undefined>;
  getAllShippingRates(): Promise<ShippingRate[]>;
  createShippingRate(rate: InsertShippingRate): Promise<ShippingRate>;
  updateShippingRate(id: number, rate: Partial<ShippingRate>): Promise<ShippingRate | undefined>;
  
  // Special route operations
  getShipmentsByRoute(originId: number, destinationId: number): Promise<Shipment[]>;
  
  // Verification Code operations
  createVerificationCode(code: InsertVerificationCode): Promise<VerificationCode>;
  getVerificationCode(userId: string, type: string, code: string): Promise<VerificationCode | undefined>;
  markVerificationCodeAsUsed(id: number): Promise<boolean>;
  verifyUserEmail(userId: string): Promise<boolean>;
  verifyUserPhone(userId: string): Promise<boolean>;
  
  // Session store for authentication
  sessionStore: Store;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private transporters: Map<number, Transporter>;
  private locations: Map<number, Location>;
  private shipments: Map<number, Shipment>;
  private shipmentSegments: Map<number, ShipmentSegment>;
  private bookings: Map<number, Booking>;
  private tickets: Map<number, Ticket>;
  private ticketResponses: Map<number, TicketResponse>;
  private documents: Map<number, Document>;
  private blogPosts: Map<number, BlogPost>;
  private shippingRates: Map<number, ShippingRate>;
  private verificationCodes: Map<number, VerificationCode>;

  sessionStore: Store;
  nextUserId: number;
  currentTransporterId: number;
  currentLocationId: number;
  currentShipmentId: number;
  currentShipmentSegmentId: number;
  currentBookingId: number;
  currentTicketId: number;
  currentTicketResponseId: number;
  currentDocumentId: number;
  currentBlogPostId: number;
  currentShippingRateId: number;
  currentVerificationCodeId: number;

  constructor() {
    this.users = new Map();
    this.transporters = new Map();
    this.locations = new Map();
    this.shipments = new Map();
    this.shipmentSegments = new Map();
    this.bookings = new Map();
    this.tickets = new Map();
    this.ticketResponses = new Map();
    this.documents = new Map();
    this.blogPosts = new Map();
    this.shippingRates = new Map();
    this.verificationCodes = new Map();
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });

    this.nextUserId = 1;
    this.currentTransporterId = 1;
    this.currentLocationId = 1;
    this.currentShipmentId = 1;
    this.currentShipmentSegmentId = 1;
    this.currentBookingId = 1;
    this.currentTicketId = 1;
    this.currentTicketResponseId = 1;
    this.currentDocumentId = 1;
    this.currentBlogPostId = 1;
    this.currentShippingRateId = 1;
    this.currentVerificationCodeId = 1;
    
    // Initialize with some locations
    this.initializeLocations();
  }

  // Method to reset and reinitialize all locations
  public resetAndInitializeLocations() {
    // Clear existing locations
    this.locations.clear();
    this.currentLocationId = 1;
    
    // Reinitialize with the latest data
    this.initializeLocations();
  }
  
  private initializeLocations() {
    // Iranian ports
    const iranianPorts = [
      { name: "بندرعباس (Bandar Abbas)", type: "port", country: "ایران (Iran)", city: "بندرعباس" },
      { name: "بندر امام خمینی (Imam Khomeini Port)", type: "port", country: "ایران (Iran)", city: "ماهشهر" },
      { name: "بندر چابهار (Chabahar Port)", type: "port", country: "ایران (Iran)", city: "چابهار" },
      { name: "بندر بوشهر (Bushehr Port)", type: "port", country: "ایران (Iran)", city: "بوشهر" },
      { name: "بندر خرمشهر (Khorramshahr Port)", type: "port", country: "ایران (Iran)", city: "خرمشهر" },
      { name: "بندر انزلی (Anzali Port)", type: "port", country: "ایران (Iran)", city: "انزلی" },
      { name: "بندر نوشهر (Nowshahr Port)", type: "port", country: "ایران (Iran)", city: "نوشهر" },
      { name: "بندر آستارا (Astara Port)", type: "port", country: "ایران (Iran)", city: "آستارا" }
    ];
    
    // UAE ports (expanded)
    const uaePorts = [
      { name: "بندر جبل علی (Jebel Ali Port)", type: "port", country: "امارات متحده عربی (UAE)", city: "دبی" },
      { name: "بندر رشید (Port Rashid)", type: "port", country: "امارات متحده عربی (UAE)", city: "دبی" },
      { name: "بندر خلیفه (Khalifa Port)", type: "port", country: "امارات متحده عربی (UAE)", city: "ابوظبی" },
      { name: "بندر زاید (Zayed Port)", type: "port", country: "امارات متحده عربی (UAE)", city: "ابوظبی" },
      { name: "بندر مصفح (Musaffah Port)", type: "port", country: "امارات متحده عربی (UAE)", city: "ابوظبی" },
      { name: "بندر فجیره (Port of Fujairah)", type: "port", country: "امارات متحده عربی (UAE)", city: "فجیره" },
      { name: "بندر خورفکان (Khor Fakkan Port)", type: "port", country: "امارات متحده عربی (UAE)", city: "شارجه" },
      { name: "بندر عجمان (Ajman Port)", type: "port", country: "امارات متحده عربی (UAE)", city: "عجمان" },
      { name: "بندر ام القیوین (Umm Al Quwain Port)", type: "port", country: "امارات متحده عربی (UAE)", city: "ام القیوین" },
      { name: "بندر رأس الخیمة (Ras Al Khaimah Port)", type: "port", country: "امارات متحده عربی (UAE)", city: "رأس الخیمة" }
    ];
    
    // Oman ports (expanded)
    const omanPorts = [
      { name: "بندر سلطان قابوس (Sultan Qaboos Port)", type: "port", country: "عمان (Oman)", city: "مسقط" },
      { name: "بندر مطرح (Mutrah Port)", type: "port", country: "عمان (Oman)", city: "مسقط" },
      { name: "بندر صلاله (Port of Salalah)", type: "port", country: "عمان (Oman)", city: "صلاله" },
      { name: "بندر دقم (Duqm Port)", type: "port", country: "عمان (Oman)", city: "دقم" },
      { name: "بندر صحار (Sohar Port)", type: "port", country: "عمان (Oman)", city: "صحار" },
      { name: "بندر صور (Sur Port)", type: "port", country: "عمان (Oman)", city: "صور" },
      { name: "بندر شناص (Shinas Port)", type: "port", country: "عمان (Oman)", city: "شناص" },
      { name: "بندر خصب (Khasab Port)", type: "port", country: "عمان (Oman)", city: "خصب" }
    ];
    
    // Other Persian Gulf ports
    const otherGulfPorts = [
      { name: "بندر حمد (Hamad Port)", type: "port", country: "قطر (Qatar)", city: "دوحه" },
      { name: "بندر راس لفان (Ras Laffan Port)", type: "port", country: "قطر (Qatar)", city: "راس لفان" },
      { name: "بندر دوحه (Doha Port)", type: "port", country: "قطر (Qatar)", city: "دوحه" },
      { name: "بندر سلمان (Mina Salman)", type: "port", country: "بحرین (Bahrain)", city: "منامه" },
      { name: "بندر خلیفه بن سلمان (Khalifa Bin Salman Port)", type: "port", country: "بحرین (Bahrain)", city: "حد" },
      { name: "بندر شویخ (Shuwaikh Port)", type: "port", country: "کویت (Kuwait)", city: "کویت" },
      { name: "بندر شعیبه (Shuaiba Port)", type: "port", country: "کویت (Kuwait)", city: "شعیبه" },
      { name: "بندر الدوحه (Doha Port)", type: "port", country: "کویت (Kuwait)", city: "دوحه کویت" },
      { name: "بندر جده اسلامی (Jeddah Islamic Port)", type: "port", country: "عربستان سعودی (Saudi Arabia)", city: "جده" },
      { name: "بندر ملک عبدالله (King Abdullah Port)", type: "port", country: "عربستان سعودی (Saudi Arabia)", city: "رابغ" },
      { name: "بندر دمام (King Abdulaziz Port)", type: "port", country: "عربستان سعودی (Saudi Arabia)", city: "دمام" },
      { name: "بندر ینبع (Yanbu Commercial Port)", type: "port", country: "عربستان سعودی (Saudi Arabia)", city: "ینبع" },
      { name: "بندر جبیل (Jubail Port)", type: "port", country: "عربستان سعودی (Saudi Arabia)", city: "جبیل" }
    ];
    
    // Combine all Gulf ports
    const gulfPorts = [...uaePorts, ...omanPorts, ...otherGulfPorts];
    
    // Chinese ports
    const chinesePorts = [
      { name: "بندر شانگهای (Port of Shanghai)", type: "port", country: "چین (China)", city: "شانگهای" },
      { name: "بندر نینگبو-ژوشان (Ningbo-Zhoushan Port)", type: "port", country: "چین (China)", city: "نینگبو" },
      { name: "بندر شنژن (Port of Shenzhen)", type: "port", country: "چین (China)", city: "شنژن" },
      { name: "بندر گوانگژو (Port of Guangzhou)", type: "port", country: "چین (China)", city: "گوانگژو" },
      { name: "بندر کینگ‌دائو (Port of Qingdao)", type: "port", country: "چین (China)", city: "کینگ‌دائو" },
      { name: "بندر تیانجین (Port of Tianjin)", type: "port", country: "چین (China)", city: "تیانجین" },
      { name: "بندر شیامن (Port of Xiamen)", type: "port", country: "چین (China)", city: "شیامن" },
      { name: "بندر دالیان (Port of Dalian)", type: "port", country: "چین (China)", city: "دالیان" }
    ];
    
    // Iranian cities
    const iranianCities = [
      { name: "تهران (Tehran)", type: "inland", country: "ایران (Iran)", city: "تهران" },
      { name: "اصفهان (Isfahan)", type: "inland", country: "ایران (Iran)", city: "اصفهان" },
      { name: "مشهد (Mashhad)", type: "inland", country: "ایران (Iran)", city: "مشهد" },
      { name: "تبریز (Tabriz)", type: "inland", country: "ایران (Iran)", city: "تبریز" },
      { name: "شیراز (Shiraz)", type: "inland", country: "ایران (Iran)", city: "شیراز" },
      { name: "کرج (Karaj)", type: "inland", country: "ایران (Iran)", city: "کرج" },
      { name: "اهواز (Ahvaz)", type: "inland", country: "ایران (Iran)", city: "اهواز" },
      { name: "قم (Qom)", type: "inland", country: "ایران (Iran)", city: "قم" },
      { name: "کرمانشاه (Kermanshah)", type: "inland", country: "ایران (Iran)", city: "کرمانشاه" },
      { name: "ارومیه (Urmia)", type: "inland", country: "ایران (Iran)", city: "ارومیه" },
      { name: "رشت (Rasht)", type: "inland", country: "ایران (Iran)", city: "رشت" },
      { name: "زاهدان (Zahedan)", type: "inland", country: "ایران (Iran)", city: "زاهدان" },
      { name: "همدان (Hamadan)", type: "inland", country: "ایران (Iran)", city: "همدان" },
      { name: "کرمان (Kerman)", type: "inland", country: "ایران (Iran)", city: "کرمان" },
      { name: "یزد (Yazd)", type: "inland", country: "ایران (Iran)", city: "یزد" },
      { name: "اردبیل (Ardabil)", type: "inland", country: "ایران (Iran)", city: "اردبیل" },
      { name: "بندرعباس (Bandar Abbas)", type: "inland", country: "ایران (Iran)", city: "بندرعباس" },
      { name: "زنجان (Zanjan)", type: "inland", country: "ایران (Iran)", city: "زنجان" },
      { name: "سنندج (Sanandaj)", type: "inland", country: "ایران (Iran)", city: "سنندج" },
      { name: "قزوین (Qazvin)", type: "inland", country: "ایران (Iran)", city: "قزوین" }
    ];
    
    // UAE cities
    const uaeCities = [
      { name: "دبی (Dubai)", type: "inland", country: "امارات متحده عربی (UAE)", city: "دبی" },
      { name: "ابوظبی (Abu Dhabi)", type: "inland", country: "امارات متحده عربی (UAE)", city: "ابوظبی" },
      { name: "شارجه (Sharjah)", type: "inland", country: "امارات متحده عربی (UAE)", city: "شارجه" },
      { name: "العین (Al Ain)", type: "inland", country: "امارات متحده عربی (UAE)", city: "العین" },
      { name: "عجمان (Ajman)", type: "inland", country: "امارات متحده عربی (UAE)", city: "عجمان" },
      { name: "رأس الخیمة (Ras Al Khaimah)", type: "inland", country: "امارات متحده عربی (UAE)", city: "رأس الخیمة" }
    ];
    
    // Chinese cities
    const chineseCities = [
      { name: "پکن (Beijing)", type: "inland", country: "چین (China)", city: "پکن" },
      { name: "شانگهای (Shanghai)", type: "inland", country: "چین (China)", city: "شانگهای" },
      { name: "گوانگژو (Guangzhou)", type: "inland", country: "چین (China)", city: "گوانگژو" },
      { name: "شنژن (Shenzhen)", type: "inland", country: "چین (China)", city: "شنژن" },
      { name: "ووهان (Wuhan)", type: "inland", country: "چین (China)", city: "ووهان" },
      { name: "چنگدو (Chengdu)", type: "inland", country: "چین (China)", city: "چنگدو" },
      { name: "شیان (Xi'an)", type: "inland", country: "چین (China)", city: "شیان" },
      { name: "نانجینگ (Nanjing)", type: "inland", country: "چین (China)", city: "نانجینگ" },
      { name: "هانگژو (Hangzhou)", type: "inland", country: "چین (China)", city: "هانگژو" },
      { name: "سوژو (Suzhou)", type: "inland", country: "چین (China)", city: "سوژو" }
    ];
    
    // Add all locations
    [...iranianPorts, ...gulfPorts, ...chinesePorts, ...iranianCities, ...uaeCities, ...chineseCities].forEach(loc => {
      this.createLocation({
        name: loc.name,
        type: loc.type,
        country: loc.country,
        city: loc.city,
        coordinates: ""
      });
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }
  
  async getUserByPhone(phone: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.phone === phone);
  }
  
  async getUserByRole(role: string): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.role === role);
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = `user_${this.nextUserId++}`;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      company: insertUser.company || null, 
      verified: insertUser.verified || false,
      role: insertUser.role || "user"
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async upsertUser(userData: any): Promise<User> {
    try {
      // اگر کاربر با این نام کاربری وجود داشته باشد، به‌روزرسانی می‌کنیم
      const existingUser = await this.getUserByUsername(userData.username);
      
      if (existingUser) {
        // به‌روزرسانی کاربر موجود
        const updatedUser = {
          ...existingUser,
          email: userData.email || existingUser.email,
          fullName: userData.fullName || existingUser.fullName,
          role: userData.role || existingUser.role,
          userType: userData.userType || existingUser.userType,
        };
        
        this.users.set(existingUser.id, updatedUser);
        return updatedUser;
      } else {
        // ایجاد کاربر جدید
        // Use the ID provided by Replit Auth if available, otherwise generate one
        const userId = userData.id || `user_${this.nextUserId++}`;
        const newUser = {
          id: userId,
          username: userData.username,
          email: userData.email || `${userData.username}@example.com`,
          phone: userData.phone || "09000000000",
          password: userData.password || "replit-auth-password",
          fullName: userData.fullName || userData.username,
          userType: userData.userType || "user",
          role: userData.role || "user",
          company: null,
          verified: false,
          createdAt: new Date(),
        };
        
        this.users.set(userId, newUser);
        return newUser;
      }
    } catch (error) {
      console.error("Error in upsertUser:", error);
      throw error;
    }
  }

  // Transporter operations
  async getTransporter(id: number): Promise<Transporter | undefined> {
    return this.transporters.get(id);
  }

  async getTransporterByUserId(userId: string): Promise<Transporter | undefined> {
    return Array.from(this.transporters.values()).find(t => t.userId === userId);
  }
  
  async getAllTransporters(): Promise<Transporter[]> {
    return Array.from(this.transporters.values());
  }

  async createTransporter(insertTransporter: InsertTransporter): Promise<Transporter> {
    const id = this.currentTransporterId++;
    const transporter: Transporter = { 
      ...insertTransporter, 
      id,
      verified: insertTransporter.verified || false,
      companyDescription: insertTransporter.companyDescription || null,
      address: insertTransporter.address || null
    };
    this.transporters.set(id, transporter);
    return transporter;
  }

  async updateTransporter(id: number, transporterData: Partial<Transporter>): Promise<Transporter | undefined> {
    const transporter = await this.getTransporter(id);
    if (!transporter) return undefined;
    
    const updatedTransporter = { ...transporter, ...transporterData };
    this.transporters.set(id, updatedTransporter);
    return updatedTransporter;
  }

  // Location operations
  async getLocation(id: number): Promise<Location | undefined> {
    return this.locations.get(id);
  }

  async getAllLocations(): Promise<Location[]> {
    return Array.from(this.locations.values());
  }

  async getLocationsByType(type: string): Promise<Location[]> {
    return Array.from(this.locations.values()).filter(location => location.type === type);
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = this.currentLocationId++;
    const location: Location = { 
      ...insertLocation, 
      id,
      coordinates: insertLocation.coordinates || null
    };
    this.locations.set(id, location);
    return location;
  }
  
  async updateLocation(id: number, locationData: Partial<Location>): Promise<Location | undefined> {
    const location = await this.getLocation(id);
    if (!location) return undefined;
    
    const updatedLocation = { ...location, ...locationData };
    this.locations.set(id, updatedLocation);
    return updatedLocation;
  }

  // Shipment operations
  async getShipment(id: number): Promise<Shipment | undefined> {
    return this.shipments.get(id);
  }

  async getShipmentsByTransporterId(transporterId: number): Promise<Shipment[]> {
    return Array.from(this.shipments.values()).filter(s => s.transporterId === transporterId);
  }
  
  async getAllShipments(): Promise<Shipment[]> {
    return Array.from(this.shipments.values());
  }
  
  async getNewShipments(limit: number): Promise<any[]> {
    // دریافت سرویس‌های فعال با ترتیب تاریخ ایجاد نزولی
    const shipments = Array.from(this.shipments.values())
      .filter(s => s.active)
      .sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA; // ترتیب نزولی
      })
      .slice(0, limit);
      
    // افزودن اطلاعات بیشتر به هر سرویس
    const enhancedShipments = shipments.map(shipment => {
      const transporter = this.transporters.get(shipment.transporterId);
      const origin = this.locations.get(shipment.originId);
      const destination = this.locations.get(shipment.destinationId);
      
      return {
        ...shipment,
        transporterName: transporter?.companyName || 'Unknown',
        transporterLogo: '', // No companyLogo field in transporter model
        originName: origin?.name || 'Unknown',
        originCountry: origin?.country || 'Unknown',
        destinationName: destination?.name || 'Unknown',
        destinationCountry: destination?.country || 'Unknown',
        discountedPrice: Math.round(shipment.price * 0.9) // قیمت با تخفیف 10%
      };
    });
    
    return enhancedShipments;
  }

  async searchShipments(params: {
    originId?: number,
    destinationId?: number,
    departureDate?: Date,
    transportType?: string,
    containerType?: string
  }): Promise<Shipment[]> {
    return Array.from(this.shipments.values()).filter(shipment => {
      if (params.originId && shipment.originId !== params.originId) return false;
      if (params.destinationId && shipment.destinationId !== params.destinationId) return false;
      if (params.transportType && shipment.transportType !== params.transportType) return false;
      if (params.containerType && shipment.containerType !== params.containerType) return false;
      if (params.departureDate) {
        const paramDate = new Date(params.departureDate);
        const shipmentDate = new Date(shipment.departureDate);
        if (paramDate.getTime() !== shipmentDate.getTime()) return false;
      }
      return shipment.active;
    });
  }

  async createShipment(insertShipment: InsertShipment): Promise<Shipment> {
    const id = this.currentShipmentId++;
    // Ensure isComposite is properly set if not provided
    const isComposite = insertShipment.isComposite ?? (insertShipment.transportType === 'mixed');
    
    // Create the shipment with proper typing
    const shipment: Shipment = { 
      ...insertShipment, 
      id, 
      createdAt: new Date(),
      isComposite: isComposite,
      containerType: insertShipment.containerType || null,
      insuranceAvailable: insertShipment.insuranceAvailable ?? true,
      insurancePrice: insertShipment.insurancePrice || null,
      specialNotes: insertShipment.specialNotes || null,
      active: insertShipment.active ?? true
    };
    
    console.log("Creating shipment with data:", shipment);
    this.shipments.set(id, shipment);
    return shipment;
  }

  async updateShipment(id: number, shipmentData: Partial<Shipment>): Promise<Shipment | undefined> {
    const shipment = await this.getShipment(id);
    if (!shipment) return undefined;
    
    const updatedShipment = { ...shipment, ...shipmentData };
    this.shipments.set(id, updatedShipment);
    return updatedShipment;
  }

  // Shipment Segment operations
  async getShipmentSegments(shipmentId: number): Promise<ShipmentSegment[]> {
    return Array.from(this.shipmentSegments.values())
      .filter(segment => segment.shipmentId === shipmentId)
      .sort((a, b) => a.segmentOrder - b.segmentOrder);
  }
  
  async getShipmentSegment(id: number): Promise<ShipmentSegment | undefined> {
    return this.shipmentSegments.get(id);
  }
  
  async createShipmentSegment(segment: InsertShipmentSegment): Promise<ShipmentSegment> {
    const id = this.currentShipmentSegmentId++;
    const shipmentSegment: ShipmentSegment = { 
      ...segment, 
      id, 
      createdAt: new Date(),
      containerType: segment.containerType || null,
      description: segment.description || null
    };
    this.shipmentSegments.set(id, shipmentSegment);
    return shipmentSegment;
  }
  
  async updateShipmentSegment(id: number, segmentData: Partial<ShipmentSegment>): Promise<ShipmentSegment | undefined> {
    const segment = await this.getShipmentSegment(id);
    if (!segment) return undefined;
    
    const updatedSegment = { ...segment, ...segmentData };
    this.shipmentSegments.set(id, updatedSegment);
    return updatedSegment;
  }
  
  async deleteShipmentSegment(id: number): Promise<boolean> {
    const exists = this.shipmentSegments.has(id);
    if (exists) {
      this.shipmentSegments.delete(id);
      return true;
    }
    return false;
  }

  // Booking operations
  async getBooking(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async getBookingsByUserId(userId: string): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(b => b.userId === userId);
  }

  async getBookingsByShipmentId(shipmentId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(b => b.shipmentId === shipmentId);
  }
  
  async getAllBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = this.currentBookingId++;
    const booking: Booking = { 
      ...insertBooking, 
      id, 
      createdAt: new Date(),
      cargoDetails: insertBooking.cargoDetails || null,
      withInsurance: insertBooking.withInsurance || false
    };
    this.bookings.set(id, booking);
    return booking;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const booking = await this.getBooking(id);
    if (!booking) return undefined;
    
    const updatedBooking = { ...booking, status };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }

  // Ticket operations
  async getTicket(id: number): Promise<Ticket | undefined> {
    return this.tickets.get(id);
  }

  async getTicketsByUserId(userId: string): Promise<Ticket[]> {
    return Array.from(this.tickets.values()).filter(t => t.userId === userId);
  }

  async getAllTickets(): Promise<Ticket[]> {
    return Array.from(this.tickets.values());
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const id = this.currentTicketId++;
    const ticket: Ticket = { ...insertTicket, id, createdAt: new Date() };
    this.tickets.set(id, ticket);
    return ticket;
  }

  async updateTicketStatus(id: number, status: string): Promise<Ticket | undefined> {
    const ticket = await this.getTicket(id);
    if (!ticket) return undefined;
    
    const updatedTicket = { ...ticket, status };
    this.tickets.set(id, updatedTicket);
    return updatedTicket;
  }

  // Ticket Response operations
  async getTicketResponses(ticketId: number): Promise<TicketResponse[]> {
    return Array.from(this.ticketResponses.values()).filter(tr => tr.ticketId === ticketId);
  }

  async createTicketResponse(insertResponse: InsertTicketResponse): Promise<TicketResponse> {
    const id = this.currentTicketResponseId++;
    const response: TicketResponse = { ...insertResponse, id, createdAt: new Date() };
    this.ticketResponses.set(id, response);
    return response;
  }

  // Document operations
  async getDocumentsByUserId(userId: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(d => d.userId === userId);
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.currentDocumentId++;
    const document: Document = { 
      ...insertDocument, 
      id, 
      createdAt: new Date(),
      verified: insertDocument.verified || false
    };
    this.documents.set(id, document);
    return document;
  }

  async updateDocumentVerification(id: number, verified: boolean): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;
    
    const updatedDocument = { ...document, verified };
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  // Blog operations
  async getBlogPost(id: number): Promise<BlogPost | undefined> {
    return this.blogPosts.get(id);
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    return Array.from(this.blogPosts.values()).find(post => post.slug === slug);
  }

  async getAllBlogPosts(publishedOnly: boolean): Promise<BlogPost[]> {
    const posts = Array.from(this.blogPosts.values());
    return publishedOnly ? posts.filter(post => post.published) : posts;
  }

  async createBlogPost(insertPost: InsertBlogPost): Promise<BlogPost> {
    const id = this.currentBlogPostId++;
    const now = new Date();
    const post: BlogPost = { 
      ...insertPost, 
      id, 
      createdAt: now, 
      updatedAt: now,
      excerpt: insertPost.excerpt || null,
      featuredImage: insertPost.featuredImage || null,
      published: insertPost.published || false
    };
    this.blogPosts.set(id, post);
    return post;
  }

  async updateBlogPost(id: number, postData: Partial<BlogPost>): Promise<BlogPost | undefined> {
    const post = await this.getBlogPost(id);
    if (!post) return undefined;
    
    const updatedPost = { ...post, ...postData, updatedAt: new Date() };
    this.blogPosts.set(id, updatedPost);
    return updatedPost;
  }
  
  // Shipping Rate operations
  async getShippingRate(id: number): Promise<ShippingRate | undefined> {
    return this.shippingRates.get(id);
  }

  async getShippingRateByRoute(originId: number, destinationId: number, transportType: string): Promise<ShippingRate | undefined> {
    return Array.from(this.shippingRates.values()).find(rate => 
      rate.originId === originId && 
      rate.destinationId === destinationId && 
      rate.transportType === transportType
    );
  }
  
  async getAllShippingRates(): Promise<ShippingRate[]> {
    return Array.from(this.shippingRates.values());
  }
  
  async createShippingRate(insertRate: InsertShippingRate): Promise<ShippingRate> {
    const id = this.currentShippingRateId++;
    const now = new Date();
    const rate: ShippingRate = { 
      ...insertRate, 
      id, 
      createdAt: now, 
      updatedAt: now,
      containerType: insertRate.containerType || null,
      distance: insertRate.distance || null,
      transitTime: insertRate.transitTime || null
    };
    this.shippingRates.set(id, rate);
    return rate;
  }
  
  async updateShippingRate(id: number, rateData: Partial<ShippingRate>): Promise<ShippingRate | undefined> {
    const rate = await this.getShippingRate(id);
    if (!rate) return undefined;
    
    const updatedRate = { 
      ...rate, 
      ...rateData,
      updatedAt: new Date()
    };
    this.shippingRates.set(id, updatedRate);
    return updatedRate;
  }
  
  // Verification Code operations
  async createVerificationCode(code: InsertVerificationCode): Promise<VerificationCode> {
    const id = this.currentVerificationCodeId++;
    const verificationCode: VerificationCode = {
      ...code,
      id,
      createdAt: new Date(),
      used: false
    };
    this.verificationCodes.set(id, verificationCode);
    return verificationCode;
  }

  async getVerificationCode(userId: string, type: string, code: string): Promise<VerificationCode | undefined> {
    return Array.from(this.verificationCodes.values()).find(
      verificationCode => verificationCode.userId === userId &&
                          verificationCode.verificationType === type &&
                          verificationCode.code === code &&
                          !verificationCode.used
    );
  }

  async markVerificationCodeAsUsed(id: number): Promise<boolean> {
    const verificationCode = this.verificationCodes.get(id);
    if (!verificationCode) return false;

    const updatedCode: VerificationCode = {
      ...verificationCode,
      used: true
    };
    this.verificationCodes.set(id, updatedCode);
    return true;
  }

  async verifyUserEmail(userId: string): Promise<boolean> {
    const user = this.users.get(userId);
    if (!user) return false;

    const updatedUser: User = {
      ...user,
      emailVerified: true
    };
    this.users.set(userId, updatedUser);
    return true;
  }

  async verifyUserPhone(userId: string): Promise<boolean> {
    const user = this.users.get(userId);
    if (!user) return false;

    const updatedUser: User = {
      ...user,
      phoneVerified: true
    };
    this.users.set(userId, updatedUser);
    return true;
  }

  // Special route operations
  async getShipmentsByRoute(originId: number, destinationId: number): Promise<Shipment[]> {
    // 1. Get direct shipments
    const directShipments = Array.from(this.shipments.values()).filter(shipment => 
      shipment.originId === originId && 
      shipment.destinationId === destinationId && 
      shipment.active
    );
    
    // 2. Get shipment segments matching this route
    const segmentsMatchingRoute = Array.from(this.shipmentSegments.values()).filter(segment => 
      segment.originId === originId && 
      segment.destinationId === destinationId
    );
    
    // 3. Get composite shipments that contain the matching segments
    const shipmentIdsFromSegments = segmentsMatchingRoute.map(segment => segment.shipmentId);
    const compositeShipments = Array.from(this.shipments.values()).filter(shipment => 
      shipmentIdsFromSegments.includes(shipment.id) && 
      shipment.active
    );
    
    // 4. Combine direct and composite shipments
    return [...directShipments, ...compositeShipments];
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      conObject: { 
        connectionString: process.env.DATABASE_URL
      },
      tableName: 'sessions',
      createTableIfMissing: false, // we already created the table
    });
  }

  // Verification Code operations
  async createVerificationCode(code: InsertVerificationCode): Promise<VerificationCode> {
    const [newCode] = await db.insert(verificationCodes).values(code).returning();
    return newCode;
  }

  async getVerificationCode(userId: string, type: string, code: string): Promise<VerificationCode | undefined> {
    const [verificationCode] = await db.select()
      .from(verificationCodes)
      .where(
        and(
          eq(verificationCodes.userId, userId),
          eq(verificationCodes.verificationType, type),
          eq(verificationCodes.code, code),
          eq(verificationCodes.used, false)
        )
      );
    return verificationCode;
  }

  async markVerificationCodeAsUsed(id: number): Promise<boolean> {
    const [updatedCode] = await db.update(verificationCodes)
      .set({ used: true })
      .where(eq(verificationCodes.id, id))
      .returning();
    return !!updatedCode;
  }

  async verifyUserEmail(userId: string): Promise<boolean> {
    const [updatedUser] = await db.update(users)
      .set({ emailVerified: true })
      .where(eq(users.id, userId))
      .returning();
    return !!updatedUser;
  }

  async verifyUserPhone(userId: string): Promise<boolean> {
    const [updatedUser] = await db.update(users)
      .set({ phoneVerified: true })
      .where(eq(users.id, userId))
      .returning();
    return !!updatedUser;
  }
  
  // Special route operations
  async getShipmentsByRoute(originId: number, destinationId: number): Promise<Shipment[]> {
    try {
      // 1. First get direct shipments between origin and destination
      const directShipments = await db
        .select()
        .from(shipments)
        .where(
          and(
            eq(shipments.originId, originId),
            eq(shipments.destinationId, destinationId),
            eq(shipments.active, true)
          )
        );
      
      // 2. Get composite shipments that might contain this route as a segment
      const allShipments = await db
        .select()
        .from(shipments)
        .where(eq(shipments.isComposite, true));
        
      // 3. Get segments matching the route
      const segments = await db
        .select()
        .from(shipmentSegments)
        .where(
          and(
            eq(shipmentSegments.originId, originId),
            eq(shipmentSegments.destinationId, destinationId)
          )
        );
      
      // 4. Filter shipment IDs from segments
      const segmentShipmentIds = segments.map(s => s.shipmentId);
      
      // 5. Get the matching composite shipments
      const matchingCompositeShipments = allShipments.filter(s => 
        segmentShipmentIds.includes(s.id) && s.active
      );
      
      // 6. Combine direct and composite shipments
      return [...directShipments, ...matchingCompositeShipments];
    } catch (error) {
      console.error("Failed to get shipments by route:", error);
      return [];
    }
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phone, phone));
    return user;
  }
  
  async getUserByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values([{
      ...insertUser,
      id: crypto.randomUUID() // Generate a random UUID for new users
    }]).returning();
    return user;
  }

  async updateUser(id: string, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async upsertUser(userData: any): Promise<User> {
    try {
      // اگر کاربر با این نام کاربری وجود داشته باشد، به‌روزرسانی می‌کنیم
      const existingUser = await this.getUserByUsername(userData.username);
      
      if (existingUser) {
        // به‌روزرسانی کاربر موجود
        const [updatedUser] = await db.update(users)
          .set({
            email: userData.email || existingUser.email,
            fullName: userData.fullName || existingUser.fullName,
            role: userData.role || existingUser.role,
            userType: userData.userType || existingUser.userType,
          })
          .where(eq(users.username, userData.username))
          .returning();
        
        return updatedUser;
      } else {
        // ایجاد کاربر جدید
        const userInsertData = {
          id: userData.id || crypto.randomUUID(),
          username: userData.username,
          email: userData.email || `${userData.username}@example.com`,
          phone: userData.phone || "09000000000",
          password: userData.password || "replit-auth-password",
          fullName: userData.fullName || userData.username,
          userType: userData.userType || "user",
          role: userData.role || "user",
        };
        
        // تبدیل به آرایه برای سازگاری با API درج
        const [newUser] = await db.insert(users)
          .values([userInsertData])
          .returning();
        
        return newUser;
      }
    } catch (error) {
      console.error("Error in upsertUser:", error);
      throw error;
    }
  }

  // Transporter operations
  async getTransporter(id: number): Promise<Transporter | undefined> {
    const [transporter] = await db.select().from(transporters).where(eq(transporters.id, id));
    return transporter;
  }

  async getTransporterByUserId(userId: string): Promise<Transporter | undefined> {
    const [transporter] = await db.select().from(transporters).where(eq(transporters.userId, userId));
    return transporter;
  }
  
  async getAllTransporters(): Promise<Transporter[]> {
    return await db.select().from(transporters);
  }

  async createTransporter(insertTransporter: InsertTransporter): Promise<Transporter> {
    const [transporter] = await db.insert(transporters).values(insertTransporter).returning();
    return transporter;
  }

  async updateTransporter(id: number, transporterData: Partial<Transporter>): Promise<Transporter | undefined> {
    const [updatedTransporter] = await db.update(transporters)
      .set(transporterData)
      .where(eq(transporters.id, id))
      .returning();
    return updatedTransporter;
  }

  // Location operations
  async getLocation(id: number): Promise<Location | undefined> {
    const [location] = await db.select().from(locations).where(eq(locations.id, id));
    return location;
  }

  async getAllLocations(): Promise<Location[]> {
    return await db.select().from(locations);
  }

  async getLocationsByType(type: string): Promise<Location[]> {
    return await db.select().from(locations).where(eq(locations.type, type));
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const [location] = await db.insert(locations).values(insertLocation).returning();
    return location;
  }
  
  async updateLocation(id: number, locationData: Partial<Location>): Promise<Location | undefined> {
    const [updatedLocation] = await db.update(locations)
      .set(locationData)
      .where(eq(locations.id, id))
      .returning();
    return updatedLocation;
  }

  // Shipment operations
  async getShipment(id: number): Promise<Shipment | undefined> {
    const [shipment] = await db.select({
      id: shipments.id,
      transporterId: shipments.transporterId,
      originId: shipments.originId,
      destinationId: shipments.destinationId,
      departureDate: shipments.departureDate,
      arrivalDate: shipments.arrivalDate,
      transportType: shipments.transportType,
      containerType: shipments.containerType,
      capacity: shipments.capacity,
      price: shipments.price,
      insuranceAvailable: shipments.insuranceAvailable,
      insurancePrice: shipments.insurancePrice,
      active: shipments.active,
      specialNotes: shipments.specialNotes,
      isComposite: shipments.isComposite,
      createdAt: shipments.createdAt
    }).from(shipments).where(eq(shipments.id, id));
    return shipment;
  }

  async getShipmentsByTransporterId(transporterId: number): Promise<Shipment[]> {
    // Selecting specific columns to avoid issues with missing columns
    return await db.select({
      id: shipments.id,
      transporterId: shipments.transporterId,
      originId: shipments.originId,
      destinationId: shipments.destinationId,
      departureDate: shipments.departureDate,
      arrivalDate: shipments.arrivalDate,
      transportType: shipments.transportType,
      containerType: shipments.containerType,
      capacity: shipments.capacity,
      price: shipments.price,
      insuranceAvailable: shipments.insuranceAvailable,
      insurancePrice: shipments.insurancePrice,
      active: shipments.active,
      specialNotes: shipments.specialNotes,
      isComposite: shipments.isComposite,
      createdAt: shipments.createdAt
    }).from(shipments).where(eq(shipments.transporterId, transporterId));
  }
  
  async getAllShipments(): Promise<Shipment[]> {
    // Selecting specific columns to avoid issues with missing columns
    return await db.select({
      id: shipments.id,
      transporterId: shipments.transporterId,
      originId: shipments.originId,
      destinationId: shipments.destinationId,
      departureDate: shipments.departureDate,
      arrivalDate: shipments.arrivalDate,
      transportType: shipments.transportType,
      containerType: shipments.containerType,
      capacity: shipments.capacity,
      price: shipments.price,
      insuranceAvailable: shipments.insuranceAvailable,
      insurancePrice: shipments.insurancePrice,
      active: shipments.active,
      specialNotes: shipments.specialNotes,
      isComposite: shipments.isComposite,
      createdAt: shipments.createdAt
    }).from(shipments);
  }
  
  async getNewShipments(limit: number): Promise<any[]> {
    // دریافت سرویس‌های فعال با ترتیب تاریخ ایجاد نزولی
    const shipmentsData = await db.select({
      id: shipments.id,
      transporterId: shipments.transporterId,
      originId: shipments.originId,
      destinationId: shipments.destinationId,
      departureDate: shipments.departureDate,
      arrivalDate: shipments.arrivalDate,
      transportType: shipments.transportType,
      containerType: shipments.containerType,
      capacity: shipments.capacity,
      price: shipments.price,
      insuranceAvailable: shipments.insuranceAvailable,
      insurancePrice: shipments.insurancePrice,
      active: shipments.active,
      specialNotes: shipments.specialNotes,
      isComposite: shipments.isComposite,
      createdAt: shipments.createdAt
    })
    .from(shipments)
    .where(eq(shipments.active, true))
    .orderBy(desc(shipments.createdAt))
    .limit(limit);
    
    // افزودن اطلاعات بیشتر به هر سرویس
    const enhancedShipments = await Promise.all(shipmentsData.map(async (shipment) => {
      const [transporter] = await db.select().from(transporters).where(eq(transporters.id, shipment.transporterId));
      const [origin] = await db.select().from(locations).where(eq(locations.id, shipment.originId));
      const [destination] = await db.select().from(locations).where(eq(locations.id, shipment.destinationId));
      
      return {
        ...shipment,
        transporterName: transporter?.companyName || 'Unknown',
        transporterDescription: transporter?.companyDescription || '',
        originName: origin?.name || 'Unknown',
        originCountry: origin?.country || 'Unknown',
        destinationName: destination?.name || 'Unknown',
        destinationCountry: destination?.country || 'Unknown',
        discountedPrice: Math.round(shipment.price * 0.9) // قیمت با تخفیف 10%
      };
    }));
    
    return enhancedShipments;
  }

  async searchShipments(params: {
    originId?: number,
    destinationId?: number,
    departureDate?: Date,
    transportType?: string,
    containerType?: string
  }): Promise<Shipment[]> {
    const conditions = [];
    
    conditions.push(eq(shipments.active, true));
    
    if (params.originId) {
      conditions.push(eq(shipments.originId, params.originId));
    }
    
    if (params.destinationId) {
      conditions.push(eq(shipments.destinationId, params.destinationId));
    }
    
    // If transportType is specified, use it; otherwise don't filter by transport type
    // This allows the search to return all transport types (rail, sea, land, mixed)
    if (params.transportType) {
      conditions.push(eq(shipments.transportType, params.transportType));
    }
    
    if (params.containerType) {
      conditions.push(eq(shipments.containerType, params.containerType));
    }
    
    // Handle departure date if needed
    if (params.departureDate) {
      // For date comparison, we need to use SQL directly as the date is stored as a string
      const dateStr = params.departureDate.toISOString().split('T')[0];
      conditions.push(sql`${shipments.departureDate} = ${dateStr}`);
    }
    
    // Selecting specific columns to avoid issues with missing columns
    return db.select({
      id: shipments.id,
      transporterId: shipments.transporterId,
      originId: shipments.originId,
      destinationId: shipments.destinationId,
      departureDate: shipments.departureDate,
      arrivalDate: shipments.arrivalDate,
      transportType: shipments.transportType,
      containerType: shipments.containerType,
      capacity: shipments.capacity,
      price: shipments.price,
      insuranceAvailable: shipments.insuranceAvailable,
      insurancePrice: shipments.insurancePrice,
      active: shipments.active,
      specialNotes: shipments.specialNotes,
      isComposite: shipments.isComposite,
      createdAt: shipments.createdAt
    }).from(shipments).where(and(...conditions));
  }

  async createShipment(insertShipment: InsertShipment): Promise<Shipment> {
    const [shipment] = await db.insert(shipments).values(insertShipment).returning();
    return shipment;
  }

  async updateShipment(id: number, shipmentData: Partial<Shipment>): Promise<Shipment | undefined> {
    const [updatedShipment] = await db.update(shipments)
      .set(shipmentData)
      .where(eq(shipments.id, id))
      .returning();
    return updatedShipment;
  }

  // Shipment Segment operations
  async getShipmentSegments(shipmentId: number): Promise<ShipmentSegment[]> {
    return await db.select().from(shipmentSegments)
      .where(eq(shipmentSegments.shipmentId, shipmentId))
      .orderBy(shipmentSegments.segmentOrder);
  }
  
  async getShipmentSegment(id: number): Promise<ShipmentSegment | undefined> {
    const [segment] = await db.select().from(shipmentSegments).where(eq(shipmentSegments.id, id));
    return segment;
  }
  
  async createShipmentSegment(segment: InsertShipmentSegment): Promise<ShipmentSegment> {
    const [createdSegment] = await db.insert(shipmentSegments).values(segment).returning();
    return createdSegment;
  }
  
  async updateShipmentSegment(id: number, segmentData: Partial<ShipmentSegment>): Promise<ShipmentSegment | undefined> {
    const [updatedSegment] = await db.update(shipmentSegments)
      .set(segmentData)
      .where(eq(shipmentSegments.id, id))
      .returning();
    return updatedSegment;
  }
  
  async deleteShipmentSegment(id: number): Promise<boolean> {
    const result = await db.delete(shipmentSegments).where(eq(shipmentSegments.id, id)).returning();
    return result.length > 0;
  }

  // Booking operations
  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking;
  }

  async getBookingsByUserId(userId: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.userId, userId));
  }

  async getBookingsByShipmentId(shipmentId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.shipmentId, shipmentId));
  }
  
  async getAllBookings(): Promise<Booking[]> {
    return await db.select().from(bookings);
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const [booking] = await db.insert(bookings).values(insertBooking).returning();
    return booking;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const [updatedBooking] = await db.update(bookings)
      .set({ status })
      .where(eq(bookings.id, id))
      .returning();
    return updatedBooking;
  }

  // Ticket operations
  async getTicket(id: number): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.id, id));
    return ticket;
  }

  async getTicketsByUserId(userId: string): Promise<Ticket[]> {
    return await db.select().from(tickets).where(eq(tickets.userId, userId));
  }

  async getAllTickets(): Promise<Ticket[]> {
    return await db.select().from(tickets);
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const [ticket] = await db.insert(tickets).values(insertTicket).returning();
    return ticket;
  }

  async updateTicketStatus(id: number, status: string): Promise<Ticket | undefined> {
    const [updatedTicket] = await db.update(tickets)
      .set({ status })
      .where(eq(tickets.id, id))
      .returning();
    return updatedTicket;
  }

  // Ticket Response operations
  async getTicketResponses(ticketId: number): Promise<TicketResponse[]> {
    return await db.select().from(ticketResponses).where(eq(ticketResponses.ticketId, ticketId));
  }

  async createTicketResponse(insertResponse: InsertTicketResponse): Promise<TicketResponse> {
    const [response] = await db.insert(ticketResponses).values(insertResponse).returning();
    return response;
  }

  // Document operations
  async getDocumentsByUserId(userId: string): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.userId, userId));
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const [document] = await db.insert(documents).values(insertDocument).returning();
    return document;
  }

  async updateDocumentVerification(id: number, verified: boolean): Promise<Document | undefined> {
    const [updatedDocument] = await db.update(documents)
      .set({ verified })
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument;
  }

  // Blog operations
  async getBlogPost(id: number): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post;
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug));
    return post;
  }

  async getAllBlogPosts(publishedOnly: boolean): Promise<BlogPost[]> {
    if (publishedOnly) {
      return await db.select().from(blogPosts)
        .where(eq(blogPosts.published, true))
        .orderBy(desc(blogPosts.createdAt));
    }
    return await db.select().from(blogPosts).orderBy(desc(blogPosts.createdAt));
  }

  async createBlogPost(insertPost: InsertBlogPost): Promise<BlogPost> {
    const [post] = await db.insert(blogPosts).values(insertPost).returning();
    return post;
  }

  async updateBlogPost(id: number, postData: Partial<BlogPost>): Promise<BlogPost | undefined> {
    const [updatedPost] = await db.update(blogPosts)
      .set(postData)
      .where(eq(blogPosts.id, id))
      .returning();
    return updatedPost;
  }
  
  // Shipping Rate operations
  async getShippingRate(id: number): Promise<ShippingRate | undefined> {
    const [rate] = await db.select().from(shippingRates).where(eq(shippingRates.id, id));
    return rate;
  }

  async getShippingRateByRoute(originId: number, destinationId: number, transportType: string): Promise<ShippingRate | undefined> {
    const [rate] = await db.select().from(shippingRates).where(
      and(
        eq(shippingRates.originId, originId),
        eq(shippingRates.destinationId, destinationId),
        eq(shippingRates.transportType, transportType)
      )
    );
    return rate;
  }
  
  async getAllShippingRates(): Promise<ShippingRate[]> {
    return await db.select().from(shippingRates);
  }
  
  async createShippingRate(insertRate: InsertShippingRate): Promise<ShippingRate> {
    const [rate] = await db.insert(shippingRates).values(insertRate).returning();
    return rate;
  }
  
  async updateShippingRate(id: number, rateData: Partial<ShippingRate>): Promise<ShippingRate | undefined> {
    const [updatedRate] = await db.update(shippingRates)
      .set(rateData)
      .where(eq(shippingRates.id, id))
      .returning();
    return updatedRate;
  }

  // Verification Code operations
  async createVerificationCode(code: InsertVerificationCode): Promise<VerificationCode> {
    const [newCode] = await db.insert(verificationCodes).values(code).returning();
    return newCode;
  }

  async getVerificationCode(userId: number, type: string, code: string): Promise<VerificationCode | undefined> {
    const [verificationCode] = await db.select()
      .from(verificationCodes)
      .where(
        and(
          eq(verificationCodes.userId, userId),
          eq(verificationCodes.verificationType, type),
          eq(verificationCodes.code, code),
          eq(verificationCodes.used, false)
        )
      );
    return verificationCode;
  }

  async markVerificationCodeAsUsed(id: number): Promise<boolean> {
    const [updatedCode] = await db.update(verificationCodes)
      .set({ used: true })
      .where(eq(verificationCodes.id, id))
      .returning();
    return !!updatedCode;
  }

  async verifyUserEmail(userId: number): Promise<boolean> {
    const [updatedUser] = await db.update(users)
      .set({ emailVerified: true })
      .where(eq(users.id, userId))
      .returning();
    return !!updatedUser;
  }

  async verifyUserPhone(userId: number): Promise<boolean> {
    const [updatedUser] = await db.update(users)
      .set({ phoneVerified: true })
      .where(eq(users.id, userId))
      .returning();
    return !!updatedUser;
  }
}

// Use the database storage instead of memory storage
export const storage = new MemStorage();
