import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { db } from "./db";
import { users, locations, blogPosts } from "../shared/schema";
import { eq } from "drizzle-orm";

// Hash password function (duplicated from auth.ts to avoid circular dependencies)
const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Initialize default locations
async function initializeLocations() {
  console.log("Initializing locations...");
  
  const locationData = [
    { name: "بندرعباس", type: "port", country: "Iran", city: "بندرعباس", coordinates: "27.183708,56.277447" },
    { name: "بندر امام خمینی", type: "port", country: "Iran", city: "بندر امام خمینی", coordinates: "30.425761,49.098362" },
    { name: "بندر چابهار", type: "port", country: "Iran", city: "چابهار", coordinates: "25.292506,60.651592" },
    { name: "تهران", type: "inland", country: "Iran", city: "تهران", coordinates: "35.689198,51.388974" },
    { name: "مشهد", type: "inland", country: "Iran", city: "مشهد", coordinates: "36.310699,59.599457" },
    { name: "اصفهان", type: "inland", country: "Iran", city: "اصفهان", coordinates: "32.654629,51.667984" },
    { name: "تبریز", type: "inland", country: "Iran", city: "تبریز", coordinates: "38.066673,46.300056" },
    { name: "شیراز", type: "inland", country: "Iran", city: "شیراز", coordinates: "29.591768,52.583698" },
    { name: "ایستگاه تهران", type: "rail_station", country: "Iran", city: "تهران", coordinates: "35.706973,51.414873" },
    { name: "ایستگاه مشهد", type: "rail_station", country: "Iran", city: "مشهد", coordinates: "36.310699,59.599457" },
    { name: "دبی", type: "port", country: "UAE", city: "دبی", coordinates: "25.276987,55.296249" },
    { name: "استانبول", type: "port", country: "Turkey", city: "استانبول", coordinates: "41.013611,28.955" }
  ];
  
  const existingLocations = await db.select().from(locations);
  
  // Only insert locations that don't already exist
  for (const location of locationData) {
    const exists = existingLocations.some(existingLoc => existingLoc.name === location.name);
    if (!exists) {
      await db.insert(locations).values(location);
    }
  }
  
  console.log("Locations initialized successfully");
}

// Create admin user
async function createAdminUser() {
  console.log("Creating admin user...");
  
  // Hash the password
  const hashedPassword = await hashPassword("admin123");
  
  const adminUser = {
    username: "admin",
    password: hashedPassword,
    email: "admin@logistino.com",
    phone: "09123456789",
    fullName: "مدیر سیستم",
    userType: "admin",
    role: "admin"
  };
  
  // Check if admin already exists
  const existingAdmins = await db.select().from(users).where(eq(users.username, "admin"));
  
  if (existingAdmins.length === 0) {
    // Create the admin user
    const [admin] = await db.insert(users).values(adminUser).returning();
    console.log("Admin user created successfully");
    return admin;
  } else {
    console.log("Admin user already exists");
    return existingAdmins[0];
  }
}

// Sample blog post
async function createSampleBlogPost(adminUser: { id: number }) {
  console.log("Creating sample blog post...");
  
  if (!adminUser || !adminUser.id) {
    console.log("Admin user not found, skipping blog post creation");
    return;
  }
  
  const samplePost = {
    title: "به وبسایت لجستینو خوش آمدید",
    slug: "welcome-to-logistino",
    content: `<p>به وبسایت لجستینو خوش آمدید!</p>
<p>لجستینو پلتفرم جامع حمل و نقل بار در ایران است که با هدف تسهیل فرآیند حمل و نقل و اتصال مستقیم صاحبان کالا با شرکت‌های حمل و نقل ایجاد شده است.</p>
<p>از طریق لجستینو می‌توانید:</p>
<ul>
<li>سرویس‌های حمل و نقل دریایی، زمینی و ریلی را جستجو کنید</li>
<li>بهترین قیمت‌ها را مقایسه کنید</li>
<li>به صورت آنلاین رزرو کنید</li>
<li>محموله خود را به صورت لحظه‌ای ردیابی کنید</li>
</ul>
<p>اگر شرکت حمل و نقل هستید، می‌توانید در لجستینو ثبت‌نام کنید و سرویس‌های خود را ارائه دهید.</p>`,
    excerpt: "آشنایی با پلتفرم لجستینو و خدماتی که ارائه می‌دهد",
    authorId: adminUser.id,
    featuredImage: "/images/ship.jpg",
    published: true
  };
  
  // Check if post already exists
  const existingPosts = await db.select().from(blogPosts).where(eq(blogPosts.slug, "welcome-to-logistino"));
  
  if (existingPosts.length === 0) {
    await db.insert(blogPosts).values({
      ...samplePost,
      createdAt: new Date(),
      updatedAt: new Date()
    });
    console.log("Sample blog post created successfully");
  } else {
    console.log("Sample blog post already exists");
  }
}

// Main initialization function
async function main() {
  try {
    await initializeLocations();
    const adminUser = await createAdminUser();
    await createSampleBlogPost(adminUser);
    console.log("Database initialization completed successfully");
  } catch (error) {
    console.error("Error initializing database:", error);
  }
}

// Run initialization immediately when imported
main();

export { main as initializeDatabase, hashPassword };