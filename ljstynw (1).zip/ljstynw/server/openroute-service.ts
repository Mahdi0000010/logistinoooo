/**
 * سرویس OpenRouteService برای محاسبه مسیر و فاصله بین مکان‌ها
 */
import axios from 'axios';
import { db } from './db';
import { sql } from 'drizzle-orm';
import { geoCoordinates } from './distance-data';

// اطمینان حاصل می‌کنیم که کلید API کامل است
const OPENROUTE_API_KEY = process.env.OPENROUTE_API_KEY;
if (!OPENROUTE_API_KEY) {
  console.error('OpenRoute API key is missing. Please set OPENROUTE_API_KEY environment variable.');
}
const BASE_URL = 'https://api.openrouteservice.org/v2';

// تنظیم مدت زمان انتظار برای درخواست‌ها
const axiosConfig = {
  timeout: 10000, // 10 ثانیه مهلت برای هر درخواست
  headers: {
    'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
    'Authorization': OPENROUTE_API_KEY,
    'Content-Type': 'application/json; charset=utf-8'
  }
};

// نوع داده برای تبدیل نام مکان به مختصات جغرافیایی
interface GeocodeResult {
  lat: number;
  lng: number;
}

// نوع داده برای ذخیره مسیر در پایگاه داده
interface RouteData {
  from: string;
  to: string;
  distance: number;
  duration: number;
  transportType: string;
  geometry?: string; // GeoJSON خط مسیر
}

/**
 * تبدیل نام مکان به مختصات جغرافیایی
 * اول در پایگاه داده خودمان جستجو می‌کند، سپس به API خارجی مراجعه می‌کند
 */
export async function geocodeLocation(locationName: string): Promise<GeocodeResult | null> {
  try {
    // ابتدا در پایگاه داده مختصات فعلی جستجو می‌کنیم
    if (geoCoordinates[locationName]) {
      return geoCoordinates[locationName];
    }
    
    // جستجو در جدول مکان‌ها
    const query = sql`
      SELECT latitude, longitude FROM locations 
      WHERE name = ${locationName} AND latitude IS NOT NULL AND longitude IS NOT NULL
      LIMIT 1
    `;
    
    const result = await db.execute(query);
    
    // اگر در پایگاه داده یافت شد
    if (result.rows && result.rows.length > 0) {
      const location = result.rows[0];
      // بررسی وجود مقادیر مختصات
      if (location && typeof location.latitude !== 'undefined' && typeof location.longitude !== 'undefined') {
        // تبدیل نوع به عدد با کنترل بیشتر
        const lat = typeof location.latitude === 'string' ? parseFloat(location.latitude) : Number(location.latitude);
        const lng = typeof location.longitude === 'string' ? parseFloat(location.longitude) : Number(location.longitude);
        
        if (!isNaN(lat) && !isNaN(lng)) {
          return { lat, lng };
        }
      }
      console.error(`Invalid coordinates for location ${locationName}: ${JSON.stringify(location)}`);
    }
    
    // اگر در پایگاه داده نبود، از سرویس جئوکدینگ استفاده می‌کنیم
    console.log(`Geocoding location: ${locationName} using OpenRouteService API`);
    // بررسی کنیم مسیر API صحیح باشد
    const response = await axios.get(`${BASE_URL}/geocode/search`, {
      params: {
        text: locationName,
        size: 1
      },
      headers: {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
        'Authorization': OPENROUTE_API_KEY,
        'Content-Type': 'application/json; charset=utf-8'
      }
    });
    
    if (response.data && response.data.features && response.data.features.length > 0) {
      const coordinates = response.data.features[0].geometry.coordinates;
      return {
        lat: coordinates[1],
        lng: coordinates[0]
      };
    }
    
    return null;
  } catch (error: any) {
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      console.error(`Error geocoding location ${locationName}: API responded with status ${error.response.status}`);
      console.error(`Response data:`, error.response.data);
    } else if (error.request) {
      // The request was made but no response was received
      console.error(`Error geocoding location ${locationName}: No response received from API`);
    } else {
      // Something happened in setting up the request that triggered an Error
      console.error(`Error geocoding location ${locationName}: ${error.message}`);
    }
    return null;
  }
}

/**
 * محاسبه مسیر بین دو مکان با استفاده از OpenRouteService
 */
export async function calculateRoute(
  fromLocation: string,
  toLocation: string,
  transportType: string = 'driving-car'
): Promise<RouteData | null> {
  try {
    // ابتدا بررسی می‌کنیم آیا این مسیر قبلاً محاسبه شده است
    const cacheQuery = sql`
      SELECT * FROM cached_routes 
      WHERE from_location = ${fromLocation} 
      AND to_location = ${toLocation} 
      AND transport_type = ${transportType}
      LIMIT 1
    `;
    
    try {
      const cachedResult = await db.execute(cacheQuery);
      if (cachedResult.rows && cachedResult.rows.length > 0) {
        const route = cachedResult.rows[0];
        console.log(`Using cached route data for ${fromLocation} to ${toLocation}`);
        // تبدیل نوع با کنترل بیشتر
        const distanceValue = route.distance as string | number;
        const durationValue = route.duration as string | number;
        const distance = typeof distanceValue === 'string' ? parseFloat(distanceValue) : Number(distanceValue);
        const duration = typeof durationValue === 'string' ? parseFloat(durationValue) : Number(durationValue);
        
        if (isNaN(distance) || isNaN(duration)) {
          console.error(`Invalid cached route data for ${fromLocation} to ${toLocation}: ${JSON.stringify(route)}`);
          // حذف رکورد نامعتبر از جدول کش
          try {
            await db.execute(sql`
              DELETE FROM cached_routes 
              WHERE from_location = ${fromLocation} 
              AND to_location = ${toLocation} 
              AND transport_type = ${transportType}
            `);
          } catch (deleteError) {
            console.error('Error deleting invalid cache entry:', deleteError);
          }
        } else {
          const fromLocation = route.from_location as string;
          const toLocation = route.to_location as string;
          const transportType = route.transport_type as string;
          const geometry = route.geometry as string | undefined;
          
          return {
            from: fromLocation,
            to: toLocation,
            distance: distance,
            duration: duration,
            transportType: transportType,
            geometry: geometry
          };
        }
      }
    } catch (error) {
      // اگر جدول کش وجود نداشت، خطا را نادیده می‌گیریم و ادامه می‌دهیم
      console.log('Cache table might not exist yet, continuing with API call');
    }
    
    // اگر هر دو مکان بندر باشند، برای مسیر دریایی محاسبه خط مستقیم انجام می‌دهیم
    const isPortFrom = fromLocation.includes('بندر') || fromLocation.toLowerCase().includes('port');
    const isPortTo = toLocation.includes('بندر') || toLocation.toLowerCase().includes('port');
    
    if (isPortFrom && isPortTo && transportType === 'sea') {
      // مختصات دو بندر را می‌گیریم
      const fromCoords = await geocodeLocation(fromLocation);
      const toCoords = await geocodeLocation(toLocation);
      
      if (fromCoords && toCoords) {
        // محاسبه فاصله مستقیم با فرمول هاورساین
        const distance = calculateHaversineDistance(fromCoords, toCoords);
        // تخمین زمان سفر دریایی (با فرض سرعت متوسط 25 کیلومتر بر ساعت)
        const duration = Math.round(distance / 25 * 60); // دقیقه
        
        // ذخیره نتیجه در کش
        try {
          await db.execute(sql`
            INSERT INTO cached_routes (from_location, to_location, distance, duration, transport_type, created_at)
            VALUES (${fromLocation}, ${toLocation}, ${distance}, ${duration}, 'sea', NOW())
          `);
        } catch (error) {
          console.error('Error saving sea route to cache:', error);
          // خطا را نادیده می‌گیریم و ادامه می‌دهیم
        }
        
        return {
          from: fromLocation,
          to: toLocation,
          distance,
          duration,
          transportType: 'sea'
        };
      }
    }
    
    // تبدیل نام مکان‌ها به مختصات جغرافیایی
    const fromCoords = await geocodeLocation(fromLocation);
    const toCoords = await geocodeLocation(toLocation);
    
    if (!fromCoords || !toCoords) {
      console.error(`Could not geocode one of the locations: ${fromLocation} or ${toLocation}`);
      return null;
    }
    
    // تبدیل نوع حمل و نقل به پارامتر مناسب برای API
    let profileParam = 'driving-car';
    if (transportType === 'rail') {
      // برای راه آهن، معادل دقیقی وجود ندارد، از مسیر جاده استفاده می‌کنیم
      profileParam = 'driving-hgv';
    } else if (transportType.startsWith('land')) {
      // برای حمل و نقل زمینی با کامیون
      profileParam = 'driving-hgv';
    }
    
    // فراخوانی API برای محاسبه مسیر
    const response = await axios.get(`${BASE_URL}/directions/${profileParam}`, {
      params: {
        start: `${fromCoords.lng},${fromCoords.lat}`,
        end: `${toCoords.lng},${toCoords.lat}`
      },
      headers: {
        'Accept': 'application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8',
        'Authorization': OPENROUTE_API_KEY,
        'Content-Type': 'application/json; charset=utf-8'
      }
    });
    
    if (response.data && response.data.routes && response.data.routes.length > 0) {
      const route = response.data.routes[0];
      const distance = route.summary.distance / 1000; // تبدیل به کیلومتر
      const duration = Math.round(route.summary.duration / 60); // تبدیل به دقیقه
      
      // ذخیره نتیجه در کش
      try {
        await db.execute(sql`
          INSERT INTO cached_routes (from_location, to_location, distance, duration, transport_type, geometry, created_at)
          VALUES (${fromLocation}, ${toLocation}, ${distance}, ${duration}, ${transportType}, ${JSON.stringify(route.geometry)}, NOW())
        `);
      } catch (error) {
        console.error('Error saving route to cache:', error);
        // خطا را نادیده می‌گیریم و ادامه می‌دهیم
      }
      
      return {
        from: fromLocation,
        to: toLocation,
        distance,
        duration,
        transportType,
        geometry: JSON.stringify(route.geometry)
      };
    }
    
    return null;
  } catch (error) {
    console.error(`Error calculating route from ${fromLocation} to ${toLocation}:`, error);
    return null;
  }
}

/**
 * محاسبه فاصله هوایی بین دو نقطه با استفاده از فرمول هاورساین
 */
function calculateHaversineDistance(from: GeocodeResult, to: GeocodeResult): number {
  const R = 6371; // شعاع زمین به کیلومتر
  const dLat = toRadians(to.lat - from.lat);
  const dLon = toRadians(to.lng - from.lng);
  
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(toRadians(from.lat)) * Math.cos(toRadians(to.lat)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c; // فاصله به کیلومتر
  
  return Math.round(distance);
}

// تبدیل درجه به رادیان
function toRadians(degrees: number): number {
  return degrees * Math.PI / 180;
}

/**
 * ایجاد جدول کش برای ذخیره مسیرهای محاسبه شده
 */
export async function initializeRouteCacheTable(): Promise<void> {
  try {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS cached_routes (
        id SERIAL PRIMARY KEY,
        from_location TEXT NOT NULL,
        to_location TEXT NOT NULL,
        distance NUMERIC NOT NULL,
        duration NUMERIC NOT NULL,
        transport_type TEXT NOT NULL,
        geometry TEXT,
        created_at TIMESTAMP NOT NULL,
        UNIQUE(from_location, to_location, transport_type)
      )
    `);
    console.log('Route cache table created or already exists');
  } catch (error) {
    console.error('Error creating route cache table:', error);
  }
}
