import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request, Response, NextFunction } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { z } from "zod";

// تعریف اطلاعات کاربر در پاسپورت
declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      email: string;
      fullName: string;
      userType: string;
      role: string;
      phone?: string;
    }
  }
}

const scryptAsync = promisify(scrypt);

// تابع رمزنگاری پسورد - صادر شده برای استفاده در routes.ts
export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// تابع مقایسه پسورد - صادر شده برای استفاده در routes.ts
export async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// اسکیماهای اعتبارسنجی برای ثبت‌نام - صادر شده برای استفاده در routes.ts
export const registerSchema = z.object({
  username: z.string().min(3, "نام کاربری باید حداقل 3 کاراکتر باشد"),
  email: z.string().email("ایمیل وارد شده معتبر نیست"),
  password: z.string().min(6, "رمز عبور باید حداقل 6 کاراکتر باشد"),
  fullName: z.string().min(3, "نام و نام خانوادگی باید حداقل 3 کاراکتر باشد"),
  phone: z.string().min(10, "شماره تلفن باید حداقل 10 رقم باشد"),
  userType: z.enum(["user", "transporter"]).default("user"),
});

// اسکیمای اعتبارسنجی برای ورود با نام کاربری
const loginUsernameSchema = z.object({
  username: z.string().min(3, "نام کاربری باید حداقل 3 کاراکتر باشد"),
  password: z.string().min(6, "رمز عبور باید حداقل 6 کاراکتر باشد"),
});

// اسکیمای اعتبارسنجی برای ورود با ایمیل
const loginEmailSchema = z.object({
  email: z.string().email("ایمیل وارد شده معتبر نیست"),
  password: z.string().min(6, "رمز عبور باید حداقل 6 کاراکتر باشد"),
});

// اسکیمای اعتبارسنجی برای ورود با شماره تلفن
const loginPhoneSchema = z.object({
  phone: z.string().min(10, "شماره تلفن باید حداقل 10 رقم باشد"),
  password: z.string().min(6, "رمز عبور باید حداقل 6 کاراکتر باشد"),
});

// اسکیمای ترکیبی برای ورود
const loginSchema = z.discriminatedUnion('loginType', [
  z.object({ loginType: z.literal('username'), ...loginUsernameSchema.shape }),
  z.object({ loginType: z.literal('email'), ...loginEmailSchema.shape }),
  z.object({ loginType: z.literal('phone'), ...loginPhoneSchema.shape }),
]);

export function setupAuth(app: Express) {
  // تنظیمات سشن
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "logistino-session-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore, // باید در storage.ts پیاده‌سازی شود
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 7 * 24 * 60 * 60 * 1000, // یک هفته
    },
  };

  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // استراتژی لوکال با پشتیبانی از نام کاربری
  passport.use('local-username', 
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "نام کاربری یا رمز عبور اشتباه است" });
        }
        
        // حذف پسورد قبل از سریالایز کردن
        const { password: _, ...userWithoutPassword } = user;
        return done(null, userWithoutPassword);
      } catch (error) {
        return done(error);
      }
    }),
  );

  // استراتژی ورود با ایمیل
  passport.use('local-email', 
    new LocalStrategy({ usernameField: 'email' }, async (email, password, done) => {
      try {
        const user = await storage.getUserByEmail(email);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "ایمیل یا رمز عبور اشتباه است" });
        }
        
        // حذف پسورد قبل از سریالایز کردن
        const { password: _, ...userWithoutPassword } = user;
        return done(null, userWithoutPassword);
      } catch (error) {
        return done(error);
      }
    }),
  );

  // استراتژی ورود با شماره تلفن
  passport.use('local-phone', 
    new LocalStrategy({ usernameField: 'phone' }, async (phone, password, done) => {
      try {
        const user = await storage.getUserByPhone(phone);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "شماره تلفن یا رمز عبور اشتباه است" });
        }
        
        // حذف پسورد قبل از سریالایز کردن
        const { password: _, ...userWithoutPassword } = user;
        return done(null, userWithoutPassword);
      } catch (error) {
        return done(error);
      }
    }),
  );

  // سریالایز و دیسریالایز کردن کاربر
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      
      // حذف پسورد قبل از ارسال به کلاینت
      const { password: _, ...userWithoutPassword } = user;
      done(null, userWithoutPassword);
    } catch (error) {
      done(error);
    }
  });

  // API ثبت‌نام با اطلاعات کاربری
  app.post("/api/auth/register", async (req, res) => {
    try {
      // صریحاً تنظیم نوع محتوا به JSON
      res.setHeader('Content-Type', 'application/json');
      
      // اعتبارسنجی داده‌های ورودی
      const validatedData = registerSchema.parse(req.body);
      
      console.log("Register data received:", { 
        username: validatedData.username, 
        email: validatedData.email,
        userType: validatedData.userType 
      });
      
      // بررسی یکتا بودن نام کاربری
      const existingUsername = await storage.getUserByUsername(validatedData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "این نام کاربری قبلاً استفاده شده است" });
      }
      
      // بررسی یکتا بودن ایمیل
      const existingEmail = await storage.getUserByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "این ایمیل قبلاً استفاده شده است" });
      }
      
      // بررسی یکتا بودن شماره تلفن
      const existingPhone = await storage.getUserByPhone(validatedData.phone);
      if (existingPhone) {
        return res.status(400).json({ message: "این شماره تلفن قبلاً استفاده شده است" });
      }
      
      // ساخت کاربر جدید
      const hashedPassword = await hashPassword(validatedData.password);
      const newUser = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
        role: validatedData.userType === "transporter" ? "transporter" : "user",
        verified: false,
        company: null,
      });
      
      // حذف فیلد پسورد قبل از ارسال به کلاینت
      const { password: _, ...userWithoutPassword } = newUser;
      
      console.log("User created successfully:", {
        id: userWithoutPassword.id,
        username: userWithoutPassword.username,
        userType: userWithoutPassword.userType
      });
      
      // لاگین خودکار پس از ثبت‌نام
      req.login(userWithoutPassword, (err) => {
        if (err) {
          console.error("Auto-login error:", err);
          return res.status(500).json({ message: "خطا در ورود به سیستم پس از ثبت‌نام" });
        }
        return res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        // برگرداندن خطاهای اعتبارسنجی
        console.error("Validation error:", error.errors);
        return res.status(400).json({ 
          message: "خطا در اعتبارسنجی داده‌ها", 
          errors: error.errors 
        });
      }
      console.error("Register error:", error);
      return res.status(500).json({ message: "خطا در ثبت‌نام. لطفاً دوباره تلاش کنید" });
    }
  });

  // API ورود با اطلاعات کاربری (نام کاربری، ایمیل یا شماره تلفن)
  app.post("/api/auth/login", (req, res, next) => {
    try {
      // صریحاً تنظیم نوع محتوا به JSON
      res.setHeader('Content-Type', 'application/json');
      
      // اعتبارسنجی داده‌های ورودی
      const validatedData = loginSchema.parse(req.body);
      
      console.log("Login attempt:", { 
        loginType: validatedData.loginType,
        // نمایش بخشی از اطلاعات برای لاگ (بدون نمایش رمز عبور)
        identifier: validatedData.loginType === 'username' ? validatedData.username : 
                    validatedData.loginType === 'email' ? validatedData.email : 
                    validatedData.loginType === 'phone' ? validatedData.phone : 'unknown'
      });
      
      let strategy = 'local-username'; // استراتژی پیش‌فرض
      
      // بررسی نوع لاگین بر اساس loginType
      switch (validatedData.loginType) {
        case 'username':
          strategy = 'local-username';
          break;
        case 'email':
          strategy = 'local-email';
          break;
        case 'phone':
          strategy = 'local-phone';
          break;
      }
      
      passport.authenticate(strategy, (err: Error | null, user: Express.User | false, info: { message: string } | undefined) => {
        if (err) {
          console.error("Login authentication error:", err);
          return next(err);
        }
        if (!user) {
          console.log("Login failed: Invalid credentials");
          return res.status(401).json({ message: info?.message || "اطلاعات ورود نامعتبر است" });
        }
        
        req.login(user, (loginErr) => {
          if (loginErr) {
            console.error("Login session error:", loginErr);
            return next(loginErr);
          }
          console.log("Login successful for user:", user.username);
          return res.json(user);
        });
      })(req, res, next);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Login validation error:", error.errors);
        return res.status(400).json({ 
          message: "خطا در اعتبارسنجی داده‌ها", 
          errors: error.errors 
        });
      }
      console.error("Login unexpected error:", error);
      next(error);
    }
  });

  // API لاگ‌اوت
  app.post("/api/auth/logout", (req, res) => {
    // صریحاً تنظیم نوع محتوا به JSON
    res.setHeader('Content-Type', 'application/json');
    
    if (req.isAuthenticated()) {
      console.log("Logout request for user:", (req.user as any).username);
    }
    
    req.logout((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "خطا در خروج از سیستم" });
      }
      console.log("User logged out successfully");
      res.status(200).json({ message: "با موفقیت از سیستم خارج شدید" });
    });
  });

  // API دریافت اطلاعات کاربر جاری
  app.get("/api/auth/user", (req, res) => {
    // صریحاً تنظیم نوع محتوا به JSON
    res.setHeader('Content-Type', 'application/json');
    
    if (req.isAuthenticated()) {
      console.log("User info requested:", (req.user as any).username);
      return res.json(req.user);
    }
    
    console.log("User info requested: not authenticated");
    return res.status(401).json({ message: "Unauthorized" });
  });
}

// میدلور برای محافظت از مسیرهای مخصوص کاربران احراز هویت شده

export const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated()) {
    return next();
  }
  return res.status(401).json({ message: "دسترسی غیرمجاز. لطفاً وارد سیستم شوید" });
};

// میدلور برای محافظت از مسیرهای مخصوص ادمین‌ها
export const isAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated() && req.user && (req.user as any).role === "admin") {
    return next();
  }
  return res.status(403).json({ message: "دسترسی غیرمجاز. فقط مدیران دسترسی دارند" });
};

// میدلور برای محافظت از مسیرهای مخصوص شرکت‌های حمل و نقل
export const isTransporter = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated() && req.user && ((req.user as any).role === "transporter" || (req.user as any).role === "admin")) {
    return next();
  }
  return res.status(403).json({ message: "دسترسی غیرمجاز. فقط شرکت‌های حمل و نقل و مدیران دسترسی دارند" });
};