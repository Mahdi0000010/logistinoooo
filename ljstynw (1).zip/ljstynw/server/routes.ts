import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage, MemStorage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { isAdmin, isTransporter } from "./auth";
import { z } from "zod";
import { db } from "./db";
import { sql } from "drizzle-orm";
import { calculateDistanceBetweenCities, estimateDistanceAndDuration, findBestRoute, findPortRoutes, hasRailwayStation, hasDirectRailConnection } from "./distance-data";
import {
  insertShipmentSchema,
  insertShipmentSegmentSchema,
  insertBookingSchema,
  insertTicketSchema,
  insertTicketResponseSchema,
  insertDocumentSchema,
  insertBlogPostSchema,
  insertLocationSchema,
  insertUserSchema
} from "@shared/schema";

// Admin middleware is now imported from auth.ts

// تابع کمکی برای محاسبه قیمت تخمینی
interface PriceResult {
  priceRial: number;
  priceToman: number;
  usedWeight: number; // وزن استفاده شده در محاسبه (کیلوگرم)
  weightInTons: number; // وزن به تن
  rate: number; // نرخ استفاده شده
  vehicleType: string; // نوع وسیله نقلیه محاسبه شده
  vehicleDisplayName: string; // نام نمایشی وسیله نقلیه
  formulaDescription: string; // توضیح فرمول محاسبه
}

/**
 * تابع محاسبه قیمت تخمینی برای حمل و نقل
 * این تابع نسخه ساده شده است که فقط قیمت به تومان را برمی‌گرداند
 * برای جزئیات بیشتر از calculateDetailedPrice استفاده کنید
 * 
 * @param transportType نوع حمل و نقل
 * @param distance فاصله به کیلومتر
 * @param cargoWeight وزن بار به کیلوگرم
 * @param containerType نوع کانتینر (اختیاری)
 * @param containerCount تعداد کانتینر (اختیاری)
 * @param isInternationalRoute آیا مسیر بین‌المللی است (اختیاری)
 * @param landOnlyDistance فاصله بخش زمینی تا بندر (اختیاری)
 * @returns قیمت تخمینی به تومان یا null در صورت عدم امکان محاسبه
 */
function calculateEstimatedPrice(
  transportType: string, 
  distance: number, 
  cargoWeight: number = 7000, 
  containerType?: string, 
  containerCount?: number,
  isInternationalRoute?: boolean,
  landOnlyDistance?: number
): number | null {
  // استفاده از تابع دقیق برای محاسبه جزئیات قیمت
  const detailedPrice = calculateDetailedPrice(
    transportType, 
    distance, 
    cargoWeight, 
    containerType, 
    containerCount,
    isInternationalRoute,
    landOnlyDistance
  );
  
  // اگر قیمت محاسبه نشده باشد (null برگردانده شده باشد) null برگردان
  if (!detailedPrice) {
    return null;
  }
  
  // فقط قیمت به تومان را برگردان (گرد شده به نزدیکترین مضرب 1,000 تومان)
  return Math.round(detailedPrice.priceToman / 1000) * 1000;
}

/**
 * تابع محاسبه دقیق قیمت با جزئیات کامل
 * این تابع برای استفاده در سراسر برنامه جهت یکسان‌سازی محاسبات قیمت استفاده می‌شود
 * @param transportType نوع حمل و نقل (land, rail, sea, mixed یا land_trailer, land_truck و غیره)
 * @param distance فاصله به کیلومتر
 * @param cargoWeight وزن بار به کیلوگرم
 * @param containerType نوع کانتینر (برای حمل و نقل دریایی)
 * @param containerCount تعداد کانتینر (برای حمل و نقل دریایی)
 * @param isInternationalRoute آیا یک مسیر بین‌المللی است (برای مسیرهای با قطعه دریایی)
 * @param landOnlyDistance فاصله بخش زمینی/ریلی تا بندر (برای مسیرهای بین‌المللی)
 * @returns جزئیات کامل محاسبه قیمت یا null در صورت عدم امکان محاسبه
 */
function calculateDetailedPrice(
  transportType: string, 
  distance: number, 
  cargoWeight: number = 7000, 
  containerType?: string, 
  containerCount?: number,
  isInternationalRoute?: boolean,
  landOnlyDistance?: number
): PriceResult | null {
  // نرخ‌های به‌روز بر اساس ریال/تن-کیلومتر یا ریال/کیلوگرم-کیلومتر (نرخ‌های دقیق بازار)
  const baseRates: Record<string, number> = {
    'rail': 34,                // ریلی (ریال به ازای هر کیلوگرم-کیلومتر)
    'land_trailer': 9500,      // تریلی: 9,500 ریال/تن-کیلومتر
    'land_truck': 10000,       // کامیون: 10,000 ریال/تن-کیلومتر
    'land_small_truck': 13500, // خاور: 13,500 ریال/تن-کیلومتر
    'land_pickup': 17500,      // نیسان: 17,500 ریال/تن-کیلومتر
    'land_van': 17500,         // وانت: 17,500 ریال/تن-کیلومتر
    'sea': 5000,               // دریایی (ریال به ازای هر تن-کیلومتر) - توجه: برای دریایی فقط از قیمت‌های واقعی استفاده می‌شود
    'mixed': 10000             // ترکیبی (ریال به ازای هر تن-کیلومتر)
  };
  
  // حداکثر ظرفیت هر نوع وسیله نقلیه (بر حسب کیلوگرم)
  const maxCapacity: Record<string, number> = {
    'land_trailer': 30000,     // تریلی - حداکثر 30 تن
    'land_truck': 20000,       // کامیون - حداکثر 20 تن
    'land_small_truck': 10000, // خاور - حداکثر 10 تن
    'land_pickup': 5000,       // نیسان - حداکثر 5 تن
    'land_van': 2000,          // وانت - حداکثر 2 تن
    'rail': 60000,             // ریلی - حداکثر 60 تن (برای یک واگن)
    'sea': 40000               // دریایی - حداکثر 40 تن (برای یک کانتینر 40 فوت)
  };
  
  // نام‌های نمایشی برای وسایل نقلیه
  const vehicleDisplayNames: Record<string, string> = {
    'land_trailer': 'تریلی',
    'land_truck': 'کامیون',
    'land_small_truck': 'خاور',
    'land_pickup': 'نیسان',
    'land_van': 'وانت',
    'rail': 'واگن باری',
    'sea': 'کانتینر 40 فوت',
    'mixed': 'حمل و نقل ترکیبی'
  };
  
  let rate = 0;
  let calculatedType = transportType;
  let calculatedPriceRial = 0;
  let usedWeight = cargoWeight; // وزن مورد استفاده برای محاسبه قیمت - پیش‌فرض وزن اصلی است
  let intelligentVehicleSelection = false; // آیا انتخاب هوشمند وسیله نقلیه انجام شده است؟
  
  // اگر مسیر بین‌المللی است و فاصله زمینی تا بندر مشخص شده، از آن استفاده کن
  let calculatedDistance = distance;
  if (isInternationalRoute && landOnlyDistance && landOnlyDistance > 0) {
    calculatedDistance = landOnlyDistance;
    console.log(`International route detected - using land/rail distance to port: ${calculatedDistance}km instead of total ${distance}km`);
  }
  
  // اگر کانتینر انتخاب شده باشد، همیشه از تریلی استفاده می‌کنیم
  if (containerType && containerType.startsWith('20_') || containerType?.startsWith('40_')) {
    calculatedType = 'land_trailer';
    // برای کانتینر 40 فوت، ظرفیت 30 تن در نظر می‌گیریم
    const containerCapacity = containerType?.startsWith('40_') ? 30000 : 25000;
    usedWeight = containerCount && containerCount > 1 ? containerCapacity * containerCount : containerCapacity;
    rate = baseRates.land_trailer;
    console.log(`Price Calculation: Container selected, using trailer with capacity ${usedWeight}kg`);
  }
  // انتخاب وسیله نقلیه مناسب و تعیین وزن مورد محاسبه
  else if (transportType.startsWith('land_')) {
    // اگر نوع وسیله نقلیه مشخص شده باشد
    calculatedType = transportType;
    rate = baseRates[calculatedType] || baseRates.land_truck;
    
    // همیشه از حداکثر ظرفیت وسیله نقلیه برای محاسبه قیمت استفاده می‌کنیم
    const capacity = maxCapacity[calculatedType] || 20000;
    usedWeight = capacity; // استفاده از حداکثر ظرفیت وسیله نقلیه
    console.log(`Price Calculation: Using max capacity of ${capacity}kg for ${calculatedType} pricing`);
  }
  else if (transportType === 'land') {
    // انتخاب هوشمند وسیله نقلیه براساس وزن محموله
    intelligentVehicleSelection = true;
    
    if (cargoWeight <= 2000) {
      calculatedType = 'land_van';  // وانت
      // همیشه از حداکثر ظرفیت برای محاسبه استفاده می‌شود
      usedWeight = maxCapacity.land_van;
      console.log(`Price Calculation: Selected van for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    } else if (cargoWeight <= 5000) {
      calculatedType = 'land_pickup';  // نیسان
      // همیشه از حداکثر ظرفیت برای محاسبه استفاده می‌شود
      usedWeight = maxCapacity.land_pickup;
      console.log(`Price Calculation: Selected pickup (Nisan) for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    } else if (cargoWeight <= 10000) {
      calculatedType = 'land_small_truck';  // خاور
      // همیشه از حداکثر ظرفیت برای محاسبه استفاده می‌شود
      usedWeight = maxCapacity.land_small_truck;
      console.log(`Price Calculation: Selected small truck (Khavar) for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    } else if (cargoWeight <= 20000) {
      calculatedType = 'land_truck';  // کامیون
      // همیشه از حداکثر ظرفیت برای محاسبه استفاده می‌شود
      usedWeight = maxCapacity.land_truck;
      console.log(`Price Calculation: Selected truck for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    } else {
      calculatedType = 'land_trailer';  // تریلی
      // همیشه از حداکثر ظرفیت برای محاسبه استفاده می‌شود
      usedWeight = maxCapacity.land_trailer;
      console.log(`Price Calculation: Selected trailer for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    }
    
    rate = baseRates[calculatedType];
  } 
  else if (transportType === 'rail') {
    calculatedType = 'rail';
    rate = baseRates.rail;
    
    // برای حمل و نقل ریلی، از مدل قیمت‌گذاری براساس وزن واقعی استفاده می‌کنیم
    // برخلاف جاده‌ای که براساس ظرفیت وسیله نقلیه است
    
    // حداقل وزن برای هر واگن باری 20 تن در نظر گرفته می‌شود
    if (cargoWeight < 20000) {
      usedWeight = 20000; // حداقل 20 تن (20,000 کیلوگرم) برای اقتصادی بودن حمل ریلی
      console.log(`Price Calculation: Rail transport - Using minimum capacity of ${usedWeight}kg for pricing`);
    } else {
      // استفاده از وزن واقعی برای بارهای بزرگتر
      usedWeight = cargoWeight;
      console.log(`Price Calculation: Rail transport - Using actual weight ${usedWeight}kg for pricing`);
    }
  }
  else if (transportType === 'sea') {
    // برای حمل و نقل دریایی، فقط از قیمت‌های واقعی شرکت‌های حمل و نقل استفاده می‌شود
    // قیمت تخمینی محاسبه نمی‌شود
    console.log(`Sea transport pricing requires actual rates from transport companies - not calculating estimated price`);
    return null; // برگرداندن null به معنی عدم ارائه قیمت تخمینی است
  }
  else {
    // برای حمل و نقل ترکیبی یا سایر موارد
    calculatedType = 'mixed';
    rate = baseRates.mixed;
    // از یک ظرفیت استاندارد برای حالت ترکیبی استفاده می‌کنیم
    const standardMixedCapacity = 25000; // 25 تن
    usedWeight = standardMixedCapacity;
    console.log(`Price Calculation: Using standard mixed capacity of ${usedWeight}kg for pricing`);
    
    // بررسی آیا این یک مسیر ترکیبی بین‌المللی با قطعه دریایی است
    if (isInternationalRoute) {
      console.log(`International mixed route detected - pricing is for land/rail portions to port only`);
    } else {
      // توجه: اگر مسیر ترکیبی شامل قطعه دریایی باشد،
      // این قیمت فقط برای بخش زمینی و ریلی است و قیمت بخش دریایی باید جداگانه تعیین شود
      console.log(`Note: If the mixed route contains sea segments, this price is only for land and rail portions`);
    }
  }
  
  // محاسبه قیمت نهایی با وزن تنظیم شده
  const weightInTons = usedWeight / 1000;  // تبدیل کیلوگرم به تن
  
  if (calculatedType === 'rail') {
    // در حالت ریلی، محاسبه بر اساس کیلوگرم است نه تن
    calculatedPriceRial = usedWeight * calculatedDistance * rate;
  } else {
    // سایر حالت‌ها بر اساس تن محاسبه می‌شوند
    calculatedPriceRial = weightInTons * calculatedDistance * rate;
  }
  
  // محاسبه قیمت به تومان (فقط تقسیم بر 10)
  const calculatedPriceToman = Math.round(calculatedPriceRial / 10);
  
  // ثبت لاگ برای تشخیص مشکلات قیمت‌گذاری
  console.log(`Price Calculation: ${calculatedType} - From ${calculatedPriceRial} Rials to ${calculatedPriceToman} Tomans`);
  
  // ایجاد توضیح فرمول محاسبه
  let formulaDescription = '';
  if (calculatedType === 'rail') {
    // برای حمل و نقل ریلی توضیح بر اساس کیلوگرم
    const formattedWeight = new Intl.NumberFormat('fa-IR').format(usedWeight);
    const formattedDistance = new Intl.NumberFormat('fa-IR').format(distance);
    const formattedRate = new Intl.NumberFormat('fa-IR').format(rate);
    const formattedPrice = new Intl.NumberFormat('fa-IR').format(calculatedPriceToman);
    
    formulaDescription = `${formattedWeight} کیلوگرم × ${formattedDistance} کیلومتر × ${formattedRate} ریال ÷ 10 = ${formattedPrice} تومان`;
  } else {
    // برای سایر حالات توضیح بر اساس تن
    const formattedWeight = new Intl.NumberFormat('fa-IR').format(weightInTons);
    const formattedDistance = new Intl.NumberFormat('fa-IR').format(distance);
    const formattedRate = new Intl.NumberFormat('fa-IR').format(rate);
    const formattedPrice = new Intl.NumberFormat('fa-IR').format(calculatedPriceToman);
    
    formulaDescription = `${formattedWeight} تن × ${formattedDistance} کیلومتر × ${formattedRate} ریال ÷ 10 = ${formattedPrice} تومان`;
  }
  
  // برگرداندن نتایج با جزئیات کامل
  return {
    priceRial: calculatedPriceRial,
    priceToman: calculatedPriceToman,
    usedWeight,
    weightInTons,
    rate,
    vehicleType: calculatedType,
    vehicleDisplayName: vehicleDisplayNames[calculatedType] || 'نامشخص',
    formulaDescription
  };
}

// Import authentication functions from auth.ts
import { registerSchema, hashPassword } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dedicated registration API on a completely different path to avoid conflicts
  app.post("/api_register", async (req, res) => {
    try {
      // Set JSON content type explicitly
      res.setHeader('Content-Type', 'application/json');
      
      // Validate input data
      const validatedData = registerSchema.parse(req.body);
      
      console.log("Direct register data received:", { 
        username: validatedData.username, 
        email: validatedData.email,
        userType: validatedData.userType 
      });
      
      // Check for existing username
      const existingUsername = await storage.getUserByUsername(validatedData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "این نام کاربری قبلاً استفاده شده است" });
      }
      
      // Check for existing email
      const existingEmail = await storage.getUserByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "این ایمیل قبلاً استفاده شده است" });
      }
      
      // Check for existing phone
      const existingPhone = await storage.getUserByPhone(validatedData.phone);
      if (existingPhone) {
        return res.status(400).json({ message: "این شماره تلفن قبلاً استفاده شده است" });
      }
      
      // Create new user
      const hashedPassword = await hashPassword(validatedData.password);
      const newUser = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
        role: validatedData.userType === "transporter" ? "transporter" : "user",
        verified: false,
        company: null,
      });
      
      // Remove password before sending to client
      const { password: _, ...userWithoutPassword } = newUser;
      
      console.log("User created successfully:", {
        id: userWithoutPassword.id,
        username: userWithoutPassword.username,
        userType: userWithoutPassword.userType
      });
      
      // Don't try to auto-login since req.login might not be available
      // Just return the user info
      console.log("User registered successfully (without auto-login)");
      return res.status(201).json({
        ...userWithoutPassword,
        message: "ثبت نام با موفقیت انجام شد. لطفاً وارد سیستم شوید."
      });
    } catch (error) {
      // Handle Zod validation errors
      if (error && (error as any).errors) {
        console.error("Validation error:", (error as any).errors);
        return res.status(400).json({ 
          message: "خطا در اعتبارسنجی داده‌ها", 
          errors: (error as any).errors 
        });
      }
      console.error("Register error:", error);
      return res.status(500).json({ message: "خطا در ثبت‌نام. لطفاً دوباره تلاش کنید" });
    }
  });
  // Set up authentication routes
  await setupAuth(app);
  
  // ایجاد API برای دریافت اطلاعات کاربر جاری
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  
  // API routes
  
  // API برای دریافت سرویس‌های حمل و نقل جدید برای نمایش در صفحه اصلی
  app.get("/api/new-shipments", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 6;
      
      // استفاده از کوئری SQL مستقیم برای دریافت سرویس‌های جدید
      const query = sql`
        SELECT 
          s.id, s.transporter_id as "transporterId", s.origin_id as "originId", 
          s.destination_id as "destinationId", s.departure_date as "departureDate", 
          s.arrival_date as "arrivalDate", s.transport_type as "transportType", 
          s.container_type as "containerType", s.capacity, s.price, 
          s.insurance_available as "insuranceAvailable", 
          s.insurance_price as "insurancePrice", s.active, 
          s.special_notes as "specialNotes", s.created_at as "createdAt",
          t.company_name as "transporterName", 
          t.company_description as "transporterDescription",
          l1.name as "originName", l1.country as "originCountry",
          l2.name as "destinationName", l2.country as "destinationCountry"
        FROM shipments s
        JOIN transporters t ON s.transporter_id = t.id
        JOIN locations l1 ON s.origin_id = l1.id
        JOIN locations l2 ON s.destination_id = l2.id
        WHERE s.active = true
        ORDER BY s.created_at DESC
        LIMIT ${limit}
      `;
      
      const result = await db.execute(query);
      
      if (!result.rows || result.rows.length === 0) {
        return res.json([]);
      }
      
      // ایجاد آبجکت‌های نتیجه بدون محاسبه تخفیف
      const enhancedShipments = result.rows.map((shipment: any) => ({
        ...shipment
      }));
      
      res.json(enhancedShipments);
    } catch (error) {
      console.error("Error fetching new shipments:", error);
      res.status(500).json({ message: "Failed to fetch new shipments" });
    }
  });
  
  // API برای دریافت سرویس‌های حمل و نقل یک ماه اخیر
  app.get("/api/recent-shipments", async (req, res) => {
    try {
      // محاسبه تاریخ یک ماه قبل
      const oneMonthAgo = new Date();
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
      
      // استفاده از کوئری SQL مستقیم برای دریافت سرویس‌های یک ماه اخیر
      const query = sql`
        SELECT 
          s.id, s.transporter_id as "transporterId", s.origin_id as "originId", 
          s.destination_id as "destinationId", s.departure_date as "departureDate", 
          s.arrival_date as "arrivalDate", s.transport_type as "transportType", 
          s.container_type as "containerType", s.capacity, s.price, 
          s.insurance_available as "insuranceAvailable", 
          s.insurance_price as "insurancePrice", s.active,
          s.special_notes as "specialNotes",
          u.full_name as "transporterName", t.company_name as "transporterCompanyName", 
          t.company_description as "transporterDescription",
          l1.name as "originName", l1.country as "originCountry",
          l2.name as "destinationName", l2.country as "destinationCountry"
        FROM shipments s
        JOIN transporters t ON s.transporter_id = t.id
        JOIN users u ON t.user_id = u.id
        JOIN locations l1 ON s.origin_id = l1.id
        JOIN locations l2 ON s.destination_id = l2.id
        WHERE s.active = true
          AND s.created_at >= ${oneMonthAgo.toISOString()}
        ORDER BY s.created_at DESC
      `;
      
      const result = await db.execute(query);
      
      if (!result.rows || result.rows.length === 0) {
        return res.json([]);
      }
      
      // ایجاد آبجکت‌های نتیجه
      const enhancedShipments = result.rows.map((shipment: any) => ({
        ...shipment
      }));
      
      res.json(enhancedShipments);
    } catch (error) {
      console.error("Error fetching recent shipments:", error);
      res.status(500).json({ message: "Failed to fetch recent shipments" });
    }
  });
  
  // Locations API
  app.get("/api/locations", async (req, res) => {
    try {
      const type = req.query.type as string | undefined;
      const locations = type 
        ? await storage.getLocationsByType(type)
        : await storage.getAllLocations();
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch locations" });
    }
  });
  
  // API برای بازنشانی لوکیشن‌ها - جدید
  app.post("/api/locations/reset", isAdmin, async (req, res) => {
    try {
      // حذف تمام لوکیشن‌های موجود و ایجاد مجدد آنها
      if (storage instanceof MemStorage) {
        (storage as MemStorage).resetAndInitializeLocations();
        res.json({ success: true, message: "Locations reset and initialized successfully" });
      } else {
        res.status(400).json({ message: "Reset operation is only available in memory storage mode" });
      }
    } catch (error) {
      console.error("Error resetting locations:", error);
      res.status(500).json({ message: "Failed to reset locations" });
    }
  });
  
  app.get("/api/locations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const location = await storage.getLocation(id);
      if (!location) {
        return res.status(404).json({ message: "Location not found" });
      }
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch location" });
    }
  });
  
  // API برای دریافت جزئیات محموله از طریق مسیریابی هوشمند
  app.get("/api/smart-routing/shipment", async (req, res) => {
    try {
      const fromLocationId = req.query.fromLocationId ? parseInt(req.query.fromLocationId as string) : null;
      const toLocationId = req.query.toLocationId ? parseInt(req.query.toLocationId as string) : null;
      const transportType = req.query.transportType as string || 'land'; // نوع حمل و نقل پیش‌فرض: زمینی
      const cargoWeight = req.query.cargoWeight ? parseInt(req.query.cargoWeight as string) : 7000; // وزن پیش‌فرض: 7 تن
      
      // بررسی پارامترهای ورودی
      if (!fromLocationId || isNaN(fromLocationId) || !toLocationId || isNaN(toLocationId)) {
        return res.status(400).json({
          id: 0,
          transporterId: 0,
          originId: fromLocationId || 0,
          destinationId: toLocationId || 0,
          departureDate: '',
          arrivalDate: '',
          transportType: transportType || 'land',
          containerType: '',
          capacity: cargoWeight || 0,
          price: 0,
          insuranceAvailable: false,
          insurancePrice: 0,
          active: true,
          description: 'محموله یافت نشد - پارامترهای مبدا یا مقصد نامعتبر است',
          isComposite: false,
          smartRouting: true,
          suggested: false,
          error: 'لطفاً مبدا و مقصد را انتخاب کنید'
        });
      }
      
      // دریافت اطلاعات مبدا و مقصد
      const fromLocation = await storage.getLocation(fromLocationId);
      const toLocation = await storage.getLocation(toLocationId);
      
      if (!fromLocation || !toLocation) {
        return res.status(404).json({
          id: 0,
          transporterId: 0,
          originId: fromLocationId || 0,
          destinationId: toLocationId || 0,
          departureDate: '',
          arrivalDate: '',
          transportType: transportType,
          containerType: '',
          capacity: 0,
          price: 0,
          insuranceAvailable: false,
          insurancePrice: 0,
          active: true,
          description: 'محموله یافت نشد - مکان‌ها موجود نیستند',
          isComposite: false,
          smartRouting: true,
          suggested: false
        });
      }
      
      // بررسی اینکه آیا مسیر بین‌المللی است
      const isInternationalRoute = toLocation.country !== "ایران" && 
                                  toLocation.country !== "ایران (Iran)" && 
                                  toLocation.type === "port";
      
      let route;
      let landRouteOnly = false;
      
      // برای مسیرهای بین‌المللی که شامل حمل و نقل دریایی هستند، فقط مسیر تا بندر را محاسبه می‌کنیم
      if (isInternationalRoute && transportType !== 'land' && transportType !== 'rail') {
        // پیدا کردن نزدیکترین بندر ایرانی به مبدا
        const iranianPorts = ["بندرعباس", "بوشهر", "چابهار", "بندر امام خمینی"];
        let nearestPortDistance = Infinity;
        let nearestPortName = "";
        
        for (const portName of iranianPorts) {
          const portRoute = await findBestRoute(fromLocation.name, portName);
          if (portRoute && portRoute.totalDistance < nearestPortDistance) {
            nearestPortDistance = portRoute.totalDistance;
            nearestPortName = portName;
            route = portRoute;
          }
        }
        
        if (route) {
          console.log(`International route detected. Using route to nearest port: ${nearestPortName}, distance: ${nearestPortDistance}km`);
          landRouteOnly = true;
        }
      }
      
      // اگر مسیر به بندر پیدا نشد یا مسیر بین‌المللی نیست، مسیر معمولی را پیدا می‌کنیم
      if (!route) {
        route = await findBestRoute(fromLocation.name, toLocation.name);
      }
      
      if (!route || route.segments.length === 0) {
        return res.status(404).json({
          id: 0,
          transporterId: 0,
          originId: fromLocationId,
          destinationId: toLocationId,
          departureDate: '',
          arrivalDate: '',
          transportType: transportType,
          containerType: '',
          capacity: 0,
          price: 0,
          insuranceAvailable: false,
          insurancePrice: 0,
          active: true,
          description: 'هیچ مسیری بین این دو مکان یافت نشد',
          isComposite: false,
          smartRouting: true,
          suggested: false
        });
      }
      
      // محاسبه شاخص‌های اصلی مسیر
      const totalDistance = route.totalDistance;
      const totalDuration = route.totalDuration;
      
      // تعیین نوع وسیله نقلیه مناسب براساس وزن بار (فقط برای حمل و نقل زمینی)
      let vehicleTypeName = "land_truck"; // مقدار پیش‌فرض
      let vehicleTypeDisplay = "کامیون";
      
      if (transportType === 'land') {
        // اگر در نوع کانتینر کلمه "کانتینر" وجود داشت، حتما از تریلی استفاده می‌کنیم
        const containerTypeParam = req.query.containerType as string | undefined;
        const containerCountParam = req.query.containerCount as string | undefined;
        
        // لاگ کردن اطلاعات کانتینر برای دیباگ
        console.log("Smart Routing API - Container Info:", { 
          containerType: containerTypeParam, 
          containerCount: containerCountParam,
          cargoWeight
        });
        
        if (containerTypeParam && 
            (containerTypeParam.includes('container') || 
             containerTypeParam.includes('کانتینر') || 
             containerTypeParam.includes('20') || 
             containerTypeParam.includes('40'))) {
          console.log("Smart Routing API: Using trailer for container shipment", containerTypeParam);
          vehicleTypeName = 'land_trailer';
          vehicleTypeDisplay = 'تریلی کشنده';
        }
        // در غیر این صورت، بر اساس وزن تصمیم‌گیری می‌کنیم
        else if (cargoWeight > 20000) {
          vehicleTypeName = 'land_trailer';
          vehicleTypeDisplay = 'تریلی';
        } else if (cargoWeight > 10000) {
          vehicleTypeName = 'land_truck';
          vehicleTypeDisplay = 'کامیون';
        } else if (cargoWeight > 5000) {
          vehicleTypeName = 'land_small_truck';
          vehicleTypeDisplay = 'خاور';
        } else if (cargoWeight > 2000) {
          vehicleTypeName = 'land_pickup';
          vehicleTypeDisplay = 'نیسان';
        } else {
          vehicleTypeName = 'land_van';
          vehicleTypeDisplay = 'وانت';
        }
      }
      
      // برای مسیرهای بین‌المللی، توضیحات اضافی نمایش دهیم
      let additionalDescription = '';
      if (landRouteOnly) {
        additionalDescription = ` (فقط مسیر زمینی تا بندر - برای ادامه مسیر دریایی باید از شرکت‌های حمل و نقل استعلام شود)`;
      }
      
      // محاسبه قیمت با استفاده از تابع محاسبه قیمت
      let price = 0;
      let calculatedPrice = 0;
      const weightInTons = cargoWeight / 1000; // تبدیل به تن
      
      // تعریف نرخ‌های به‌روز
      const localBaseRates: Record<string, number> = {
        'rail': 34,                // ریلی (ریال به ازای هر کیلوگرم-کیلومتر)
        'land_trailer': 9500,      // تریلی: 9,500 ریال/تن-کیلومتر
        'land_truck': 10000,       // کامیون: 10,000 ریال/تن-کیلومتر
        'land_small_truck': 13500, // خاور: 13,500 ریال/تن-کیلومتر
        'land_pickup': 17500,      // نیسان: 17,500 ریال/تن-کیلومتر
        'land_van': 17500,         // وانت: 17,500 ریال/تن-کیلومتر
        'sea': 5000,               // دریایی
        'mixed': 10000             // ترکیبی
      };
      
      // محاسبه قیمت براساس نوع حمل و نقل
      if (transportType === 'rail') {
        // برای حمل و نقل ریلی، محاسبه بر اساس کیلوگرم-کیلومتر
        const railRatePerKgKm = localBaseRates.rail; // ریال برای هر کیلوگرم-کیلومتر
        
        // حداقل وزن برای هر واگن باری 20 تن در نظر گرفته می‌شود
        let usedWeight = cargoWeight;
        if (cargoWeight < 20000) {
          usedWeight = 20000; // حداقل 20 تن (20,000 کیلوگرم) برای اقتصادی بودن حمل ریلی
          console.log(`Rail transport - Using minimum capacity of ${usedWeight}kg for economic calculation`);
        }
        
        const exactRailPriceRial = usedWeight * totalDistance * railRatePerKgKm;
        calculatedPrice = exactRailPriceRial / 10; // تبدیل به تومان
        price = Math.round(calculatedPrice / 1000) * 1000; // گرد کردن به نزدیکترین 1000 تومان
      } 
      else if (transportType === 'land') {
        // قیمت زمینی بر اساس نوع وسیله و تن-کیلومتر (نرخ‌های به‌روز بازار)
        // استفاده از نرخ‌های به‌روز از baseRates در بالای فایل
        const landRates: Record<string, number> = {
          'land_trailer': localBaseRates.land_trailer,     // تریلی - نرخ جدید: 9,500 ریال/تن-کیلومتر
          'land_truck': localBaseRates.land_truck,        // کامیون - نرخ جدید: 10,000 ریال/تن-کیلومتر
          'land_small_truck': localBaseRates.land_small_truck, // خاور - نرخ جدید: 13,500 ریال/تن-کیلومتر
          'land_pickup': localBaseRates.land_pickup,      // نیسان - نرخ جدید: 17,500 ریال/تن-کیلومتر
          'land_van': localBaseRates.land_van,            // وانت - نرخ جدید: 17,500 ریال/تن-کیلومتر
        };
        
        // حداکثر ظرفیت هر نوع وسیله نقلیه (بر حسب کیلوگرم)
        const maxCapacity: Record<string, number> = {
          'land_trailer': 30000,     // تریلی - حداکثر 30 تن
          'land_truck': 20000,       // کامیون - حداکثر 20 تن
          'land_small_truck': 10000, // خاور - حداکثر 10 تن
          'land_pickup': 5000,       // نیسان - حداکثر 5 تن
          'land_van': 2000,          // وانت - حداکثر 2 تن
        };
        
        const rate = landRates[vehicleTypeName] || 9500; // نرخ پیش‌فرض کامیون
        
        // همیشه از حداکثر ظرفیت وسیله نقلیه برای محاسبه قیمت استفاده می‌کنیم
        const vehicleCapacity = maxCapacity[vehicleTypeName] || 20000;
        const vehicleCapacityTons = vehicleCapacity / 1000; // تبدیل به تن
        
        console.log(`Smart Routing: Using max capacity of ${vehicleCapacity}kg (${vehicleCapacityTons} tons) for ${vehicleTypeDisplay} pricing`);
        const exactLandPriceRial = totalDistance * vehicleCapacityTons * rate;
        calculatedPrice = exactLandPriceRial / 10; // تبدیل به تومان
        price = Math.round(calculatedPrice / 1000) * 1000; // گرد کردن به نزدیکترین 1000 تومان
      } 
      else if (transportType === 'sea') {
        // برای حمل و نقل دریایی، قیمت خودکار محاسبه نمی‌شود
        // زیرا فقط شرکت‌های حمل و نقل می‌توانند قیمت‌های دریایی واقعی ارائه دهند
        console.log("Sea transport pricing requires actual rates from transport companies - not calculating estimated price");
        calculatedPrice = 0;
        price = 0;
      } 
      else {
        // حالت ترکیبی یا نامشخص
        // بررسی اگر مسیر شامل بخش دریایی است
        const hasSeeSegment = route.segments.some(segment => segment.transportType === 'sea');
        
        if (hasSeeSegment) {
          // محاسبه فاصله و زمان فقط برای بخش‌های غیر دریایی
          let landRailDistance = 0;
          let landRailDuration = 0;
          
          route.segments.forEach(segment => {
            if (segment.transportType !== 'sea') {
              landRailDistance += segment.distance;
              landRailDuration += segment.duration;
            }
          });
          
          console.log(`Mixed route with sea segments: Calculating price only for ${landRailDistance}km of land/rail portions`);
          
          // اگر فاصله غیر دریایی صفر است، قیمت صفر برمی‌گردد
          if (landRailDistance === 0) {
            console.log("No land/rail segments in this route, cannot calculate price automatically");
            calculatedPrice = 0;
            price = 0;
          } else {
            // استفاده از یک ظرفیت استاندارد برای محاسبه قیمت در حالت ترکیبی
            const maxMixedCapacity = 25000; // 25 تن ظرفیت پیش‌فرض برای حمل و نقل ترکیبی
            const mixedCapacityTons = maxMixedCapacity / 1000; // تبدیل به تن
            
            const mixedRate = localBaseRates.mixed; // ریال به ازای هر تن-کیلومتر
            
            console.log(`Smart Routing: Using max mixed capacity of ${maxMixedCapacity}kg (${mixedCapacityTons} tons) for land/rail portions only`);
            const exactMixedPriceRial = landRailDistance * mixedCapacityTons * mixedRate;
            calculatedPrice = exactMixedPriceRial / 10; // تبدیل به تومان
            price = Math.round(calculatedPrice / 1000) * 1000; // گرد کردن به نزدیکترین 1000 تومان
          }
        } else {
          // مسیر بدون بخش دریایی
          const maxMixedCapacity = 25000; // 25 تن ظرفیت پیش‌فرض برای حمل و نقل ترکیبی
          const mixedCapacityTons = maxMixedCapacity / 1000; // تبدیل به تن
          
          const mixedRate = localBaseRates.mixed; // ریال به ازای هر تن-کیلومتر
          
          console.log(`Smart Routing: Using max mixed capacity of ${maxMixedCapacity}kg (${mixedCapacityTons} tons) for mixed transport pricing`);
          const exactMixedPriceRial = totalDistance * mixedCapacityTons * mixedRate;
          calculatedPrice = exactMixedPriceRial / 10; // تبدیل به تومان
          price = Math.round(calculatedPrice / 1000) * 1000; // گرد کردن به نزدیکترین 1000 تومان
        }
      }
      
      // ساخت تاریخ‌های حرکت و رسیدن
      const departureDate = new Date();
      const arrivalDate = new Date(departureDate.getTime() + (totalDuration * 60 * 1000));
      
      // ایجاد نوع کانتینر بر اساس نوع حمل و نقل
      const containerType = transportType === 'rail' ? "واگن باری" : 
                (transportType === 'sea' ? "کانتینر استاندارد" : vehicleTypeDisplay);
      
      // ایجاد محموله مسیریابی هوشمند
      const smartShipment = {
        id: `smart-${fromLocationId}-${toLocationId}-${transportType}`,
        transporterId: 0,
        originId: fromLocationId,
        destinationId: toLocationId,
        originName: fromLocation.name,
        destinationName: toLocation.name,
        originCountry: fromLocation.country,
        destinationCountry: toLocation.country,
        departureDate: departureDate.toLocaleDateString('fa-IR'),
        arrivalDate: arrivalDate.toLocaleDateString('fa-IR'),
        transportType: transportType,
        containerType: containerType,
        capacity: transportType === 'sea' ? 500 : (transportType === 'rail' ? 100 : 30),
        price: price, // قیمت پایه
        calculatedPrice: calculatedPrice, // قیمت محاسبه شده با فرمول دقیق
        insuranceAvailable: true,
        insurancePrice: Math.round(calculatedPrice * 0.05), // 5% قیمت بیمه
        active: true,
        description: `مسیر هوشمند ${fromLocation.name} به ${toLocation.name} با حمل و نقل ${transportType === 'rail' ? 'ریلی' : (transportType === 'sea' ? 'دریایی' : 'زمینی')}${landRouteOnly ? additionalDescription : ''}`,
        isComposite: route.segments.length > 1,
        features: [
          `مسافت: ${totalDistance.toLocaleString('fa-IR')} کیلومتر${landRouteOnly ? ' (فقط مسیر زمینی تا بندر)' : ''}`, 
          `زمان تخمینی: ${Math.floor(totalDuration/60)} ساعت و ${totalDuration%60} دقیقه${landRouteOnly ? ' (فقط مسیر زمینی تا بندر)' : ''}`,
          transportType === 'land' ? `نوع وسیله نقلیه: ${vehicleTypeDisplay}` : 
            (transportType === 'rail' ? 'نوع وسیله نقلیه: واگن باری' : 'نوع وسیله نقلیه: کشتی باری'),
          `وزن محموله: ${weightInTons.toLocaleString('fa-IR')} تن`,
          `قیمت تخمینی: ${calculatedPrice > 0 ? calculatedPrice.toLocaleString('fa-IR') + ' تومان' : 'قیمت دریایی باید از شرکت حمل و نقل استعلام شود'}${landRouteOnly ? ' (فقط هزینه مسیر زمینی تا بندر)' : ''}`
        ],
        specifications: {
          "نوع حمل و نقل": transportType === 'rail' ? 'ریلی' : (transportType === 'sea' ? 'دریایی' : 'زمینی'),
          "نوع وسیله": transportType === 'land' ? vehicleTypeDisplay : (transportType === 'rail' ? 'واگن باری' : 'کشتی'),
          "وزن محموله": `${weightInTons.toLocaleString('fa-IR')} تن (${cargoWeight.toLocaleString('fa-IR')} کیلوگرم)`,
          "قیمت تخمینی": `${calculatedPrice.toLocaleString('fa-IR')} تومان`,
          "فاصله": `${totalDistance.toLocaleString('fa-IR')} کیلومتر`,
          "مدت زمان": `${Math.floor(totalDuration/60)} ساعت و ${totalDuration%60} دقیقه`
        },
        smartRouting: true,
        suggested: route.segments.length > 1,
        distance: totalDistance,
        duration: totalDuration,
        transporterName: "سیستم مسیریابی هوشمند",
        // اطلاعات قطعه اول اگر مسیر چندبخشی است
        segmentInfo: route.segments.length > 0 ? {
          from: route.segments[0].from,
          to: route.segments[0].to,
          distance: route.segments[0].distance,
          duration: route.segments[0].duration,
          transportType: route.segments[0].transportType
        } : undefined
      };
      
      res.json(smartShipment);
    } catch (error) {
      console.error("Error in smart routing shipment API:", error);
      res.status(500).json({ 
        id: 0,
        transporterId: 0,
        originId: 0,
        destinationId: 0,
        departureDate: '',
        arrivalDate: '',
        transportType: 'rail',
        containerType: '',
        capacity: 0,
        price: 0,
        insuranceAvailable: false,
        insurancePrice: 0,
        active: true,
        description: 'خطا در مسیریابی هوشمند',
        isComposite: false,
        smartRouting: true,
        suggested: false
      });
    }
  });

  app.get("/api/smart-routing", async (req, res) => {
    try {
      const fromLocationId = req.query.fromLocationId ? parseInt(req.query.fromLocationId as string) : null;
      const toLocationId = req.query.toLocationId ? parseInt(req.query.toLocationId as string) : null;
      // گزینه‌های اضافی برای جستجوی پیشرفته
      const preferredTransport = req.query.preferredTransport as string || null;
      const date = req.query.date as string || null;
      // وزن کانتینرها را براساس نوع کانتینر تعیین می‌کنیم
      let cargoWeight = req.query.cargoWeight ? parseInt(req.query.cargoWeight as string) : 7000; // وزن پیش‌فرض 7 تن
      const containerType = req.query.containerType as string || null;
      const containerCount = req.query.containerCount ? parseInt(req.query.containerCount as string) : null;
      // آیا اطلاعات بنادر نزدیک اضافه شود؟
      const showPortOptions = req.query.showPortOptions === 'true' || true; // همیشه گزینه‌های بندر را نشان بده (به صورت پیش‌فرض)
      
      // تنظیم وزن بار متناسب با نوع کانتینر
      if (containerType) {
        if (containerType.startsWith('40_')) {
          // کانتینر 40 فوتی - حدود 30 تن
          cargoWeight = 30000;
        } else if (containerType.startsWith('20_')) {
          // کانتینر 20 فوتی - حدود 20 تن
          cargoWeight = 20000;
        }
      }
      
      // لاگ کردن اطلاعات کانتینر برای دیباگ
      console.log("Smart Routing API - Container params:", { 
        containerType, 
        containerCount,
        cargoWeight
      });
      
      if (!fromLocationId || !toLocationId) {
        return res.status(400).json({ message: "Both fromLocationId and toLocationId are required" });
      }
      
      // دریافت اطلاعات مبدا و مقصد
      const fromLocation = await storage.getLocation(fromLocationId);
      const toLocation = await storage.getLocation(toLocationId);
      
      if (!fromLocation || !toLocation) {
        return res.status(404).json({ message: "One or both locations not found" });
      }
      
      // چک کنیم آیا مسیر بین‌المللی است
      const isInternationalRoute = fromLocation.country !== toLocation.country || 
                                  (toLocation.type === "port" && toLocation.country !== "ایران") ||
                                  (fromLocation.type === "port" && fromLocation.country !== "ایران");
      
      // ایجاد گزینه‌های مختلف مسیریابی براساس انواع حمل و نقل
      const transportOptions: any[] = [];
      
      // گزینه 1: مسیر زمینی (اگر امکان‌پذیر باشد)
      try {
        const landRoute = await findBestRoute(fromLocation.name, toLocation.name, 'land');
        if (landRoute) {
          transportOptions.push({
            type: 'land',
            label: 'حمل و نقل زمینی',
            route: landRoute
          });
        }
      } catch (error) {
        console.error(`Error finding land route from ${fromLocation.name} to ${toLocation.name}:`, error);
      }
      
      // گزینه 2: مسیر ریلی (اگر امکان‌پذیر باشد)
      try {
        // ابتدا بررسی می‌کنیم که آیا هر دو مکان دارای ایستگاه راه‌آهن هستند یا خیر
        const originName = String(fromLocation.name || "");
        const destinationName = String(toLocation.name || "");
        
        const originHasRailStation = hasRailwayStation(originName);
        const destinationHasRailStation = hasRailwayStation(destinationName);
        
        if (originHasRailStation && destinationHasRailStation) {
          console.log(`Checking rail route from ${originName} to ${destinationName}, both have railway stations`);
          
          // بررسی وجود اتصال مستقیم ریلی
          const hasDirectRail = hasDirectRailConnection(originName, destinationName);
          if (hasDirectRail) {
            console.log(`Direct rail connection exists between ${originName} and ${destinationName}`);
          }
          
          const railRoute = await findBestRoute(originName, destinationName, 'rail');
          if (railRoute) {
            transportOptions.push({
              type: 'rail',
              label: 'حمل و نقل ریلی',
              route: railRoute
            });
          } else {
            console.log(`No rail route found in database, but could be a valid connection based on railway map`);
            
            // اگر اتصال ریلی مستقیم وجود دارد اما در پایگاه داده نیست، رکورد ریلی را براساس داده‌های زمینی بسازیم
            if (hasDirectRail) {
              const landRoute = await findBestRoute(originName, destinationName, 'land');
              if (landRoute) {
                const estimatedRoute = {
                  segments: [{
                    from: originName,
                    to: destinationName,
                    distance: landRoute.totalDistance,
                    duration: Math.round(landRoute.totalDistance * 0.6), // زمان سفر ریلی معمولاً کمتر از زمینی است
                    transportType: 'rail'
                  }],
                  totalDistance: landRoute.totalDistance,
                  totalDuration: Math.round(landRoute.totalDistance * 0.6),
                  transportTypes: ['rail'],
                  isEstimate: true
                };
                
                transportOptions.push({
                  type: 'rail',
                  label: 'حمل و نقل ریلی (تخمینی)',
                  route: estimatedRoute
                });
              }
            }
          }
        } else {
          console.log(`Rail route not available: ${!originHasRailStation ? originName : destinationName} does not have a railway station`);
        }
      } catch (error) {
        console.error(`Error finding rail route from ${fromLocation.name} to ${toLocation.name}:`, error);
      }
      
      // گزینه 3: مسیر دریایی (اگر امکان‌پذیر باشد)
      try {
        const seaRoute = await findBestRoute(fromLocation.name, toLocation.name, 'sea');
        if (seaRoute) {
          transportOptions.push({
            type: 'sea',
            label: 'حمل و نقل دریایی',
            route: seaRoute
          });
        }
      } catch (error) {
        console.error(`Error finding sea route from ${fromLocation.name} to ${toLocation.name}:`, error);
      }
      
      // گزینه 4: مسیر ترکیبی/بهینه (بهترین مسیر بدون محدودیت نوع حمل و نقل)
      try {
        const mixedRoute = await findBestRoute(fromLocation.name, toLocation.name);
        if (mixedRoute) {
          // فقط اگر با یکی از مسیرهای قبلی متفاوت باشد اضافه کن
          const isDifferent = transportOptions.every(option => 
            option.route.totalDistance !== mixedRoute.totalDistance || 
            option.route.transportTypes.join(',') !== mixedRoute.transportTypes.join(',')
          );
          
          if (isDifferent) {
            transportOptions.push({
              type: 'mixed',
              label: 'حمل و نقل ترکیبی (بهینه)',
              route: mixedRoute
            });
          }
        }
      } catch (error) {
        console.error(`Error finding mixed route from ${fromLocation.name} to ${toLocation.name}:`, error);
      }
      
      // اگر هیچ مسیری یافت نشد
      if (transportOptions.length === 0) {
        return res.status(404).json({ message: "No route found between these locations" });
      }
      
      // تغییر در منطق انتخاب مسیر - همیشه برای مسیرهای زمینی، ریلی را هم نشان می‌دهیم
      // و برعکس (به جز وقتی کاربر به صراحت یک نوع را خواسته)
      
      // انتخاب مسیرهای مناسب برای پاسخ
      const selectedOptions = [];
      
      // اگر کاربر یک نوع حمل و نقل خاص درخواست کرده باشد
      if (preferredTransport && preferredTransport !== 'all' && preferredTransport !== 'auto') {
        // ابتدا نوع حمل و نقل درخواست شده را پیدا می‌کنیم
        const preferredOption = transportOptions.find(opt => opt.type === preferredTransport);
        if (preferredOption) {
          selectedOptions.push(preferredOption);
          
          // اگر نوع حمل و نقل درخواست شده زمینی است، ریلی را هم اضافه می‌کنیم (اگر موجود باشد)
          if (preferredTransport === 'land') {
            const railOption = transportOptions.find(opt => opt.type === 'rail');
            if (railOption) {
              selectedOptions.push(railOption);
            }
          }
          // اگر نوع حمل و نقل درخواست شده ریلی است، زمینی را هم اضافه می‌کنیم (اگر موجود باشد)
          else if (preferredTransport === 'rail') {
            const landOption = transportOptions.find(opt => opt.type === 'land');
            if (landOption) {
              selectedOptions.push(landOption);
            }
          }
        }
      } else if (preferredTransport === 'all') {
        // اگر "all" انتخاب شده، همه گزینه‌ها را اضافه می‌کنیم
        selectedOptions.push(...transportOptions);
      } else {
        // در حالت "خودکار" یا پیش‌فرض، ابتدا گزینه‌ی ترکیبی را انتخاب می‌کنیم
        const mixedOption = transportOptions.find(opt => opt.type === 'mixed');
        if (mixedOption) {
          selectedOptions.push(mixedOption);
        }
        
        // سپس گزینه‌های زمینی و ریلی را هم اضافه می‌کنیم (اگر موجود باشند)
        const landOption = transportOptions.find(opt => opt.type === 'land');
        if (landOption) {
          selectedOptions.push(landOption);
        }
        
        const railOption = transportOptions.find(opt => opt.type === 'rail');
        if (railOption) {
          selectedOptions.push(railOption);
        }
      }
      
      // اگر هیچ گزینه‌ای انتخاب نشده باشد، اولین گزینه موجود را انتخاب می‌کنیم
      if (selectedOptions.length === 0 && transportOptions.length > 0) {
        selectedOptions.push(transportOptions[0]);
      }
      
      // استفاده از تابع مسیریابی هوشمند برای پیدا کردن بهترین مسیر
      // از اولین گزینه انتخاب شده به عنوان مسیر اصلی استفاده می‌کنیم
      const bestRoute = selectedOptions[0]?.route;
      
      if (!bestRoute) {
        return res.status(404).json({ message: "No route found between these locations" });
      }
      
      // اگر مسیر بین‌المللی است یا showPortOptions فعال است، گزینه‌های بندر را اضافه کن
      let portOptions = null;
      if (isInternationalRoute || showPortOptions) {
        try {
          console.log(`Finding port routes for ${fromLocation.name} to ${toLocation.name}`);
          // یافتن بنادر نزدیک و گزینه‌های مسیریابی از طریق آنها
          portOptions = await findPortRoutes(fromLocation.name, toLocation.name);
          
          // لاگ کردن گزینه‌های بندر برای دیباگ
          console.log("Port options found:", {
            originPortsCount: portOptions.originPorts.length,
            destinationPortsCount: portOptions.destinationPorts.length,
            directRouteAvailable: portOptions.directRouteAvailable
          });
          
          // برای مسیرهای بین‌المللی، فقط بنادر کشور مبدا (ایران) را نشان می‌دهیم
          
          // اگر مسیر بهینه جایگزین پیدا شد، اضافه کردن آن به گزینه‌های انتخاب شده
          if (portOptions.bestAlternativeRoute) {
            console.log(`Best alternative route via ports: ${portOptions.bestAlternativeRoute.originPort.name} to ${portOptions.bestAlternativeRoute.destinationPort.name}`);
          }
        } catch (error) {
          console.error("Error finding port options:", error);
        }
      }
      
      // پردازش همه گزینه‌های انتخاب شده
      let allRoutesWithShipments = [];
      
      // برای هر گزینه انتخاب شده، سرویس‌های حمل و نقل را پردازش می‌کنیم
      for (const option of selectedOptions) {
        const currentRoute = option.route;
        
        // تعیین سرویس‌های حمل و نقل موجود برای هر سگمنت مسیر
        const routeWithShipments = await Promise.all(currentRoute.segments.map(async (segment: {
          from: string;
          to: string;
          distance: number;
          duration: number;
          transportType: string;
        }) => {
        // یافتن مکان‌های مبدا و مقصد هر سگمنت
        const segmentFromLocations = await storage.getAllLocations();
        const segmentToLocations = await storage.getAllLocations();
        
        const segmentFrom = segmentFromLocations.find(loc => loc.name === segment.from);
        const segmentTo = segmentToLocations.find(loc => loc.name === segment.to);
        
        // اگر هر دو مکان پیدا شدند، سرویس‌های موجود را جستجو کن
        let availableShipments: any[] = [];
        if (segmentFrom && segmentTo) {
          // تعیین نوع حمل و نقل برای جستجو با در نظر گرفتن اولویت‌ها
          let transportType = segment.transportType;
          
          // اگر نوع حمل و نقل ترجیحی مشخص شده و با 'all' متفاوت است
          if (preferredTransport && preferredTransport !== 'all') {
            transportType = preferredTransport;
          }
          
          // پارامترهای جستجو
          const searchParams: {
            originId?: number;
            destinationId?: number;
            transportType?: string;
            departureDate?: Date;
            containerType?: string;
          } = {
            originId: segmentFrom.id,
            destinationId: segmentTo.id,
            transportType: transportType
          };
          
          // اگر تاریخ مشخص شده، آن را به جستجو اضافه کنید
          if (date) {
            searchParams.departureDate = typeof date === 'string' ? new Date(date) : new Date(date);
          }
          
          availableShipments = await storage.searchShipments(searchParams);
          
          // اگر سرویس موجود نیست، یک سرویس پیشنهادی ایجاد کن
          if (availableShipments.length === 0) {
            // تعیین ظرفیت و نوع کانتینر/وسیله نقلیه بر اساس نوع حمل و نقل و وزن بار
            let capacity = cargoWeight / 1000; // تبدیل به تن
            let displayContainerType = "کامیون";
            let vehicleType = "land_truck";
            
            // بررسی اینکه آیا این سگمنت بخشی از مسیر بین‌المللی است (مقصد یک بندر خارجی است)
            const isInternationalSegment = segmentTo.country !== "ایران" && 
                                          segmentTo.country !== "ایران (Iran)" && 
                                          segmentTo.type === "port";
            
            // تعیین اینکه آیا این مسیر به بندر می‌رود و چه فاصله‌ای دارد
            let landOnlyDistance = undefined;
            
            if (isInternationalSegment) {
              // این یک مسیر به بندر بین‌المللی است - ممکن است نیاز به محاسبه فاصله جداگانه باشد
              console.log(`International segment detected: ${segmentFrom.name} to ${segmentTo.name}`);
              
              // برای مسیر بین‌المللی، فقط بخش زمینی تا بندر را محاسبه می‌کنیم
              // اگر مسیر دریایی است، نزدیکترین بندر داخلی را می‌یابیم و فاصله تا آن را استفاده می‌کنیم
              if (segment.transportType === 'sea' || segment.transportType === 'mixed') {
                // در این حالت، می‌توانیم از فاصله فعلی استفاده کنیم چون قبلاً در findBestRoute محاسبه شده
                landOnlyDistance = segment.distance;
                console.log(`Using land distance to port: ${landOnlyDistance}km for pricing calculation`);
              }
            }
            
            if (containerType && transportType === "land") {
              // اگر کانتینر انتخاب شده، همیشه از تریلی استفاده می‌کنیم
              console.log(`Smart Routing - Using container type ${containerType} for segment ${segmentFrom.name} to ${segmentTo.name}`);
              displayContainerType = "تریلی کشنده";
              vehicleType = "land_trailer";
              // تعیین ظرفیت بر اساس نوع کانتینر
              if (containerType.startsWith('40_') || containerType.includes('40')) {
                capacity = 30; // کانتینر ۴۰ فوتی - ۳۰ تن
              } else if (containerType.startsWith('20_') || containerType.includes('20')) {
                capacity = 20; // کانتینر ۲۰ فوتی - ۲۰ تن
              }
            } else if (transportType === "land") {
              // انتخاب هوشمند وسیله نقلیه زمینی بر اساس وزن محموله
              if (cargoWeight <= 2000) {
                vehicleType = "land_van";
                displayContainerType = "وانت";
                capacity = 2;
              } else if (cargoWeight <= 5000) {
                vehicleType = "land_pickup";
                displayContainerType = "نیسان";
                capacity = 5;
              } else if (cargoWeight <= 10000) {
                vehicleType = "land_small_truck";
                displayContainerType = "خاور";
                capacity = 10;
              } else if (cargoWeight <= 20000) {
                vehicleType = "land_truck";
                displayContainerType = "کامیون";
                capacity = 20;
              } else {
                vehicleType = "land_trailer";
                displayContainerType = "تریلی";
                capacity = 30;
              }
            } else if (transportType === "sea") {
              capacity = 50; 
              displayContainerType = containerType || "20 فوت استاندارد";
            } else if (transportType === "rail") {
              capacity = 60;
              displayContainerType = "واگن باری";
            }
            
            // محاسبه قیمت تقریبی بر اساس نوع حمل و نقل، فاصله و وزن بار
            // تبدیل containerType از حالت احتمالی null به undefined
            const containerTypeForCalc = containerType === null ? undefined : containerType;
            const contCountForCalc = containerCount === null ? undefined : containerCount;
            
            // استفاده از تابع محاسبه دقیق قیمت
            const detailedPrice = calculateDetailedPrice(
              transportType === 'sea' ? 'sea' : vehicleType, 
              segment.distance, 
              cargoWeight, 
              containerTypeForCalc, 
              contCountForCalc,
              isInternationalSegment,  // آیا مسیر بین‌المللی است
              landOnlyDistance         // فاصله بخش زمینی تا بندر (اگر مشخص شده باشد)
            );
            
            console.log(`Smart Routing: ${detailedPrice ? `Using max capacity of ${detailedPrice.usedWeight}kg (${detailedPrice.weightInTons} tons) for ${detailedPrice.vehicleDisplayName} pricing` : 'No price calculation available'}`);
            
            // قیمت تخمینی برای مسیر
            const estimatedPrice = detailedPrice ? Math.round(detailedPrice.priceToman / 1000) * 1000 : null;
            
            // تخمین تاریخ‌های رفت و برگشت
            const departureDate = date ? new Date(date) : new Date();
            if (!date) departureDate.setDate(departureDate.getDate() + 1); // فردا اگر تاریخ مشخص نشده باشد
            
            const arrivalDate = new Date(departureDate);
            const durationInDays = Math.ceil(segment.duration / (24 * 60)); // تبدیل دقیقه به روز
            arrivalDate.setDate(arrivalDate.getDate() + durationInDays);
            
            // اتلاعات قیمت و توضیحات
            let exactPriceRial = detailedPrice ? detailedPrice.priceRial : 0;
            let exactPriceToman = detailedPrice ? detailedPrice.priceToman : 0;
            let formulaDesc = detailedPrice ? detailedPrice.formulaDescription : 'قیمت موجود نیست';
            
            // برای حمل و نقل دریایی، فقط از قیمت‌های واقعی شرکت‌های حمل و نقل استفاده می‌شود
            if (transportType === 'sea') {
              formulaDesc = 'قیمت مسیر دریایی فقط از شرکت‌های حمل و نقل دریافت می‌شود';
            }
            
            // اطلاعات وسیله نقلیه و نرخ
            let rateForTransport = detailedPrice ? detailedPrice.rate : 0;
            let vehicleDisplayName = detailedPrice ? detailedPrice.vehicleDisplayName : 
                (transportType === 'rail' ? 'واگن باری' : 
                transportType === 'sea' ? 'کانتینر دریایی' : 
                vehicleType === 'land_trailer' ? 'تریلی' : 
                vehicleType === 'land_truck' ? 'کامیون' : 
                vehicleType === 'land_small_truck' ? 'خاور' : 
                vehicleType === 'land_pickup' ? 'نیسان' : 'وسیله نقلیه');
            
            // تنظیم نرخ برای نمایش اگر محاسبه دقیق موجود نباشد
            if (!detailedPrice) {
              if (transportType === 'rail') {
                rateForTransport = 34;
              } else if (vehicleType === 'land_trailer') {
                rateForTransport = 9500;
              } else if (vehicleType === 'land_truck') {
                rateForTransport = 10000;
              } else if (vehicleType === 'land_small_truck') {
                rateForTransport = 13500;
              } else if (vehicleType === 'land_pickup') {
                rateForTransport = 17500;
              } else {
                rateForTransport = 17500; // نرخ پیش‌فرض وانت
              }
            }
            
            // ایجاد سرویس پیشنهادی
            availableShipments = [{
              id: `smart-${segmentFrom.id}-${segmentTo.id}-${transportType}`,
              originId: segmentFrom.id,
              destinationId: segmentTo.id,
              transportType: transportType,
              price: transportType === 'sea' ? null : estimatedPrice,
              departureDate: departureDate.toISOString().split('T')[0],
              arrivalDate: arrivalDate.toISOString().split('T')[0],
              distance: segment.distance,
              duration: segment.duration,
              suggested: true,
              originName: segmentFrom.name,
              destinationName: segmentTo.name,
              originCountry: segmentFrom.country,
              destinationCountry: segmentTo.country,
              containerType: displayContainerType,
              transporterName: "سیستم مسیریابی هوشمند",
              capacity: capacity,
              vehicleType: vehicleType,
              calculatedPrice: Math.round(exactPriceToman), // اضافه کردن قیمت دقیق محاسبه شده
              transportPrice: {
                priceRial: exactPriceRial,
                priceToman: exactPriceToman,
                formulaDescription: formulaDesc
              },
              transportDetails: {
                vehicleType: vehicleType,
                vehicleDisplayName: displayContainerType,
                baseRate: transportType === 'rail' ? 34 : 
                         vehicleType === 'land_trailer' ? 8900 : 
                         vehicleType === 'land_truck' ? 9500 : 
                         vehicleType === 'land_small_truck' ? 12000 : 
                         vehicleType === 'land_pickup' ? 15000 : 20000,
                baseRateDescription: `تعرفه ${displayContainerType}: ${(transportType === 'rail' ? 34 : 
                                            vehicleType === 'land_trailer' ? 8900 : 
                                            vehicleType === 'land_truck' ? 9500 : 
                                            vehicleType === 'land_small_truck' ? 12000 : 
                                            vehicleType === 'land_pickup' ? 15000 : 20000).toLocaleString('fa-IR')} ریال/تن-کیلومتر`
              }
            }];
          } else {
            // تعریف نوع وسیله نقلیه برای این مسیر
            let innerVehicleType = transportType;
            
            // متغیر نرخ پایه برای انواع حمل و نقل
            let rate = transportType === 'rail' ? 34 : 
                      innerVehicleType === 'land_trailer' ? 8900 : 
                      innerVehicleType === 'land_truck' ? 9500 : 
                      innerVehicleType === 'land_small_truck' ? 12000 : 
                      innerVehicleType === 'land_pickup' ? 15000 : 20000;
                      
            // غنی‌سازی سرویس‌های موجود با اطلاعات مبدا و مقصد
            availableShipments = await Promise.all(availableShipments.map(async (shipment) => {
              const originLoc = await storage.getLocation(shipment.originId);
              const destLoc = await storage.getLocation(shipment.destinationId);
              const transporter = await storage.getTransporter(shipment.transporterId);
              
              return {
                ...shipment,
                originName: originLoc?.name || segment.from,
                destinationName: destLoc?.name || segment.to,
                originCountry: originLoc?.country || '',
                destinationCountry: destLoc?.country || '',
                transporterName: transporter?.companyName || 'نامشخص',
                distance: segment.distance,
                duration: segment.duration,
                suggested: false
              };
            }));
          }
        }
        
        return {
          ...segment,
          shipments: availableShipments
        };
      }));
      
      // محاسبه جزئیات کلی مسیر
      const totalShipments = routeWithShipments.flatMap(segment => segment.shipments);
      
      // محاسبه قیمت کل مسیر براساس قطعات مسیر
      let totalPrice = 0;
      
      // ایجاد محموله پیشنهادی برای هر قطعه مسیر
      // ابتدا همه مکان‌ها را یکبار دریافت می‌کنیم (برای بهینه‌سازی)
      const allLocations = await storage.getAllLocations();
      
      // ایجاد محموله‌های پیشنهادی برای هر قطعه مسیر
      for (const segment of routeWithShipments) {
        if (segment.shipments.length === 0) {
          // پیدا کردن مکان‌های مبدا و مقصد این قطعه مسیر با مطابقت دقیق‌تر
          // حذف پرانتز و متن داخل آن برای مطابقت بهتر
          const fromNameSimplified = segment.from.replace(/ \(.*?\)/g, "");
          const toNameSimplified = segment.to.replace(/ \(.*?\)/g, "");
          
          // تابع یافتن مکان با شباهت بیشتر
          const findBestMatchLocation = (locationName: string, simplifiedName: string) => {
            // ابتدا تطابق دقیق نام کامل
            let match = allLocations.find(loc => loc.name === locationName);
            if (match) return match;
            
            // سپس تطابق بدون پرانتز
            match = allLocations.find(loc => {
              const locNameSimplified = loc.name.replace(/ \(.*?\)/g, "");
              return locNameSimplified === simplifiedName;
            });
            if (match) return match;
            
            // در نهایت تطابق نسبی (فقط شامل بودن نام ساده)
            match = allLocations.find(loc => {
              const locNameSimplified = loc.name.replace(/ \(.*?\)/g, "");
              return locNameSimplified.includes(simplifiedName) || simplifiedName.includes(locNameSimplified);
            });
            
            return match;
          };
          
          const segmentFrom = findBestMatchLocation(segment.from, fromNameSimplified);
          const segmentTo = findBestMatchLocation(segment.to, toNameSimplified);
          
          if (segmentFrom && segmentTo) {
            // انتخاب نوع وسیله نقلیه بر اساس وزن محموله و نوع حمل و نقل
            let shipmentContainerType = 'کانتینر استاندارد'; // پیش‌فرض
            let vehicleType = segment.transportType;
            
            // بررسی اگر این قطعه مسیر بخشی از مسیر بین‌المللی است
            const isInternationalSegment = 
              segmentTo.country !== "ایران" && 
              segmentTo.country !== "ایران (Iran)" && 
              (segmentTo.type === "port" || segmentTo.name.toLowerCase().includes('port') || segmentTo.name.includes('بندر'));
            
            let landOnlyDistance = undefined;
            if (isInternationalSegment) {
              // برای مسیرهای بین‌المللی، فاصله تا بندر برای قیمت‌گذاری استفاده می‌شود
              landOnlyDistance = segment.distance;
            }
            
            // محاسبه قیمت تقریبی با استفاده از وزن محموله
            // استفاده از تابع محاسبه دقیق قیمت جدید
            const detailedPriceResult = calculateDetailedPrice(
              segment.transportType, 
              segment.distance, 
              cargoWeight, 
              shipmentContainerType,
              undefined,
              isInternationalSegment,
              landOnlyDistance
            );
            
            const estimatedPrice = detailedPriceResult ? Math.round(detailedPriceResult.priceToman / 1000) * 1000 : null;
            
            if (segment.transportType === 'land') {
              if (cargoWeight <= 2000) {
                shipmentContainerType = 'وانت';
                vehicleType = 'land_van';
              } else if (cargoWeight <= 5000) {
                shipmentContainerType = 'نیسان';
                vehicleType = 'land_pickup';
              } else if (cargoWeight <= 10000) {
                shipmentContainerType = 'خاور';
                vehicleType = 'land_small_truck';
              } else if (cargoWeight <= 20000) {
                shipmentContainerType = 'کامیون';
                vehicleType = 'land_truck';
              } else {
                shipmentContainerType = 'تریلی';
                vehicleType = 'land_trailer';
              }
            } else if (segment.transportType === 'rail') {
              shipmentContainerType = 'واگن باری';
              vehicleType = 'rail';
            } else if (segment.transportType === 'sea') {
              shipmentContainerType = 'کشتی باری';
              vehicleType = 'sea';
            }
            
            // ایجاد محموله پیشنهادی
            const suggestedShipment = {
              id: `smart-${segmentFrom.id}-${segmentTo.id}-${segment.transportType}`,
              originId: segmentFrom.id,
              destinationId: segmentTo.id,
              transportType: segment.transportType,
              containerType: shipmentContainerType,
              price: segment.transportType === 'sea' ? null : estimatedPrice,
              calculatedPrice: segment.transportType === 'sea' ? null : estimatedPrice, // قیمت محاسبه شده بدون تقسیم اضافی بر 10
              distance: segment.distance,
              duration: segment.duration,
              suggested: true,
              originName: segmentFrom.name,
              destinationName: segmentTo.name,
              originCountry: segmentFrom.country || 'ایران',
              destinationCountry: segmentTo.country || 'ایران',
              transporterName: "سیستم مسیریابی هوشمند",
              departureDate: new Date(),
              specifications: {
                "نوع وسیله": shipmentContainerType,
                "ظرفیت": `${cargoWeight} کیلوگرم`,
                "فاصله": `${segment.distance} کیلومتر`,
                "زمان تقریبی": `${Math.ceil(segment.duration / 60)} ساعت`,
              },
              features: [
                `مسیر: ${segmentFrom.name} به ${segmentTo.name}`,
                `نوع حمل و نقل: ${segment.transportType === 'land' ? 'زمینی' : segment.transportType === 'rail' ? 'ریلی' : 'دریایی'}`,
                `وسیله نقلیه: ${shipmentContainerType}`,
                `فاصله: ${segment.distance} کیلومتر`,
                `قیمت تخمینی: ${segment.transportType === 'sea' ? 'قیمت سرویس فقط از شرکت حمل و نقل دریافت می‌شود' : (estimatedPrice ? new Intl.NumberFormat('fa-IR').format(estimatedPrice) + ' تومان' : 'محاسبه نشده')}`
              ]
            };
            
            // اضافه کردن محموله به لیست محموله‌های این قطعه مسیر
            segment.shipments = [suggestedShipment];
          }
        }
      }
      
          // محاسبه مجدد تمام محموله‌ها با محموله‌های پیشنهادی جدید
          const updatedTotalShipments = routeWithShipments.flatMap(segment => segment.shipments);
          
          // محاسبه قیمت کل براساس تمام محموله‌ها - بدون در نظر گرفتن محموله‌های دریایی
          const hasSeaSegments = updatedTotalShipments.some(shipment => shipment.transportType === 'sea');
          
          // اضافه کردن مسیر با محموله‌ها به لیست کلی
          allRoutesWithShipments.push({
            type: option.type,
            routeWithShipments,
            totalPrice: 0, // موقتا صفر، بعدا محاسبه می‌شود
            hasSeaSegments
          });
      }
      
      // استفاده از اولین مسیر برای نمایش (می‌توان بعدا این منطق را تغییر داد)
      const mainRouteWithShipments = allRoutesWithShipments[0]?.routeWithShipments;
      
      // اگر از allRoutesWithShipments استفاده می‌کنیم، باید اطلاعات را از اولین مسیر استخراج کنیم
      let routeWithShipments = mainRouteWithShipments;
      
      // محاسبه مجموع قیمت‌ها از محموله‌های موجود در مسیر اصلی
      let totalPrice = 0;
      let hasSeaSegments = false;
      
      if (mainRouteWithShipments && mainRouteWithShipments.length > 0) {
        const updatedTotalShipments = mainRouteWithShipments.flatMap(segment => segment.shipments || []);
        
        // محاسبه قیمت کل براساس تمام محموله‌ها - بدون در نظر گرفتن محموله‌های دریایی
        hasSeaSegments = updatedTotalShipments.some(shipment => shipment.transportType === 'sea');
        
        totalPrice = updatedTotalShipments.reduce((sum, shipment) => {
          // اگر نوع حمل و نقل دریایی باشد، آن را در محاسبه قیمت کل در نظر نمی‌گیریم
          if (shipment.transportType === 'sea') {
            return sum;
          }
          return sum + (shipment.price || 0);
        }, 0);
      }
      
      // اضافه کردن یادداشت در صورت وجود قطعه دریایی
      if (hasSeaSegments) {
        console.log("Route contains sea segments - pricing shows land/rail portions only");
      }
      
      // محاسبه پشتیبان: اگر هنوز قیمت صفر است، از تابع محاسبه قیمت استفاده کن
      if (totalPrice === 0) {
        totalPrice = bestRoute.segments.reduce((sum: number, segment: {transportType: string; distance: number}) => {
          // اگر نوع حمل و نقل دریایی باشد، آن را در محاسبه قیمت کل در نظر نمی‌گیریم
          if (segment.transportType === 'sea') {
            return sum;
          }
          // تبدیل containerType از حالت احتمالی null به undefined
          const containerTypeForCalc = containerType === null ? undefined : containerType as string | undefined;
          const contCountForCalc = containerCount === null ? undefined : containerCount as number | undefined;
          
          // بررسی اگر این قطعه مسیر بخشی از مسیر بین‌المللی است
          const isInternationalSegment = bestRoute.segments.some((s: {to: string}) => 
            (s.to.toLowerCase().includes('port') || 
            s.to.includes('بندر')) && 
            !s.to.includes('ایران') && 
            !s.to.includes('Iran'));
          
          let landOnlyDistance = undefined;
          if (isInternationalSegment) {
            // برای مسیرهای بین‌المللی، فاصله تا بندر برای قیمت‌گذاری استفاده می‌شود
            landOnlyDistance = segment.distance;
          }
          
          const detailedPriceResult = calculateDetailedPrice(
            segment.transportType, 
            segment.distance, 
            cargoWeight, 
            containerTypeForCalc, 
            contCountForCalc,
            isInternationalSegment,
            landOnlyDistance
          );
          
          const segmentPrice = detailedPriceResult ? detailedPriceResult.priceToman : null;
          return sum + (segmentPrice ?? 0);
        }, 0);
      }
      const estimatedTotalDays = Math.ceil(bestRoute.totalDuration / (24 * 60)); // تبدیل دقیقه به روز
      
      // اگر کاربر درخواست نمایش همه گزینه‌ها را داشته باشد
      if (preferredTransport === 'all') {
        // پردازش تمام گزینه‌های حمل و نقل و محاسبه قیمت کل برای هریک
        const processedOptions = transportOptions.map(option => {
          const routePrice = option.route.segments.reduce((sum: number, segment: any) => {
            // اگر نوع حمل و نقل دریایی باشد، آن را در محاسبه قیمت کل در نظر نمی‌گیریم
            if (segment.transportType === 'sea') {
              return sum;
            }
            // تبدیل containerType از حالت احتمالی null به undefined
            const containerTypeForCalc = containerType === null ? undefined : containerType;
            const contCountForCalc = containerCount === null ? undefined : containerCount;
            
            // بررسی اگر این قطعه مسیر بخشی از مسیر بین‌المللی است
            const isInternationalSegment = option.route.segments.some((s: {to: string}) => 
              (s.to.toLowerCase().includes('port') || 
              s.to.includes('بندر')) && 
              !s.to.includes('ایران') && 
              !s.to.includes('Iran'));
            
            let landOnlyDistance = undefined;
            if (isInternationalSegment) {
              // برای مسیرهای بین‌المللی، فاصله تا بندر برای قیمت‌گذاری استفاده می‌شود
              landOnlyDistance = segment.distance;
            }
            
            const detailedPriceResult = calculateDetailedPrice(
              segment.transportType, 
              segment.distance, 
              cargoWeight, 
              containerTypeForCalc, 
              contCountForCalc,
              isInternationalSegment,
              landOnlyDistance
            );
            
            const segmentPrice = detailedPriceResult ? detailedPriceResult.priceToman : null;
            return sum + (segmentPrice ?? 0);
          }, 0);
          
          return {
            type: option.type,
            label: option.label,
            totalPrice: routePrice,
            totalDistance: option.route.totalDistance,
            totalDuration: option.route.totalDuration,
            estimatedDays: Math.ceil(option.route.totalDuration / (24 * 60)),
            segments: option.route.segments.length,
            transportModes: option.route.transportTypes,
            details: option.route
          };
        });
        
        // پاسخ به کاربر با نمایش همه گزینه‌ها
        res.json({
          selectedRoute: {
            route: bestRoute,
            routeWithShipments,
            totalPrice,
            totalDistance: bestRoute.totalDistance,
            totalDuration: bestRoute.totalDuration,
            estimatedDays: estimatedTotalDays,
            segments: routeWithShipments.length,
            transportModes: bestRoute.transportTypes,
            // افزودن اطلاعات بنادر به پاسخ
            portInfo: portOptions ? {
              // بنادر نزدیک به مبدا
              originPorts: portOptions.originPorts.map(port => ({
                name: port.name,
                country: port.country,
                distance: port.distanceFromLocation,
                travelTime: port.travelTime
              })),
              // بنادر نزدیک به مقصد
              destinationPorts: portOptions.destinationPorts.map(port => ({
                name: port.name,
                country: port.country,
                distance: port.distanceFromLocation,
                travelTime: port.travelTime
              })),
              // آیا مسیر مستقیم وجود دارد
              directRouteAvailable: portOptions.directRouteAvailable,
              // اضافه کردن مسیرهای متنوع از طریق بنادر مختلف
              portRoutes: portOptions.portRoutes ? portOptions.portRoutes.map(route => {
                // برای هر مسیر بندری، محاسبه قیمت برای مسیر زمینی به بندر
                let landPrice = null;
                if (cargoWeight) {
                  // محاسبه قیمت برای مسیر زمینی
                  landPrice = calculateDetailedPrice(
                    "land", 
                    route.landRoute.distance, 
                    parseFloat(String(cargoWeight)),
                    containerType === null ? undefined : containerType,
                    containerCount === null ? undefined : containerCount
                  );
                }
                
                // محاسبه قیمت برای مسیر ریلی در صورت وجود
                let railPrice = null;
                if (route.railRoute?.available && cargoWeight) {
                  railPrice = calculateDetailedPrice(
                    "rail", 
                    route.railRoute.distance, 
                    parseFloat(String(cargoWeight)),
                    containerType === null ? undefined : containerType,
                    containerCount === null ? undefined : containerCount
                  );
                }
                
                return {
                  port: route.port,
                  landRoute: {
                    ...route.landRoute,
                    price: landPrice ? landPrice.priceRial : null,
                    priceToman: landPrice ? landPrice.priceToman : null,
                    vehicleType: landPrice ? landPrice.vehicleType : null,
                    vehicleDisplayName: landPrice ? landPrice.vehicleDisplayName : null,
                  },
                  seaRoute: route.seaRoute,
                  railRoute: route.railRoute ? {
                    ...route.railRoute,
                    price: railPrice ? railPrice.priceRial : null,
                    priceToman: railPrice ? railPrice.priceToman : null
                  } : undefined
                };
              }) : [],
              // بهترین مسیر جایگزین (از طریق بنادر)
              bestAlternativeRoute: portOptions.bestAlternativeRoute ? {
                originPort: {
                  name: portOptions.bestAlternativeRoute.originPort.name,
                  country: portOptions.bestAlternativeRoute.originPort.country,
                  distance: portOptions.bestAlternativeRoute.landDistance1
                },
                destinationPort: {
                  name: portOptions.bestAlternativeRoute.destinationPort.name,
                  country: portOptions.bestAlternativeRoute.destinationPort.country,
                  distance: portOptions.bestAlternativeRoute.landDistance2
                },
                seaDistance: portOptions.bestAlternativeRoute.seaDistance,
                totalDistance: portOptions.bestAlternativeRoute.totalDistance,
                totalDuration: portOptions.bestAlternativeRoute.totalDuration
              } : null
            } : null,
            isInternationalRoute: isInternationalRoute
          },
          allOptions: processedOptions
        });
      } else {
        // حالت معمولی: فقط مسیر انتخاب شده نمایش داده می‌شود
        res.json({
          route: bestRoute,
          routeWithShipments,
          totalPrice,
          totalDistance: bestRoute.totalDistance,
          totalDuration: bestRoute.totalDuration,
          estimatedDays: estimatedTotalDays,
          segments: routeWithShipments.length,
          transportModes: bestRoute.transportTypes,
          // اضافه کردن اطلاعات در مورد گزینه‌های دیگر حمل و نقل (فقط نام‌ها)
          availableTransportOptions: transportOptions.map(opt => ({
            type: opt.type,
            label: opt.label
          })),
          // افزودن اطلاعات بنادر به پاسخ
          portInfo: portOptions ? {
            // بنادر نزدیک به مبدا
            originPorts: portOptions.originPorts.map(port => ({
              name: port.name,
              country: port.country,
              distance: port.distanceFromLocation,
              travelTime: port.travelTime
            })),
            // بنادر نزدیک به مقصد
            destinationPorts: portOptions.destinationPorts.map(port => ({
              name: port.name,
              country: port.country,
              distance: port.distanceFromLocation,
              travelTime: port.travelTime
            })),
            // آیا مسیر مستقیم وجود دارد
            directRouteAvailable: portOptions.directRouteAvailable,
            // بهترین مسیر جایگزین (از طریق بنادر)
            bestAlternativeRoute: portOptions.bestAlternativeRoute ? {
              originPort: {
                name: portOptions.bestAlternativeRoute.originPort.name,
                country: portOptions.bestAlternativeRoute.originPort.country,
                distance: portOptions.bestAlternativeRoute.landDistance1
              },
              destinationPort: {
                name: portOptions.bestAlternativeRoute.destinationPort.name,
                country: portOptions.bestAlternativeRoute.destinationPort.country,
                distance: portOptions.bestAlternativeRoute.landDistance2
              },
              seaDistance: portOptions.bestAlternativeRoute.seaDistance,
              totalDistance: portOptions.bestAlternativeRoute.totalDistance,
              totalDuration: portOptions.bestAlternativeRoute.totalDuration
            } : null
          } : null,
          isInternationalRoute: isInternationalRoute
        });
      }
      
    } catch (error) {
      console.error("Error in smart routing:", error);
      res.status(500).json({ message: "Failed to calculate route" });
    }
  });
  
  // Shipments API
  // Get shipments by specific route (origin and destination)
  app.get("/api/shipments/route", async (req, res) => {
    try {
      const originId = req.query.originId ? parseInt(req.query.originId as string) : null;
      const destinationId = req.query.destinationId ? parseInt(req.query.destinationId as string) : null;
      
      if (!originId || !destinationId) {
        return res.status(400).json({ message: "Both originId and destinationId are required" });
      }
      
      const shipments = await storage.getShipmentsByRoute(originId, destinationId);
      
      // Enhance shipments with origin, destination, and transporter information
      const enhancedShipments = await Promise.all(shipments.map(async shipment => {
        const origin = await storage.getLocation(shipment.originId);
        const destination = await storage.getLocation(shipment.destinationId);
        const transporter = await storage.getTransporter(shipment.transporterId);
        
        return {
          ...shipment,
          originName: origin?.name || 'Unknown',
          originCountry: origin?.country || 'Unknown',
          destinationName: destination?.name || 'Unknown',
          destinationCountry: destination?.country || 'Unknown',
          transporterName: transporter?.companyName || 'Unknown'
        };
      }));
      
      res.json(enhancedShipments);
    } catch (error) {
      console.error("Error fetching shipments by route:", error);
      res.status(500).json({ message: "Failed to fetch shipments by route" });
    }
  });

  app.get("/api/shipments/search", async (req, res) => {
    try {
      // دریافت پارامترهای کانتینر برای لاگ
      const containerType = req.query.containerType as string | undefined;
      const containerCount = req.query.containerCount ? parseInt(req.query.containerCount as string) : undefined;
      let cargoWeight = req.query.cargoWeight ? parseInt(req.query.cargoWeight as string) : 7000; // وزن پیش‌فرض: 7 تن
      
      // بررسی وجود وزن بار صریح
      const userSpecifiedWeight = req.query.cargoWeight ? true : false;
      
      // تنظیم وزن بار متناسب با نوع کانتینر
      if (containerType) {
        // اگر کاربر وزن بار را مشخص نکرده یا وزن بار بیشتر از حد مشخصی است
        if (!userSpecifiedWeight || (userSpecifiedWeight && cargoWeight > 10000)) {
          if (containerType.startsWith('40_')) {
            // کانتینر 40 فوتی - حدود 30 تن
            cargoWeight = 30000;
            console.log("Using trailer for container shipment: 40-foot container (30 tons)");
          } else if (containerType.startsWith('20_')) {
            // کانتینر 20 فوتی - حدود 20 تن
            cargoWeight = 20000;
            console.log("Using trailer for container shipment: 20-foot container (20 tons)");
          }
        } else {
          // اگر کاربر وزن کم را وارد کرده است، کانتینر نادیده گرفته می‌شود و بر اساس وزن تصمیم می‌گیریم
          console.log(`Cargo weight ${cargoWeight}kg is too small for container - will calculate based on cargo weight`);
        }
      }
      
      // لاگ اطلاعات کانتینر برای دیباگ
      console.log("Search API - Container Info:", {
        containerType,
        containerCount,
        cargoWeight
      });
      
      const params = {
        originId: req.query.originId ? parseInt(req.query.originId as string) : undefined,
        destinationId: req.query.destinationId ? parseInt(req.query.destinationId as string) : undefined,
        departureDate: req.query.departureDate ? new Date(req.query.departureDate as string) : undefined,
        // اگر نوع حمل و نقل مشخص شده باشد، آن را استفاده می‌کنیم
        transportType: req.query.transportType as string | undefined,
        containerType: containerType,
        cargoWeight: cargoWeight, // اضافه کردن وزن محموله به پارامترهای جستجو
        containerCount: containerCount // اضافه کردن تعداد کانتینر به پارامترهای جستجو
      };
      
      // Get origin and destination to determine appropriate transport types
      const origin = params.originId ? await storage.getLocation(params.originId) : null;
      const destination = params.destinationId ? await storage.getLocation(params.destinationId) : null;
      
      // If both locations are found, automatically determine possible transport types
      let possibleTransportTypes: string[] = [];
      if (origin && destination) {
        // Inland to inland within Iran - always show both rail and land
        if (origin.type === "inland" && destination.type === "inland" && 
            origin.country === "ایران" && destination.country === "ایران") {
          possibleTransportTypes = ["rail", "land", "mixed"];
        }
        // Port to inland or inland to port within Iran - always show both rail and land
        else if ((origin.type === "port" && destination.type === "inland" || 
                origin.type === "inland" && destination.type === "port") && 
                origin.country === "ایران" && destination.country === "ایران") {
          possibleTransportTypes = ["rail", "land", "mixed"];
        }
        // Port to port - only use actual sea transport prices from providers
        else if (origin.type === "port" && destination.type === "port") {
          possibleTransportTypes = ["sea"];
        }
        // International via sea (inland in Iran to international destination)
        else if (origin.country !== destination.country) {
          // Provide all transportation options for multi-modal routes
          if (origin.type === "inland" && origin.country === "ایران") {
            possibleTransportTypes = ["rail-sea", "land-sea", "mixed", "rail", "land"];
          } 
          else if (destination.type === "inland" && destination.country === "ایران") {
            possibleTransportTypes = ["sea-rail", "sea-land", "mixed", "rail", "land"];
          }
          else {
            possibleTransportTypes = ["sea", "mixed"];
          }
        }
      }
      
      // Get all shipments matching basic criteria
      const baseShipments = await storage.searchShipments(params);
      
      // If we have determined transport options, get additional shipments for those transport types
      let additionalShipments: any[] = [];
      for (const transportType of possibleTransportTypes) {
        // Only search for transport types not already included
        if (!baseShipments.some(s => s.transportType === transportType)) {
          const typeShipments = await storage.searchShipments({
            ...params,
            transportType
          });
          additionalShipments = [...additionalShipments, ...typeShipments];
        }
      }
      
      // Combine all shipments without duplicates
      const allShipmentIds = new Set(baseShipments.map(s => s.id));
      const uniqueAdditionalShipments = additionalShipments.filter(s => !allShipmentIds.has(s.id));
      const shipments = [...baseShipments, ...uniqueAdditionalShipments];
      
      // If no shipments found, create virtual/suggested shipments
      if (shipments.length === 0 && origin && destination) {
        // Find the distance between the origin and destination
        // Default values if distance calculation fails
        let distanceKm = 0;
        let durationMin = 0;
        
        try {
          const distance = await calculateDistanceBetweenCities(origin.name, destination.name);
          
          if (distance) {
            distanceKm = distance.distance;
            durationMin = distance.duration;
          } else {
            // Try estimating with our advanced estimation function
            const estimatedInfo = await estimateDistanceAndDuration(origin.name, destination.name);
            distanceKm = estimatedInfo.distance;
            durationMin = estimatedInfo.duration;
          }
        } catch (error) {
          console.error(`Error calculating distance between ${origin.name} and ${destination.name}:`, error);
          // Use fallback values
          distanceKm = 500;
          durationMin = 360;
        }
        
        // Current date for default departure date
        const now = new Date();
        const tomorrow = new Date(now);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        // Define suggested arrival dates for different transport types
        const railArrival = new Date(tomorrow);
        railArrival.setDate(railArrival.getDate() + Math.ceil(durationMin / (24 * 60)));
        
        const landArrival = new Date(tomorrow);
        landArrival.setDate(landArrival.getDate() + Math.ceil((durationMin * 1.2) / (24 * 60)));
        
        // Cargo weight from params or default - keep this as a let since we might adjust it based on container type
        let cargoWeight = params.cargoWeight ? (typeof params.cargoWeight === 'string' ? parseInt(params.cargoWeight) : params.cargoWeight) : 7000;
        
        // بررسی اینکه چه نوع حمل و نقلی درخواست شده (اگر مشخص نشده باشد، هر دو را پیشنهاد می‌کنیم)
        const requestedTransportType = params.transportType || '';
        
        // مشخص کردن انواع حمل و نقل پیشنهادی
        const suggestedTransportTypes: string[] = [];
        
        if (requestedTransportType) {
          // اگر نوع حمل و نقل مشخص شده، فقط همان نوع را پیشنهاد می‌کنیم
          if (requestedTransportType === 'rail' || requestedTransportType === 'land' || 
              requestedTransportType === 'sea' || requestedTransportType.startsWith('land_')) {
            suggestedTransportTypes.push(requestedTransportType);
          } else if (requestedTransportType === 'mixed') {
            // برای حالت ترکیبی، هر دو نوع را پیشنهاد می‌کنیم
            suggestedTransportTypes.push('rail');
            suggestedTransportTypes.push('land');
          }
        } else {
          // اگر نوع حمل و نقل مشخص نشده، بسته به نوع مبدا و مقصد، انواع مناسب را پیشنهاد می‌کنیم
          // برای مسیرهای داخلی ایران، هم ریلی و هم زمینی پیشنهاد می‌شود
          if (origin.country === "ایران" && destination.country === "ایران") {
            suggestedTransportTypes.push('rail');
            suggestedTransportTypes.push('land');
          }
          // برای مسیرهای بین‌المللی، فقط نوع‌های مناسب
          else if (origin.type === "port" && destination.type === "port") {
            suggestedTransportTypes.push('sea');
          }
          else {
            // برای حالت‌های دیگر، به صورت پیش‌فرض فقط ریلی و زمینی
            suggestedTransportTypes.push('rail');
            suggestedTransportTypes.push('land');
          }
        }
        
        // ساخت پیشنهاد ریلی اگر در انواع پیشنهادی باشد
        if (suggestedTransportTypes.includes('rail')) {
          // Create virtual rail shipment
          // بررسی اگر این مسیر بین‌المللی است 
          const isInternationalRoute = 
            (origin.country !== destination.country) || 
            (origin.type === "inland" && destination.type === "port" && destination.country !== "ایران") || 
            (destination.type === "inland" && origin.type === "port" && origin.country !== "ایران");
          
          const railPriceDetails = calculateDetailedPrice(
            'rail', 
            distanceKm, 
            cargoWeight, 
            undefined, 
            undefined, 
            isInternationalRoute
          );
          
          const railPrice = railPriceDetails ? railPriceDetails.priceToman : null;
          
          // استفاده از نتایج محاسبه شده توسط calculateDetailedPrice برای حمل و نقل ریلی
          const railRatePerKgKm = railPriceDetails ? railPriceDetails.rate : 34; // ریال برای هر کیلوگرم-کیلومتر
          const exactRailPriceRial = railPriceDetails ? railPriceDetails.priceRial : 0;
          const exactRailPriceToman = railPriceDetails ? railPriceDetails.priceToman : 0;
          const railFormulaDesc = railPriceDetails ? railPriceDetails.formulaDescription : '';
          
          shipments.push({
            id: `suggested-rail-${origin.id}-${destination.id}`,
            transporterId: 0,
            originId: origin.id,
            destinationId: destination.id,
            transportType: 'rail',
            containerType: 'واگن باری',
            departureDate: tomorrow.toISOString().split('T')[0],
            arrivalDate: railArrival.toISOString().split('T')[0],
            capacity: cargoWeight,
            price: railPrice,
            calculatedPrice: Math.round(exactRailPriceToman), // اضافه کردن قیمت دقیق محاسبه شده
            suggested: true,
            distance: distanceKm,
            duration: durationMin,
            active: true,
            originName: origin.name,
            originCountry: origin.country,
            destinationName: destination.name,
            destinationCountry: destination.country,
            transporterName: "سیستم مسیریابی هوشمند",
            transportPrice: {
              priceRial: exactRailPriceRial,
              priceToman: exactRailPriceToman,
              formulaDescription: railFormulaDesc
            },
            transportDetails: {
              vehicleType: "rail",
              vehicleDisplayName: "واگن باری",
              baseRate: railRatePerKgKm, // ریال برای هر کیلوگرم-کیلومتر
              baseRateDescription: "قطار باری: ۳۴ ریال/کیلوگرم-کیلومتر"
            }
          });
        }
        
        // ساخت پیشنهادهای زمینی برای انواع وسایل نقلیه مختلف
        if (suggestedTransportTypes.includes('land') || suggestedTransportTypes.some(t => t.startsWith('land_'))) {
          // بررسی اگر این مسیر بین‌المللی است
          const isInternationalRoute = 
            (origin.country !== destination.country) || 
            (origin.type === "inland" && destination.type === "port" && destination.country !== "ایران") || 
            (destination.type === "inland" && origin.type === "port" && origin.country !== "ایران");

          // لیست وسایل نقلیه زمینی که باید نمایش داده شوند
          const landVehicleTypes = [
            { type: 'land_trailer', displayName: 'تریلی', capacity: 24000, minWeight: 20000 },
            { type: 'land_truck', displayName: 'کامیون', capacity: 18000, minWeight: 10000 },
            { type: 'land_small_truck', displayName: 'خاور', capacity: 9000, minWeight: 5000 },
            { type: 'land_pickup', displayName: 'نیسان', capacity: 5000, minWeight: 2000 },
            { type: 'land_van', displayName: 'وانت', capacity: 2000, minWeight: 0 },
          ];
          
          // بررسی پارامترهای ورودی برای تصمیم‌گیری 
          const containerTypeParam = params.containerType as string | undefined;
          const userSpecifiedWeight = params.cargoWeight ? true : false;
          
          // اگر کانتینر انتخاب شده، فقط تریلی را نشان بده
          let vehiclesToShow = landVehicleTypes;
          if (containerTypeParam && 
              (containerTypeParam.includes('container') || containerTypeParam.includes('کانتینر') || 
               containerTypeParam.includes('20') || containerTypeParam.includes('40'))) {
            
            // برای کانتینر فقط تریلی را نشان می‌دهیم
            vehiclesToShow = [landVehicleTypes[0]]; // فقط تریلی
            console.log("Container selected - showing only trailer option");
            
            // تنظیم وزن بار متناسب با نوع کانتینر
            if (containerTypeParam.startsWith('40_') || containerTypeParam.includes('40')) {
              // کانتینر 40 فوتی - حدود 30 تن
              cargoWeight = 30000;
            } else if (containerTypeParam.startsWith('20_') || containerTypeParam.includes('20')) {
              // کانتینر 20 فوتی - حدود 20 تن
              cargoWeight = 20000;
            }
          } else if (requestedTransportType && requestedTransportType.startsWith('land_')) {
            // اگر نوع خاصی از وسیله نقلیه درخواست شده، فقط همان را نشان بده
            const specificVehicle = landVehicleTypes.find(v => v.type === requestedTransportType);
            if (specificVehicle) {
              vehiclesToShow = [specificVehicle];
              console.log(`Specific vehicle type requested: ${requestedTransportType} - showing only this option`);
            }
          } else {
            // نمایش همه گزینه‌های مناسب بر اساس وزن
            // فقط وسایل نقلیه‌ای که برای این وزن مناسب هستند را نشان بده
            vehiclesToShow = landVehicleTypes.filter(vehicle => cargoWeight >= vehicle.minWeight);
            console.log(`Showing ${vehiclesToShow.length} vehicle options appropriate for weight ${cargoWeight}kg`);
          }

          // ایجاد گزینه‌های حمل و نقل برای هر نوع وسیله نقلیه
          for (const vehicle of vehiclesToShow) {
            // محاسبه قیمت با حداکثر ظرفیت وسیله نقلیه (رویکرد قیمت‌گذاری بر اساس کل ظرفیت)
            const landPriceDetails = calculateDetailedPrice(
              vehicle.type, 
              distanceKm, 
              vehicle.capacity, // حداکثر ظرفیت را برای محاسبه استفاده می‌کنیم
              undefined, 
              undefined,
              isInternationalRoute
            );
            
            if (!landPriceDetails) continue; // اگر محاسبه قیمت ناموفق بود، این گزینه را نشان نده
            
            // استفاده از نتایج محاسبه شده توسط calculateDetailedPrice
            const exactPriceRial = landPriceDetails.priceRial;
            const exactPriceToman = landPriceDetails.priceToman;
            const rate = landPriceDetails.rate;
            const formulaDesc = landPriceDetails.formulaDescription;
            
            const landPrice = Math.round(exactPriceToman / 1000) * 1000;
            
            // تعیین مدت زمان سفر - وسایل کوچکتر سریعتر هستند
            let vehicleDuration = durationMin;
            if (vehicle.type === 'land_van' || vehicle.type === 'land_pickup') {
              vehicleDuration = Math.round(durationMin * 0.9); // وانت و نیسان سریعتر هستند
            } else if (vehicle.type === 'land_trailer') {
              vehicleDuration = Math.round(durationMin * 1.2); // تریلی کندتر است
            }
            
            // تعیین تاریخ رسیدن بر اساس مدت زمان سفر
            const vehicleArrival = new Date(tomorrow);
            vehicleArrival.setMinutes(vehicleArrival.getMinutes() + vehicleDuration);
            
            // توضیحات نرخ پایه برای هر وسیله نقلیه
            const baseRateDescription = 
              vehicle.type === 'land_trailer' ? 
                "تریلی: ۹,۵۰۰ ریال/تن-کیلومتر" : 
              vehicle.type === 'land_truck' ? 
                "کامیون: ۱۰,۰۰۰ ریال/تن-کیلومتر" : 
              vehicle.type === 'land_small_truck' ? 
                "خاور: ۱۳,۵۰۰ ریال/تن-کیلومتر" : 
              vehicle.type === 'land_pickup' ? 
                "نیسان: ۱۷,۵۰۰ ریال/تن-کیلومتر" : 
                "وانت: ۲۰,۰۰۰ ریال/تن-کیلومتر";

            // ایجاد رکورد سرویس برای این وسیله نقلیه
            shipments.push({
              id: `suggested-${vehicle.type}-${origin.id}-${destination.id}`,
              transporterId: 0,
              originId: origin.id,
              destinationId: destination.id,
              transportType: 'land',
              containerType: vehicle.displayName, // نام فارسی وسیله نقلیه
              departureDate: tomorrow.toISOString().split('T')[0],
              arrivalDate: vehicleArrival.toISOString().split('T')[0],
              capacity: vehicle.capacity,
              price: landPrice,
              calculatedPrice: Math.round(exactPriceToman),
              suggested: true,
              distance: distanceKm,
              duration: vehicleDuration,
              active: true,
              originName: origin.name,
              originCountry: origin.country,
              destinationName: destination.name,
              destinationCountry: destination.country,
              transporterName: "سیستم مسیریابی هوشمند",
              transportPrice: {
                priceRial: exactPriceRial,
                priceToman: exactPriceToman,
                formulaDescription: formulaDesc
              },
              transportDetails: {
                vehicleType: vehicle.type,
                vehicleDisplayName: vehicle.displayName,
                baseRate: rate,
                baseRateDescription: baseRateDescription
              }
            });
          }
        }
        
        // اگر حمل و نقل دریایی درخواست شده باشد
        if (suggestedTransportTypes.includes('sea')) {
          // برای حمل و نقل دریایی، فقط قیمت‌های واقعی از شرکت‌های حمل و نقل
          // یک مسیر دریایی با قیمت خالی ایجاد کنیم
          console.log(`Adding sea route option from ${origin.name} to ${destination.name} without automatic pricing`);
          
          shipments.push({
            id: `suggested-sea-${origin.id}-${destination.id}`,
            transporterId: 0,
            originId: origin.id,
            destinationId: destination.id,
            transportType: 'sea',
            containerType: 'کشتی حمل بار',
            departureDate: tomorrow.toISOString().split('T')[0],
            arrivalDate: new Date(tomorrow.getTime() + (distanceKm / 25 * 60 * 60 * 1000)).toISOString().split('T')[0],
            capacity: 8000,
            price: null, // قیمت ندارد - باید از شرکت حمل و نقل دریافت شود
            suggested: true,
            distance: distanceKm,
            duration: Math.round(distanceKm / 25 * 60), // سرعت حرکت کشتی حدود 25 کیلومتر در ساعت
            active: true,
            originName: origin.name,
            originCountry: origin.country,
            destinationName: destination.name,
            destinationCountry: destination.country,
            transporterName: 'شرکت‌های حمل و نقل دریایی',
            transportPrice: {
              priceRial: null,
              priceToman: null,
              formulaDescription: 'قیمت باید از شرکت حمل و نقل دریایی دریافت شود'
            },
            transportDetails: {
              vehicleType: 'sea',
              vehicleDisplayName: 'کشتی حمل بار',
              baseRate: null,
              baseRateDescription: 'قیمت باید از شرکت حمل و نقل دریایی دریافت شود'
            }
          });
        }
      }
      
      // Enhance shipments with origin and destination information and calculate distances for rail transport
      const enhancedShipments = await Promise.all(shipments.map(async shipment => {
        const origin = await storage.getLocation(shipment.originId);
        const destination = await storage.getLocation(shipment.destinationId);
        const transporter = await storage.getTransporter(shipment.transporterId);
        
        // استفاده از تابع محاسبه فاصله از پایگاه داده مسافت‌ها
        const calculateDistance = async (loc1: any, loc2: any) => {
          if (!loc1 || !loc2 || !loc1.name || !loc2.name) return null;
          
          try {
            // استفاده از تابع محاسبه فاصله از پایگاه داده
            const distanceInfo = await calculateDistanceBetweenCities(loc1.name, loc2.name);
            
            // اگر مسیر در پایگاه داده یافت شد
            if (distanceInfo) {
              return distanceInfo.distance;
            }
            
            // اگر مسیر در پایگاه داده نبود، از تابع تخمین فاصله استفاده می‌کنیم
            const estimatedInfo = await estimateDistanceAndDuration(loc1.name, loc2.name);
            return estimatedInfo.distance;
          } catch (error) {
            console.error(`Error calculating distance between ${loc1.name} and ${loc2.name}:`, error);
            // در صورت خطا، مقدار پیش‌فرض برگردان
            return 500; // فاصله پیش‌فرض
          }
        };
        
        // تابع محاسبه قیمت بر اساس نوع وسیله نقلیه، وزن و فاصله
        const calculateTransportPrice = (transportType: string, distance: number, weight: number | null = null) => {
          // نرخ‌های پایه بر اساس ریال/تن-کیلومتر (نرخ‌های به‌روز بازار)
          const baseRates: Record<string, number> = {
            'rail': 34,                // نرخ ریلی (ریال به ازای هر کیلوگرم-کیلومتر)
            'land_trailer': 8900,      // تریلی (ریال به ازای هر تن-کیلومتر) - نرخ پایه که با توجه به بازار تا 10,000 ریال متغیر است
            'land_truck': 9500,        // کامیون (ریال به ازای هر تن-کیلومتر) - نرخ پایه که تا 11,000 ریال متغیر است
            'land_small_truck': 12000, // خاور (ریال به ازای هر تن-کیلومتر) - نرخ پایه که تا 15,000 ریال متغیر است
            'land_pickup': 15000,      // نیسان (ریال به ازای هر تن-کیلومتر) - نرخ پایه که تا 20,000 ریال متغیر است
            'land_van': 20000,         // وانت (ریال به ازای هر تن-کیلومتر)
            'sea': 5000                // حمل دریایی (ریال به ازای هر تن-کیلومتر)
          };
          
          // تعیین نرخ بر اساس نوع حمل و نقل
          let rate = 0;
          let weightInTons = 0;
          
          // پردازش بر اساس نوع حمل و نقل
          if (transportType === 'rail') {
            rate = baseRates.rail;
            // برای حمل و نقل ریلی، وزن بر حسب کیلوگرم است
            weightInTons = weight ? weight / 1000 : 1;  // تبدیل به تن
            // قیمت بر اساس ریال: وزن (کیلوگرم) × فاصله × نرخ
            return {
              priceRial: weight ? weight * distance * rate : null,
              priceToman: weight ? (weight * distance * rate) / 10 : null,
              formulaDescription: weight ? `${weight} کیلوگرم × ${distance} کیلومتر × ${rate} ریال ÷ 10 = قیمت (تومان)` : null
            };
          } else if (transportType.startsWith('land_')) {
            // برای حمل و نقل زمینی، انتخاب نرخ مناسب
            rate = baseRates[transportType] || baseRates.land_truck;
            weightInTons = weight ? weight / 1000 : 1;  // تبدیل به تن
            // قیمت بر اساس ریال: وزن (تن) × فاصله × نرخ
            return {
              priceRial: weight ? weightInTons * distance * rate : null,
              priceToman: weight ? (weightInTons * distance * rate) / 10 : null,
              formulaDescription: weight ? `${weightInTons} تن × ${distance} کیلومتر × ${rate} ریال ÷ 10 = قیمت (تومان)` : null
            };
          } else if (transportType === 'sea') {
            // برای حمل و نقل دریایی نباید قیمت تخمینی تولید کنیم
            return {
              priceRial: null,
              priceToman: null,
              formulaDescription: "قیمت دریایی باید از شرکت حمل و نقل دریافت شود",
              isActualPrice: false
            };
          } else {
            // برای سایر انواع حمل و نقل
            return {
              priceRial: null,
              priceToman: null,
              formulaDescription: null
            };
          }
        };
        
        // محاسبه فاصله و قیمت برای سرویس‌های حمل و نقل
        let distance = null;
        let transportPrice = null;
        let transportDetails = null;
        
        if (origin && destination) {
          // فراخوانی آسنکرون محاسبه فاصله
          distance = await calculateDistance(origin, destination);
          
          // بررسی وجود وزن محموله
          const cargoWeight = shipment.containerType?.includes('20') ? 20000 : 
                              shipment.containerType?.includes('40') ? 30000 : 
                              null;  // وزن پیش‌فرض برای کانتینرها
                              
          // محاسبه قیمت بر اساس نوع حمل و نقل
          let vehicleType = 'land_truck';  // نوع وسیله نقلیه پیش‌فرض
          
          if (shipment.transportType === 'land') {
            // تعیین نوع وسیله نقلیه زمینی بر اساس ظرفیت یا نوع کانتینر
            if (shipment.capacity > 20000) {
              vehicleType = 'land_trailer';
            } else if (shipment.capacity > 10000) {
              vehicleType = 'land_truck';
            } else if (shipment.capacity > 5000) {
              vehicleType = 'land_small_truck';
            } else if (shipment.capacity > 2000) {
              vehicleType = 'land_pickup';
            } else {
              vehicleType = 'land_van';
            }
            
            transportPrice = distance !== null ? calculateTransportPrice(vehicleType, Number(distance), cargoWeight) : null;
            // تعیین نام نوع وسیله نقلیه زمینی برای نمایش
            let vehicleDisplayName = "کامیون";
            if (vehicleType === 'land_van') {
              vehicleDisplayName = "وانت";
            } else if (vehicleType === 'land_pickup') {
              vehicleDisplayName = "نیسان";
            } else if (vehicleType === 'land_small_truck') {
              vehicleDisplayName = "خاور";
            } else if (vehicleType === 'land_truck') {
              vehicleDisplayName = "کامیون";
            } else if (vehicleType === 'land_trailer') {
              vehicleDisplayName = "تریلی";
            }
            
            transportDetails = {
              vehicleType: vehicleType,
              vehicleDisplayName: vehicleDisplayName,
              baseRate: vehicleType === 'land_trailer' ? 8900 : // نرخ پایه که با توجه به بازار تا 10,000 ریال متغیر است
                        vehicleType === 'land_truck' ? 9500 : // نرخ پایه که تا 11,000 ریال متغیر است
                        vehicleType === 'land_small_truck' ? 12000 : // نرخ پایه که تا 15,000 ریال متغیر است
                        vehicleType === 'land_pickup' ? 15000 : 20000 // نیسان: نرخ پایه که تا 20,000 ریال متغیر است
            };
          } else if (shipment.transportType === 'rail') {
            transportPrice = distance !== null ? calculateTransportPrice('rail', Number(distance), cargoWeight) : null;
            transportDetails = {
              vehicleType: 'rail',
              vehicleDisplayName: "واگن باری",
              baseRate: 34,
              baseRateDescription: "قطار باری: ۳۴ ریال/کیلوگرم-کیلومتر"
            };
          } else if (shipment.transportType === 'sea') {
            // برای حمل و نقل دریایی، فقط از قیمت‌های واقعی ارائه شده توسط شرکت‌های حمل و نقل استفاده می‌کنیم
            // و هیچ قیمت تخمینی محاسبه نمی‌کنیم
            // اگر محموله قیمتی دارد، از آن استفاده می‌کنیم
            if (shipment.price) {
              transportPrice = {
                priceRial: shipment.price,
                priceToman: shipment.price / 10,
                formulaDescription: 'قیمت واقعی از شرکت حمل و نقل',
                isActualPrice: true
              };
            } else {
              // در غیر این صورت، هیچ قیمتی محاسبه نمی‌کنیم
              transportPrice = null;
            }
            
            transportDetails = {
              vehicleType: 'sea',
              baseRate: null, // نرخ پایه نداریم چون از قیمت‌های واقعی استفاده می‌کنیم
              note: 'فقط قیمت‌های واقعی از شرکت‌های حمل و نقل'
            };
          }
        }
        
        return {
          ...shipment,
          originName: origin?.name || 'Unknown',
          originCountry: origin?.country || 'Unknown',
          destinationName: destination?.name || 'Unknown',
          destinationCountry: destination?.country || 'Unknown',
          transporterName: transporter?.companyName || 'Unknown',
          distance: distance,
          transportPrice: transportPrice,
          transportDetails: transportDetails
        };
      }));
      
      res.json(enhancedShipments);
    } catch (error) {
      res.status(500).json({ message: "Failed to search shipments" });
    }
  });
  
  // Hot Deals API - returns the newest shipments as special deals
  app.get("/api/hot-deals", async (req, res) => {
    try {
      // Directly get active shipments with newest first - maximum 3
      const query = sql`
        SELECT s.id, s.transporter_id, s.origin_id, s.destination_id, 
               s.departure_date, s.arrival_date, s.transport_type, 
               s.container_type, s.capacity, s.price, s.insurance_available, 
               s.insurance_price, s.active, s.special_notes, s.created_at
        FROM shipments s
        WHERE s.active = true
        ORDER BY s.created_at DESC
        LIMIT 3
      `;
      
      const result = await db.execute(query);
      
      if (!result.rows || result.rows.length === 0) {
        return res.json([]);
      }
      
      // Convert snake_case to camelCase for our shipments
      const recentShipments = result.rows.map((row: any) => ({
        id: row.id,
        transporterId: row.transporter_id,
        originId: row.origin_id,
        destinationId: row.destination_id,
        departureDate: row.departure_date,
        arrivalDate: row.arrival_date,
        transportType: row.transport_type,
        containerType: row.container_type,
        capacity: row.capacity,
        price: row.price,
        insuranceAvailable: row.insurance_available,
        insurancePrice: row.insurance_price,
        active: row.active,
        specialNotes: row.special_notes,
        createdAt: row.created_at
      }));
      
      // Map to simplified objects with needed information
      const hotDeals = [];
      
      for (const shipment of recentShipments) {
        try {
          const origin = await storage.getLocation(Number(shipment.originId));
          const destination = await storage.getLocation(Number(shipment.destinationId));
          const transporter = await storage.getTransporter(Number(shipment.transporterId));
          
          if (!origin || !destination) {
            continue; // Skip if origin or destination missing
          }
          
          // قیمت را بدون تخفیف استفاده می‌کنیم
          const originalPrice = Number(shipment.price);
          
          // Format for Persian date
          let departureDateDisplay = 'تاریخ نامشخص';
          if (shipment.departureDate) {
            try {
              departureDateDisplay = new Date(String(shipment.departureDate)).toLocaleDateString('fa-IR');
            } catch (e) {
              console.error('Error formatting date:', e);
            }
          }
          
          hotDeals.push({
            id: shipment.id,
            route: `${origin.name} به ${destination.name}`,
            description: shipment.containerType === '20_standard' ? 'کانتینر ۲۰ فوت' : 
                        shipment.containerType === '40_standard' ? 'کانتینر ۴۰ فوت' : 
                        'حمل بار تجاری',
            departureDate: departureDateDisplay,
            companyName: transporter?.companyName || 'شرکت حمل و نقل',
            price: originalPrice,
            badge: {
              text: "پیشنهاد ویژه",
              color: "amber"
            },
            transportType: shipment.transportType as "sea" | "land" | "rail" | "mixed"
          });
        } catch (err) {
          console.error('Error processing shipment for hot deals:', err);
          // Continue with next shipment
        }
      }
      
      // Always return an array, even if empty
      res.json(hotDeals);
    } catch (error) {
      console.error('Error in hot-deals API:', error);
      res.status(500).json({ message: "Failed to get hot deals" });
    }
  });
  
  app.get("/api/shipments/own", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Check if user is a transporter or admin
      const user = req.user;
      let transporterId;
      
      if (user.userType === "transporter") {
        // Get transporter information
        const transporter = await storage.getTransporterByUserId(user.id);
        if (!transporter) {
          return res.status(404).json({ message: "Transporter profile not found" });
        }
        transporterId = transporter.id;
      } else if (user.role === "admin") {
        // Allow admin to view any transporter's shipments
        // If transporterId is provided in query, use that; otherwise, find the first transporter
        if (req.query.transporterId) {
          transporterId = parseInt(req.query.transporterId as string);
        } else {
          const allTransporters = await storage.getAllTransporters();
          if (allTransporters.length === 0) {
            return res.json([]);
          }
          transporterId = allTransporters[0].id;
        }
      } else {
        return res.status(403).json({ message: "Only transporters or admins can view shipments" });
      }
      
      // Directly query the database to avoid column mismatch issues
      const query = sql`
        SELECT s.id, s.transporter_id, s.origin_id, s.destination_id, 
               s.departure_date, s.arrival_date, s.transport_type, 
               s.container_type, s.capacity, s.price, s.insurance_available, 
               s.insurance_price, s.active, s.special_notes, s.created_at
        FROM shipments s
        WHERE s.transporter_id = ${transporterId}
        ORDER BY s.created_at DESC
      `;
      
      const result = await db.execute(query);
      
      if (!result.rows || result.rows.length === 0) {
        return res.json([]);
      }
      
      // Convert snake_case to camelCase for our shipments
      const shipments = result.rows.map((row: any) => ({
        id: row.id,
        transporterId: row.transporter_id,
        originId: row.origin_id,
        destinationId: row.destination_id,
        departureDate: row.departure_date,
        arrivalDate: row.arrival_date,
        transportType: row.transport_type,
        containerType: row.container_type,
        capacity: row.capacity,
        price: row.price,
        insuranceAvailable: row.insurance_available,
        insurancePrice: row.insurance_price,
        active: row.active,
        specialNotes: row.special_notes,
        createdAt: row.created_at
      }));
      
      // Enhance shipments with origin and destination information
      const enhancedShipments = await Promise.all(shipments.map(async shipment => {
        const origin = await storage.getLocation(Number(shipment.originId));
        const destination = await storage.getLocation(Number(shipment.destinationId));
        
        return {
          ...shipment,
          originName: origin?.name || 'Unknown',
          originCountry: origin?.country || 'Unknown',
          destinationName: destination?.name || 'Unknown',
          destinationCountry: destination?.country || 'Unknown'
        };
      }));
      
      res.json(enhancedShipments);
    } catch (error) {
      console.error("Error fetching own shipments:", error);
      res.status(500).json({ message: "Failed to fetch shipment" });
    }
  });
  
  app.get("/api/shipments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const shipment = await storage.getShipment(id);
      if (!shipment) {
        return res.status(404).json({ message: "Shipment not found" });
      }
      
      // Get additional information for the shipment
      const origin = await storage.getLocation(shipment.originId);
      const destination = await storage.getLocation(shipment.destinationId);
      const transporter = await storage.getTransporter(shipment.transporterId);
      
      // Get cargo weight from query params if it exists
      const cargoWeight = req.query.cargoWeight as string | undefined;
      
      // استفاده از تابع محاسبه فاصله از پایگاه داده مسافت‌ها
      const calculateDistance = async (loc1: any, loc2: any) => {
        if (!loc1 || !loc2 || !loc1.name || !loc2.name) return null;
        
        try {
          // استفاده از تابع محاسبه فاصله از پایگاه داده
          const distanceInfo = await calculateDistanceBetweenCities(loc1.name, loc2.name);
          
          // اگر مسیر در پایگاه داده یافت شد
          if (distanceInfo) {
            return distanceInfo.distance;
          }
          
          // اگر مسیر در پایگاه داده نبود، از تابع تخمین فاصله استفاده می‌کنیم
          const estimatedInfo = await estimateDistanceAndDuration(loc1.name, loc2.name);
          return estimatedInfo.distance;
        } catch (error) {
          console.error(`Error calculating distance between ${loc1.name} and ${loc2.name}:`, error);
          // در صورت خطا، مقدار پیش‌فرض برگردان
          return 500; // فاصله پیش‌فرض
        }
      };
      
      // تابع محاسبه قیمت بر اساس نوع وسیله نقلیه، وزن و فاصله
      const calculateTransportPrice = (transportType: string, distance: number, weight: number | null = null) => {
        // نرخ‌های پایه بر اساس ریال/تن-کیلومتر (نرخ‌های به‌روز بازار)
        const baseRates: Record<string, number> = {
          'rail': 34,                // نرخ ریلی (ریال به ازای هر کیلوگرم-کیلومتر)
          'land_trailer': 8900,      // تریلی (ریال به ازای هر تن-کیلومتر) - نرخ پایه که با توجه به بازار تا 10,000 ریال متغیر است
          'land_truck': 9500,        // کامیون (ریال به ازای هر تن-کیلومتر) - نرخ پایه که تا 11,000 ریال متغیر است
          'land_small_truck': 12000, // خاور (ریال به ازای هر تن-کیلومتر) - نرخ پایه که تا 15,000 ریال متغیر است
          'land_pickup': 15000,      // نیسان (ریال به ازای هر تن-کیلومتر) - نرخ پایه که تا 20,000 ریال متغیر است
          'land_van': 20000,         // وانت (ریال به ازای هر تن-کیلومتر)
          'sea': 5000                // حمل دریایی (ریال به ازای هر تن-کیلومتر)
        };
        
        // تعیین نرخ بر اساس نوع حمل و نقل
        let rate = 0;
        let weightInTons = 0;
        
        // پردازش بر اساس نوع حمل و نقل
        if (transportType === 'rail') {
          rate = baseRates.rail;
          // برای حمل و نقل ریلی، وزن بر حسب کیلوگرم است
          weightInTons = weight ? weight / 1000 : 1;  // تبدیل به تن
          // قیمت بر اساس ریال: وزن (کیلوگرم) × فاصله × نرخ
          return {
            priceRial: weight ? weight * distance * rate : null,
            priceToman: weight ? (weight * distance * rate) / 10 : null,
            formulaDescription: weight ? `${weight} کیلوگرم × ${distance} کیلومتر × ${rate} ریال ÷ 10 = قیمت (تومان)` : null
          };
        } else if (transportType.startsWith('land_')) {
          // برای حمل و نقل زمینی، انتخاب نرخ مناسب
          rate = baseRates[transportType] || baseRates.land_truck;
          weightInTons = weight ? weight / 1000 : 1;  // تبدیل به تن
          // قیمت بر اساس ریال: وزن (تن) × فاصله × نرخ
          return {
            priceRial: weight ? weightInTons * distance * rate : null,
            priceToman: weight ? (weightInTons * distance * rate) / 10 : null,
            formulaDescription: weight ? `${weightInTons} تن × ${distance} کیلومتر × ${rate} ریال ÷ 10 = قیمت (تومان)` : null
          };
        } else if (transportType === 'sea') {
          rate = baseRates.sea;
          weightInTons = weight ? weight / 1000 : 1;
          return {
            priceRial: weight ? weightInTons * distance * rate : null,
            priceToman: weight ? (weightInTons * distance * rate) / 10 : null,
            formulaDescription: weight ? `${weightInTons} تن × ${distance} کیلومتر × ${rate} ریال ÷ 10 = قیمت (تومان)` : null
          };
        } else {
          // برای سایر انواع حمل و نقل
          return {
            priceRial: null,
            priceToman: null,
            formulaDescription: null
          };
        }
      };
      
      // محاسبه اطلاعات بیشتر برای حمل و نقل
      let distance = null;
      let transportPrice = null;
      let transportDetails = null;
      let calculatedPrice = null;
      let weight = null;
      let vehicleType = 'land_truck';
      
      if (origin && destination) {
        try {
          distance = await calculateDistance(origin, destination);
          
          // بررسی وجود وزن محموله
          const parsedWeight = cargoWeight ? parseFloat(cargoWeight) : null;
          weight = parsedWeight || (shipment.containerType?.includes('20') ? 20000 : 
                              shipment.containerType?.includes('40') ? 30000 : null);
          
          // محاسبه قیمت بر اساس نوع حمل و نقل
          // نوع وسیله نقلیه پیش‌فرض
        } catch (error) {
          console.error('Error calculating distance:', error);
          distance = null;
        }
        
        // Parse weight from query or use default for container types
        const parsedWeight = cargoWeight ? parseFloat(cargoWeight) : null;
        const defaultWeight = shipment.containerType?.includes('20') ? 20000 : 
                             shipment.containerType?.includes('40') ? 30000 : null;
        weight = parsedWeight || defaultWeight;
        
        if (shipment.transportType === 'land') {
          // تعیین نوع وسیله نقلیه زمینی بر اساس ظرفیت یا نوع کانتینر
          if (shipment.capacity > 20000) {
            vehicleType = 'land_trailer';
          } else if (shipment.capacity > 10000) {
            vehicleType = 'land_truck';
          } else if (shipment.capacity > 5000) {
            vehicleType = 'land_small_truck';
          } else if (shipment.capacity > 2000) {
            vehicleType = 'land_pickup';
          } else {
            vehicleType = 'land_van';
          }
          
          if (distance !== null) {
            transportPrice = calculateTransportPrice(vehicleType, Number(distance), weight);
            calculatedPrice = transportPrice?.priceToman || null;
          }
          
          // تعیین نام نوع وسیله نقلیه زمینی برای نمایش
          let vehicleDisplayName = "کامیون";
          if (vehicleType === 'land_van') {
            vehicleDisplayName = "وانت";
          } else if (vehicleType === 'land_pickup') {
            vehicleDisplayName = "نیسان";
          } else if (vehicleType === 'land_small_truck') {
            vehicleDisplayName = "خاور";
          } else if (vehicleType === 'land_truck') {
            vehicleDisplayName = "کامیون";
          } else if (vehicleType === 'land_trailer') {
            vehicleDisplayName = "تریلی";
          }

          transportDetails = {
            vehicleType: vehicleType,
            vehicleDisplayName: vehicleDisplayName,
            baseRate: vehicleType === 'land_trailer' ? 8900 : 
                      vehicleType === 'land_truck' ? 9500 : 
                      vehicleType === 'land_small_truck' ? 12000 : 
                      vehicleType === 'land_pickup' ? 15000 : 20000,
            baseRateDescription: vehicleType === 'land_trailer' ? 
              "تریلی: ۸۹۰۰ تا ۱۰,۰۰۰ ریال/تن-کیلومتر" : 
              vehicleType === 'land_truck' ? 
              "کامیون: ۹,۵۰۰ تا ۱۱,۰۰۰ ریال/تن-کیلومتر" : 
              vehicleType === 'land_small_truck' ? 
              "خاور: ۱۲,۰۰۰ تا ۱۵,۰۰۰ ریال/تن-کیلومتر" : 
              vehicleType === 'land_pickup' ? 
              "نیسان: ۱۵,۰۰۰ تا ۲۰,۰۰۰ ریال/تن-کیلومتر" : 
              "وانت: ۲۰,۰۰۰ ریال/تن-کیلومتر"
          };
        } else if (shipment.transportType === 'rail') {
          if (distance !== null && weight) {
            transportPrice = calculateTransportPrice('rail', Number(distance), weight);
            calculatedPrice = transportPrice?.priceToman || null;
          }
          
          transportDetails = {
            vehicleType: 'rail',
            vehicleDisplayName: "واگن باری",
            baseRate: 34,
            baseRateDescription: "قطار باری: ۳۴ ریال/کیلوگرم-کیلومتر"
          };
        } else if (shipment.transportType === 'sea') {
          if (distance !== null) {
            transportPrice = calculateTransportPrice('sea', Number(distance), weight);
            calculatedPrice = transportPrice?.priceToman || null;
          }
          
          transportDetails = {
            vehicleType: 'sea',
            vehicleDisplayName: "کشتی حمل بار",
            baseRate: 5000,
            baseRateDescription: "حمل دریایی: ۵,۰۰۰ ریال/تن-کیلومتر"
          };
        }
      }
      
      // ارسال نتیجه با اطلاعات تکمیلی
      res.json({
        ...shipment,
        originName: origin?.name || 'Unknown',
        originCountry: origin?.country || 'Unknown',
        destinationName: destination?.name || 'Unknown',
        destinationCountry: destination?.country || 'Unknown',
        transporterName: transporter?.companyName || 'Unknown',
        distance: distance,
        calculatedPrice: calculatedPrice,
        transportPrice: transportPrice,
        transportDetails: transportDetails
      });
      
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shipment" });
    }
  });
  
  app.post("/api/shipments", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Check if user is a transporter or admin
      const user = req.user;
      let transporterId;
      
      if (user.userType === "transporter") {
        // Get transporter information
        const transporter = await storage.getTransporterByUserId(user.id);
        if (!transporter) {
          return res.status(404).json({ message: "Transporter profile not found" });
        }
        transporterId = transporter.id;
      } else if (user.role === "admin") {
        // Allow admin to create shipments too
        // Admin needs to provide transporterId in the request body
        if (!req.body.transporterId) {
          return res.status(400).json({ message: "Admin must provide transporterId when creating shipments" });
        }
        transporterId = req.body.transporterId;
      } else {
        return res.status(403).json({ message: "Only transporters or admins can create shipments" });
      }
      
      // Log the incoming data for debugging
      console.log("Shipment data received:", req.body);
      
      // Check for isComposite field and handle it explicitly
      const isComposite = req.body.transportType === 'mixed';
      
      const validatedData = insertShipmentSchema.parse({
        ...req.body,
        transporterId: transporterId,
        isComposite: isComposite
      });
      
      // Log validated data
      console.log("Validated shipment data:", validatedData);
      
      const shipment = await storage.createShipment(validatedData);
      res.status(201).json(shipment);
    } catch (error) {
      console.error("Error creating shipment:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid shipment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create shipment" });
    }
  });
  
  app.put("/api/shipments/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const shipmentId = parseInt(req.params.id);
      const shipment = await storage.getShipment(shipmentId);
      
      if (!shipment) {
        return res.status(404).json({ message: "Shipment not found" });
      }
      
      // Check if user is the owner of the shipment
      const transporter = await storage.getTransporterByUserId(req.user.id);
      if (!transporter || shipment.transporterId !== transporter.id) {
        return res.status(403).json({ message: "Not authorized to update this shipment" });
      }
      
      const updatedShipment = await storage.updateShipment(shipmentId, req.body);
      res.json(updatedShipment);
    } catch (error) {
      res.status(500).json({ message: "Failed to update shipment" });
    }
  });
  
  // This endpoint has been merged with the previous /api/shipments/:id endpoint
  
  // API endpoint to toggle shipment active status
  app.put("/api/shipments/:id/status", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const shipmentId = parseInt(req.params.id);
      const shipment = await storage.getShipment(shipmentId);
      
      if (!shipment) {
        return res.status(404).json({ message: "Shipment not found" });
      }
      
      // Check if user is the owner of the shipment
      const transporter = await storage.getTransporterByUserId(req.user.id);
      if (!transporter || shipment.transporterId !== transporter.id) {
        return res.status(403).json({ message: "Not authorized to update this shipment" });
      }
      
      const { active } = req.body;
      if (typeof active !== 'boolean') {
        return res.status(400).json({ message: "Invalid active status" });
      }
      
      const updatedShipment = await storage.updateShipment(shipmentId, { active });
      res.json(updatedShipment);
    } catch (error) {
      res.status(500).json({ message: "Failed to update shipment status" });
    }
  });
  
  // Shipment Segment Operations
  app.get("/api/shipments/:shipmentId/segments", async (req, res) => {
    try {
      const shipmentId = parseInt(req.params.shipmentId);
      const segments = await storage.getShipmentSegments(shipmentId);
      
      // Enhance segments with origin and destination information
      const enhancedSegments = await Promise.all(segments.map(async segment => {
        const origin = await storage.getLocation(segment.originId);
        const destination = await storage.getLocation(segment.destinationId);
        
        return {
          ...segment,
          originName: origin?.name || 'Unknown',
          originCountry: origin?.country || 'Unknown',
          destinationName: destination?.name || 'Unknown',
          destinationCountry: destination?.country || 'Unknown'
        };
      }));
      
      res.json(enhancedSegments);
    } catch (error) {
      console.error("Error fetching shipment segments:", error);
      res.status(500).json({ message: "Failed to fetch shipment segments" });
    }
  });
  
  app.get("/api/segments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const segment = await storage.getShipmentSegment(id);
      
      if (!segment) {
        return res.status(404).json({ message: "Segment not found" });
      }
      
      res.json(segment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch segment" });
    }
  });
  
  app.post("/api/shipments/:shipmentId/segments", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const shipmentId = parseInt(req.params.shipmentId);
      
      // Check if shipment exists
      const shipment = await storage.getShipment(shipmentId);
      if (!shipment) {
        return res.status(404).json({ message: "Shipment not found" });
      }
      
      // Check if user is the owner of the shipment or admin
      const user = req.user;
      const transporter = await storage.getTransporterByUserId(user.id);
      
      if (user.role !== "admin" && (!transporter || transporter.id !== shipment.transporterId)) {
        return res.status(403).json({ message: "Only the shipment owner or admins can add segments" });
      }
      
      // Parse the validated data
      const segmentData = insertShipmentSegmentSchema.parse({
        ...req.body,
        shipmentId
      });
      
      const segment = await storage.createShipmentSegment(segmentData);
      
      // Update the isComposite flag on the parent shipment if not already set
      if (!shipment.isComposite) {
        await storage.updateShipment(shipmentId, { isComposite: true });
      }
      
      res.status(201).json(segment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid segment data", errors: error.errors });
      }
      console.error("Error creating shipment segment:", error);
      res.status(500).json({ message: "Failed to create segment" });
    }
  });
  
  app.put("/api/segments/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id);
      
      // Check if segment exists
      const segment = await storage.getShipmentSegment(id);
      if (!segment) {
        return res.status(404).json({ message: "Segment not found" });
      }
      
      // Get parent shipment
      const shipment = await storage.getShipment(segment.shipmentId);
      if (!shipment) {
        return res.status(404).json({ message: "Parent shipment not found" });
      }
      
      // Check if user is the owner of the shipment or admin
      const user = req.user;
      const transporter = await storage.getTransporterByUserId(user.id);
      
      if (user.role !== "admin" && (!transporter || transporter.id !== shipment.transporterId)) {
        return res.status(403).json({ message: "Only the shipment owner or admins can update segments" });
      }
      
      // Update segment
      const updatedSegment = await storage.updateShipmentSegment(id, req.body);
      res.json(updatedSegment);
    } catch (error) {
      console.error("Error updating shipment segment:", error);
      res.status(500).json({ message: "Failed to update segment" });
    }
  });
  
  app.delete("/api/segments/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id);
      
      // Check if segment exists
      const segment = await storage.getShipmentSegment(id);
      if (!segment) {
        return res.status(404).json({ message: "Segment not found" });
      }
      
      // Get parent shipment
      const shipment = await storage.getShipment(segment.shipmentId);
      if (!shipment) {
        return res.status(404).json({ message: "Parent shipment not found" });
      }
      
      // Check if user is the owner of the shipment or admin
      const user = req.user;
      const transporter = await storage.getTransporterByUserId(user.id);
      
      if (user.role !== "admin" && (!transporter || transporter.id !== shipment.transporterId)) {
        return res.status(403).json({ message: "Only the shipment owner or admins can delete segments" });
      }
      
      // Delete segment
      const success = await storage.deleteShipmentSegment(id);
      
      // Check if this was the last segment and update the parent shipment's isComposite flag if needed
      const remainingSegments = await storage.getShipmentSegments(segment.shipmentId);
      if (remainingSegments.length === 0 && shipment.isComposite) {
        await storage.updateShipment(segment.shipmentId, { isComposite: false });
      }
      
      if (success) {
        res.status(204).send();
      } else {
        res.status(500).json({ message: "Failed to delete segment" });
      }
    } catch (error) {
      console.error("Error deleting shipment segment:", error);
      res.status(500).json({ message: "Failed to delete segment" });
    }
  });
  
  // Bookings API
  app.post("/api/bookings", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Check if user is a cargo owner
      if (req.user.userType !== "cargo_owner") {
        return res.status(403).json({ message: "Only cargo owners can create bookings" });
      }
      
      const validatedData = insertBookingSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      // Check if shipment exists
      const shipment = await storage.getShipment(validatedData.shipmentId);
      if (!shipment) {
        return res.status(404).json({ message: "Shipment not found" });
      }
      
      // Check if there's enough capacity
      const existingBookings = await storage.getBookingsByShipmentId(shipment.id);
      const totalBookedCapacity = existingBookings.reduce((sum, booking) => sum + booking.quantity, 0);
      
      if (totalBookedCapacity + validatedData.quantity > shipment.capacity) {
        return res.status(400).json({ message: "Not enough capacity available" });
      }
      
      const booking = await storage.createBooking(validatedData);
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });
  
  app.get("/api/bookings/user", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const bookings = await storage.getBookingsByUserId(req.user.id);
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });
  
  app.get("/api/bookings/transporter", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Check if user is a transporter or admin
      const user = req.user;
      let transporterId;
      
      if (user.userType === "transporter") {
        // Get transporter information
        const transporter = await storage.getTransporterByUserId(user.id);
        if (!transporter) {
          return res.status(404).json({ message: "Transporter profile not found" });
        }
        transporterId = transporter.id;
      } else if (user.role === "admin") {
        // Admin needs to specify a transporter ID
        transporterId = req.query.transporterId ? parseInt(req.query.transporterId as string) : null;
        
        if (!transporterId) {
          // Return first transporter for admin if none specified
          const allTransporters = await storage.getAllTransporters();
          if (allTransporters.length === 0) {
            return res.json([]);
          }
          
          transporterId = allTransporters[0].id;
        }
      } else {
        return res.status(403).json({ message: "Only transporters or admins can view transporter bookings" });
      }
      
      // Get all shipments belonging to this transporter
      const shipments = await storage.getShipmentsByTransporterId(transporterId);
      
      // For each shipment, get all bookings
      const allBookings = [];
      for (const shipment of shipments) {
        const bookings = await storage.getBookingsByShipmentId(shipment.id);
        // Add shipment info to each booking
        const enhancedBookings = await Promise.all(bookings.map(async booking => {
          // Get user information
          const user = await storage.getUser(booking.userId);
          
          return {
            ...booking,
            shipmentDetails: {
              id: shipment.id,
              originId: shipment.originId,
              destinationId: shipment.destinationId,
              departureDate: shipment.departureDate,
              arrivalDate: shipment.arrivalDate,
              transportType: shipment.transportType,
              capacity: shipment.capacity,
              price: shipment.price
            },
            userName: user ? user.fullName : 'Unknown User',
            userEmail: user ? user.email : 'No Email'
          };
        }));
        
        allBookings.push(...enhancedBookings);
      }
      
      res.json(allBookings);
    } catch (error) {
      console.error("Error fetching transporter bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });
  
  app.get("/api/bookings/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.getBooking(id);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Check if user is the owner of the booking or the transporter
      if (booking.userId !== req.user.id) {
        const transporter = await storage.getTransporterByUserId(req.user.id);
        if (!transporter) {
          return res.status(403).json({ message: "Not authorized to view this booking" });
        }
        
        const shipment = await storage.getShipment(booking.shipmentId);
        if (!shipment || shipment.transporterId !== transporter.id) {
          return res.status(403).json({ message: "Not authorized to view this booking" });
        }
      }
      
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch booking" });
    }
  });
  
  app.put("/api/bookings/:id/status", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const bookingId = parseInt(req.params.id);
      const booking = await storage.getBooking(bookingId);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Check if user is a transporter for this shipment
      const transporter = await storage.getTransporterByUserId(req.user.id);
      if (!transporter) {
        return res.status(403).json({ message: "Not authorized to update this booking" });
      }
      
      const shipment = await storage.getShipment(booking.shipmentId);
      if (!shipment || shipment.transporterId !== transporter.id) {
        return res.status(403).json({ message: "Not authorized to update this booking" });
      }
      
      const { status } = req.body;
      if (!status || !["pending", "confirmed", "in_transit", "delivered", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const updatedBooking = await storage.updateBookingStatus(bookingId, status);
      res.json(updatedBooking);
    } catch (error) {
      res.status(500).json({ message: "Failed to update booking status" });
    }
  });
  
  // Support Tickets API
  app.post("/api/tickets", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const validatedData = insertTicketSchema.parse({
        ...req.body,
        userId: req.user.id,
        status: "open"
      });
      
      const ticket = await storage.createTicket(validatedData);
      res.status(201).json(ticket);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid ticket data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create support ticket" });
    }
  });
  
  app.get("/api/tickets", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Regular users can only see their own tickets
      // Admin users can see all tickets (but we don't have admin roles yet)
      const tickets = await storage.getTicketsByUserId(req.user.id);
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tickets" });
    }
  });
  
  app.get("/api/tickets/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getTicket(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      // Check if user is the owner of the ticket
      if (ticket.userId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to view this ticket" });
      }
      
      // Get ticket responses
      const responses = await storage.getTicketResponses(ticketId);
      
      res.json({ ticket, responses });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ticket" });
    }
  });
  
  // Transporter API
  app.get("/api/transporters/me", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Check if user is a transporter or admin
      const user = req.user;
      
      if (user.userType === "transporter") {
        // Get transporter information
        const transporter = await storage.getTransporterByUserId(user.id);
        if (!transporter) {
          return res.status(404).json({ message: "Transporter profile not found" });
        }
        
        res.json(transporter);
      } else if (user.role === "admin") {
        // Admin needs to specify a transporter ID
        const transporterId = req.query.transporterId ? parseInt(req.query.transporterId as string) : null;
        
        if (!transporterId) {
          // Return first transporter for admin if none specified
          const allTransporters = await storage.getAllTransporters();
          if (allTransporters.length === 0) {
            return res.status(404).json({ message: "No transporters found in the system" });
          }
          
          res.json(allTransporters[0]);
        } else {
          const transporter = await storage.getTransporter(transporterId);
          if (!transporter) {
            return res.status(404).json({ message: "Transporter not found" });
          }
          
          res.json(transporter);
        }
      } else {
        return res.status(403).json({ message: "Only transporters or admins can access transporter profile" });
      }
    } catch (error) {
      console.error("Error fetching transporter profile:", error);
      res.status(500).json({ message: "Failed to fetch transporter profile" });
    }
  });
  
  app.post("/api/tickets/:id/responses", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getTicket(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      // Check if user is the owner of the ticket
      if (ticket.userId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to respond to this ticket" });
      }
      
      const validatedData = insertTicketResponseSchema.parse({
        ticketId,
        userId: req.user.id,
        message: req.body.message
      });
      
      const response = await storage.createTicketResponse(validatedData);
      res.status(201).json(response);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid response data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create ticket response" });
    }
  });
  
  // Documents API
  app.post("/api/documents", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const validatedData = insertDocumentSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const document = await storage.createDocument(validatedData);
      res.status(201).json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid document data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to upload document" });
    }
  });
  
  app.get("/api/documents", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const documents = await storage.getDocumentsByUserId(req.user.id);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });
  
  // Price Calculation API
  app.post("/api/calculate-price", async (req, res) => {
    try {
      const { originId, destinationId, weight } = req.body;
      
      if (!originId || !destinationId || !weight) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      const origin = await storage.getLocation(originId);
      const destination = await storage.getLocation(destinationId);
      
      if (!origin || !destination) {
        return res.status(404).json({ message: "Origin or destination not found" });
      }
      
      // Automatically determine transport types based on origin and destination
      let possibleTransportTypes = [];
      
      // Check if both are inland cities (within Iran)
      if (origin.type === "inland" && destination.type === "inland" && origin.country === "ایران" && destination.country === "ایران") {
        possibleTransportTypes.push("rail"); // قطار
        possibleTransportTypes.push("land"); // کامیون
      }
      
      // Check if one is port and one is inland within Iran
      else if ((origin.type === "port" && destination.type === "inland" || 
                origin.type === "inland" && destination.type === "port") && 
                origin.country === "ایران" && destination.country === "ایران") {
        possibleTransportTypes.push("rail"); // قطار
        possibleTransportTypes.push("land"); // کامیون
      } 
      
      // Check if both are ports
      else if (origin.type === "port" && destination.type === "port") {
        if (origin.country === destination.country) {
          possibleTransportTypes.push("sea"); // کشتی
        } else {
          possibleTransportTypes.push("sea"); // کشتی
        }
      }
      
      // International mixed transportation
      else if (origin.country !== destination.country) {
        if (origin.type === "inland" && origin.country === "ایران") {
          possibleTransportTypes.push("rail-sea"); // ترکیبی قطار و کشتی
          possibleTransportTypes.push("land-sea"); // ترکیبی کامیون و کشتی
        } else if (destination.type === "inland" && destination.country === "ایران") {
          possibleTransportTypes.push("sea-rail"); // ترکیبی کشتی و قطار
          possibleTransportTypes.push("sea-land"); // ترکیبی کشتی و کامیون
        } else {
          possibleTransportTypes.push("sea"); // فقط کشتی
        }
      }
      
      const transportType = possibleTransportTypes[0]; // انتخاب اولین مسیر پیشنهادی
      
      // Get Bandar Abbas port location for sea transport
      const bandarAbbasName = "بندرعباس";
      const iranianPorts = await storage.getLocationsByType("port");
      const bandarAbbas = iranianPorts.find(port => port.name === bandarAbbasName);
      
      if (!bandarAbbas && transportType.includes("sea")) {
        return res.status(404).json({ message: "Bandar Abbas port not found" });
      }
      
      // Constants for calculation
      const trainRatePerKgKm = 34; // ریال به ازای هر کیلوگرم در هر کیلومتر
      
      // Fixed rail distances (could be moved to a config file or database)
      const railDistances: Record<string, number> = {
        "تهران": 1300,
        "مشهد": 1400,
        "اصفهان": 1050,
        "تبریز": 1750,
        "شیراز": 800,
        "کرمان": 450,
        "اهواز": 1100,
        "قم": 1150,
        "کرمانشاه": 1550,
        "رشت": 1600,
        "همدان": 1400,
        "اراک": 1250,
        "یزد": 800,
        "زاهدان": 950,
        "اردبیل": 1800,
        "بندرعباس": 0,
      };
      
      // Fix sea distances (could be moved to a config file or database)
      const seaDistances: Record<string, Record<string, number>> = {
        "بندرعباس": {
          "دبی": 450,
          "شانگهای": 9500,
          "سنگاپور": 6200,
          "روتردام": 12500,
          "بمبئی": 1800,
          "انتورپ": 12200,
          "حایفا": 3800,
          "چابهار": 350,
        }
      };
      
      // Calculate rail distance and cost (from origin to Bandar Abbas)
      const railDistance = railDistances[origin.name] || 0;
      const railCost = railDistance * weight * trainRatePerKgKm;
      
      // Calculate sea distance and cost if applicable
      let seaDistance = null;
      let seaCost = null;
      let estimatedDays = null;
      let seaAvailable = false;
      
      if (transportType.includes("sea") && bandarAbbas) {
        // Check for shipping rate from Bandar Abbas to destination
        const shippingRate = await storage.getShippingRateByRoute(
          bandarAbbas.id,
          destination.id,
          "sea"
        );
        
        if (shippingRate) {
          seaDistance = shippingRate.distance || 
                        (seaDistances["بندرعباس"] && seaDistances["بندرعباس"][destination.name]) || 
                        null;
          seaCost = weight * shippingRate.pricePerKg;
          seaAvailable = true;
          
          // Rough estimation of days based on distance - could be more sophisticated
          if (seaDistance) {
            // Assume average ship speed of 20 knots = 37 km/h -> ~900 km/day
            const seaDays = Math.ceil(seaDistance / 900);
            // Add 1 day for rail transport per 700 km + 2 days for loading/customs
            const railDays = Math.ceil(railDistance / 700);
            estimatedDays = railDays + seaDays + 2;
          }
        } else {
          seaAvailable = false;
        }
      }
      
      // Get available shipments for this route based on transport type
      let availableShipments: any[] = [];
      
      // Direct rail shipments (if origin is inland)
      if (transportType === "rail" || transportType.startsWith("rail-")) {
        const railShipments = await storage.searchShipments({
          originId: originId,
          destinationId: destinationId,
          transportType: "rail"
        });
        
        // If no direct rail shipments, check for services from the origin to Bandar Abbas
        if (railShipments.length === 0 && origin.type === "inland" && bandarAbbas) {
          const toPortShipments = await storage.searchShipments({
            originId: originId,
            destinationId: bandarAbbas.id,
            transportType: "rail"
          });
          
          // Enhance the shipments with additional info
          const enhancedRailShipments = await Promise.all(toPortShipments.map(async (shipment) => {
            const transporter = await storage.getTransporter(shipment.transporterId);
            return {
              ...shipment,
              originName: origin.name,
              destinationName: bandarAbbas.name,
              transporterName: transporter?.companyName || "Unknown"
            };
          }));
          
          availableShipments = [...availableShipments, ...enhancedRailShipments];
        } else {
          // Enhance the direct rail shipments with additional info
          const enhancedRailShipments = await Promise.all(railShipments.map(async (shipment) => {
            const transporter = await storage.getTransporter(shipment.transporterId);
            return {
              ...shipment,
              originName: origin.name,
              destinationName: destination.name,
              transporterName: transporter?.companyName || "Unknown"
            };
          }));
          
          availableShipments = [...availableShipments, ...enhancedRailShipments];
        }
      }
      
      // Sea shipments if needed
      if ((transportType.includes("sea") || transportType === "sea") && bandarAbbas && seaAvailable) {
        const seaShipments = await storage.getShipmentsByRoute(bandarAbbas.id, destinationId);
        
        // Enhance the shipments with additional info
        const enhancedSeaShipments = await Promise.all(seaShipments.map(async (shipment) => {
          const transporter = await storage.getTransporter(shipment.transporterId);
          return {
            ...shipment,
            originName: bandarAbbas.name,
            destinationName: destination.name,
            transporterName: transporter?.companyName || "Unknown"
          };
        }));
        
        availableShipments = [...availableShipments, ...enhancedSeaShipments];
      }
      
      // Calculate total cost
      const totalCost = railCost + (seaCost || 0);
      
      // Prepare the result
      const result = {
        railCost,
        seaCost,
        totalCost,
        railDistance,
        seaDistance,
        estimatedDays,
        availableShipments,
        seaAvailable
      };
      
      res.json(result);
    } catch (error) {
      console.error("Error calculating price:", error);
      res.status(500).json({ message: "Failed to calculate price" });
    }
  });
  
  // Blog API
  app.get("/api/blog", async (req, res) => {
    try {
      const publishedOnly = req.query.published !== "false";
      const posts = await storage.getAllBlogPosts(publishedOnly);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blog posts" });
    }
  });
  
  // API برای محاسبه فاصله بین دو شهر
  app.get("/api/calculate-distance", async (req, res) => {
    try {
      const { fromCity, toCity } = req.query;
      
      if (!fromCity || !toCity) {
        return res.status(400).json({ 
          message: "هر دو پارامتر fromCity و toCity باید مشخص شوند" 
        });
      }
      
      // محاسبه فاصله بین دو شهر با استفاده از پایگاه داده مسافت‌ها
      const distanceInfo = await calculateDistanceBetweenCities(fromCity as string, toCity as string);
      
      if (distanceInfo) {
        // اگر مسیر در پایگاه داده وجود داشت
        return res.json({
          fromCity,
          toCity,
          distance: distanceInfo.distance,
          duration: distanceInfo.duration,
          source: "database"
        });
      } else {
        // اگر مسیر در پایگاه داده وجود نداشت، از تخمین استفاده می‌کنیم
        const estimatedInfo = await estimateDistanceAndDuration(fromCity as string, toCity as string);
        return res.json({
          fromCity,
          toCity,
          distance: estimatedInfo.distance,
          duration: estimatedInfo.duration,
          source: "estimated"
        });
      }
    } catch (error) {
      console.error("Error calculating distance:", error);
      res.status(500).json({ message: "خطا در محاسبه فاصله بین دو شهر" });
    }
  });
  
  // API برای محاسبه هزینه حمل و نقل بین دو شهر
  app.get("/api/calculate-transport-price", async (req, res) => {
    try {
      const { fromCity, toCity, vehicleType, weight } = req.query;
      
      // بررسی پارامترهای ورودی
      if (!fromCity || !toCity) {
        return res.status(400).json({ 
          message: "پارامترهای fromCity و toCity باید مشخص شوند" 
        });
      }
      
      // نوع وسیله نقلیه پیش‌فرض: کامیون
      const transportType = vehicleType as string || 'land_truck';
      
      // وزن محموله (کیلوگرم)
      let cargoWeight: number | null = null;
      if (weight) {
        cargoWeight = parseFloat(weight as string);
        if (isNaN(cargoWeight)) {
          return res.status(400).json({ message: "وزن محموله باید یک عدد معتبر باشد" });
        }
      }
      
      // محاسبه فاصله بین دو شهر
      const distanceInfo = await calculateDistanceBetweenCities(fromCity as string, toCity as string) || 
                           await estimateDistanceAndDuration(fromCity as string, toCity as string);
      
      // نرخ‌های پایه بر اساس ریال/تن-کیلومتر یا ریال/کیلوگرم-کیلومتر
      const baseRates: Record<string, number> = {
        'rail': 34,                // نرخ ریلی (ریال به ازای هر کیلوگرم-کیلومتر)
        'land_trailer': 8900,     // تریلی (ریال به ازای هر تن-کیلومتر)
        'land_truck': 9500,       // کامیون (ریال به ازای هر تن-کیلومتر)
        'land_small_truck': 12000, // خاور (ریال به ازای هر تن-کیلومتر)
        'land_pickup': 15000,     // نیسان (ریال به ازای هر تن-کیلومتر)
        'land_van': 20000,        // وانت (ریال به ازای هر تن-کیلومتر)
        'sea': 5000               // حمل دریایی (ریال به ازای هر تن-کیلومتر)
      };
      
      // استفاده از نرخ پایه متناسب با نوع وسیله نقلیه
      const rate = baseRates[transportType] || baseRates.land_truck;
      
      // محاسبه قیمت
      let priceRial = null;
      let priceToman = null;
      let formulaDescription = null;
      let weightInTons = 0;
      
      if (distanceInfo && cargoWeight) {
        const distance = distanceInfo.distance;
        
        if (transportType === 'rail') {
          // برای حمل و نقل ریلی، وزن بر حسب کیلوگرم محاسبه می‌شود
          priceRial = cargoWeight * distance * rate;
          priceToman = priceRial / 10;
          formulaDescription = `${cargoWeight} کیلوگرم × ${distance} کیلومتر × ${rate} ریال ÷ 10 = ${priceToman.toLocaleString()} تومان`;
        } else {
          // برای سایر انواع حمل و نقل، وزن به تن تبدیل می‌شود
          weightInTons = cargoWeight / 1000;
          priceRial = weightInTons * distance * rate;
          priceToman = priceRial / 10;
          formulaDescription = `${weightInTons} تن × ${distance} کیلومتر × ${rate} ریال ÷ 10 = ${priceToman.toLocaleString()} تومان`;
        }
      }
      
      // ارسال نتیجه
      res.json({
        fromCity,
        toCity,
        transportType,
        vehicleName: transportType === 'rail' ? 'قطار' :
                    transportType === 'land_trailer' ? 'تریلی' :
                    transportType === 'land_truck' ? 'کامیون' :
                    transportType === 'land_small_truck' ? 'خاور' :
                    transportType === 'land_pickup' ? 'نیسان' :
                    transportType === 'land_van' ? 'وانت' : 'نامشخص',
        distance: distanceInfo ? distanceInfo.distance : null,
        duration: distanceInfo ? distanceInfo.duration : null,
        weight: cargoWeight,
        weightInTons: transportType === 'rail' ? null : weightInTons,
        baseRate: rate,
        priceRial,
        priceToman,
        formulaDescription
      });
    } catch (error) {
      console.error("Error calculating transport price:", error);
      res.status(500).json({ message: "خطا در محاسبه هزینه حمل و نقل" });
    }
  });
  
  app.get("/api/blog/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getBlogPost(id);
      
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      // Only return published posts to non-authenticated users
      if (!post.published && !req.isAuthenticated()) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });
  
  app.get("/api/blog/slug/:slug", async (req, res) => {
    try {
      const slug = req.params.slug;
      const post = await storage.getBlogPostBySlug(slug);
      
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      // Only return published posts to non-authenticated users
      if (!post.published && !req.isAuthenticated()) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });
  
  app.post("/api/blog", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // For now, any authenticated user can create blog posts
      // In a real app, we'd have an admin role check here
      
      const validatedData = insertBlogPostSchema.parse({
        ...req.body,
        authorId: req.user.id
      });
      
      const post = await storage.createBlogPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid blog post data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create blog post" });
    }
  });
  
  app.put("/api/blog/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const postId = parseInt(req.params.id);
      const post = await storage.getBlogPost(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      // Check if user is the author of the post
      if (post.authorId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to update this post" });
      }
      
      const updatedPost = await storage.updateBlogPost(postId, req.body);
      res.json(updatedPost);
    } catch (error) {
      res.status(500).json({ message: "Failed to update blog post" });
    }
  });

  // Admin API Routes
  // Special route to promote a user to admin without authentication (ONLY FOR DEVELOPMENT)
  app.get("/api/make-admin/:id", async (req, res) => {
    try {
      const userId = req.params.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, { role: "admin" });
      return res.json({ message: "User promoted to admin successfully", user: updatedUser });
    } catch (error) {
      console.error("Error promoting user to admin:", error);
      return res.status(500).json({ message: "Failed to promote user to admin" });
    }
  });

  // Create admin user
  app.post("/api/admin/create-admin", async (req, res) => {
    try {
      // Check if any admin exists
      const adminExists = await storage.getUserByRole("admin");
      
      // If an admin already exists, require authentication
      if (adminExists && adminExists.length > 0) {
        // Only existing admins can create new admins
        if (!req.isAuthenticated() || req.user.role !== "admin") {
          return res.status(403).json({ message: "Only existing admins can create new admin accounts" });
        }
      } else {
        // First admin being created, no auth required but use a secret token
        const secretToken = process.env.ADMIN_SETUP_TOKEN || "logistino-first-admin-token";
        if (req.body.secretToken !== secretToken) {
          return res.status(403).json({ message: "Invalid setup token" });
        }
      }
      
      // Create new admin user
      const userData = insertUserSchema.parse({
        ...req.body,
        role: "admin"
      });
      
      // Hash password - import from auth.ts
      const { hashPassword } = require("./auth");
      const hashedPassword = await hashPassword(userData.password);
      
      // Create the admin user
      const adminUser = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Don't return password
      const { password, ...userWithoutPassword } = adminUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create admin user" });
    }
  });
  
  // Admin API: Get all users
  app.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Remove passwords from response
      const safeUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Admin API: Update user role
  app.put("/api/admin/users/:id/role", isAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      const { role } = req.body;
      
      if (!role || !["user", "admin", "moderator"].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
      
      const updatedUser = await storage.updateUser(userId, { role });
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return password
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user role" });
    }
  });
  
  // Admin API: Verify user
  app.put("/api/admin/users/:id/verify", isAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      const { verified } = req.body;
      
      if (typeof verified !== "boolean") {
        return res.status(400).json({ message: "Invalid verified status" });
      }
      
      const updatedUser = await storage.updateUser(userId, { verified });
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return password
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user verification" });
    }
  });
  
  // Admin API: Verify transporter
  app.put("/api/admin/transporters/:id/verify", isAdmin, async (req, res) => {
    try {
      const transporterId = parseInt(req.params.id);
      const { verified } = req.body;
      
      if (typeof verified !== "boolean") {
        return res.status(400).json({ message: "Invalid verified status" });
      }
      
      const updatedTransporter = await storage.updateTransporter(transporterId, { verified });
      if (!updatedTransporter) {
        return res.status(404).json({ message: "Transporter not found" });
      }
      
      res.json(updatedTransporter);
    } catch (error) {
      res.status(500).json({ message: "Failed to update transporter verification" });
    }
  });
  
  // Admin API: Create location
  app.post("/api/admin/locations", isAdmin, async (req, res) => {
    try {
      const locationData = insertLocationSchema.parse(req.body);
      const location = await storage.createLocation(locationData);
      res.status(201).json(location);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid location data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create location" });
    }
  });
  
  // Admin API: Update location
  app.put("/api/admin/locations/:id", isAdmin, async (req, res) => {
    try {
      const locationId = parseInt(req.params.id);
      const location = await storage.getLocation(locationId);
      
      if (!location) {
        return res.status(404).json({ message: "Location not found" });
      }
      
      const updatedLocation = await storage.updateLocation(locationId, req.body);
      res.json(updatedLocation);
    } catch (error) {
      res.status(500).json({ message: "Failed to update location" });
    }
  });
  
  // Admin API: Get all shipments
  app.get("/api/admin/shipments", isAdmin, async (req, res) => {
    try {
      const shipments = await storage.getAllShipments();
      res.json(shipments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shipments" });
    }
  });
  
  // Admin API: Get all bookings
  app.get("/api/admin/bookings", isAdmin, async (req, res) => {
    try {
      const bookings = await storage.getAllBookings();
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });
  
  // Admin API: Get all tickets (for support staff)
  app.get("/api/admin/tickets", isAdmin, async (req, res) => {
    try {
      const tickets = await storage.getAllTickets();
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tickets" });
    }
  });
  
  // Admin API: Respond to ticket
  app.post("/api/admin/tickets/:id/responses", isAdmin, async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getTicket(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      const validatedData = insertTicketResponseSchema.parse({
        ticketId,
        userId: req.user.id,
        message: req.body.message
      });
      
      const response = await storage.createTicketResponse(validatedData);
      
      // Update ticket status if provided
      if (req.body.status && ["open", "in_progress", "resolved", "closed"].includes(req.body.status)) {
        await storage.updateTicketStatus(ticketId, req.body.status);
      }
      
      res.status(201).json(response);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid response data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create ticket response" });
    }
  });
  
  // Shipping Rate routes
  app.get("/api/shipping-rates", async (req, res) => {
    try {
      const rates = await storage.getAllShippingRates();
      res.json(rates);
    } catch (error) {
      console.error("Error fetching shipping rates:", error);
      res.status(500).json({ error: "Failed to fetch shipping rates" });
    }
  });
  
  app.get("/api/shipping-rates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const rate = await storage.getShippingRate(id);
      if (!rate) {
        return res.status(404).json({ error: "Shipping rate not found" });
      }
      res.json(rate);
    } catch (error) {
      console.error("Error fetching shipping rate:", error);
      res.status(500).json({ error: "Failed to fetch shipping rate" });
    }
  });
  
  app.get("/api/shipping-rates/route", async (req, res) => {
    try {
      const { originId, destinationId, transportType } = req.query;
      
      if (!originId || !destinationId || !transportType) {
        return res.status(400).json({ error: "Missing required parameters" });
      }
      
      const rate = await storage.getShippingRateByRoute(
        parseInt(originId as string), 
        parseInt(destinationId as string), 
        transportType as string
      );
      
      if (!rate) {
        return res.status(404).json({ error: "No shipping rate found for this route" });
      }
      
      res.json(rate);
    } catch (error) {
      console.error("Error fetching shipping rate by route:", error);
      res.status(500).json({ error: "Failed to fetch shipping rate" });
    }
  });
  
  // API for getting available shipments by route
  app.get("/api/shipments/route", async (req, res) => {
    try {
      const { originId, destinationId } = req.query;
      
      if (!originId || !destinationId) {
        return res.status(400).json({ error: "Missing required parameters" });
      }
      
      const shipments = await storage.getShipmentsByRoute(
        parseInt(originId as string), 
        parseInt(destinationId as string)
      );
      
      // Enhance shipments with additional information
      const enhancedShipments = await Promise.all(shipments.map(async s => {
        const origin = await storage.getLocation(s.originId);
        const destination = await storage.getLocation(s.destinationId);
        const transporter = await storage.getTransporter(s.transporterId);
        
        return {
          ...s,
          originName: origin?.name || 'Unknown',
          destinationName: destination?.name || 'Unknown',
          transporterName: transporter?.companyName || 'Unknown'
        };
      }));
      
      res.json(enhancedShipments);
    } catch (error) {
      console.error("Error fetching shipments by route:", error);
      res.status(500).json({ error: "Failed to fetch shipments" });
    }
  });
  
  app.post("/api/shipping-rates", isAdmin, async (req, res) => {
    try {
      const rate = await storage.createShippingRate(req.body);
      res.status(201).json(rate);
    } catch (error) {
      console.error("Error creating shipping rate:", error);
      res.status(500).json({ error: "Failed to create shipping rate" });
    }
  });
  
  app.patch("/api/shipping-rates/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const rate = await storage.updateShippingRate(id, req.body);
      if (!rate) {
        return res.status(404).json({ error: "Shipping rate not found" });
      }
      res.json(rate);
    } catch (error) {
      console.error("Error updating shipping rate:", error);
      res.status(500).json({ error: "Failed to update shipping rate" });
    }
  });
  
  // Price Calculator API - calculates cost for rail-sea combined transport
  app.post("/api/calculate-price", async (req, res) => {
    try {
      const { originId, destinationId, weight, transportType } = req.body;
      
      if (!originId || !destinationId || !weight) {
        return res.status(400).json({ error: "Missing required parameters" });
      }
      
      // Get origin and destination locations
      const origin = await storage.getLocation(originId);
      const destination = await storage.getLocation(destinationId);
      
      if (!origin || !destination) {
        return res.status(404).json({ error: "Origin or destination not found" });
      }
      
      // For combined rail-sea transport, we need two rates:
      // 1. Rail rate from origin city to Bandar Abbas
      // 2. Sea rate from Bandar Abbas to foreign port
      
      let result: any = {
        originName: origin.name,
        destinationName: destination.name,
        weight: weight
      };
      
      // If it's a domestic rail transport (no sea transport needed)
      if (transportType === 'rail' && destination.country === 'ایران') {
        // Get rail shipping rate
        const railRate = await storage.getShippingRateByRoute(originId, destinationId, 'rail');
        
        if (!railRate) {
          // Use formula: distance × weight × 34 rials
          const DEFAULT_DISTANCE = 500; // km (estimate)
          const DEFAULT_PRICE_PER_KM_KG = 34; // rials

          const distance = DEFAULT_DISTANCE;
          const railCost = distance * weight * DEFAULT_PRICE_PER_KM_KG;
          
          result = {
            ...result,
            railCost: railCost,
            totalCost: railCost,
            railDistance: distance,
            estimatedDays: Math.ceil(distance / 250) // Estimate 250 km per day
          };
        } else {
          // Use the stored rate information
          const railCost = railRate.pricePerKg * weight;
          result = {
            ...result,
            railCost: railCost,
            totalCost: railCost,
            railDistance: railRate.distance || 0,
            estimatedDays: railRate.transitTime || Math.ceil((railRate.distance || 500) / 250)
          };
        }
      } 
      // Combined rail-sea transport
      else if ((transportType === 'rail-sea' || transportType === 'mixed') && destination.country !== 'ایران') {
        // Find Bandar Abbas port
        const bandarAbbas = (await storage.getLocationsByType('port'))
                            .find(loc => loc.name === 'بندرعباس');
        
        if (!bandarAbbas) {
          return res.status(404).json({ error: "Bandar Abbas port not found in the system" });
        }
        
        // استعلام نرخ ریلی از مبدأ به بندرعباس
        const railRate = await storage.getShippingRateByRoute(originId, bandarAbbas.id, 'rail');
        
        // استعلام نرخ دریایی از بندرعباس به مقصد
        const seaRate = await storage.getShippingRateByRoute(bandarAbbas.id, destinationId, 'sea');
        
        // محاسبه هزینه حمل ریلی (با استفاده از فرمول اگر نرخ موجود نیست)
        let railCost = 0;
        let railDistance = 0;
        
        if (railRate) {
          railCost = railRate.pricePerKg * weight;
          railDistance = railRate.distance || 0;
        } else {
          // محاسبه با فرمول: مسافت × وزن × 34 ریال
          // استفاده از فاصله تخمینی بر اساس جدول مسافت‌ها
          // جستجوی نزدیک‌ترین شهر در جدول مسافت‌ها
          const DISTANCES = {
            "تهران": 1300,
            "مشهد": 1400,
            "اصفهان": 1050,
            "تبریز": 1750,
            "شیراز": 800,
            "کرمان": 450,
            "اهواز": 1100,
            "قم": 1150,
            "کرمانشاه": 1550,
            "رشت": 1600,
            "همدان": 1400,
            "اراک": 1250,
            "یزد": 800,
            "زاهدان": 950,
            "اردبیل": 1800,
            "بندرعباس": 0,
          };
          
          // پیدا کردن نام شهر مبدأ
          const originLocation = await storage.getLocation(originId);
          const cityName = originLocation?.name || "";
          
          // استفاده از جدول فاصله‌ها اگر شهر در آن یافت شود
          const DEFAULT_DISTANCE = 800; // کیلومتر (تخمینی)
          const DEFAULT_PRICE_PER_KM_KG = 34; // ریال
          
          // @ts-ignore
          railDistance = DISTANCES[cityName] !== undefined ? DISTANCES[cityName] : DEFAULT_DISTANCE;
          railCost = railDistance * weight * DEFAULT_PRICE_PER_KM_KG;
        }
        
        // محاسبه هزینه حمل دریایی
        let seaCost = null;
        let seaDistance = null;
        let seaAvailable = false;
        
        if (seaRate) {
          seaCost = seaRate.pricePerKg * weight;
          seaDistance = seaRate.distance;
          seaAvailable = true;
        } else {
          // استفاده از جدول فاصله‌های دریایی اگر نرخ موجود نیست
          const SEA_DISTANCES = {
            "دبی": 450,
            "شانگهای": 9500,
            "سنگاپور": 6200,
            "روتردام": 12500,
            "بمبئی": 1800,
            "انتورپ": 12200,
            "حایفا": 3800,
            "چابهار": 350,
            "عمان": 550,
            "جده": 1950,
            "کراچی": 900,
          };
          
          // پیدا کردن نام بندر مقصد
          const destPortName = destination?.name || "";
          
          // اگر مسافت دریایی شناخته شده است
          // @ts-ignore
          if (SEA_DISTANCES[destPortName] !== undefined) {
            // محاسبه قیمت دریایی: مسافت × وزن × نرخ پایه
            // @ts-ignore
            seaDistance = SEA_DISTANCES[destPortName];
            const seaBaseRate = 5000; // ریال به ازای هر کیلوگرم در هر 1000 کیلومتر
            seaCost = (seaDistance / 1000) * weight * seaBaseRate;
            seaAvailable = true;
          }
        }
        
        // جستجوی محموله‌های مشابه
        // محموله‌های فعال از بندرعباس به مقصد
        const availableShipments: any[] = [];
        try {
          // پیدا کردن محموله‌های مشابه در این مسیر
          const shipments = await storage.getShipmentsByRoute(bandarAbbas.id, destinationId);
          // فیلتر کردن محموله‌های فعال و نوع حمل دریایی
          const activeSeaShipments = shipments.filter(s => 
            s.active === true && s.transportType === 'sea'
          );
          
          if (activeSeaShipments.length > 0) {
            availableShipments.push(...activeSeaShipments);
            seaAvailable = true;
          }
        } catch (error) {
          console.error("Error fetching similar shipments:", error);
        }
        
        // محاسبه زمان تخمینی
        const railDays = railRate?.transitTime || Math.ceil(railDistance / 250); // تخمین 250 کیلومتر در روز
        const seaDays = seaRate?.transitTime || (seaDistance ? Math.ceil(seaDistance / 500) : null); // تخمین 500 کیلومتر در روز برای دریا
        
        // مجموع زمان تخمینی
        const estimatedDays = railDays + (seaDays || 0);
        
        // آماده‌سازی نتیجه
        result = {
          ...result,
          railCost: railCost,
          seaCost: seaCost,
          totalCost: railCost + (seaCost || 0),
          railDistance: railDistance,
          seaDistance: seaDistance,
          estimatedDays: estimatedDays,
          seaAvailable: seaAvailable, // آیا مسیر دریایی موجود است؟
          availableShipments: availableShipments
        };
      } else {
        // For other transport types
        const rate = await storage.getShippingRateByRoute(originId, destinationId, transportType || 'land');
        
        if (!rate) {
          return res.status(404).json({ error: `No shipping rate found for route with transport type: ${transportType || 'land'}` });
        }
        
        const cost = rate.pricePerKg * weight;
        result = {
          ...result,
          cost: cost,
          totalCost: cost,
          distance: rate.distance || 0,
          estimatedDays: rate.transitTime || Math.ceil((rate.distance || 500) / 250)
        };
      }
      
      res.json(result);
    } catch (error) {
      console.error("Error calculating price:", error);
      res.status(500).json({ error: "Failed to calculate price" });
    }
  });

  // Admin API: Get dashboard stats 
  app.get("/api/admin/stats", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const transporters = await storage.getAllTransporters();
      const shipments = await storage.getAllShipments();
      const bookings = await storage.getAllBookings();
      const tickets = await storage.getAllTickets();
      
      const stats = {
        totalUsers: users.length,
        totalTransporters: transporters.length,
        totalShipments: shipments.length,
        totalBookings: bookings.length,
        activeShipments: shipments.filter(s => s.active).length,
        pendingBookings: bookings.filter(b => b.status === "pending").length,
        openTickets: tickets.filter(t => t.status === "open").length,
        verifiedUsers: users.filter(u => u.verified).length,
        verifiedTransporters: transporters.filter(t => t.verified).length,
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
