import { geocodeLocation } from './openroute-service';
import { db } from './db';
import { sql } from 'drizzle-orm';

// لیست شهرهای دارای ایستگاه راه‌آهن در ایران بر اساس نقشه رسمی راه‌آهن جمهوری اسلامی ایران
export const railwayStations = [
  "آبیک",
  "آذرشهر",
  "آستارا",
  "آستانه",
  "آق قلا",
  "اراک",
  "اردبیل",
  "اردکان",
  "ارومیه",
  "اسلامشهر",
  "اصفهان",
  "اندیمشک",
  "اهواز",
  "ایلام",
  "بابل",
  "بادرود",
  "بافق",
  "بجنورد",
  "بندر امام خمینی",
  "بندرعباس",
  "بندرگز",
  "بوشهر",
  "بیرجند",
  "پاکدشت",
  "پرند",
  "پل سفید",
  "پیشوا",
  "تاکستان",
  "تبریز",
  "تربت حیدریه",
  "تهران",
  "جلفا",
  "جندق",
  "خرمشهر",
  "خرم‌آباد",
  "خواف",
  "دامغان",
  "دورود",
  "دیزل‌آباد",
  "رباط کریم",
  "رشت",
  "زاهدان",
  "زنجان",
  "ساری",
  "سبزوار",
  "سرخس",
  "سمنان",
  "سنگان",
  "شاهرود",
  "شوش",
  "شیراز",
  "شیرگاه",
  "قائمشهر",
  "قزوین",
  "قم",
  "کاشان",
  "کرج",
  "کرمان",
  "کرمانشاه",
  "گرگان",
  "گرمسار",
  "گلشهر",
  "گناباد",
  "مراغه",
  "مرند",
  "مشهد",
  "ملایر",
  "میانه",
  "نیشابور",
  "همدان",
  "ورامین",
  "یزد"
];

/**
 * تابع برای بررسی وجود ایستگاه راه‌آهن در یک شهر
 * @param cityName نام شهر مورد بررسی
 * @returns آیا شهر دارای ایستگاه راه‌آهن است یا خیر
 */
export function hasRailwayStation(cityName: string): boolean {
  // استاندارد کردن نام شهر (حذف پسوند و پیشوند اضافی)
  const normalizedName = cityName.replace(/\(.*\)/g, '').trim();
  
  // جستجو در لیست ایستگاه‌های راه‌آهن
  return railwayStations.some(station => {
    // مقایسه نام‌ها با حذف فاصله‌های اضافی و تبدیل به حروف کوچک
    const normalizedStation = station.trim();
    return normalizedName === normalizedStation || 
           normalizedName.includes(normalizedStation) || 
           normalizedStation.includes(normalizedName);
  });
}

/**
 * تابع بررسی وجود مسیر ریلی مستقیم بین دو شهر براساس نقشه راه‌آهن
 * @param fromCity شهر مبدا
 * @param toCity شهر مقصد
 * @returns آیا مسیر ریلی مستقیم وجود دارد یا خیر
 */
export function hasDirectRailConnection(fromCity: string, toCity: string): boolean {
  // ابتدا بررسی می‌کنیم که هر دو شهر دارای ایستگاه راه‌آهن باشند
  if (!hasRailwayStation(fromCity) || !hasRailwayStation(toCity)) {
    console.log(`Rail route check: ${fromCity} or ${toCity} does not have a railway station`);
    return false;
  }
  
  // جستجو در پایگاه داده مسیرهای ریلی
  const directConnection = railDistances.some(route => 
    (route.from === fromCity && route.to === toCity && route.transportType === 'rail') ||
    (route.from === toCity && route.to === fromCity && route.transportType === 'rail')
  );
  
  if (directConnection) {
    console.log(`Rail route check: Direct rail connection exists between ${fromCity} and ${toCity}`);
  } else {
    console.log(`Rail route check: No direct rail connection between ${fromCity} and ${toCity}`);
  }
  
  return directConnection;
}

// ذخیره اطلاعات نقشه راه‌آهن ایران
// این داده‌ها از نقشه رسمی راه‌آهن ایران استخراج شده‌اند
// منبع: نقشه خطوط ریلی موجود در دست ساخت و مطالعه، راه‌آهن جمهوری اسلامی ایران

// تابع کمکی برای تبدیل درجه به رادیان
function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}

// پایگاه داده فاصله بین شهرهای مهم ایران و بنادر کشورهای همسایه (بر حسب کیلومتر)
// منبع: اطلاعات عمومی مسیرهای جاده‌ای و دریایی

export type CityDistance = {
  from: string;
  to: string;
  distance: number;
  duration: number; // مدت زمان تقریبی سفر (دقیقه)
  transportType?: string; // نوع حمل و نقل: "land", "sea", "rail"
};

/**
 * ساختار داده برای قیمت حمل و نقل
 */
export interface PriceResult {
  priceRial: number;
  priceToman: number;
  usedWeight: number; // وزن استفاده شده در محاسبه (کیلوگرم)
  weightInTons: number; // وزن به تن
  rate: number; // نرخ استفاده شده
  vehicleType: string; // نوع وسیله نقلیه محاسبه شده
  vehicleDisplayName: string; // نام نمایشی وسیله نقلیه
  formulaDescription: string; // توضیح فرمول محاسبه
};

/**
 * تابع محاسبه دقیق قیمت با جزئیات کامل
 * این تابع برای استفاده در سراسر برنامه جهت یکسان‌سازی محاسبات قیمت استفاده می‌شود
 * @param transportType نوع حمل و نقل (land, rail, sea, mixed یا land_trailer, land_truck و غیره)
 * @param distance فاصله به کیلومتر
 * @param cargoWeight وزن بار به کیلوگرم
 * @param containerType نوع کانتینر (برای حمل و نقل دریایی)
 * @param containerCount تعداد کانتینر (برای حمل و نقل دریایی)
 * @param isInternationalRoute آیا یک مسیر بین‌المللی است (برای مسیرهای با قطعه دریایی)
 * @param landOnlyDistance فاصله بخش زمینی/ریلی تا بندر (برای مسیرهای بین‌المللی)
 * @returns جزئیات کامل محاسبه قیمت یا null در صورت عدم امکان محاسبه
 */
export function calculateDetailedPrice(
  transportType: string, 
  distance: number, 
  cargoWeight: number = 7000, 
  containerType?: string, 
  containerCount?: number,
  isInternationalRoute?: boolean,
  landOnlyDistance?: number
): PriceResult | null {
  // نرخ‌های به‌روز بر اساس ریال/تن-کیلومتر یا ریال/کیلوگرم-کیلومتر (نرخ‌های دقیق بازار)
  const baseRates: Record<string, number> = {
    'rail': 34,                // ریلی (ریال به ازای هر کیلوگرم-کیلومتر)
    'land_trailer': 9500,      // تریلی: 9,500 ریال/تن-کیلومتر
    'land_truck': 10000,       // کامیون: 10,000 ریال/تن-کیلومتر
    'land_small_truck': 13500, // خاور: 13,500 ریال/تن-کیلومتر
    'land_pickup': 17500,      // نیسان: 17,500 ریال/تن-کیلومتر
    'land_van': 17500,         // وانت: 17,500 ریال/تن-کیلومتر
    'sea': 5000,               // دریایی (ریال به ازای هر تن-کیلومتر) - توجه: برای دریایی فقط از قیمت‌های واقعی استفاده می‌شود
    'mixed': 10000             // ترکیبی (ریال به ازای هر تن-کیلومتر)
  };
  
  // حداکثر ظرفیت هر نوع وسیله نقلیه (بر حسب کیلوگرم) - براساس ظرفیت واقعی در بازار
  const maxCapacity: Record<string, number> = {
    'land_trailer': 24000,     // تریلی - حداکثر 24 تن (22 تا 24 تن)
    'land_truck': 18000,       // کامیون جفت (10 چرخ) - حداکثر 18 تن (15 تا 18 تن)
    'land_small_truck': 9000, // خاور (6 چرخ) - حداکثر 9 تن (5.5 تا 9 تن)
    'land_pickup': 5000,       // نیسان - حداکثر 5 تن
    'land_van': 2000,          // وانت - حداکثر 2 تن
    'rail': 60000,             // ریلی - حداکثر 60 تن (برای یک واگن)
    'sea': 40000               // دریایی - حداکثر 40 تن (برای یک کانتینر 40 فوت)
  };
  
  // نام‌های نمایشی برای وسایل نقلیه
  const vehicleDisplayNames: Record<string, string> = {
    'land_trailer': 'تریلی',
    'land_truck': 'کامیون',
    'land_small_truck': 'خاور',
    'land_pickup': 'نیسان',
    'land_van': 'وانت',
    'rail': 'واگن باری',
    'sea': 'کانتینر 40 فوت',
    'mixed': 'حمل و نقل ترکیبی'
  };
  
  let rate = 0;
  let calculatedType = transportType;
  let calculatedPriceRial = 0;
  let usedWeight = cargoWeight; // وزن مورد استفاده برای محاسبه قیمت - پیش‌فرض وزن اصلی است
  let intelligentVehicleSelection = false; // آیا انتخاب هوشمند وسیله نقلیه انجام شده است؟
  
  // اگر مسیر بین‌المللی است و فاصله زمینی تا بندر مشخص شده، از آن استفاده کن
  let calculatedDistance = distance;
  if (isInternationalRoute && landOnlyDistance && landOnlyDistance > 0) {
    calculatedDistance = landOnlyDistance;
    console.log(`International route detected - using land/rail distance to port: ${calculatedDistance}km instead of total ${distance}km`);
  }
  
  // اگر کانتینر انتخاب شده باشد، همیشه از تریلی استفاده می‌کنیم
  if (containerType && containerType.startsWith('20_') || containerType?.startsWith('40_')) {
    calculatedType = 'land_trailer';
    // برای کانتینر 40 فوت، ظرفیت 30 تن در نظر می‌گیریم
    const containerCapacity = containerType?.startsWith('40_') ? 30000 : 25000;
    usedWeight = containerCount && containerCount > 1 ? containerCapacity * containerCount : containerCapacity;
    rate = baseRates.land_trailer;
    console.log(`Price Calculation: Container selected, using trailer with capacity ${usedWeight}kg`);
  }
  // انتخاب وسیله نقلیه مناسب و تعیین وزن مورد محاسبه
  else if (transportType.startsWith('land_')) {
    // اگر نوع وسیله نقلیه مشخص شده باشد
    calculatedType = transportType;
    rate = baseRates[calculatedType] || baseRates.land_truck;
    
    // همیشه از حداکثر ظرفیت وسیله نقلیه برای محاسبه قیمت استفاده می‌کنیم
    const capacity = maxCapacity[calculatedType] || 20000;
    usedWeight = capacity; // استفاده از حداکثر ظرفیت وسیله نقلیه
    console.log(`Price Calculation: Using max capacity of ${capacity}kg for ${calculatedType} pricing`);
  }
  else if (transportType === 'land') {
    // انتخاب هوشمند وسیله نقلیه براساس وزن محموله
    intelligentVehicleSelection = true;
    
    // انتخاب هوشمند وسیله نقلیه براساس وزن محموله و ظرفیت واقعی وسایل نقلیه
    if (cargoWeight <= 2000) {
      // وانت - حداکثر 2 تن
      calculatedType = 'land_van';
      usedWeight = maxCapacity.land_van;
      console.log(`Price Calculation: Selected van for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    } else if (cargoWeight <= 5000) {
      // نیسان - حداکثر 5 تن
      calculatedType = 'land_pickup';
      usedWeight = maxCapacity.land_pickup;
      console.log(`Price Calculation: Selected pickup (Nisan) for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    } else if (cargoWeight <= 9000) {
      // خاور (6 چرخ) - حداکثر 9 تن
      calculatedType = 'land_small_truck';
      usedWeight = maxCapacity.land_small_truck;
      console.log(`Price Calculation: Selected small truck (Khavar) for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    } else if (cargoWeight <= 18000) {
      // کامیون جفت (10 چرخ) - حداکثر 18 تن
      calculatedType = 'land_truck';
      usedWeight = maxCapacity.land_truck;
      console.log(`Price Calculation: Selected truck for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    } else {
      // تریلی - حداکثر 24 تن
      calculatedType = 'land_trailer';
      usedWeight = maxCapacity.land_trailer;
      console.log(`Price Calculation: Selected trailer for cargo weight ${cargoWeight}kg - Using max capacity ${usedWeight}kg for pricing`);
    }
    
    rate = baseRates[calculatedType];
  } 
  else if (transportType === 'rail') {
    calculatedType = 'rail';
    rate = baseRates.rail;
    
    // برای حمل و نقل ریلی، از مدل قیمت‌گذاری براساس وزن واقعی استفاده می‌کنیم
    // برخلاف جاده‌ای که براساس ظرفیت وسیله نقلیه است
    
    // حداقل وزن برای حمل و نقل ریلی 100 کیلوگرم در نظر گرفته می‌شود
    if (cargoWeight < 100) {
      usedWeight = 100; // حداقل 100 کیلوگرم برای محاسبه قیمت
      console.log(`Price Calculation: Rail transport - Using minimum weight of ${usedWeight}kg for pricing`);
    } else {
      // استفاده از وزن واقعی برای بارهای بزرگتر
      usedWeight = cargoWeight;
      console.log(`Price Calculation: Rail transport - Using actual weight ${usedWeight}kg for pricing`);
    }
  }
  else if (transportType === 'sea') {
    // برای حمل و نقل دریایی، فقط از قیمت‌های واقعی شرکت‌های حمل و نقل استفاده می‌شود
    // قیمت تخمینی محاسبه نمی‌شود
    console.log(`Sea transport pricing requires actual rates from transport companies - not calculating estimated price`);
    return null; // برگرداندن null به معنی عدم ارائه قیمت تخمینی است
  }
  else {
    // برای حمل و نقل ترکیبی یا سایر موارد
    calculatedType = 'mixed';
    rate = baseRates.mixed;
    // از یک ظرفیت استاندارد برای حالت ترکیبی استفاده می‌کنیم
    const standardMixedCapacity = 25000; // 25 تن
    usedWeight = standardMixedCapacity;
    console.log(`Price Calculation: Using standard mixed capacity of ${usedWeight}kg for pricing`);
    
    // بررسی آیا این یک مسیر ترکیبی بین‌المللی با قطعه دریایی است
    if (isInternationalRoute) {
      console.log(`International mixed route detected - pricing is for land/rail portions to port only`);
    } else {
      // توجه: اگر مسیر ترکیبی شامل قطعه دریایی باشد،
      // این قیمت فقط برای بخش زمینی و ریلی است و قیمت بخش دریایی باید جداگانه تعیین شود
      console.log(`Note: If the mixed route contains sea segments, this price is only for land and rail portions`);
    }
  }
  
  // محاسبه قیمت نهایی با وزن تنظیم شده
  const weightInTons = usedWeight / 1000;  // تبدیل کیلوگرم به تن
  
  if (calculatedType === 'rail') {
    // در حالت ریلی، محاسبه بر اساس کیلوگرم است نه تن
    calculatedPriceRial = usedWeight * calculatedDistance * rate;
  } else {
    // سایر حالت‌ها بر اساس تن محاسبه می‌شوند
    calculatedPriceRial = weightInTons * calculatedDistance * rate;
  }
  
  // محاسبه قیمت به تومان
  const calculatedPriceToman = Math.round(calculatedPriceRial / 10 / 10000) * 10000;
  
  // ایجاد توضیح فرمول محاسبه
  let formulaDescription = '';
  if (calculatedType === 'rail') {
    // برای حمل و نقل ریلی توضیح بر اساس کیلوگرم
    const formattedWeight = new Intl.NumberFormat('fa-IR').format(usedWeight);
    const formattedDistance = new Intl.NumberFormat('fa-IR').format(calculatedDistance);
    const formattedRate = new Intl.NumberFormat('fa-IR').format(rate);
    const formattedPrice = new Intl.NumberFormat('fa-IR').format(calculatedPriceToman);
    
    formulaDescription = `${formattedWeight} کیلوگرم × ${formattedDistance} کیلومتر × ${formattedRate} ریال ÷ 10 = ${formattedPrice} تومان`;
  } else {
    // برای سایر حالات توضیح بر اساس تن
    const formattedWeight = new Intl.NumberFormat('fa-IR').format(weightInTons);
    const formattedDistance = new Intl.NumberFormat('fa-IR').format(calculatedDistance);
    const formattedRate = new Intl.NumberFormat('fa-IR').format(rate);
    const formattedPrice = new Intl.NumberFormat('fa-IR').format(calculatedPriceToman);
    
    formulaDescription = `${formattedWeight} تن × ${formattedDistance} کیلومتر × ${formattedRate} ریال ÷ 10 = ${formattedPrice} تومان`;
  }
  
  // برگرداندن نتایج با جزئیات کامل
  return {
    priceRial: calculatedPriceRial,
    priceToman: calculatedPriceToman,
    usedWeight,
    weightInTons,
    rate,
    vehicleType: calculatedType,
    vehicleDisplayName: vehicleDisplayNames[calculatedType] || calculatedType,
    formulaDescription
  };
}

// نوع داده برای اطلاعات مختصات جغرافیایی
export type GeoCoordinate = {
  lat: number;
  lng: number;
};

// تعریف ساختار برای بندر
export type Port = {
  name: string;
  country: string;
  distanceFromLocation: number; // فاصله به کیلومتر از مکان موردنظر
  travelTime: number; // زمان سفر به دقیقه
};

// نقشه مختصات جغرافیایی برای شهرهای مهم
export const geoCoordinates: Record<string, GeoCoordinate> = {
  // شهرهای ایران
  "تهران": { lat: 35.6892, lng: 51.3890 },
  "اصفهان": { lat: 32.6546, lng: 51.6680 },
  "مشهد": { lat: 36.2605, lng: 59.6168 },
  "تبریز": { lat: 38.0962, lng: 46.2738 },
  "اهواز": { lat: 31.3183, lng: 48.6706 },
  "شیراز": { lat: 29.5926, lng: 52.5836 },
  "کرمان": { lat: 30.2839, lng: 57.0834 },
  "بندرعباس": { lat: 27.1832, lng: 56.2665 },
  "رشت": { lat: 37.2809, lng: 49.5924 },
  "ارومیه": { lat: 37.5550, lng: 45.0733 },
  "همدان": { lat: 34.7989, lng: 48.5148 },
  "کرمانشاه": { lat: 34.3142, lng: 47.0650 },
  "یزد": { lat: 31.8974, lng: 54.3569 },
  "اردبیل": { lat: 38.2498, lng: 48.2933 },
  "زاهدان": { lat: 29.4952, lng: 60.8629 },
  "سنندج": { lat: 35.3219, lng: 46.9862 },
  "گرگان": { lat: 36.8427, lng: 54.4275 },
  "بوشهر": { lat: 28.9676, lng: 50.8371 },
  "بندر امام خمینی": { lat: 30.4256, lng: 49.1041 },
  "چابهار": { lat: 25.2919, lng: 60.6430 },
  "بندر جاسک": { lat: 25.6439, lng: 57.7744 },
  "قم": { lat: 34.6416, lng: 50.8746 },
  "ساری": { lat: 36.5659, lng: 53.0586 },
  "خرم‌آباد": { lat: 33.4871, lng: 48.3550 },
  "قزوین": { lat: 36.0881, lng: 49.8547 },
  "زنجان": { lat: 36.6769, lng: 48.4963 },
  
  // بنادر کشورهای حاشیه خلیج فارس
  "بندر جبل علی": { lat: 24.9857, lng: 55.0494 },
  "بندر رشید": { lat: 25.2653, lng: 55.2712 },
  "بندر خلیفه": { lat: 24.8103, lng: 54.6437 },
  "بندر صلاله": { lat: 16.9561, lng: 54.0093 },
  "بندر دقم": { lat: 19.6563, lng: 57.7041 },
  "بندر صحار": { lat: 24.3617, lng: 56.7458 },
  
  // بنادر چین
  "بندر شانگهای": { lat: 31.2304, lng: 121.4737 },
  "بندر نینگبو-ژوشان": { lat: 29.8683, lng: 121.5440 },
  "بندر شنژن": { lat: 22.5431, lng: 114.0579 },
  "بندر گوانگژو": { lat: 23.1291, lng: 113.2644 },
};

// تعریف فاصله‌های جاده‌ای بین شهرهای داخلی
export const landDistances: CityDistance[] = [
  // Tehran to major cities
  { from: "تهران", to: "اصفهان", distance: 450, duration: 330, transportType: "land" },
  { from: "تهران", to: "مشهد", distance: 900, duration: 600, transportType: "land" },
  { from: "تهران", to: "تبریز", distance: 630, duration: 420, transportType: "land" },
  { from: "تهران", to: "اهواز", distance: 680, duration: 480, transportType: "land" },
  { from: "تهران", to: "شیراز", distance: 919, duration: 660, transportType: "land" },
  { from: "تهران", to: "کرمان", distance: 1050, duration: 720, transportType: "land" },
  { from: "تهران", to: "بندرعباس", distance: 1200, duration: 840, transportType: "land" },
  { from: "تهران", to: "رشت", distance: 330, duration: 240, transportType: "land" },
  { from: "تهران", to: "ارومیه", distance: 750, duration: 540, transportType: "land" },
  { from: "تهران", to: "همدان", distance: 320, duration: 210, transportType: "land" },
  { from: "تهران", to: "کرمانشاه", distance: 525, duration: 360, transportType: "land" },
  { from: "تهران", to: "یزد", distance: 700, duration: 480, transportType: "land" },
  { from: "تهران", to: "اردبیل", distance: 590, duration: 420, transportType: "land" },
  { from: "تهران", to: "زاهدان", distance: 1580, duration: 1080, transportType: "land" },
  { from: "تهران", to: "سنندج", distance: 520, duration: 360, transportType: "land" },
  { from: "تهران", to: "گرگان", distance: 400, duration: 300, transportType: "land" },
  { from: "تهران", to: "بوشهر", distance: 960, duration: 720, transportType: "land" },
  { from: "تهران", to: "بندر امام خمینی", distance: 800, duration: 600, transportType: "land" },
  { from: "تهران", to: "چابهار", distance: 2000, duration: 1440, transportType: "land" },
  { from: "تهران", to: "بندر جاسک", distance: 1650, duration: 1200, transportType: "land" },
  { from: "تهران", to: "قم", distance: 150, duration: 90, transportType: "land" },
  { from: "تهران", to: "ساری", distance: 280, duration: 210, transportType: "land" },
  { from: "تهران", to: "خرم‌آباد", distance: 470, duration: 330, transportType: "land" },
  { from: "تهران", to: "قزوین", distance: 150, duration: 90, transportType: "land" },
  { from: "تهران", to: "زنجان", distance: 330, duration: 240, transportType: "land" },
  
  // Isfahan to major cities
  { from: "اصفهان", to: "مشهد", distance: 1150, duration: 780, transportType: "land" },
  { from: "اصفهان", to: "تبریز", distance: 820, duration: 600, transportType: "land" },
  { from: "اصفهان", to: "اهواز", distance: 480, duration: 360, transportType: "land" },
  { from: "اصفهان", to: "شیراز", distance: 480, duration: 330, transportType: "land" },
  { from: "اصفهان", to: "کرمان", distance: 670, duration: 480, transportType: "land" },
  { from: "اصفهان", to: "بندرعباس", distance: 900, duration: 660, transportType: "land" },
  { from: "اصفهان", to: "رشت", distance: 590, duration: 420, transportType: "land" },
  { from: "اصفهان", to: "بندر امام خمینی", distance: 650, duration: 480, transportType: "land" },
  { from: "اصفهان", to: "یزد", distance: 320, duration: 210, transportType: "land" },
  { from: "اصفهان", to: "بوشهر", distance: 820, duration: 600, transportType: "land" },
  
  // Mashhad to major cities
  { from: "مشهد", to: "تبریز", distance: 1450, duration: 1020, transportType: "land" },
  { from: "مشهد", to: "اهواز", distance: 1560, duration: 1080, transportType: "land" },
  { from: "مشهد", to: "شیراز", distance: 1680, duration: 1200, transportType: "land" },
  { from: "مشهد", to: "کرمان", distance: 1160, duration: 840, transportType: "land" },
  { from: "مشهد", to: "بندرعباس", distance: 1400, duration: 1020, transportType: "land" },
  { from: "مشهد", to: "زاهدان", distance: 900, duration: 660, transportType: "land" },
  
  // Tabriz to major cities
  { from: "تبریز", to: "اهواز", distance: 1200, duration: 840, transportType: "land" },
  { from: "تبریز", to: "شیراز", distance: 1350, duration: 960, transportType: "land" },
  { from: "تبریز", to: "کرمان", distance: 1500, duration: 1080, transportType: "land" },
  { from: "تبریز", to: "بندرعباس", distance: 1650, duration: 1200, transportType: "land" },
  { from: "تبریز", to: "ارومیه", distance: 150, duration: 120, transportType: "land" },
  
  // Ahvaz to major cities
  { from: "اهواز", to: "شیراز", distance: 520, duration: 360, transportType: "land" },
  { from: "اهواز", to: "کرمان", distance: 990, duration: 720, transportType: "land" },
  { from: "اهواز", to: "بندرعباس", distance: 920, duration: 660, transportType: "land" },
  { from: "اهواز", to: "بندر امام خمینی", distance: 100, duration: 75, transportType: "land" },
  { from: "اهواز", to: "بوشهر", distance: 310, duration: 240, transportType: "land" },
  
  // Shiraz to major cities
  { from: "شیراز", to: "کرمان", distance: 570, duration: 420, transportType: "land" },
  { from: "شیراز", to: "بندرعباس", distance: 670, duration: 480, transportType: "land" },
  { from: "شیراز", to: "بوشهر", distance: 280, duration: 210, transportType: "land" },
  { from: "شیراز", to: "یزد", distance: 450, duration: 330, transportType: "land" },
  
  // Kerman to major cities
  { from: "کرمان", to: "بندرعباس", distance: 370, duration: 270, transportType: "land" },
  { from: "کرمان", to: "زاهدان", distance: 530, duration: 390, transportType: "land" },
  { from: "کرمان", to: "یزد", distance: 350, duration: 240, transportType: "land" },
  { from: "کرمان", to: "بندر جاسک", distance: 680, duration: 480, transportType: "land" },
  
  // Bandar Abbas to major cities
  { from: "بندرعباس", to: "زاهدان", distance: 850, duration: 600, transportType: "land" },
  { from: "بندرعباس", to: "چابهار", distance: 650, duration: 480, transportType: "land" },
  { from: "بندرعباس", to: "بندر جاسک", distance: 320, duration: 240, transportType: "land" },
  { from: "بندرعباس", to: "بوشهر", distance: 830, duration: 600, transportType: "land" },
  
  // Other important connections
  { from: "یزد", to: "زاهدان", distance: 780, duration: 540, transportType: "land" },
  { from: "زاهدان", to: "چابهار", distance: 690, duration: 480, transportType: "land" },
  { from: "رشت", to: "اردبیل", distance: 180, duration: 150, transportType: "land" },
  { from: "قزوین", to: "رشت", distance: 180, duration: 150, transportType: "land" },
  { from: "همدان", to: "کرمانشاه", distance: 190, duration: 150, transportType: "land" },
  { from: "اصفهان", to: "قم", distance: 280, duration: 210, transportType: "land" },
  { from: "زنجان", to: "قزوین", distance: 130, duration: 90, transportType: "land" },
  { from: "سنندج", to: "کرمانشاه", distance: 140, duration: 120, transportType: "land" },
];

// تعریف فاصله‌های ریلی بین شهرهای داخلی
export const railDistances: CityDistance[] = [
  // مسیرهای ریلی بین شهرهای اصلی
  { from: "تهران", to: "اصفهان", distance: 450, duration: 300, transportType: "rail" },
  { from: "تهران", to: "مشهد", distance: 900, duration: 480, transportType: "rail" },
  { from: "تهران", to: "تبریز", distance: 630, duration: 360, transportType: "rail" },
  { from: "تهران", to: "اهواز", distance: 680, duration: 420, transportType: "rail" },
  { from: "تهران", to: "قم", distance: 150, duration: 60, transportType: "rail" },
  { from: "تهران", to: "بندرعباس", distance: 1200, duration: 720, transportType: "rail" },
  { from: "تهران", to: "کرمان", distance: 1050, duration: 660, transportType: "rail" },
  { from: "تهران", to: "شیراز", distance: 919, duration: 600, transportType: "rail" },
  { from: "تهران", to: "یزد", distance: 700, duration: 420, transportType: "rail" },
  { from: "تهران", to: "زاهدان", distance: 1580, duration: 900, transportType: "rail" },
  { from: "تهران", to: "گرگان", distance: 400, duration: 240, transportType: "rail" },
  { from: "تهران", to: "رشت", distance: 330, duration: 180, transportType: "rail" },
  { from: "تهران", to: "همدان", distance: 320, duration: 180, transportType: "rail" },
  { from: "تهران", to: "قزوین", distance: 150, duration: 70, transportType: "rail" },
  { from: "تهران", to: "کرمانشاه", distance: 525, duration: 330, transportType: "rail" },
  { from: "تهران", to: "زنجان", distance: 330, duration: 200, transportType: "rail" },
  
  // شمال به جنوب
  { from: "رشت", to: "قزوین", distance: 160, duration: 90, transportType: "rail" },
  { from: "رشت", to: "اصفهان", distance: 590, duration: 360, transportType: "rail" },
  { from: "رشت", to: "شیراز", distance: 970, duration: 600, transportType: "rail" },
  
  // شمال شرقی
  { from: "مشهد", to: "گرگان", distance: 550, duration: 330, transportType: "rail" },
  { from: "مشهد", to: "تهران", distance: 900, duration: 480, transportType: "rail" },
  { from: "مشهد", to: "یزد", distance: 950, duration: 580, transportType: "rail" },
  { from: "مشهد", to: "زاهدان", distance: 900, duration: 540, transportType: "rail" },
  
  // مرکز و جنوب
  { from: "اصفهان", to: "شیراز", distance: 480, duration: 300, transportType: "rail" },
  { from: "اصفهان", to: "یزد", distance: 320, duration: 180, transportType: "rail" },
  { from: "اصفهان", to: "بندرعباس", distance: 900, duration: 600, transportType: "rail" },
  { from: "اصفهان", to: "تبریز", distance: 820, duration: 540, transportType: "rail" },
  { from: "اصفهان", to: "اهواز", distance: 480, duration: 300, transportType: "rail" },
  { from: "اصفهان", to: "بوشهر", distance: 820, duration: 540, transportType: "rail" },
  { from: "اصفهان", to: "کرمان", distance: 670, duration: 420, transportType: "rail" },
  
  // مسیرهای ریلی دیگر 
  { from: "یزد", to: "کرمان", distance: 350, duration: 210, transportType: "rail" },
  { from: "یزد", to: "بندرعباس", distance: 630, duration: 390, transportType: "rail" },
  { from: "یزد", to: "شیراز", distance: 450, duration: 270, transportType: "rail" },
  { from: "یزد", to: "زاهدان", distance: 790, duration: 480, transportType: "rail" },
  
  { from: "کرمان", to: "بندرعباس", distance: 470, duration: 300, transportType: "rail" },
  { from: "کرمان", to: "زاهدان", distance: 520, duration: 320, transportType: "rail" },
  
  { from: "تبریز", to: "زنجان", distance: 300, duration: 180, transportType: "rail" },
  { from: "تبریز", to: "ارومیه", distance: 150, duration: 90, transportType: "rail" },
  { from: "تبریز", to: "تهران", distance: 630, duration: 360, transportType: "rail" },
  
  { from: "اهواز", to: "شیراز", distance: 520, duration: 320, transportType: "rail" },
  { from: "اهواز", to: "بندر امام خمینی", distance: 100, duration: 60, transportType: "rail" },
  { from: "اهواز", to: "بندرعباس", distance: 920, duration: 570, transportType: "rail" },
  
  { from: "شیراز", to: "بندرعباس", distance: 670, duration: 420, transportType: "rail" },
  { from: "شیراز", to: "بوشهر", distance: 280, duration: 180, transportType: "rail" },
  { from: "شیراز", to: "کرمان", distance: 570, duration: 360, transportType: "rail" },
  
  // بندرها
  { from: "بندرعباس", to: "بندر امام خمینی", distance: 1100, duration: 660, transportType: "rail" },
  { from: "بندرعباس", to: "بندر چابهار", distance: 650, duration: 390, transportType: "rail" },
  { from: "بندرعباس", to: "بندر بوشهر", distance: 900, duration: 540, transportType: "rail" },
  
  // مسیرهای مرزی چین
  { from: "تهران", to: "بندر شانگهای", distance: 7500, duration: 9600, transportType: "rail" }, // 6-7 روز
  { from: "تهران", to: "پکن", distance: 6800, duration: 8640, transportType: "rail" }, // 6 روز
  
  // مسیرهای بین تهران و امارات/عمان از طریق بندرعباس به صورت ترکیبی
  { from: "تهران", to: "بندر جبل علی", distance: 1460, duration: 2160, transportType: "mixed" }, // ریلی + دریایی
  { from: "تهران", to: "بندر رشید", distance: 1440, duration: 2040, transportType: "mixed" }, // ریلی + دریایی
  { from: "تهران", to: "بندر خلیفه", distance: 1490, duration: 2280, transportType: "mixed" }, // ریلی + دریایی
  { from: "تهران", to: "بندر صلاله", distance: 1780, duration: 2880, transportType: "mixed" }, // ریلی + دریایی
];

// تعریف فاصله‌های دریایی بین بنادر
export const seaDistances: CityDistance[] = [
  // بندرعباس به بنادر خلیج فارس
  { from: "بندرعباس", to: "بندر جبل علی", distance: 260, duration: 1440, transportType: "sea" }, // ~24h
  { from: "بندرعباس", to: "بندر رشید", distance: 240, duration: 1320, transportType: "sea" }, // ~22h
  { from: "بندرعباس", to: "بندر خلیفه", distance: 290, duration: 1560, transportType: "sea" }, // ~26h
  { from: "بندرعباس", to: "بندر صلاله", distance: 580, duration: 2160, transportType: "sea" }, // ~36h
  { from: "بندرعباس", to: "بندر دقم", distance: 350, duration: 1800, transportType: "sea" }, // ~30h
  { from: "بندرعباس", to: "بندر صحار", distance: 320, duration: 1680, transportType: "sea" }, // ~28h
  
  // چابهار به بنادر خلیج فارس
  { from: "چابهار", to: "بندر جبل علی", distance: 450, duration: 2160, transportType: "sea" }, // ~36h
  { from: "چابهار", to: "بندر صلاله", distance: 340, duration: 1680, transportType: "sea" }, // ~28h
  { from: "چابهار", to: "بندر دقم", distance: 280, duration: 1440, transportType: "sea" }, // ~24h
  
  // بندر امام خمینی به بنادر خلیج فارس
  { from: "بندر امام خمینی", to: "بندر جبل علی", distance: 420, duration: 2160, transportType: "sea" }, // ~36h
  { from: "بندر امام خمینی", to: "بندر خلیفه", distance: 430, duration: 2280, transportType: "sea" }, // ~38h
  
  // بوشهر به بنادر خلیج فارس
  { from: "بوشهر", to: "بندر جبل علی", distance: 380, duration: 1920, transportType: "sea" }, // ~32h
  { from: "بوشهر", to: "بندر صحار", distance: 420, duration: 2040, transportType: "sea" }, // ~34h
  
  // بندر جاسک به بنادر خلیج فارس
  { from: "بندر جاسک", to: "بندر صلاله", distance: 400, duration: 2040, transportType: "sea" }, // ~34h
  { from: "بندر جاسک", to: "بندر دقم", distance: 320, duration: 1680, transportType: "sea" }, // ~28h
  
  // مسیرهای طولانی بین بنادر ایران و چین (نمونه)
  { from: "بندرعباس", to: "بندر شانگهای", distance: 7500, duration: 14400, transportType: "sea" }, // ~10 days
  { from: "بندرعباس", to: "بندر نینگبو-ژوشان", distance: 7300, duration: 14400, transportType: "sea" }, // ~10 days
  { from: "بندرعباس", to: "بندر شنژن", distance: 7000, duration: 13440, transportType: "sea" }, // ~9.3 days
  { from: "بندرعباس", to: "بندر گوانگژو", distance: 6800, duration: 12960, transportType: "sea" }, // ~9 days
  { from: "چابهار", to: "بندر شانگهای", distance: 7200, duration: 13920, transportType: "sea" }, // ~9.6 days
  { from: "چابهار", to: "بندر شنژن", distance: 6700, duration: 12960, transportType: "sea" }, // ~9 days
  { from: "بندر امام خمینی", to: "بندر شانگهای", distance: 7800, duration: 15120, transportType: "sea" }, // ~10.5 days
];

// ترکیب همه مسیرها
import { calculateRoute } from './openroute-service';

export const distances: CityDistance[] = [
  ...landDistances,
  ...railDistances, 
  ...seaDistances
];

/**
 * تابع محاسبه فاصله بین دو شهر/بندر
 * @param fromCity نام شهر مبدا
 * @param toCity نام شهر مقصد
 * @param preferredTransportType نوع حمل و نقل ترجیحی ("land", "sea", "rail")
 * @returns فاصله بر حسب کیلومتر و زمان بر حسب دقیقه، یا null در صورت عدم وجود مسیر در پایگاه داده
 */
export async function calculateDistanceBetweenCities(
  fromCity: string, 
  toCity: string, 
  preferredTransportType?: string
): Promise<{ distance: number; duration: number; transportType?: string; isEstimate?: boolean } | null> {
  // حذف پرانتز و محتوای داخل آن برای استفاده در هنگام نیاز به تطبیق با انگلیسی و فارسی
  const normalizeCity = (city: string): string => {
    return city.replace(/\s*\(.*?\)\s*/g, '').trim();
  };
  
  const normalizedFromCity = normalizeCity(fromCity);
  const normalizedToCity = normalizeCity(toCity);
  
  // ابتدا جستجوی مستقیم مسیر در پایگاه داده موجود با در نظر گرفتن نوع حمل و نقل ترجیحی
  let directRoute = distances.find(
    (route) => {
      const routeFromNormalized = normalizeCity(route.from);
      const routeToNormalized = normalizeCity(route.to);
      
      const cityMatch = 
        (routeFromNormalized === normalizedFromCity && routeToNormalized === normalizedToCity) || 
        (routeFromNormalized === normalizedToCity && routeToNormalized === normalizedFromCity);
        
      if (!cityMatch) return false;
      
      // اگر نوع حمل و نقل مشخص شده، فقط مسیرهایی با همان نوع را در نظر بگیر
      if (preferredTransportType && route.transportType) {
        return route.transportType === preferredTransportType;
      }
      
      return true;
    }
  );
  
  if (directRoute) {
    return {
      distance: directRoute.distance,
      duration: directRoute.duration,
      transportType: directRoute.transportType
    };
  }
  
  // اگر مسیر مستقیم در پایگاه داده محلی نبود، از OpenRouteService استفاده می‌کنیم
  // آیا هر دو مکان بندر هستند؟ در این صورت باید مسیر دریایی را ترجیح دهیم
  const isFromPort = fromCity.toLowerCase().includes('port') || fromCity.includes('بندر');
  const isToPort = toCity.toLowerCase().includes('port') || toCity.includes('بندر');
  
  // اگر هر دو مکان بندر هستند و نوع حمل و نقل ترجیحی مشخص نشده، از مسیر دریایی استفاده می‌کنیم
  const suggestedTransportType = (isFromPort && isToPort && !preferredTransportType) ? 'sea' : (preferredTransportType || 'land');
  
  // اگر هر دو بندر هستند و مسیر دریایی را می‌خواهیم، بررسی کنیم اگر در داده‌های دریایی ارتباط مستقیم وجود ندارد
  if (isFromPort && isToPort && suggestedTransportType === 'sea') {
    // جستجوی مسیر دریایی بین دو بندر
    const seaDistance = seaDistances.find(d => 
      (d.from === fromCity && d.to === toCity) || 
      (d.from === toCity && d.to === fromCity)
    );
    
    if (!seaDistance) {
      // اگر مسیر دریایی مستقیم نداریم، مقدار تخمینی تعیین می‌کنیم
      const estimatedSeaDistance = 1200; // مقدار تخمینی برای مسیرهای دریایی بین بنادر ناشناخته
      const estimatedSeaDuration = estimatedSeaDistance * 2.4; // حدود 2.4 دقیقه برای هر کیلومتر در حمل و نقل دریایی (میانگین سرعت 25 کیلومتر در ساعت)
      
      console.log(`No direct sea distance data found between ${fromCity} and ${toCity}, using estimated distance of ${estimatedSeaDistance}km`);
      
      return {
        distance: estimatedSeaDistance,
        duration: estimatedSeaDuration,
        transportType: 'sea'
      };
    }
  }
  
  try {
    // استفاده از OpenRouteService برای محاسبه مسیر جهانی
    console.log(`Using OpenRouteService API for route from ${fromCity} to ${toCity}`);
    const routeData = await calculateRoute(fromCity, toCity, suggestedTransportType);
    
    if (routeData) {
      return {
        distance: routeData.distance,
        duration: routeData.duration,
        transportType: routeData.transportType || preferredTransportType || 'land',
        isEstimate: false
      };
    }
  } catch (error: any) {
    // بهبود پیام خطا با جزئیات بیشتر
    const errorMessage = error.message || 'Unknown error';
    console.error(`Error using OpenRouteService for route from ${fromCity} to ${toCity}: ${errorMessage}`);
    
    // در صورت خطای جغرافیایی، پیام خاصی را لاگ می‌کنیم
    if (errorMessage.includes('latitude') || errorMessage.includes('geocode')) {
      console.log(`Could not geocode one of the locations: ${fromCity} or ${toCity}`);
    }
  }
  
  // اگر OpenRouteService هم موفق نبود، مقدار null برمی‌گرداند
  return null;
}

/**
 * تابع مسیریابی پیشرفته برای یافتن بهترین مسیر بین دو مکان
 * با پشتیبانی از مسیرهای چندبخشی و مدل‌های مختلف حمل و نقل
 * 
 * @param fromCity مبدا
 * @param toCity مقصد
 * @param preferredTransportType نوع حمل و نقل ترجیحی ('land', 'rail', 'sea', یا undefined برای انتخاب خودکار)
 * @returns بهترین مسیر بین دو مکان شامل قطعات مسیر
 */
export async function findBestRoute(fromCity: string, toCity: string, preferredTransportType?: string): Promise<{
  segments: {
    from: string;
    to: string;
    distance: number;
    duration: number;
    transportType: string;
  }[];
  totalDistance: number;
  totalDuration: number;
  transportTypes: string[];
  isEstimate?: boolean;
} | null> {
  // اگر نوع حمل و نقل مشخص شده باشد، فقط آن نوع را بررسی می‌کنیم
  if (preferredTransportType === 'rail') {
    // اگر کاربر به طور خاص حمل و نقل ریلی را درخواست کرده است
    // بررسی می‌کنیم آیا هر دو شهر دارای ایستگاه راه‌آهن هستند
    if (!hasRailwayStation(fromCity) || !hasRailwayStation(toCity)) {
      console.log(`Rail transport requested but ${fromCity} or ${toCity} does not have a railway station`);      
      return null; // اگر امکان حمل و نقل ریلی نیست، null برمی‌گردانیم
    }
    
    // بررسی می‌کنیم آیا مسیر ریلی مستقیم وجود دارد
    const hasRailRoute = hasDirectRailConnection(fromCity, toCity);
    if (hasRailRoute) {
      // یافتن مسیر ریلی مستقیم در پایگاه داده
      const directRailPath = await calculateDistanceBetweenCities(fromCity, toCity, 'rail');
      if (directRailPath) {
        return {
          segments: [{
            from: fromCity,
            to: toCity,
            distance: directRailPath.distance,
            duration: directRailPath.duration,
            transportType: 'rail'
          }],
          totalDistance: directRailPath.distance,
          totalDuration: directRailPath.duration,
          transportTypes: ['rail'],
          isEstimate: false
        };
      }
    }
    
    // اگر مسیر ریلی مستقیم نیست، باید مسیر چندبخشی ریلی پیدا کنیم (در آینده پیاده‌سازی خواهد شد)
    console.log(`No direct rail route between ${fromCity} and ${toCity}, searching for multi-segment rail routes...`);
    // فعلا مسیر ریلی نداریم
    return null;
  }
  
  // بررسی می‌کنیم آیا مسیر مستقیم بین دو شهر وجود دارد
  const directPath = await calculateDistanceBetweenCities(fromCity, toCity, preferredTransportType);
  
  // اگر مسیر مستقیم موجود باشد، آن را برمی‌گردانیم
  if (directPath) {
    // مطمئن می‌شویم که فرمت درست است
    return {
      segments: [{
        from: fromCity,
        to: toCity,
        distance: directPath.distance,
        duration: directPath.duration,
        transportType: directPath.transportType || preferredTransportType || 'land'
      }],
      totalDistance: directPath.distance,
      totalDuration: directPath.duration,
      transportTypes: [directPath.transportType || preferredTransportType || 'land'],
      isEstimate: directPath.isEstimate
    };
  }

  // بررسی هوشمند نوع مبدأ و مقصد برای تشخیص بندر
  const isPortFrom = fromCity.includes('بندر') || fromCity.toLowerCase().includes('port');
  const isPortTo = toCity.includes('بندر') || toCity.toLowerCase().includes('port');
  
  // اگر هر دو مبدأ و مقصد بندر باشند، باید حتماً از حمل و نقل دریایی استفاده شود
  // مگر اینکه کاربر به صراحت نوع دیگری از حمل و نقل را درخواست کرده باشد
  if (isPortFrom && isPortTo && preferredTransportType !== 'land' && preferredTransportType !== 'rail') {
    console.log(`Both ${fromCity} and ${toCity} are ports, creating direct sea route`);
    
    // بررسی مسیر مستقیم دریایی بین دو بندر
    const seaRoute = await calculateDistanceBetweenCities(fromCity, toCity, "sea");
    
    if (seaRoute) {
      // مسیر دریایی مستقیم بین دو بندر پیدا شد
      return {
        segments: [{
          from: fromCity,
          to: toCity,
          distance: seaRoute.distance,
          duration: seaRoute.duration,
          transportType: "sea"
        }],
        totalDistance: seaRoute.distance,
        totalDuration: seaRoute.duration,
        transportTypes: ["sea"]
      };
    } else {
      // اگر مسیر دریایی مستقیم در داده‌ها نیست، یک مسیر تخمینی ایجاد کنیم
      // محاسبه فاصله هوایی بین دو شهر (تخمینی)
      // فاصله بر اساس مختصات جغرافیایی یا تخمین
      let estimatedDistance = 1200; // مقدار پیش‌فرض
      let estimatedDuration = 2880; // مقدار پیش‌فرض - 48 ساعت 
      
      try {
        // بررسی وجود مختصات جغرافیایی برای محاسبه دقیق‌تر فاصله
        const query = sql`
          SELECT l1.latitude as lat1, l1.longitude as lng1, 
                 l2.latitude as lat2, l2.longitude as lng2
          FROM locations l1, locations l2
          WHERE l1.name = ${fromCity} AND l2.name = ${toCity}
          AND l1.latitude IS NOT NULL AND l1.longitude IS NOT NULL
          AND l2.latitude IS NOT NULL AND l2.longitude IS NOT NULL
          LIMIT 1
        `;
        
        const result = await db.execute(query);
        
        if (result.rows && result.rows.length > 0) {
          const coords = result.rows[0];
          if (coords.lat1 && coords.lng1 && coords.lat2 && coords.lng2) {
            // محاسبه فاصله بر اساس فرمول هاورساین
            const R = 6371; // شعاع زمین به کیلومتر
            const lat1 = Number(coords.lat1);
            const lng1 = Number(coords.lng1);
            const lat2 = Number(coords.lat2);
            const lng2 = Number(coords.lng2);
            
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLon = (lng2 - lng1) * Math.PI / 180;
            const a = 
              Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
              Math.sin(dLon/2) * Math.sin(dLon/2); 
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
            estimatedDistance = R * c;
            
            // زمان سفر دریایی: متوسط سرعت کشتی‌های باری حدود 25 کیلومتر در ساعت
            estimatedDuration = Math.round(estimatedDistance / 25 * 60); // زمان به دقیقه
            
            console.log(`Calculated sea distance between ${fromCity} and ${toCity} is ${estimatedDistance.toFixed(2)}km`);
          }
        }
      } catch (error) {
        console.error(`Error calculating precise distance between ports: ${error}`);
        // ادامه با مقادیر پیش‌فرض
      }
      
      console.log(`Using sea route between ${fromCity} and ${toCity}, distance: ${estimatedDistance.toFixed(2)}km, duration: ${estimatedDuration} minutes`);
      
      return {
        segments: [
          {
            from: fromCity,
            to: toCity,
            distance: estimatedDistance,
            duration: estimatedDuration,
            transportType: "sea"
          }
        ],
        totalDistance: estimatedDistance,
        totalDuration: estimatedDuration,
        transportTypes: ["sea"]
      };
    }
  }
  
  // ابتدا بررسی کنیم آیا مسیر مستقیم وجود دارد با توجه به نوع حمل و نقل ترجیحی
  let directRoute: { distance: number; duration: number; transportType?: string } | null = null;
  
  // اگر نوع حمل و نقل ترجیحی مشخص شده باشد، ابتدا آن را بررسی می‌کنیم
  if (preferredTransportType) {
    directRoute = await calculateDistanceBetweenCities(fromCity, toCity, preferredTransportType);
  } else {
    // بررسی اولویت‌های مختلف حمل و نقل
    // اگر هر دو مکان بندر هستند، ابتدا مسیر دریایی را بررسی کن
    if (isPortFrom && isPortTo) {
      directRoute = await calculateDistanceBetweenCities(fromCity, toCity, "sea");
    }
    
    // اگر مسیر دریایی نبود، مسیر ریلی را بررسی کن
    if (!directRoute) {
      directRoute = await calculateDistanceBetweenCities(fromCity, toCity, "rail");
    }
    
    // اگر مسیر ریلی هم نبود، هر نوع حمل و نقلی را بپذیر
    if (!directRoute) {
      directRoute = await calculateDistanceBetweenCities(fromCity, toCity);
    }
  }
  
  if (directRoute && directRoute.transportType) {
    return {
      segments: [{
        from: fromCity,
        to: toCity,
        distance: directRoute.distance,
        duration: directRoute.duration,
        transportType: directRoute.transportType
      }],
      totalDistance: directRoute.distance,
      totalDuration: directRoute.duration,
      transportTypes: [directRoute.transportType]
    };
  }
  
  // اگر مسیر مستقیم وجود نداشت، شروع به یافتن مسیر بهینه با یک مرحله میانی می‌کنیم
  
  // شناسایی اینکه آیا مقصد در ایران است یا خارج از ایران
  const isInternational = (city: string): boolean => {
    // لیست شهرهای ایران (نام‌ها بدون پرانتز و محتوای داخل آن)
    const iranianCities = [
      "تهران", "اصفهان", "مشهد", "تبریز", "اهواز", "شیراز", "کرمان", 
      "بندرعباس", "رشت", "ارومیه", "همدان", "کرمانشاه", "یزد", "اردبیل", 
      "زاهدان", "سنندج", "گرگان", "بوشهر", "بندر امام خمینی", "چابهار", 
      "بندر جاسک", "قم", "ساری", "خرم‌آباد", "قزوین", "زنجان"
    ];
    
    const normalizeCity = (c: string): string => c.replace(/\s*\(.*?\)\s*/g, '').trim();
    return !iranianCities.includes(normalizeCity(city));
  };
  
  const isPersianGulfPort = (city: string): boolean => {
    const gulfPorts = [
      "بندر جبل علی", "بندر رشید", "بندر خلیفه", "بندر صلاله", 
      "بندر دقم", "بندر صحار"
    ];
    const normalizeCity = (c: string): string => c.replace(/\s*\(.*?\)\s*/g, '').trim();
    return gulfPorts.includes(normalizeCity(city));
  };
  
  const isChinesePort = (city: string): boolean => {
    const chinesePorts = [
      "بندر شانگهای", "بندر نینگبو-ژوشان", "بندر شنژن", "بندر گوانگژو"
    ];
    const normalizeCity = (c: string): string => c.replace(/\s*\(.*?\)\s*/g, '').trim();
    return chinesePorts.includes(normalizeCity(city));
  };
  
  // Determine the best intermediate points based on origin and destination types
  const getIntermediatePoints = (): string[] => {
    // اگر مقصد بین‌المللی است، ما به یک بندر ایرانی به عنوان نقطه میانی نیاز داریم
    if (isInternational(toCity)) {
      // اگر مقصد در خلیج فارس است، بندرعباس و چابهار را پیشنهاد می‌کنیم
      if (isPersianGulfPort(toCity)) {
        return ["بندرعباس", "چابهار", "بوشهر", "بندر امام خمینی"];
      }
      
      // اگر مقصد یک بندر چینی است
      if (isChinesePort(toCity)) {
        return ["بندرعباس", "چابهار"];
      }
      
      // برای سایر مقاصد بین‌المللی
      return ["بندرعباس", "چابهار", "بوشهر", "بندر امام خمینی"];
    }
    
    // اگر هم مبدا و هم مقصد در ایران هستند، ممکن است نیاز به یافتن یک شهر میانجی داشته باشیم
    // ما شهرهای بزرگ را به عنوان نقاط احتمالی میانی استفاده می‌کنیم
    return ["تهران", "اصفهان", "شیراز", "مشهد", "اهواز", "کرمان", "یزد", "تبریز", "بندرعباس"];
  };
  
  const intermediatePoints = getIntermediatePoints();
  let bestRoute = null;
  let minTotalDuration = Infinity;
  
  // بررسی همه مسیرهای ممکن از طریق نقاط میانی
  for (const via of intermediatePoints) {
    // اولویت با مسیرهای ریلی است
    let firstLeg = await calculateDistanceBetweenCities(fromCity, via, "rail");
    if (!firstLeg) {
      firstLeg = await calculateDistanceBetweenCities(fromCity, via);
    }
    
    let secondLeg = await calculateDistanceBetweenCities(via, toCity, "rail");
    if (!secondLeg) {
      secondLeg = await calculateDistanceBetweenCities(via, toCity);
    }
    
    if (firstLeg && secondLeg) {
      const totalDistance = firstLeg.distance + secondLeg.distance;
      const totalDuration = firstLeg.duration + secondLeg.duration;
      
      // اگر این مسیر بهتر از بهترین مسیر فعلی است، آن را به روز کنید
      if (totalDuration < minTotalDuration) {
        minTotalDuration = totalDuration;
        bestRoute = {
          segments: [
            {
              from: fromCity,
              to: via,
              distance: firstLeg.distance,
              duration: firstLeg.duration,
              transportType: firstLeg.transportType || 'land'
            },
            {
              from: via,
              to: toCity,
              distance: secondLeg.distance,
              duration: secondLeg.duration,
              transportType: secondLeg.transportType || 'land'
            }
          ],
          totalDistance,
          totalDuration,
          transportTypes: [
            firstLeg.transportType || 'land', 
            secondLeg.transportType || 'land'
          ]
        };
      }
    }
  }
  
  // اگر هیچ مسیر بهینه‌ای یافت نشد، یک تخمین ساده ارائه می‌دهیم
  if (!bestRoute) {
    return await estimatePath(fromCity, toCity);
  }
  
  return bestRoute;
}

/**
 * تابع تخمین مسیر برای مواردی که داده دقیق وجود ندارد
 * @param fromCity مبدا
 * @param toCity مقصد
 * @returns مسیر تخمینی
 */
async function estimatePath(fromCity: string, toCity: string): Promise<{
  segments: {
    from: string;
    to: string;
    distance: number;
    duration: number;
    transportType: string;
  }[];
  totalDistance: number;
  totalDuration: number;
  transportTypes: string[];
} | null> {
  // بررسی می‌کنیم آیا مقصد یک بندر خارجی است
  const isPersianGulfPort = (city: string): boolean => {
    const gulfPorts = [
      "بندر جبل علی", "بندر رشید", "بندر خلیفه", "بندر صلاله", 
      "بندر دقم", "بندر صحار"
    ];
    const normalizeCity = (c: string): string => c.replace(/\s*\(.*?\)\s*/g, '').trim();
    return gulfPorts.includes(normalizeCity(city));
  };
  
  const isChinesePort = (city: string): boolean => {
    const chinesePorts = [
      "بندر شانگهای", "بندر نینگبو-ژوشان", "بندر شنژن", "بندر گوانگژو"
    ];
    const normalizeCity = (c: string): string => c.replace(/\s*\(.*?\)\s*/g, '').trim();
    return chinesePorts.includes(normalizeCity(city));
  };
  
  // انتخاب بهترین بندر ایرانی برای مسیرهای بین‌المللی
  let bestIranianPort = "بندرعباس";
  
  // اگر مقصد بندری در خلیج فارس یا چین است، مسیری از طریق بندرعباس تخمین می‌زنیم
  if (isPersianGulfPort(toCity) || isChinesePort(toCity)) {
    const landLeg = await calculateDistanceBetweenCities(fromCity, bestIranianPort, "land") || 
                    { distance: 800, duration: 600, transportType: "land" };
                    
    let seaDistance = 0;
    let seaDuration = 0;
    
    if (isPersianGulfPort(toCity)) {
      seaDistance = 300; // تقریبی برای بنادر خلیج فارس
      seaDuration = 1440; // حدود 24 ساعت
    } else if (isChinesePort(toCity)) {
      seaDistance = 7000; // تقریبی برای بنادر چین
      seaDuration = 14400; // حدود 10 روز
    }
    
    return {
      segments: [
        {
          from: fromCity,
          to: bestIranianPort,
          distance: landLeg.distance,
          duration: landLeg.duration,
          transportType: "land"
        },
        {
          from: bestIranianPort,
          to: toCity,
          distance: seaDistance,
          duration: seaDuration,
          transportType: "sea"
        }
      ],
      totalDistance: landLeg.distance + seaDistance,
      totalDuration: landLeg.duration + seaDuration,
      transportTypes: ["land", "sea"]
    };
  }
  
  // برای سایر موارد، یک تخمین ساده ارائه می‌دهیم
  // در حالت واقعی، این قسمت می‌تواند با استفاده از محاسبات مبتنی بر مختصات جغرافیایی بهبود یابد
  const estimatedDistance = 600;
  const estimatedDuration = Math.round(estimatedDistance * 0.7);
  
  return {
    segments: [
      {
        from: fromCity,
        to: toCity,
        distance: estimatedDistance,
        duration: estimatedDuration,
        transportType: "land"
      }
    ],
    totalDistance: estimatedDistance,
    totalDuration: estimatedDuration,
    transportTypes: ["land"]
  };
}

/**
 * تابع تخمین فاصله برای مسیرهایی که در پایگاه داده موجود نیست
 * با استفاده از مسیریابی چندگانه
 * 
 * @param fromCity نام شهر مبدا
 * @param toCity نام شهر مقصد
 * @returns فاصله تخمینی بر حسب کیلومتر و زمان تخمینی بر حسب دقیقه و نوع حمل و نقل
 */
export async function estimateDistanceAndDuration(fromCity: string, toCity: string): Promise<{ 
  distance: number; 
  duration: number;
  transportType: string;
  isEstimate: boolean;
  route?: any;
}> {
  // ابتدا بررسی می‌کنیم آیا مسیر مستقیم در پایگاه داده موجود است
  const directDistance = await calculateDistanceBetweenCities(fromCity, toCity);
  if (directDistance) {
    return {
      distance: directDistance.distance,
      duration: directDistance.duration,
      transportType: directDistance.transportType || "land",
      isEstimate: false
    };
  }
  
  // بررسی مسیرهای چندبخشی
  const bestRoute = await findBestRoute(fromCity, toCity);
  
  if (bestRoute) {
    // یک شناسه منحصر به فرد برای نوع حمل و نقل ترکیبی ایجاد کن
    let transportType = bestRoute.transportTypes.length > 1 
      ? "mixed" 
      : bestRoute.transportTypes[0];
    
    return {
      distance: bestRoute.totalDistance,
      duration: bestRoute.totalDuration,
      transportType,
      isEstimate: true,
      route: bestRoute
    };
  }
  
  // اگر هیچ مسیری یافت نشد، یک تخمین پایه ارائه می‌دهیم
  const estimatedDistance = 600; // میانگین فاصله تخمینی
  const estimatedDuration = Math.round(estimatedDistance * 0.7); // زمان تخمینی بر اساس سرعت متوسط
  
  return {
    distance: estimatedDistance,
    duration: estimatedDuration,
    transportType: "land",
    isEstimate: true
  };
}

/**
 * تابع برای تشخیص بنادر از مکان‌های دیگر
 * @param locationName نام مکان
 * @returns آیا این مکان یک بندر است یا خیر
 */
export function isPort(locationName: string): boolean {
  return locationName.includes('بندر') || 
         locationName.toLowerCase().includes('port') ||
         locationName.includes('اسکله');
}

/**
 * تابع برای محاسبه فاصله بین دو مختصات جغرافیایی
 * @param coord1 مختصات مکان اول
 * @param coord2 مختصات مکان دوم
 * @returns فاصله به کیلومتر
 */
function calculateDistance(coord1: GeoCoordinate, coord2: GeoCoordinate): number {
  const R = 6371; // شعاع زمین به کیلومتر
  const lat1Rad = toRadians(coord1.lat);
  const lat2Rad = toRadians(coord2.lat);
  const latDiffRad = toRadians(coord2.lat - coord1.lat);
  const lngDiffRad = toRadians(coord2.lng - coord1.lng);

  const a = Math.sin(latDiffRad/2) * Math.sin(latDiffRad/2) +
          Math.cos(lat1Rad) * Math.cos(lat2Rad) *
          Math.sin(lngDiffRad/2) * Math.sin(lngDiffRad/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;

  return distance;
}

/**
 * تابع برای پیدا کردن نزدیکترین بنادر به یک مکان
 * @param locationName نام مکان
 * @param limit تعداد بنادر مورد نیاز (پیش‌فرض: 2)
 * @returns لیستی از نزدیکترین بنادر همراه با فاصله و زمان سفر
 */
export async function getNearestPorts(locationName: string, limit: number = 2): Promise<Port[]> {
  // اگر خود مکان یک بندر است، آن را برگردان
  if (isPort(locationName)) {
    const locationCountry = "ایران"; // پیش‌فرض
    return [{
      name: locationName,
      country: locationCountry,
      distanceFromLocation: 0,
      travelTime: 0
    }];
  }
  
  // گرفتن مختصات جغرافیایی مکان
  let locationCoord: GeoCoordinate | undefined;
  
  // ابتدا بررسی کنیم آیا مختصات در پایگاه داده موجود است
  const simpleLocationName = locationName.split('(')[0].trim();
  
  // جستجو در پایگاه داده مختصات
  for (const [name, coord] of Object.entries(geoCoordinates)) {
    if (locationName.includes(name) || name.includes(simpleLocationName)) {
      locationCoord = coord;
      break;
    }
  }
  
  // اگر مختصات یافت نشد، از API خارجی استفاده کنیم
  if (!locationCoord) {
    try {
      // استفاده از تابع geocodeLocation که قبلاً تعریف شده است
      const geocodeResult = await geocodeLocation(locationName);
      if (geocodeResult) {
        locationCoord = geocodeResult;
      } else {
        throw new Error(`Could not find coordinates for location: ${locationName}`);
      }
    } catch (error) {
      console.error(`Error geocoding location ${locationName}:`, error);
      return [];
    }
  }
  
  if (!locationCoord) {
    return [];
  }
  
  // فیلتر کردن بنادر از مختصات
  const ports: {name: string, country: string, coord: GeoCoordinate}[] = [];
  
  for (const [name, coord] of Object.entries(geoCoordinates)) {
    if (isPort(name)) {
      // تعیین کشور بر اساس نام (تخمینی)
      let country = "ایران";
      if (name.includes("علی") || name.includes("رشید") || name.includes("خلیفه")) {
        country = "امارات متحده عربی";
      } else if (name.includes("صلاله") || name.includes("دقم") || name.includes("صحار") || name.includes("قابوس")) {
        country = "عمان";
      } else if (name.includes("شانگهای") || name.includes("نینگبو") || name.includes("شنژن") || name.includes("گوانگژو")) {
        country = "چین";
      }
      
      ports.push({
        name,
        country,
        coord
      });
    }
  }
  
  // محاسبه فاصله هر بندر تا مکان مورد نظر
  const portsWithDistance = ports.map(port => {
    const distance = calculateDistance(locationCoord!, port.coord);
    // محاسبه زمان تقریبی سفر (با فرض متوسط سرعت 65 کیلومتر در ساعت)
    const travelTimeHours = distance / 65;
    const travelTimeMinutes = Math.round(travelTimeHours * 60);
    
    return {
      name: port.name,
      country: port.country,
      distanceFromLocation: Math.round(distance),
      travelTime: travelTimeMinutes
    };
  });
  
  // مرتب‌سازی بنادر بر اساس فاصله (نزدیکترین اول)
  portsWithDistance.sort((a, b) => a.distanceFromLocation - b.distanceFromLocation);
  
  // برگرداندن تعداد درخواست شده از نزدیکترین بنادر
  return portsWithDistance.slice(0, limit);
}

/**
 * تابع برای پیدا کردن بنادر نزدیک برای مسیریابی بین دو مکان
 * فقط بنادر کشور مبدا (ایران) نشان داده می‌شوند
 * @param fromLocation مکان مبدا
 * @param toLocation مکان مقصد
 * @returns مسیرهای پیشنهادی از طریق بنادر نزدیک
 */
export async function findPortRoutes(fromLocation: string, toLocation: string): Promise<{
  originPorts: Port[],
  destinationPorts: Port[],
  directRouteAvailable: boolean,
  bestAlternativeRoute?: {
    originPort: Port,
    destinationPort: Port,
    totalDistance: number,
    landDistance1: number,
    seaDistance: number,
    landDistance2: number,
    totalDuration: number
  },
  // افزودن مسیرهای چندگانه از طریق بنادر مختلف
  portRoutes: Array<{
    port: Port,
    landRoute: {
      distance: number,
      duration: number,
      transportType: string,
      price?: PriceResult | null // اطلاعات قیمت برای مسیر زمینی
    },
    seaRoute: {
      distance: number, 
      duration: number,
      price?: PriceResult | null // اطلاعات قیمت برای مسیر دریایی
    },
    railRoute?: {
      distance: number,
      duration: number,
      available: boolean,
      price?: PriceResult | null // اطلاعات قیمت برای مسیر ریلی
    },
    // اطلاعات قیمت کلی مسیر
    totalPriceInfo?: {
      landPrice: PriceResult | null,
      railPrice: PriceResult | null,
      seaPrice: PriceResult | null,
      totalPriceToman: number | null
    }
  }>
}> {
  // لیست بنادر ایران - برای اطمینان از نمایش همه بنادر مهم
  const iranianPorts = [
    "بندرعباس", "بندر عباس", "بندر امام خمینی", "چابهار", "بندر چابهار", "بوشهر", "بندر بوشهر", "بندر جاسک"
  ];
  
  // یافتن بنادر نزدیک به مبدا (فقط بنادر ایران)
  let originPorts = await getNearestPorts(fromLocation, 3); 
  
  // اطمینان از اینکه همه بنادر مهم را در نظر گرفته‌ایم
  // اگر تعداد بنادر کمتر از 4 باشد، سعی می‌کنیم بنادر مهم را اضافه کنیم
  if (originPorts.length < 4) {
    // برای هر بندر ایرانی که در لیست نیست
    for (const portName of iranianPorts) {
      if (!originPorts.some(p => p.name === portName)) {
        try {
          // محاسبه فاصله بین مبدا و این بندر
          const route = await calculateDistanceBetweenCities(fromLocation, portName);
          if (route) {
            // اضافه کردن بندر به لیست با اطلاعات محاسبه شده
            originPorts.push({
              name: portName,
              country: "ایران",
              distanceFromLocation: route.distance,
              travelTime: route.duration
            });
          }
        } catch (error) {
          console.error(`Error calculating distance to port ${portName}:`, error);
        }
        
        // اگر تعداد بنادر به 4 رسید، خارج شو
        if (originPorts.length >= 4) break;
      }
    }
  }
  
  // مرتب‌سازی بنادر براساس فاصله
  originPorts.sort((a, b) => a.distanceFromLocation - b.distanceFromLocation);
  
  // برای مسیرهای بین‌المللی، فقط بنادر کشور مبدا (ایران) را نشان می‌دهیم
  // اما هنوز مجموعه خالی destinationPorts را برمی‌گردانیم برای حفظ سازگاری با رابط
  const destinationPorts: Port[] = [];
  
  // بررسی امکان مسیر مستقیم
  const directRoute = await calculateDistanceBetweenCities(fromLocation, toLocation);
  const directRouteAvailable = !!directRoute && !directRoute.isEstimate;
  
  // برای مقاصد بین‌المللی، می‌توانیم بندر مقصد را مشخص کنیم
  // ذکر یک بندر اصلی در کشور مقصد برای محاسبه مسیر دریایی
  const defaultDestinationPort = {
    name: "بندر مقصد",
    country: "کشور مقصد",
    distanceFromLocation: 0,
    travelTime: 0
  };
  
  // ایجاد مسیرهای جایگزین از طریق بنادر
  let bestAlternativeRoute = undefined;
  
  // اگر تنها یک بندر مقصد را برای محاسبه مسیر دریایی اضافه می‌کنیم
  if (isInternationalDestination(toLocation)) {
    destinationPorts.push(defaultDestinationPort);
  }
  
  // تابع کمکی برای محاسبه مسیر دریایی برای هر نوع مقصد
  const getSeaRouteForDestination = (destLocation: string) => {
    // اگر مقصد در خلیج فارس است
    if (destLocation.toLowerCase().includes("dubai") || 
        destLocation.toLowerCase().includes("hamad") || 
        destLocation.toLowerCase().includes("قطر") ||
        destLocation.toLowerCase().includes("امارات") ||
        destLocation.toLowerCase().includes("عمان") ||
        destLocation.toLowerCase().includes("qatar") ||
        destLocation.toLowerCase().includes("uae") ||
        destLocation.toLowerCase().includes("emirates") ||
        destLocation.toLowerCase().includes("oman") ||
        destLocation.toLowerCase().includes("bahrain") ||
        destLocation.toLowerCase().includes("بحرین")) {
      // فاصله تقریبی خلیج فارس
      return {
        distance: 300,
        duration: 1440 // حدود یک روز
      };
    } 
    // اگر مقصد در آسیای شرقی/چین است
    else if (destLocation.toLowerCase().includes("china") || 
             destLocation.toLowerCase().includes("چین") || 
             destLocation.toLowerCase().includes("hong kong") ||
             destLocation.toLowerCase().includes("singapore")) {
      return {
        distance: 7000,
        duration: 14400 // حدود 10 روز
      };
    }
    // برای سایر مقاصد بین‌المللی
    else {
      return {
        distance: 1200,
        duration: 2880 // حدود دو روز
      };
    }
  };

  // محاسبه مسیرهای مختلف از طریق بنادر مختلف
  const portRoutesData = await Promise.all(originPorts.map(async (port) => {
    // محاسبه مسیر زمینی از مبدا تا بندر
    const landRoute: any = {
      distance: port.distanceFromLocation,
      duration: port.travelTime,
      transportType: "land"
    };
    
    // بررسی امکان مسیر ریلی از مبدا تا بندر
    const railRoute = await calculateDistanceBetweenCities(fromLocation, port.name, "rail");
    let railData: any = undefined;
    
    if (railRoute && railRoute.transportType === "rail") {
      railData = {
        distance: railRoute.distance,
        duration: railRoute.duration,
        available: true
      };
    } else {
      // اگر مسیر ریلی وجود ندارد، وجود نداشتن را مشخص کن
      railData = {
        distance: landRoute.distance,
        duration: Math.floor(landRoute.duration * 0.8), // ریل معمولا سریع‌تر است
        available: false
      };
    }
    
    // محاسبه مسیر دریایی از بندر تا مقصد
    const seaRoute: any = getSeaRouteForDestination(toLocation);
    
    // محاسبه قیمت برای مسیر زمینی - وزن بار پیش‌فرض 20 تن
    const defaultCargoWeight = 20000; // 20 تن = 20,000 کیلوگرم
    
    // محاسبه قیمت برای مسیر زمینی
    const landPrice = calculateDetailedPrice(
      "land", // استفاده از حالت خودکار انتخاب وسیله نقلیه براساس وزن
      landRoute.distance, 
      defaultCargoWeight,
      undefined,
      undefined,
      isInternationalDestination(toLocation),
      landRoute.distance // برای مسیرهای بین‌المللی، فقط فاصله تا بندر محاسبه می‌شود
    );
    
    // محاسبه قیمت برای مسیر ریلی
    const railPrice = railData?.available ? calculateDetailedPrice(
      "rail", 
      railData.distance, 
      defaultCargoWeight,
      undefined,
      undefined,
      isInternationalDestination(toLocation),
      railData.distance
    ) : null;
    
    // برای مسیر دریایی، قیمت null است (نیاز به قیمت‌های واقعی شرکت‌های حمل و نقل)
    const seaPrice = null;
    
    // محاسبه قیمت کل
    const totalPriceToman = (landPrice?.priceToman || 0) + (railPrice?.priceToman || 0);
    
    // اضافه کردن اطلاعات قیمت به مسیرها
    landRoute.price = landPrice;
    if (railData) railData.price = railPrice;
    seaRoute.price = seaPrice;
    
    return {
      port,
      landRoute,
      seaRoute,
      railRoute: railData,
      totalPriceInfo: {
        landPrice,
        railPrice,
        seaPrice,
        totalPriceToman: totalPriceToman || null
      }
    };
  }));
  
  // اگر این یک مسیر بین‌المللی است، بهترین مسیر جایگزین را محاسبه کن
  if (isInternationalDestination(toLocation) && portRoutesData.length > 0 && destinationPorts.length > 0) {
    // با این فرض که destinationPorts دارای defaultDestinationPort است
    const destinationPort = destinationPorts[0];
    
    // بهترین بندر را براساس کوتاه‌ترین فاصله زمینی از مبدا تا بندر انتخاب کن
    const bestRoute = portRoutesData.reduce((prev, current) => {
      return (prev.landRoute.distance < current.landRoute.distance) ? prev : current;
    });
    
    // محاسبه کل فاصله و زمان
    const totalDistance = bestRoute.landRoute.distance + bestRoute.seaRoute.distance;
    const totalDuration = bestRoute.landRoute.duration + bestRoute.seaRoute.duration;
    
    // تنظیم بهترین مسیر جایگزین
    bestAlternativeRoute = {
      originPort: bestRoute.port,
      destinationPort: destinationPort,
      totalDistance: Math.round(totalDistance),
      landDistance1: Math.round(bestRoute.landRoute.distance),
      seaDistance: Math.round(bestRoute.seaRoute.distance),
      landDistance2: 0, // برای مسیرهای بین‌المللی، فاصله زمینی در مقصد را صفر در نظر می‌گیریم
      totalDuration: totalDuration
    };
  }
  
  return {
    originPorts,
    destinationPorts,
    directRouteAvailable,
    bestAlternativeRoute,
    portRoutes: portRoutesData
  };
}

// تابع کمکی برای تشخیص مقاصد بین‌المللی
// بررسی می‌کند که آیا مقصد یک کشور خارجی است
function isInternationalDestination(location: string): boolean {
  // لیست کلیدواژه‌های کشورهای خارجی
  const internationalKeywords = [
    "dubai", "دبی", "qatar", "قطر", "bahrain", "بحرین", 
    "oman", "عمان", "uae", "emirates", "امارات",
    "kuwait", "کویت", "saudi", "عربستان",
    "china", "چین", "hong kong", "singapore", "سنگاپور",
    "turkey", "ترکیه", "india", "هند", "iraq", "عراق"
  ];
  
  // بررسی وجود هر یک از کلیدواژه‌ها در نام مقصد
  const locationLower = location.toLowerCase();
  return internationalKeywords.some(keyword => locationLower.includes(keyword));
}