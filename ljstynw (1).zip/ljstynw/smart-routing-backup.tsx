import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronRight, TruckIcon, ShipIcon, TrainIcon, DollarSign, Clock, MapPin, Calendar, PackageIcon } from "lucide-react";
import LocationsDropdown from "@/components/home/LocationsDropdown";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import LoadingIndicator from "@/components/common/LoadingIndicator";

interface Segment {
  from: string;
  to: string;
  distance: number;
  duration: number;
  transportType: string;
  shipments: any[];
}

interface Route {
  segments: Segment[];
  totalDistance: number;
  totalDuration: number;
  transportTypes: string[];
}

interface SmartRoutingResult {
  route: Route;
  routeWithShipments: Segment[];
  totalPrice: number;
  totalDistance: number;
  totalDuration: number;
  estimatedDays: number;
  segments: number;
  transportModes: string[];
}

export default function SmartRoutingPage() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Parse search params manually
  const getParamValue = (paramName: string): string | null => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get(paramName);
    }
    return null;
  };
  
  const [fromLocationId, setFromLocationId] = useState<string | null>(
    getParamValue("fromLocationId")
  );
  const [toLocationId, setToLocationId] = useState<string | null>(
    getParamValue("toLocationId")
  );
  
  // Set search params whenever location selections change
  useEffect(() => {
    const params = new URLSearchParams();
    if (fromLocationId) params.set("fromLocationId", fromLocationId);
    if (toLocationId) params.set("toLocationId", toLocationId);
    
    // Update URL without navigation
    const newUrl = `${window.location.pathname}?${params.toString()}`;
    window.history.pushState({}, '', newUrl);
  }, [fromLocationId, toLocationId]);
  
  // Query for smart routing results
  const { data: routingResults, isLoading, error, refetch } = useQuery<SmartRoutingResult>({
    queryKey: ["/api/smart-routing", fromLocationId, toLocationId],
    queryFn: async () => {
      if (!fromLocationId || !toLocationId) return null;
      const res = await fetch(
        `/api/smart-routing?fromLocationId=${fromLocationId}&toLocationId=${toLocationId}`
      );
      if (!res.ok) throw new Error("Failed to fetch routing data");
      return res.json();
    },
    enabled: !!(fromLocationId && toLocationId),
  });
  
  // Function to map transport type to a descriptive text in Persian
  const getTransportTypeText = (type: string) => {
    switch (type) {
      case "land": return "حمل و نقل جاده‌ای";
      case "rail": return "حمل و نقل ریلی";
      case "sea": return "حمل و نقل دریایی";
      case "air": return "حمل و نقل هوایی";
      case "mixed": return "حمل و نقل ترکیبی";
      default: return type;
    }
  };
  
  // Function to map transport type to an icon
  const getTransportIcon = (type: string) => {
    switch (type) {
      case "land": return <TruckIcon className="h-5 w-5" />;
      case "rail": return <TrainIcon className="h-5 w-5" />;
      case "sea": return <ShipIcon className="h-5 w-5" />;
      default: return <PackageIcon className="h-5 w-5" />;
    }
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fromLocationId || !toLocationId) {
      toast({
        title: "خطا",
        description: "لطفاً مبدأ و مقصد را انتخاب کنید",
        variant: "destructive",
      });
      return;
    }
    refetch();
  };
  
  // Format duration (minutes) to days and hours
  const formatDuration = (minutes: number) => {
    const days = Math.floor(minutes / (24 * 60));
    const hours = Math.floor((minutes % (24 * 60)) / 60);
    
    if (days > 0) {
      return `${days} روز و ${hours} ساعت`;
    }
    return `${hours} ساعت`;
  };
  
  // Format price with commas and toman suffix
  const formatPrice = (price: number | null) => {
    if (price === null) {
      return 'قیمت موجود نیست'; // "Price not available" in Persian
    }
    return new Intl.NumberFormat('fa-IR').format(Math.round(price / 10)) + ' تومان';
  };
  
  return (
    <div className="container mx-auto py-8 px-4 md:px-6 dirrtl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-primary mb-2">مسیریابی هوشمند</h1>
        <p className="text-gray-600">
          با استفاده از مسیریابی هوشمند بهترین مسیر و ترکیب انواع حمل و نقل را پیدا کنید
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Search Form */}
        <Card className="mb-6 lg:col-span-1">
          <CardHeader>
            <CardTitle>جستجوی مسیر</CardTitle>
            <CardDescription>
              مبدأ و مقصد را انتخاب کنید تا بهترین مسیر حمل و نقل را پیدا کنیم
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fromLocation">مبدأ</Label>
                <LocationsDropdown
                  selectedLocationId={fromLocationId ? parseInt(fromLocationId) : undefined}
                  onLocationSelect={(id: number | undefined) => setFromLocationId(id?.toString() || null)}
                  placeholder="انتخاب مبدأ"
                  countryFilter={null}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="toLocation">مقصد</Label>
                <LocationsDropdown
                  selectedLocationId={toLocationId ? parseInt(toLocationId) : undefined}
                  onLocationSelect={(id: number | undefined) => setToLocationId(id?.toString() || null)}
                  placeholder="انتخاب مقصد"
                  countryFilter={null}
                />
              </div>
              
              <Button type="submit" className="w-full mt-4" disabled={isLoading}>
                {isLoading ? "درحال پردازش..." : "جستجوی مسیر"}
              </Button>
            </form>
          </CardContent>
        </Card>
        
        {/* Results */}
        <div className="lg:col-span-2">
          {isLoading ? (
            <LoadingIndicator />
          ) : error ? (
            <Card className="bg-red-50">
              <CardHeader>
                <CardTitle className="text-red-600">خطا در دریافت اطلاعات</CardTitle>
              </CardHeader>
              <CardContent>
                <p>متأسفانه خطایی رخ داده است. لطفاً مجدداً تلاش کنید.</p>
              </CardContent>
            </Card>
          ) : routingResults ? (
            // Check if there are any valid segments with shipments (after filtering null prices)
            routingResults.routeWithShipments
              .filter(segment => segment.shipments && segment.shipments.some(shipment => shipment.price !== null))
              .length === 0 ? (
                <Card className="bg-yellow-50">
                  <CardHeader>
                    <CardTitle className="text-yellow-700">برای این مسیر هیچ حمل و نقلی با قیمت مشخص پیدا نشد</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>در حال حاضر برای مسیر انتخاب شده، هیچ سرویس حمل و نقلی با قیمت مشخص وجود ندارد. لطفاً مسیر دیگری را انتخاب کنید.</p>
                  </CardContent>
                </Card>
              ) : (
            <div className="space-y-6">
              {/* Summary Card */}
              <Card className="bg-primary/5">
                <CardHeader>
                  <CardTitle className="text-primary">خلاصه بهترین مسیر</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="flex items-center mb-2">
                        <MapPin className="h-5 w-5 mr-2 text-primary" />
                        <span className="text-sm font-medium">مسافت کل</span>
                      </div>
                      <p className="text-xl font-bold">{routingResults.totalDistance} کیلومتر</p>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="flex items-center mb-2">
                        <Clock className="h-5 w-5 mr-2 text-primary" />
                        <span className="text-sm font-medium">زمان تقریبی</span>
                      </div>
                      <p className="text-xl font-bold">{routingResults.estimatedDays} روز</p>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="flex items-center mb-2">
                        <DollarSign className="h-5 w-5 mr-2 text-primary" />
                        <span className="text-sm font-medium">هزینه تقریبی</span>
                      </div>
                      <p className="text-xl font-bold">{formatPrice(routingResults.totalPrice)}</p>
                    </div>
                    
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <div className="flex items-center mb-2">
                        <TruckIcon className="h-5 w-5 mr-2 text-primary" />
                        <span className="text-sm font-medium">روش حمل و نقل</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {routingResults.transportModes.map((mode, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {getTransportTypeText(mode)}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Segments */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold mb-4">جزئیات مسیر</h3>
                
                {/* Filter segments to only include those with at least one shipment that has a price */}
                {routingResults.routeWithShipments
                  .map(segment => {
                    // Filter out shipments with null prices
                    if (segment.shipments) {
                      segment.shipments = segment.shipments.filter(shipment => shipment.price !== null);
                    }
                    return segment;
                  })
                  // Only include segments that have at least one shipment left after filtering
                  .filter(segment => segment.shipments && segment.shipments.length > 0)
                  .map((segment, index) => (
                  <Card key={index} className="border-2 border-primary/10">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          {getTransportIcon(segment.transportType)}
                          <CardTitle className="text-lg mr-2">
                            {getTransportTypeText(segment.transportType)}
                          </CardTitle>
                        </div>
                        <Badge variant="outline" className="font-normal">
                          {segment.distance} کیلومتر
                        </Badge>
                      </div>
                      <CardDescription className="flex items-center mt-2 text-base font-medium">
                        <span>{segment.from}</span>
                        <ChevronRight className="mx-2 h-4 w-4" />
                        <span>{segment.to}</span>
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>مدت زمان تقریبی:</span>
                          <span className="font-medium">{formatDuration(segment.duration)}</span>
                        </div>
                        
                        {segment.shipments && segment.shipments.length > 0 && (
                          <div className="mt-4">
                            <h4 className="text-md font-medium mb-2">سرویس‌های موجود:</h4>
                            <div className="space-y-3">
                              {segment.shipments.map((shipment, shipIndex) => (
                                <div 
                                  key={shipIndex} 
                                  className={`p-3 rounded-lg ${shipment.suggested ? 'bg-primary/5 border border-primary/20' : 'bg-gray-50'}`}
                                >
                                  <div className="flex justify-between items-center mb-2">
                                    <div className="font-medium">
                                      {shipment.transporterName}
                                      {shipment.suggested && (
                                        <Badge variant="outline" className="mr-2 bg-primary/10">
                                          پیشنهادی
                                        </Badge>
                                      )}
                                    </div>
                                    <div className="font-bold text-primary">
                                      {formatPrice(shipment.price)}
                                    </div>
                                  </div>
                                  
                                  <div className="text-sm text-gray-600">
                                    <div className="flex justify-between">
                                      <span>تاریخ حرکت:</span>
                                      <span>{new Date(shipment.departureDate).toLocaleDateString('fa-IR')}</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span>تاریخ رسیدن:</span>
                                      <span>{new Date(shipment.arrivalDate).toLocaleDateString('fa-IR')}</span>
                                    </div>
                                    {shipment.containerType && (
                                      <div className="flex justify-between">
                                        <span>نوع کانتینر:</span>
                                        <span>{shipment.containerType}</span>
                                      </div>
                                    )}
                                  </div>
                                  
                                  <div className="mt-3">
                                    <Button variant="outline" size="sm" className="w-full">
                                      انتخاب این سرویس
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : fromLocationId && toLocationId ? (
            <Card className="bg-yellow-50">
              <CardHeader>
                <CardTitle className="text-yellow-700">اطلاعاتی یافت نشد</CardTitle>
              </CardHeader>
              <CardContent>
                <p>برای مسیر انتخاب شده، اطلاعاتی یافت نشد. لطفاً مسیر دیگری را امتحان کنید.</p>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-blue-50">
              <CardHeader>
                <CardTitle className="text-blue-700">مسیریابی هوشمند</CardTitle>
              </CardHeader>
              <CardContent>
                <p>لطفاً مبدأ و مقصد را انتخاب کنید تا بهترین مسیر و ترکیب انواع حمل و نقل را پیدا کنیم.</p>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center">
                    <Badge className="bg-primary/20 text-primary border-none">ویژگی‌های مسیریابی هوشمند</Badge>
                  </div>
                  <ul className="mr-6 space-y-1 text-sm">
                    <li>ترکیب انواع مختلف حمل و نقل (زمینی، ریلی، دریایی)</li>
                    <li>محاسبه بهینه‌ترین و کم‌هزینه‌ترین مسیر</li>
                    <li>برآورد زمان حمل محموله</li>
                    <li>پیشنهاد سرویس‌های موجود برای هر بخش مسیر</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}